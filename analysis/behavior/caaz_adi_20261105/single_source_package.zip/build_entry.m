% One fresh-worker graph stage, selected by SAR20_PKU_BUILD_PHASE.
% Root stages and hash-checks INTEGRATION_MANIFEST before starting this worker.
job='D:/Temp/SAR20PKU_SINGLE_20261105';phase=getenv('SAR20_PKU_BUILD_PHASE');
expected=lower(getenv('SAR20_PKU_INTEGRATION_SHA'));previous=lower(getenv('SAR20_PKU_PREVIOUS_RECEIPT_SHA'));
assert(any(strcmp(phase,{'probe','demod'})),'sar20Pku:phase','Use probe or demod.');
assert(~isempty(regexp(expected,'^[0-9a-f]{64}$','once')),'sar20Pku:manifest','Need integration manifest SHA.');
mf=fullfile(job,'INTEGRATION_MANIFEST.json');assert(strcmp(file_sha(mf),expected),'sar20Pku:manifest','Integration manifest differs.');
m=jsondecode(fileread(mf));assert(strcmp(m.schema,'sar20-pku-integration/v1'),'sar20Pku:manifest','Wrong schema.');
for k=1:numel(m.items)
    if iscell(m.items),e=m.items{k};else,e=m.items(k);end
    f=fullfile(job,strrep(char(e.path),'/',filesep));assert(strcmp(file_sha(f),char(e.sha256)), ...
        'sar20Pku:source','Staged file differs: %s',char(e.path));
end
pinsFile=fullfile(job,'TOOLKIT_PINS.json');assert(strcmp(file_sha(pinsFile),m.toolkit_pins_sha256),'sar20Pku:toolkit','Pins file differs.');
pins=jsondecode(fileread(pinsFile));if iscell(pins),pins=[pins{:}];end
restoredefaultpath;rehash;project=fullfile(job,'candidate');cd(job);addpath(fullfile(project,'tests'),'-begin');
if strcmp(phase,'probe')
    assert(strcmp(file_sha(fullfile(project,'current','models','SarAdc.slx')),m.baseline_model_sha256), ...
        'sar20Pku:inputGraph','Private initial graph is not the 9197 baseline.');
    sar20_probe_entry(job,m.baseline_model_sha256,pins);
else
    receipt=fullfile(job,'probe_receipt.json');assert(~isempty(regexp(previous,'^[0-9a-f]{64}$','once'))&& ...
        strcmp(file_sha(receipt),previous),'sar20Pku:probeReceipt','Need exact preceding probe receipt.');
    prior=jsondecode(fileread(receipt));assert(strcmp(prior.status,'SAVED_PENDING_XML_DIFF')&& ...
        strcmp(prior.input_model_sha256,m.baseline_model_sha256)&&prior.owned_model_closed&&prior.filegen_restored, ...
        'sar20Pku:probeReceipt','Preceding probe did not save/close correctly.');
    sar20_demod_entry(job,prior.model_sha256,pins);
end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300000000,'sar20Pku:size','Missing or oversized: %s',file);
    f=fopen(file,'rb');assert(f>=0,'sar20Pku:read','Cannot read: %s',file);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));
    h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
