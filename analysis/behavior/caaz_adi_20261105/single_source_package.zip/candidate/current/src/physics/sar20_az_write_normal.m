function [z,digest_hex]=sar20_az_write_normal(seed,epoch,writeId,kind,lane)
%SAR20_AZ_WRITE_NORMAL Stateless SHA/Box-Muller normal for one AZ write lane.
% Distinct domain from RA OU and comparator. Deterministic same key; no global
% RNG, persistent state or I/O. Independence is a modeling assumption.
    assert(isa(seed,'uint64')&&isscalar(seed),'sar20AZ:seed','Need one uint64 seed.');
    values={epoch,writeId,kind,lane};
    for k=1:numel(values)
        v=values{k};assert(isa(v,'double')&&isreal(v)&&isscalar(v)&&isfinite(v)&& ...
            v>=0&&v<flintmax&&v==floor(v),'sar20AZ:key','Keys must be exact nonnegative integers.');
    end
    assert(any(kind==[1 2])&&any(lane==[1 2]),'sar20AZ:key','Invalid write domain or half lane.');
    payload=[uint8('SAR20-AZ-WRITE-v1'),uint8(0),word(seed),word(uint64(epoch)), ...
        word(uint64(writeId)),word(uint64(kind)),word(uint64(lane))];
    assert(usejava('jvm'),'sar20AZ:jvm','AZ keyed noise requires a MATLAB JVM.');
    md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(payload(:),'int8'));
    digest=typecast(md.digest(),'uint8');assert(numel(digest)==32,'sar20AZ:digest','Expected SHA-256.');
    a=readword(digest(1:8));b=readword(digest(9:16));scale=4503599627370496;
    u1=(double(bitshift(a,-12))+0.5)/scale;u2=(double(bitshift(b,-12))+0.5)/scale;
    assert(u1>0&&u1<1&&u2>0&&u2<1,'sar20AZ:uniform','Uniforms must lie strictly inside (0,1).');
    z=sqrt(-2*log(u1))*cos(2*pi*u2);
    assert(isfinite(z),'sar20AZ:normal','Nonfinite AZ innovation.');
    if nargout>1,digest_hex=lower(reshape(dec2hex(digest(:),2).',1,[]));end
end
function b=word(v)
    b=zeros(1,8,'uint8');
    for j=1:8,b(j)=uint8(bitand(bitshift(v,-8*(8-j)),uint64(255)));end
end
function v=readword(b)
    v=uint64(0);
    for j=1:8,v=bitor(bitshift(v,8),uint64(b(j)));end
end
