function [delta,applied,sigma]=behavior_az_write_innovation(p,epoch,sampleId,elapsed)
%BEHAVIOR_AZ_WRITE_INNOVATION One two-half input-referred terminal write draw.
% Called only at the actual AZ write-on to write-off edge. The finite-write
% deterministic evolution is already complete; never apply that decay again.
% No draw if both terminal sigmas are zero. Seed/epoch/write ID determine it.
    behavior_az_noise_validate_backend(p);
    assert(p.ni.az_noise&&isa(epoch,'double')&&isreal(epoch)&&isscalar(epoch)&& ...
        isfinite(epoch)&&epoch>=0&&epoch<flintmax&&epoch==floor(epoch)&& ...
        isa(sampleId,'double')&&isreal(sampleId)&&isscalar(sampleId)&& ...
        isfinite(sampleId)&&sampleId>=0&&sampleId<flintmax&&sampleId==floor(sampleId)&& ...
        isa(elapsed,'double')&&isreal(elapsed)&&isscalar(elapsed)&&isfinite(elapsed)&&elapsed>0, ...
        'sar20AZ:edge','A valid write ID/epoch and positive elapsed window are required.');
    n=p.az.noise;
    if strcmp(n.model,'terminal_input_sigma')
        sigma=n.sigma_input_half_rms_v;
    else
        % Engineering assumption only: two capacitively stored thermal-noise
        % halves with a first-order write response and explicit input gain.
        kB=1.380649e-23;
        sigma=sqrt(kB*n.temperature_K./n.cap_storage_half_f).* ...
            sqrt(-expm1(-2*elapsed./p.az.write_tau_s))./n.gain_storage_per_input;
    end
    assert(all(isfinite(sigma))&&all(sigma>=0),'sar20AZ:scale','AZ input noise scale is invalid.');
    delta=zeros(2,1);applied=any(sigma>0);
    if ~applied,return;end % signed-zero-safe: caller must not add this vector
    paired=strcmp(p.az.mode,'pku_input_hold_chop_v1');
    if paired
        assert(mod(sampleId,2)==0,'sar20AZ:pairWrite','Only even service starts a pair write.');
        kind=2;writeId=floor(sampleId/2);
    else
        kind=1;writeId=sampleId;
    end
    z1=sar20_az_write_normal(n.seed_u64,epoch,double(writeId),double(kind),1);
    z2=sar20_az_write_normal(n.seed_u64,epoch,double(writeId),double(kind),2);
    delta=[sigma(1)*z1;sigma(2)*(n.corr_pn*z1+sqrt(max(0,1-n.corr_pn^2))*z2)];
    assert(all(isfinite(delta)),'sar20AZ:finite','AZ innovation must be finite.');
end
