function out=behavior_input_chop_streams(voltage_v,target_id,epoch,valid,fs_hz,fsr_diff_v)
%BEHAVIOR_INPUT_CHOP_STREAMS Optional digital views of actual de-chopped volts.
% Inputs are vectors of signed input-referred volts AFTER input demodulation
% and BEFORE unsigned rounding/clipping, with RAW target ID/epoch/valid tags.
% fs_hz is the nominal raw sampling rate; fsr_diff_v is differential FSR [V].
% raw: every supplied record at nominal fs_hz, code20 after one quantization.
% pair: average ONLY adjacent even/odd consecutive IDs in the same epoch when
% both are valid; nominal fs_hz/2, available after the odd record. Missing or
% invalid records never bridge a pair. Pair centre is ID_even+0.5, not a claim
% about the physical converter timestamp.
% fir: y[n]=(x[n]+x[n-1])/2 at nominal fs_hz; valid only for adjacent valid,
% consecutive IDs in one epoch. Its first/discontinuous sample is NaN/invalid.
% FIR group delay is 0.5 raw samples; |H(f)|^2=cos^2(pi*f/fs_hz). Noise
% improvement is bandwidth/spectrum dependent, not a fixed full-band number.
% Pair/FIR quantization happens AFTER averaging, never on clipped raw codes.
    values={voltage_v,target_id,epoch,valid};
    for k=1:numel(values)
        x=values{k};assert((isnumeric(x)||islogical(x))&&isreal(x)&&isvector(x)&&~isempty(x), ...
            'inputChopStreams:vector','Inputs must be nonempty real numeric vectors.');
    end
    n=numel(voltage_v);assert(all(cellfun(@numel,values)==n), ...
        'inputChopStreams:length','Voltage and tag vectors must have equal lengths.');
    v=double(voltage_v(:));id=double(target_id(:));ep=double(epoch(:));vv=double(valid(:));
    assert(all(isfinite(id)&id>=0&id<=2^32-1&id==floor(id))&& ...
        all(isfinite(ep)&ep>=0&ep<=2^32-1&ep==floor(ep))&& ...
        all(isfinite(vv)&(vv==0|vv==1)),'inputChopStreams:tags','Tags/valid must be public binary or uint32 values.');
    good=logical(vv);assert(all(isfinite(v(good))),'inputChopStreams:voltage','Valid samples must be finite.');
    assert(size(unique([ep id],'rows'),1)==n,'inputChopStreams:duplicate', ...
        'Duplicate epoch/target ID records are ambiguous.');
    assert(isnumeric(fs_hz)&&isreal(fs_hz)&&isscalar(fs_hz)&&isfinite(fs_hz)&&fs_hz>0&& ...
        isnumeric(fsr_diff_v)&&isreal(fsr_diff_v)&&isscalar(fsr_diff_v)&&isfinite(fsr_diff_v)&&fsr_diff_v>0, ...
        'inputChopStreams:scale','fs_hz and fsr_diff_v must be finite positive scalars.');
    adjacent=(id(2:end)==id(1:end-1)+1)&(ep(2:end)==ep(1:end-1))& ...
        good(2:end)&good(1:end-1);
    left=find(adjacent & mod(id(1:end-1),2)==0);right=left+1;
    pairV=0.5*(v(left)+v(right));
    firValid=[false;adjacent];firV=NaN(n,1);
    idx=find(firValid);firV(idx)=0.5*(v(idx-1)+v(idx));
    out=struct();
    out.raw=struct('nominal_sample_rate_hz',double(fs_hz),'target_id',id,'epoch',ep, ...
        'valid',good,'voltage_v',v,'code20',quantize(v,good,fsr_diff_v));
    out.pair=struct('nominal_sample_rate_hz',double(fs_hz)/2, ...
        'epoch',ep(left),'pair_id',floor(id(left)/2),'first_id',id(left), ...
        'available_id',id(right),'centre_id',id(left)+0.5, ...
        'voltage_v',pairV,'code20',quantize(pairV,true(size(pairV)),fsr_diff_v));
    out.fir=struct('nominal_sample_rate_hz',double(fs_hz),'target_id',id,'epoch',ep, ...
        'valid',firValid,'voltage_v',firV,'code20',quantize(firV,firValid,fsr_diff_v), ...
        'group_delay_raw_samples',0.5);
end
function code=quantize(v,valid,fsr)
    code=NaN(size(v));
    if any(valid)
        q=round(v(valid)*(2^20/double(fsr))+2^19);
        code(valid)=max(0,min(2^20-1,q));
    end
end
