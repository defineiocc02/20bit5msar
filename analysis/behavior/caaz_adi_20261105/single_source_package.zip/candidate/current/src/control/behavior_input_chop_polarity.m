function [polarity,pairId,tag]=behavior_input_chop_polarity(targetId,epoch,mode)
%BEHAVIOR_INPUT_CHOP_POLARITY Input sampling coordinate for one target ID.
% Modes: off (always +1); pku_input_hold_chop_v1 (even +1, odd -1).
% targetId/epoch are actual acquisition tags, not the currently active RA ID.
% epoch is part of the returned identity; it never changes the sign sequence.
% pairId=floor(targetId/2); pairing always also requires the SAME epoch.
% This input polarity must not be multiplied into Qres or release Vtop again.
% No state, RNG, source waveform, analog charge or timing is changed.
    for value={targetId,epoch}
        v=value{1};
        assert((isnumeric(v)||islogical(v))&&isreal(v)&&isscalar(v)&& ...
            isfinite(double(v))&&double(v)>=0&&double(v)<=2^32-1&& ...
            double(v)==floor(double(v)), ...
            'inputChop:tag','Target ID and epoch must be unsigned32-valued scalars.');
    end
    assert((ischar(mode)&&isrow(mode))||(isstring(mode)&&isscalar(mode)), ...
        'inputChop:mode','Mode must be a scalar text label.');
    mode=char(mode);
    assert(any(strcmp(mode,{'off','pku_input_hold_chop_v1'})), ...
        'inputChop:mode','Use off or pku_input_hold_chop_v1.');
    targetId=double(targetId);epoch=double(epoch);
    polarity=1;
    if strcmp(mode,'pku_input_hold_chop_v1')&&mod(targetId,2)==1
        polarity=-1;
    end
    pairId=floor(targetId/2);
    if nargout>2
        tag=struct('schema','sar20-pku-input-chop/v1','target_id',targetId, ...
            'epoch',epoch,'pair_id',pairId,'input_polarity',polarity);
    end
end
