function behavior_input_chop_demod_sfun(b)
%BEHAVIOR_INPUT_CHOP_DEMOD_SFUN Stateless signed-voltage input de-chopper.
% Dialog DecodeP; inputs signed_sum_v [V], RAW target ID, RAW epoch; output
% signed de-chopped voltage [V]. All are scalar double, direct feedthrough.
% Place AFTER PlusDither and BEFORE Counts/unsigned midpoint/round/saturate.
% This block does not determine validity or create hits, state or RNG.
    b.NumDialogPrms=1;b.DialogPrmsTunable={'Nontunable'};
    b.NumInputPorts=3;b.NumOutputPorts=1;b.SetPreCompPortInfoToDefaults;
    for k=1:3
        b.InputPort(k).Dimensions=1;b.InputPort(k).DatatypeID=0;
        b.InputPort(k).Complexity='Real';b.InputPort(k).DirectFeedthrough=true;
    end
    b.OutputPort(1).Dimensions=1;b.OutputPort(1).DatatypeID=0;b.OutputPort(1).Complexity='Real';
    b.SampleTimes=[-1 0];b.NumContStates=0;b.SimStateCompliance='DefaultSimState';
    b.RegBlockMethod('Outputs',@outputs);
end
function outputs(b)
    p=b.DialogPrm(1).Data;
    assert(isstruct(p)&&isscalar(p)&&isfield(p,'az_mode'), ...
        'inputChopDemod:config','DecodeP must carry the actual applied mode.');
    ditherEnabled=[];if isfield(p,'dither_enabled'),ditherEnabled=p.dither_enabled;end
    b.OutputPort(1).Data=behavior_input_chop_demod(b.InputPort(1).Data, ...
        b.InputPort(2).Data,b.InputPort(3).Data,p.az_mode,ditherEnabled);
end
