function [voltage_v,polarity]=behavior_input_chop_demod(signed_sum_v,target_id,epoch,mode,dither_enabled)
%BEHAVIOR_INPUT_CHOP_DEMOD Input-referred voltage before unsigned quantization.
% signed_sum_v [V] is the chopped-coordinate D1+D2/G+DT/G+dither sum.
% target_id/epoch are the RAW record tags, not the current conversion/event ID.
% pku_input_hold_chop_v1: even ID +1, odd ID -1; epoch does not shift phase.
% Legacy modes pass voltage through bit-for-bit; residue chop remains separate.
% The dither addback, when explicitly used, is in the chopped coordinate and
% would be included in signed_sum_v before this call. The present input-chop
% profile requires explicit dither_enabled=false; ON is not qualified.
% No clipping, rounding or state.
    assert(isnumeric(signed_sum_v)&&isreal(signed_sum_v)&&isscalar(signed_sum_v), ...
        'inputChopDemod:voltage','Expected one real numeric signed voltage.');
    % This preserves the original tag/mode validation for every legacy mode.
    behavior_public_pol(target_id,epoch,mode);
    polarity=1;voltage_v=signed_sum_v;
    if strcmp(char(mode),'pku_input_hold_chop_v1')
        assert(nargin>=5&&(isnumeric(dither_enabled)||islogical(dither_enabled))&& ...
            isreal(dither_enabled)&&isscalar(dither_enabled)&&isfinite(double(dither_enabled))&& ...
            double(dither_enabled)==0,'inputChopDemod:ditherUnsupported', ...
            'Input chop currently requires explicit digital dither OFF.');
        polarity=behavior_input_chop_polarity(target_id,epoch,char(mode));
        if polarity<0,voltage_v=-signed_sum_v;end
    end
end
