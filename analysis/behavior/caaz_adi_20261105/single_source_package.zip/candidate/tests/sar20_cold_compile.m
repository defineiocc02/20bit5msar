function result=sar20_cold_compile(jobRoot,modelSha)
% Compile/update the saved private graph in a new process; never runs ADC.
    assert(ispc&&feature('getpid')~=27628&&~usejava('desktop')&&~bdIsLoaded('SarAdc'), ...
        'sar20Pku:compileSession','Fresh private headless process required.');
    jobRoot=canon(jobRoot);assert(~isempty(regexp(jobRoot,'(?i)^D:/Temp/SAR20[A-Za-z0-9_]+$','once')), ...
        'sar20Pku:compileJob','Use a private D:/Temp/SAR20* job.');
    project=fullfile(jobRoot,'candidate');model=fullfile(project,'current','models','SarAdc.slx');
    assert(strcmp(file_sha(model),modelSha),'sar20Pku:compileModel','Graph SHA differs.');
    oldPath=path;oldCwd=pwd;restore=onCleanup(@()restore_env(oldPath,oldCwd)); %#ok<NASGU>
    addpath(genpath(fullfile(project,'current','src')),fullfile(project,'config'),project,'-begin');rehash;
    cd(project);load_system(model);closer=onCleanup(@()close_private(model)); %#ok<NASGU>
    assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(model)),'sar20Pku:compileOwner','Not private model.');
    set_param('SarAdc','SimulationCommand','update');
    assert(strcmp(file_sha(model),modelSha),'sar20Pku:compileDrift','Saved graph changed.');
    result=struct('status','COMPILE_PASS','pid',feature('getpid'),'model_sha256',modelSha, ...
        'simulation_run',false,'scope','private saved baseline P graph update only');
end
function close_private(m),if bdIsLoaded('SarAdc')&&strcmpi(canon(get_param('SarAdc','FileName')),canon(m))&&strcmp(get_param('SarAdc','Dirty'),'off'),close_system('SarAdc',0);end,end
function restore_env(p,c),path(p);cd(c);end
function p=canon(p),p=strrep(char(java.io.File(char(p)).getCanonicalPath()),'\','/');end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300000000,'sar20Pku:size','Missing or oversized: %s',file);
    f=fopen(file,'rb');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
