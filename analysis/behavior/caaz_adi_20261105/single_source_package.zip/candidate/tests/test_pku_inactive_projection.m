function report=test_pku_inactive_projection(base)
% Function-only qualification using the actual prepared N8 P. No model is loaded.
    assert(~bdIsLoaded('SarAdc')&&isstruct(base)&&isscalar(base), ...
        'sar20Pku:projectionTest','Require the saved N8 P and no loaded graph.');
    before=rng;legacy=behavior_training_configuration(base);
    assert(sb256_same_bits(legacy,base)&&isequaln(before,rng), ...
        'sar20Pku:legacyProjection','Existing ordinary P changed.');
    mode='pku_input_hold_chop_v1';q=base;
    q.front.input_chop_mode=mode;q.backend.az.mode=mode;q.digital.az_mode=mode;
    ready=behavior_training_configuration(q);
    assert(~ready.training.enabled&&~ready.cal_cfg.enabled&&~ready.frozen.enabled&&~ready.bank.enabled&& ...
        strcmp(ready.cal_cfg.public_cfg.az_mode,mode)&& ...
        strcmp(ready.cal_cfg.public_cfg.pool_schedule,'inactive_single_bank_uncalibrated'), ...
        'sar20Pku:projection','New mode metadata is not inactive and explicitly labeled.');
    bad=base;bad.front.input_chop_mode=mode;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=base;bad.backend.az.mode=mode;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=base;bad.digital.az_mode=mode;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.front.input_chop_mode='off';expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.backend.az.mode='ordinary';expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.training.enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.training.reference.enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.cal_cfg.enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.frozen.enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.bank.enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.digital.calibration_mode='trained';expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.front.dither_enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    bad=q;bad.digital.dither_enabled=true;expect(@()behavior_training_configuration(bad),'calConfig:pkuInactive');
    % Even if a caller forges the legacy pool label, its old feature basis
    % must still reject the new mode; no true analog data is supplied here.
    cfg=ready.cal_cfg.public_cfg;cfg.pool_schedule='causal_18_8_8_2_pm_v1';
    raw=struct('raw_D1',0,'raw_D2',0,'raw_DT',0,'sample_id',0,'epoch',base.epoch,'valid',1);
    expect(@()behavior_public_cal_features(raw,cfg),'publicCal:azMode');
    assert(isequaln(before,rng),'sar20Pku:projectionRng','Projection changed global RNG.');
    report=struct('status','passed','legacy_P_bits_equal',true,'inactive_new_mode',true, ...
        'negative_cases',14,'legacy_pool_feature_rejected',true,'model_loaded',false, ...
        'scope','function-only inactive metadata; does not validate CAAZ/ADI graph');
end
function expect(fn,id)
    try,fn();catch e,assert(strcmp(e.identifier,id),'sar20Pku:wrongError', ...
            'Expected %s, received %s: %s',id,e.identifier,e.message);return;end
    error('sar20Pku:missingError','Expected %s.',id);
end
