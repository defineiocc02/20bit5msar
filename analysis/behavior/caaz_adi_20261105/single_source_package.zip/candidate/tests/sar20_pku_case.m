function result=sar20_pku_case(jobRoot,profile,manifestSha)
% One genuine isolated main-SLX N8. Root controls staging and Windows process.
% CASE_MANIFEST.json is generated only AFTER integration + graph/audit, and
% pins every source, final graph, actual baseline P/simout and graph receipt.
% This scope qualifies CICC/CAAZ only; ADI/combined remain hard rejected.
    assert(ispc&&feature('getpid')~=27628&&~usejava('desktop')&&~bdIsLoaded('SarAdc'), ...
        'sar20Pku:caseSession','A new headless worker with no loaded model is required.');
    jobRoot=canon(jobRoot);
    assert(~isempty(regexp(jobRoot,'(?i)^D:/Temp/SAR20[A-Za-z0-9_]+$','once')), ...
        'sar20Pku:job','Use a fresh D:/Temp/SAR20* private job.');
    assert(ischar(profile)&&any(strcmp(profile,{'cicc','caaz'})), ...
        'sar20Pku:profile','Only CICC and CAAZ are currently qualified for an N8 attempt.');
    assert(ischar(manifestSha)&&~isempty(regexp(manifestSha,'^[0-9a-f]{64}$','once')), ...
        'sar20Pku:manifest','A complete external manifest SHA is required.');
    mf=fullfile(jobRoot,'CASE_MANIFEST.json');assert(strcmp(file_sha(mf),manifestSha), ...
        'sar20Pku:manifest','Case manifest identity differs.');
    manifest=jsondecode(fileread(mf));assert(strcmp(manifest.schema,'sar20-pku-case/v1'), ...
        'sar20Pku:manifest','Wrong case manifest schema.');
    project=fullfile(jobRoot,'candidate');model=fullfile(project,'current','models','SarAdc.slx');
    referenceP=fullfile(jobRoot,'reference','P_used.mat');referenceOut=fullfile(jobRoot,'reference','simout.mat');
    graphReceipt=fullfile(jobRoot,'graph_receipt.json');referenceReceipt=fullfile(jobRoot,'reference','complete.json');
    for x={manifest.model_sha256,manifest.reference_P_sha256,manifest.reference_simout_sha256,manifest.graph_receipt_sha256,manifest.reference_receipt_sha256}
        assert(ischar(x{1})&&~isempty(regexp(x{1},'^[0-9a-f]{64}$','once')), ...
            'sar20Pku:manifest','Malformed manifest SHA.');
    end
    assert(strcmp(file_sha(model),manifest.model_sha256)&&strcmp(file_sha(referenceP),manifest.reference_P_sha256)&& ...
        strcmp(file_sha(referenceOut),manifest.reference_simout_sha256)&& ...
        strcmp(file_sha(graphReceipt),manifest.graph_receipt_sha256)&& ...
        strcmp(file_sha(referenceReceipt),manifest.reference_receipt_sha256),'sar20Pku:inputs','Input bytes differ.');
    rr=jsondecode(fileread(referenceReceipt));assert(strcmp(rr.status,'passed')&& ...
        strcmp(rr.P_used_sha256,manifest.reference_P_sha256)&&strcmp(rr.simout_sha256,manifest.reference_simout_sha256), ...
        'sar20Pku:reference','Reference P/simout do not belong to the same passed N8.');
    gr=jsondecode(fileread(graphReceipt));assert(strcmp(gr.status,'GRAPH_AUDITED')&& ...
        strcmp(gr.model_sha256,manifest.model_sha256),'sar20Pku:graph','Actual saved graph is not bound to an audit.');
    entries=manifest.source_files;if iscell(entries),entries=[entries{:}];end
    assert(isstruct(entries)&&~isempty(entries),'sar20Pku:source','Source manifest is empty.');
    verify_sources(project,entries);
    out=fullfile(jobRoot,'results',profile);assert(~isfolder(out)&&~isfile(out),'sar20Pku:exists','Case already exists.');
    [ok,msg,id]=mkdir(out);assert(ok&&isempty(id),'sar20Pku:mkdir','%s',msg);
    result=struct('status','started','profile',profile,'pid',feature('getpid'),'manifest_sha256',manifestSha, ...
        'model_sha256',manifest.model_sha256,'input_P_sha256',manifest.reference_P_sha256, ...
        'scope','private same-SLX 5MS/s N8; no production or full qualification claim');
    oldPath=path;oldCwd=pwd;oldFilegen=Simulink.fileGenControl('getConfig');opened=false;
    try
        restoredefaultpath;rehash;cd(project);addpath(fullfile(project,'tests'),'-begin');
        bound=normal_bind_runtime(project,entries,true);save(fullfile(out,'binding_before.mat'),'bound','-v7.3');
        baseData=load(referenceP,'P');base=baseData.P;before=rng;
        [P,meta]=sar20_qualification_profile(base,profile);
        assert(isequaln(before,rng),'sar20Pku:rng','Profile construction changed global RNG.');
        if strcmp(profile,'cicc')
            assert(sb256_same_bits(P,base),'sar20Pku:baseP','CICC must retain the complete old P bits.');
        end
        assert(P.N==8&&P.Ts_s==200e-9&&P.front.single_bank&& ...
            ~P.front.dither_enabled&&~P.digital.dither_enabled,'sar20Pku:caseScope', ...
            'Require the actual 5MS/s single-bank N8 with dither OFF.');
        save(fullfile(out,'P_used.mat'),'P','meta','-v7.3');write_new(fullfile(out,'started.json'),result);
        Simulink.fileGenControl('set','CacheFolder',fullfile(out,'cache'),'CodeGenFolder',fullfile(out,'codegen'), ...
            'keepPreviousPath',true,'createDir',true);
        load_system(model);opened=true;
        assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(model)),'sar20Pku:owner','Model is not private.');
        ws=get_param('SarAdc','ModelWorkspace');savedP=getVariable(ws,'P');savedD=getVariable(ws,'DecodeP');savedT=getVariable(ws,'TrainCaptureFile');
        assert(ischar(savedT)&&isempty(savedT),'sar20Pku:train','Saved training capture must be empty.');
        si=Simulink.SimulationInput('SarAdc');si=si.setVariable('P',P,'Workspace','SarAdc');
        si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');si=si.setVariable('TrainCaptureFile','','Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        timer=tic;simout=sim(si);result.sim_s=toc(timer);save(fullfile(out,'simout.mat'),'simout','-v7.3');
        assert(isempty(simout.ErrorMessage)&&isequaln(before,rng),'sar20Pku:sim','Simulation/RNG failed: %s',simout.ErrorMessage);
        assert(sb256_same_bits(getVariable(ws,'P'),savedP)&&sb256_same_bits(getVariable(ws,'DecodeP'),savedD)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),savedT),'sar20Pku:workspace','Saved workspace changed.');
        view=behavior_record_view(simout,P);assert(size(view.raw,1)==8&& ...
            isequal(view.raw(:,4),(P.first_id:P.first_id+7).')&&all(view.raw(:,5)==P.epoch)&& ...
            all(view.raw(:,6)==1),'sar20Pku:records','Need eight ordered actual valid RAW records.');
        rows=sar20_pku_signed_reference(view.raw,view.code20,P.digital,meta.input_chop);
        az=sar20_pku_az_check(simout,P);inputTrace=sar20_pku_input_trace(simout,P,meta.input_chop);
        writetable(rows,fullfile(out,'raw_signed_code.csv'));writetable(inputTrace,fullfile(out,'input_actual_held.csv'));
        writetable(az.az_at_ra_start,fullfile(out,'az_actual_state.csv'));
        save(fullfile(out,'checks.mat'),'rows','az','inputTrace','view','meta','-v7.3');
        if strcmp(profile,'cicc')
            prior=load(referenceOut,'simout');comparison=sar20_pku_compare_base(prior.simout,simout);
            assert(strcmp(comparison.status,'PASS'),'sar20Pku:baseline','Prior normal N8 outputs changed.');
            save(fullfile(out,'baseline_comparison.mat'),'comparison','-v7.3');result.baseline_all_original_logs_and_3roots='PASS';
        else
            result.input_pol_sequence=rows.input_pol.';result.baseline_all_original_logs_and_3roots='NOT_APPLICABLE';
        end
        verify_sources(project,entries);boundAfter=normal_bind_runtime(project,entries,false);
        save(fullfile(out,'binding_after.mat'),'boundAfter','-v7.3');
        assert(strcmp(file_sha(model),manifest.model_sha256),'sar20Pku:modelDrift','Saved graph changed during simulation.');
        result.status='N8_RAW_SIGNED_AZ_PASS';result.simout_sha256=file_sha(fullfile(out,'simout.mat'));
        result.P_used_sha256=file_sha(fullfile(out,'P_used.mat'));result.checks_sha256=file_sha(fullfile(out,'checks.mat'));
        result.rows=height(rows);result.RA_next_old_bit_pairs=az.adjacent_pairs;
        result.input_trace_scope='actual FE held; nominal p*source is derived diagnostic, residual includes RC/history/noise';
        result.scope='single-bank same-SLX 5MS/s N8: actual RAW, nominal signed code, RA old/next and AZ pair; not noise benefit, ADI or signoff';
        write_new(fullfile(out,'complete.json'),result);
    catch e
        try,write_new(fullfile(out,'failed.json'),struct('status','failed','id',e.identifier, ...
            'error',getReport(e,'extended','hyperlinks','off'),'simout_saved',isfile(fullfile(out,'simout.mat'))));catch,end
        rethrow(e)
    end
    if opened&&bdIsLoaded('SarAdc')&&strcmpi(canon(get_param('SarAdc','FileName')),canon(model))&& ...
            strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off')
        close_system('SarAdc',0);
    end
    Simulink.fileGenControl('set','CacheFolder',char(oldFilegen.CacheFolder),'CodeGenFolder',char(oldFilegen.CodeGenFolder), ...
        'keepPreviousPath',true,'createDir',false);path(oldPath);cd(oldCwd);
end
function verify_sources(project,entries)
    for k=1:numel(entries)
        f=fullfile(project,strrep(char(entries(k).path),'/',filesep));
        assert(under(f,project)&&~isempty(regexp(char(entries(k).sha256),'^[0-9a-f]{64}$','once'))&& ...
            strcmp(file_sha(f),char(entries(k).sha256)),'sar20Pku:source','Source differs: %s',entries(k).path);
    end
end
function tf=under(p,r),a=lower(canon(p));b=lower(canon(r));tf=startsWith(a,[b '/']);end
function p=canon(p),p=strrep(char(java.io.File(char(p)).getCanonicalPath()),'\','/');end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300000000,'sar20Pku:size','Missing or oversized: %s',file);
    f=fopen(file,'rb');assert(f>=0,'sar20Pku:read','Cannot read: %s',file);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
function write_new(file,value)
    assert(~isfile(file)&&~isfolder(file),'sar20Pku:exists','Refuse existing result: %s',file);
    f=fopen(file,'w','n','UTF-8');assert(f>=0,'sar20Pku:write','Cannot write result.');c=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(value));
end
