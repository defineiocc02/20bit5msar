function report=sar20_pku_compare_base(original,observed)
% Compare every original output and 3 root ports; accept only the two RA taps.
    assert(isa(original,'Simulink.SimulationOutput')&&isa(observed,'Simulink.SimulationOutput')&& ...
        isempty(original.ErrorMessage)&&isempty(observed.ErrorMessage),'denseCompare:output','Need two completed outputs.');
    before=sort(original.who);after=sort(observed.who);
    probes={'pku_ra_old48','pku_ra_next48'};
    assert(~any(ismember(probes,before))&&all(ismember(probes,after))&& ...
        isequal(before,setdiff(after,probes)),'sar20Pku:inventory', ...
        'Only the two RA state probes may be added; every original output must remain.');
    required={'raw_log','ready_log','record_log','record_ready_log','front_log','back_log', ...
        'control_log','event_log','code_log','tout','yout'};
    assert(all(ismember(required,before)),'denseCompare:required','Original output missing.');
    for k=1:numel(before),same_value(original.get(before{k}),observed.get(before{k}),before{k});end
    y=original.get('yout');assert(isa(y,'Simulink.SimulationData.Dataset')&&y.numElements==3, ...
        'denseCompare:rootPorts','Expected three root outputs.');
    report=struct('status','PASS','compared_variables',{before},'only_added',{probes}, ...
        'root_outputs',3,'scope','bit equality of all original output data/time and three root ports');
end
function same_value(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'sbN8:type','Class or shape differs: %s.',where);
    if isa(a,'timeseries')
        assert(a.IsTimeFirst==b.IsTimeFirst,'sbN8:timeFirst','Time orientation differs: %s.',where);
        same_value(a.Time,b.Time,[where '.Time']);same_value(a.Data,b.Data,[where '.Data']);
    elseif isa(a,'Simulink.SimulationData.Dataset')
        assert(a.numElements==b.numElements,'sbN8:dataset','Dataset count differs: %s.',where);
        for j=1:a.numElements
            x=a.getElement(j);y=b.getElement(j);
            assert(strcmp(class(x),class(y))&&isprop(x,'Name')&&isprop(x,'Values')&& ...
                isequal(x.Name,y.Name),'sbN8:signal','Dataset signal differs: %s.',where);
            same_value(x.Values,y.Values,sprintf('%s[%d]',where,j));
        end
    elseif isnumeric(a)
        assert(isreal(a)==isreal(b),'sbN8:complex','Complexity differs: %s.',where);
        assert(isequal(typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')), ...
            'sbN8:bits','Real bits differ: %s.',where);
        if ~isreal(a)
            assert(isequal(typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')), ...
                'sbN8:bits','Imaginary bits differ: %s.',where);
        end
    elseif islogical(a)||ischar(a)||isstring(a)
        assert(isequaln(a,b),'sbN8:value','Value differs: %s.',where);
    else,error('sbN8:unhandled','Cannot skip output class %s at %s.',class(a),where);
    end
end
