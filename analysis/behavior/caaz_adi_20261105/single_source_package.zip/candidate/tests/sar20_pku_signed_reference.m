function rows=sar20_pku_signed_reference(raw,code20,digital,inputChop)
% Recompute input-signed code from actual RAW and *nominal digital* P only.
% Independent arithmetic check; integer-code agreement is not float bit equality.
    assert(islogical(inputChop)&&isscalar(inputChop)&&isnumeric(raw)&& ...
        isequal(size(raw,2),6)&&numel(code20)==size(raw,1), ...
        'sar20Pku:reference','Expected actual RAW6 rows and code20.');
    assert(digital.vref_v==5&&digital.fsr_diff_v==10&&digital.ra_gain==32&& ...
        digital.d1_bias_v==0&&~digital.dither_enabled&&strcmp(digital.calibration_mode,'off'), ...
        'sar20Pku:digital','Use the actual nominal FSR10 configuration with dither/calibration OFF.');
    assert(numel(digital.d2_weights_ra_v)==12,'sar20Pku:weights','Require nominal D2 weights.');
    n=size(raw,1);ids=raw(:,4);epochs=raw(:,5);valid=raw(:,6);
    D1=raw(:,1);D2=raw(:,2);DT=raw(:,3);pol=ones(n,1);predicted=zeros(n,1);voltage=zeros(n,1);
    for k=1:n
        w=raw(k,:);assert(all(isfinite(w))&&all(w==floor(w))&& ...
            w(1)>=0&&w(1)<=2047&&w(2)>=0&&w(2)<=4095&&w(3)>=0&&w(3)<=255&& ...
            w(4)>=0&&w(5)>=0&&any(w(6)==[0 1]),'sar20Pku:raw','Invalid RAW row.');
        c=floor(w(1)/32);d1units=2*w(1)-32*c;
        d2=double(bitget(uint32(w(2)),12:-1:1)).';dt=double(bitget(uint32(w(3)),8:-1:1)).';
        d1v=(d1units-1039)*(digital.vref_v/1024)+digital.d1_bias_v;
        d2v=(reshape(digital.d2_weights_ra_v,1,12)*d2+digital.d2_offset_ra_v)*(1/digital.ra_gain);
        dtv=(2*((8:-1:1)*dt)-36)*(digital.tracking_step_ra_v/(8*digital.ra_gain));
        v=((d1v+d2v)+dtv)+0;
        if inputChop,pol(k)=1-2*mod(w(4),2);if pol(k)<0,v=-v;end,end
        voltage(k)=v;predicted(k)=max(0,min(2^20-1,round(v*(2^20/digital.fsr_diff_v)+2^19)));
    end
    observed=double(code20(:));
    assert(isequal(predicted,observed),'sar20Pku:signedCode', ...
        'Actual code20 differs from the public RAW nominal signed reconstruction.');
    signedCode=observed-2^19;
    rows=table(ids,epochs,valid,D1,D2,DT,pol,voltage,observed,signedCode,predicted, ...
        'VariableNames',{'sample_id','epoch','valid','raw_D1','raw_D2','raw_DT', ...
        'input_pol','nominal_voltage_v','actual_code20','signed_code20','independent_code20'});
end
