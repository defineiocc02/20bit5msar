function T=sar20_pku_input_trace(out,P,inputChop)
% Actual FE held values at CNV vs nominal source with target-ID input sign.
% Difference includes finite tracking, previous charge and noise; not kTC.
    [te,event]=series(out,'event_log',2);[tf,front]=series(out,'front_log',7);
    assert(sb256_same_bits(te,tf),'sar20Pku:inputAxis','Event and FE logs are not time aligned.');
    g=find(arrayfun(@(x)any(strcmp({x.events.type},'cnv')),P.groups));
    assert(isscalar(g),'sar20Pku:inputCNV','Expected exactly one CNV group.');
    mask=event(:,2)==g;ids=event(mask,1);times=te(mask);held=front(mask,1);
    assert(numel(ids)==P.schedule.n_cycles&&isequal(ids,(0:P.schedule.n_cycles-1).'), ...
        'sar20Pku:inputIDs','Actual CNV IDs are not consecutive.');
    pol=ones(size(ids));if inputChop,pol=1-2*mod(ids,2);end
    source=P.input.offset_v+P.input.amplitude_v*sin(2*pi*P.input.frequency_hz*times+P.input.phase_rad);
    reference=pol.*source;selected=ids>=P.first_id&ids<P.first_id+P.N;
    assert(nnz(selected)==P.N&&all(held(selected).*reference(selected)>0), ...
        'sar20Pku:inputSign','Actual selected held values do not follow the target-ID input polarity.');
    T=table(ids,times,selected,pol,source,reference,held,held-reference, ...
        'VariableNames',{'sample_id','cnv_time_s','selected','input_pol','nominal_source_v', ...
        'nominal_chopped_source_v','actual_FE_held_v','held_minus_nominal_v'});
end
function [t,x]=series(out,name,width)
    names=out.who;if isstring(names),names=cellstr(names);end
    assert(any(strcmp(names,name)),'sar20Pku:inputLog','Missing %s.',name);
    s=out.get(name);assert(isa(s,'timeseries'),'sar20Pku:inputLog','Expected timeseries %s.',name);
    t=s.Time(:);if s.IsTimeFirst,x=reshape(s.Data,numel(t),[]);else,x=reshape(permute(s.Data,[ndims(s.Data) 1:ndims(s.Data)-1]),numel(t),[]);end
    assert(isequal(size(x),[numel(t) width]),'sar20Pku:inputWidth','Unexpected logger width %s.',name);
end
