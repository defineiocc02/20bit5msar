function report=test_singlebank_inputchop(projectRoot,profileFile)
%TEST_SINGLEBANK_INPUTCHOP Draft FE-only tests; does not open or run a model.
% Uses an actual saved normal P for the OFF gate, then explicit test stimuli.
    assert(isfolder(projectRoot)&&isfile(profileFile)&&~bdIsLoaded('SarAdc'), ...
        'inputChopTest:input','Use a fresh process, installed source and saved normal P.');
    d=dir(profileFile);assert(isscalar(d)&&d.bytes<300e6,'inputChopTest:size','Invalid profile size.');
    here=fileparts(mfilename('fullpath'));oldPath=path;
    restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    fixtureSha=file_sha(profileFile);
    assert(any(strcmp(fixtureSha,{'e42b739ed7c465845ed0e415a9f2fdfdd1afa0caaf0c18055c3f77fbfe683b61', ...
        'aa9f8f6d97108fbfae66701e8d09db123940a1b5f1b75fc9187c9b0203aba3c3'})), ...
        'inputChopTest:fixtureSha','Use pinned archived N8 or installed-run N256 P.');
    names={'behavior_frontend_init','behavior_frontend_step','behavior_frontend_stage', ...
        'behavior_input_chop_polarity','behavior_frontend_init_baseline', ...
        'behavior_frontend_step_baseline','behavior_frontend_stage_baseline', ...
        'behavior_frontend_pack','behavior_frontend_unpack','behavior_jitter_parameters','behavior_aperture_times'};
    loaded=inmem('-completenames');
    for k=1:numel(loaded)
        [~,stem]=fileparts(loaded{k});
        assert(~any(strcmpi(stem,names)),'inputChopTest:cache', ...
            'Use a fresh process; %s is already cached.',stem);
    end
    addpath(genpath(fullfile(projectRoot,'current','src')),'-begin');
    addpath(here,fullfile(here,'baseline_aliases'),'-begin');rehash;
    files={fullfile(here,'behavior_frontend_init.m'),'dba46566bf6933d121c43b93e1e5445361103f48d57036c05f2dabcf89ef9e2b'; ...
        fullfile(here,'behavior_frontend_step.m'),'e05f92d29c59962302e130b2b6ad4e07a69d3aff99d487c22f2e45453c5f6006'; ...
        fullfile(here,'behavior_frontend_stage.m'),'5897dcc0f720d449ccda3f2c60cb089a5b0b1f6b1ded3455d132d852ba36a360'; ...
        fullfile(here,'behavior_input_chop_polarity.m'),'272a46c2cf586c23aa61a7d1e19f56d0891e788d89574c97145ebb6d834c37a2'; ...
        fullfile(here,'baseline_aliases','behavior_frontend_init_baseline.m'),'aca0ed10ac447a112c2146bdd1dd90202a2504ca1923f6d8c9c610c7a126e5c3'; ...
        fullfile(here,'baseline_aliases','behavior_frontend_step_baseline.m'),'906fbe7dbda8a714e469c429db6bfad8d228967dee9a4eef01bc5351168bdc0d'; ...
        fullfile(here,'baseline_aliases','behavior_frontend_stage_baseline.m'),'30b893e1e684378f3a8b9738dfa47ac1fd3455488066134409750b6cfec95c99'; ...
        fullfile(projectRoot,'current','src','frontend','behavior_frontend_pack.m'),'cf2cde7f5eed9819387d6bcf7778abf6c76f7d1bff907ca2a7f9657fe32c073e'; ...
        fullfile(projectRoot,'current','src','frontend','behavior_frontend_unpack.m'),'f345c0520de23fdb12ab4466403cd5519865782b2c26eaac654e6c854e108f25'; ...
        fullfile(projectRoot,'current','src','frontend','behavior_jitter_parameters.m'),'12895b36914aa2af35c1ff12a84a44c58f0c49f4a355192cde9fabcab5499dae'; ...
        fullfile(projectRoot,'current','src','frontend','behavior_aperture_times.m'),'efc2c1236078cbe5400c8d6b222446d1e81733f7c8cfb28271ed9cb3f9546db0'};
    for k=1:size(files,1)
        [~,name]=fileparts(files{k,1});
        assert(strcmp(file_sha(files{k,1}),files{k,2})&&same_path(which(name),files{k,1}), ...
            'inputChopTest:source','Wrong source SHA or path for %s.',name);
    end
    rngBefore=rng;q=load(profileFile,'P');P=q.P;
    assert(P.front.single_bank&&P.Ts_s==200e-9&&~P.front.dem_enabled&& ...
        ~P.front.dither_enabled&&~P.front.jitter.enabled&& ...
        ~isfield(P.front,'input_chop_mode'), ...
        'inputChopTest:normal','Expected the original saved normal single-bank P.');
    F=P.front;if isfield(F,'group_C_f'),F=rmfield(F,'group_C_f');end

    % Original P without new fields must retain full parameter shape and the
    % FE state/output bits at each physically meaningful event.
    [old,po]=behavior_frontend_init_baseline(F);[now,pn]=behavior_frontend_init(F);
    same_bits(po,pn,'legacy normalized FE parameters');same_bits(old,now,'legacy FE initial state');
    rel=P.calendar(strcmp({P.calendar.type},'release')).time_s;
    commands={cmd('acquire_open',-P.Ts_s+rel,0,P.epoch),cmd('capture',0,0,P.epoch), ...
        cmd('convert_join',0,0,P.epoch),cmd('dac_commit',12.5*1e-9,0,P.epoch), ...
        cmd('observe',45*1e-9,0,P.epoch),cmd('release',90*1e-9,0,P.epoch), ...
        cmd('acquire_open',90*1e-9,1,P.epoch)};
    commands{4}.d1_code=1040;commands{6}.vtop_v=0.002;
    for k=1:numel(commands)
        [old,a]=behavior_frontend_step_baseline(old,commands{k},po);
        [now,b]=behavior_frontend_step(now,commands{k},pn);
        same_bits(old,now,'legacy FE state');same_bits(a,b,'legacy FE output');
    end
    [oldNext,oldObs,oldOut]=behavior_frontend_stage_baseline('advance', ...
        behavior_frontend_pack(old),[P.Ts_s;1;P.epoch;1;0;0],po);
    [newNext,newObs,newOut]=behavior_frontend_stage('advance', ...
        behavior_frontend_pack(now),[P.Ts_s;1;P.epoch;1;0;0],pn);
    same_bits(oldNext,newNext,'legacy FE353 stage state');
    same_bits(oldObs,newObs,'legacy FE stage observation');same_bits(oldOut,newOut,'legacy FE stage output');

    % Known constant source and long finite RC are a mechanism fixture, not
    % normal values. Even target acquires +VIN; odd target acquires -VIN.
    C=F;C.input_chop_mode='pku_input_hold_chop_v1';C.ktc_enabled=false;
    C.tau_sample_s(:)=30e-9;C.input=struct('offset_v',0.125,'amplitude_v',0,'frequency_hz',0,'phase_rad',0);
    [s,C]=behavior_frontend_init(C);
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',-P.Ts_s+rel,0,P.epoch),C);
    [s,~]=behavior_frontend_step(s,cmd('capture',0,0,P.epoch),C);
    [s,~]=behavior_frontend_step(s,cmd('convert_join',0,0,P.epoch),C);
    ids=(1:8).';expected=0.125*(1-exp(-((P.Ts_s-rel)-C.single_guard_s)/C.tau_sample_s(1)));
    assert(all(abs(s.v_capture_v(ids)-expected)<1e-13), ...
        'inputChopTest:even','Even capture or finite-RC response differs.');
    vtop=0.007;release=cmd('release',rel,0,P.epoch);release.vtop_v=vtop;
    [s,~]=behavior_frontend_step(s,release,C);
    vreturn=s.B_c(ids,1)./C.group_C_f(ids,1);
    assert(all(abs(vreturn-(expected-vtop))<1e-13), ...
        'inputChopTest:return','Actual Vtop must return once in the same FE coordinate.');
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',rel,1,P.epoch),C);
    assert(all(s.target_id(ids)==1)&&all(s.target_epoch(ids)==P.epoch), ...
        'inputChopTest:target','The next acquisition must own ID 1 and its epoch.');
    pre=s.B_c(ids,1);
    [s,~]=behavior_frontend_step(s,cmd('observe',rel+C.single_guard_s/2,1,P.epoch),C);
    same_bits(s.B_c(ids,1),pre,'return charge held throughout guard');
    [s,~]=behavior_frontend_step(s,cmd('capture',P.Ts_s,1,P.epoch),C);
    expectedOdd=-0.125+(vreturn+0.125).*exp(-(P.Ts_s-rel-C.single_guard_s)/C.tau_sample_s(1));
    assert(all(abs(s.v_capture_v(ids)-expectedOdd)<1e-13)&&all(s.capture_id(ids)==1)&& ...
        all(s.capture_epoch(ids)==P.epoch),'inputChopTest:odd','Odd target must acquire -VIN from returned charge.');

    % Independent sinusoidal particular/homogeneous solution at odd polarity,
    % with nonzero offset and initial returned charge. Do not call FE rc_sine.
    V=F;V.input_chop_mode='pku_input_hold_chop_v1';V.ktc_enabled=false;V.tau_sample_s(:)=30e-9;
    V.input=struct('offset_v',0.05,'amplitude_v',0.3,'frequency_hz',97656.25,'phase_rad',0.731);
    [s,V]=behavior_frontend_init(V);s.B_c(ids,1)=V.group_C_f(ids,1)*0.08;
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',-P.Ts_s+rel,1,P.epoch),V);
    initial=s.B_c(ids,1)./V.group_C_f(ids,1);openTime=-P.Ts_s+rel+V.single_guard_s;
    w=2*pi*V.input.frequency_hz;a=w*V.tau_sample_s(1);
    sinusoid=@(t) V.input.offset_v+V.input.amplitude_v/sqrt(1+a*a)* ...
        sin(w*t+V.input.phase_rad-atan(a));
    expectedSine=-sinusoid(0)+(initial+sinusoid(openTime))*exp(-(-openTime)/V.tau_sample_s(1));
    [s,~]=behavior_frontend_step(s,cmd('capture',0,1,P.epoch),V);
    assert(all(abs(s.v_capture_v(ids)-expectedSine)<1e-13), ...
        'inputChopTest:sine','Odd finite-RC sinusoid with returned charge differs.');

    % Guard=0, tau=Inf, kTC OFF must hold B bits even for both POLs. This
    % exact B/C fixture is from a real archived normal trace; its multiply
    % roundtrip differs by one ULP and would expose an unintended write.
    I=F;I.input_chop_mode='pku_input_hold_chop_v1';I.ktc_enabled=false;
    I.single_guard_s=0;I.tau_sample_s(:)=Inf;
    bHold=1.4039278482018078e-11;
    [~,ti]=behavior_frontend_init(I);
    bRoundtrip=(bHold/ti.group_C_f(1,1))*ti.group_C_f(1,1);
    assert(~same_double(bHold,bRoundtrip),'inputChopTest:infFixture','Expected one-ULP-sensitive B/C fixture.');
    for id=0:1
        [s,ti]=behavior_frontend_init(I);s.B_c(1,1)=bHold;
        [s,~]=behavior_frontend_step(s,cmd('acquire_open',-P.Ts_s+rel,id,P.epoch),ti);
        [s,~]=behavior_frontend_step(s,cmd('observe',0,id,P.epoch),ti);
        assert(same_double(s.B_c(1,1),bHold),'inputChopTest:infHold','Inf tau must retain B bits.');
    end

    % Existing stochastic sample innovation must be retained rather than
    % cancelled by input polarity. This fixture has zero signal and same key.
    K=F;K.input=struct('offset_v',0,'amplitude_v',0,'frequency_hz',0,'phase_rad',0);
    KC=K;KC.input_chop_mode='pku_input_hold_chop_v1';
    [a,pa]=behavior_frontend_init(K);[b,pb]=behavior_frontend_init(KC);
    c=cmd('acquire_open',-P.Ts_s+rel,1,P.epoch);
    [a,~]=behavior_frontend_step(a,c,pa);[b,~]=behavior_frontend_step(b,c,pb);
    c=cmd('capture',0,1,P.epoch);
    [a,~]=behavior_frontend_step(a,c,pa);[b,~]=behavior_frontend_step(b,c,pb);
    same_bits(a.B_c(:,1),b.B_c(:,1),'same-key kTC preserved across input POL');
    assert(any(a.B_c(1:8,1)~=0),'inputChopTest:ktc','Expected nonzero normal kTC fixture.');

    % A source descriptor changed during acquisition has unresolved same-edge
    % semantics in the old model. The new mode rejects it; OFF is unchanged.
    C=rmfield(C,'group_C_f');[s,C]=behavior_frontend_init(C);
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',-P.Ts_s+rel,0,P.epoch),C);
    event=[0;0;P.epoch;1;0;0];newInput=[0.25;0;0;0];
    expect_error(@()behavior_frontend_stage('advance',behavior_frontend_pack(s),event,C,newInput), ...
        'inputChop:sourceChangeDuringAcq');
    Q=F;Q.input_chop_mode='pku_input_hold_chop_v1';Q.dither_enabled=true;
    expect_error(@()behavior_frontend_init(Q),'inputChop:ditherUnsupported');
    Q=F;Q.input_chop_mode='pku_input_hold_chop_v1';Q.single_bank=false;Q.single_guard_s=0;
    expect_error(@()behavior_frontend_init(Q),'inputChop:singleBankOnly');
    Q=pn;Q.input_chop_mode='unknown';
    expect_error(@()behavior_frontend_step(now,cmd('observe',90*1e-9,1,P.epoch),Q),'inputChop:mode');
    Q=pn;Q.input_chop_mode='pku_input_hold_chop_v1';Q.single_bank=false;
    expect_error(@()behavior_frontend_step(now,cmd('observe',90*1e-9,1,P.epoch),Q),'inputChop:singleBankOnly');
    assert(isequaln(rngBefore,rng),'inputChopTest:rng','Global RNG changed.');
    report=struct('status','passed','scope','single-bank FE functions only; no SLX/RA/noise-reduction claim', ...
        'fixture_sha256',fixtureSha,'fixture_N',double(P.N), ...
        'legacy_P_state_output_exact',true,'input_polarity',[1 -1], ...
        'finite_rc_return_guard_and_sinusoid_checked',true,'infinite_tau_bit_hold',true, ...
        'same_key_sampling_noise_preserved',true, ...
        'source_change_during_acquire_rejected',true,'dither_enabled',false, ...
        'global_rng_unchanged',true);
end
function c=cmd(name,time,id,epoch),c=struct('event',name,'t_s',time,'id',id,'epoch',epoch);end
function yes=same_double(a,b),yes=isequal(typecast(double(a),'uint64'),typecast(double(b),'uint64'));end
function yes=same_path(a,b)
    yes=~isempty(a)&&strcmpi(char(java.io.File(char(a)).getCanonicalPath()), ...
        char(java.io.File(char(b)).getCanonicalPath()));
end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<300e6,'inputChopTest:size','Invalid source size.');
    f=fopen(file,'rb');assert(f>=0,'inputChopTest:read','Cannot read source.');c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
function expect_error(f,id)
    try,f();catch err
        assert(strcmp(err.identifier,id),'inputChopTest:error','Expected %s got %s.',id,err.identifier);return;
    end
    error('inputChopTest:error','Expected %s.',id);
end
function same_bits(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)),'inputChopTest:type','Type/size at %s.',where);
    if isstruct(a)
        names=fieldnames(a);assert(isequal(names,fieldnames(b)),'inputChopTest:fields','Fields at %s.',where);
        for i=1:numel(a),for k=1:numel(names),same_bits(a(i).(names{k}),b(i).(names{k}),[where '.' names{k}]);end,end
    elseif iscell(a)
        for i=1:numel(a),same_bits(a{i},b{i},where);end
    elseif isa(a,'double')
        assert(isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64')),'inputChopTest:bits','Double bits at %s.',where);
    else
        assert(isequaln(a,b),'inputChopTest:value','Value at %s.',where);
    end
end
