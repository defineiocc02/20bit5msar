function result=sar20_add_input_demod(jobRoot,inputModelSha,toolkitPins)
% Add one input-chop signed-sum demodulator after the existing PlusDither.
% Private graph only; inputModelSha binds the preceding RA-probe stage.
    assert(ispc&&feature('getpid')~=27628&&~usejava('desktop')&&~bdIsLoaded('SarAdc'), ...
        'sar20Pku:demodSession','Require a fresh isolated headless process.');
    jobRoot=canon(jobRoot);assert(~isempty(regexp(jobRoot,'(?i)^D:/Temp/SAR20[A-Za-z0-9_]+$','once')), ...
        'sar20Pku:job','Job must be a fresh D:/Temp/SAR20* directory.');
    assert(ischar(inputModelSha)&&~isempty(regexp(inputModelSha,'^[0-9a-f]{64}$','once')), ...
        'sar20Pku:demodHash','Expected full preceding model SHA.');
    model=fullfile(jobRoot,'candidate','current','models','SarAdc.slx');
    assert(strcmp(file_sha(model),inputModelSha),'sar20Pku:demodModel','Prior private graph differs.');
    assert(isstruct(toolkitPins)&&numel(toolkitPins)==4&& ...
        isequal(sort({toolkitPins.name}),sort({'model_read','model_edit','model_check','library.settingsLookup'})), ...
        'sar20Pku:toolkit','Need four exact SATK pins.');
    toolkit='D:/Academic/Projects/sar20m1/SAR20/dependencies/toolkit/tools';
    result=struct('status','started','pid',feature('getpid'),'input_model_sha256',inputModelSha, ...
        'keep_worker_alive',false,'scope','one stateless signed-sum digital S-function; no physical state change');
    oldPath=path;oldCwd=pwd;opened=false;edited=false;safe=true;
    oldFilegen=Simulink.fileGenControl('getConfig');filegenChanged=false;
    try
        project=fullfile(jobRoot,'candidate');
        addpath(genpath(fullfile(project,'current','src')),fullfile(project,'config'),project, ...
            fullfile(project,'tests'),'-begin');rehash;
        addpath(fullfile(toolkit,'common'),fullfile(toolkit,'common','autolayout'), ...
            fullfile(toolkit,'model_read'),fullfile(toolkit,'model_edit'),fullfile(toolkit,'model_check'),'-begin');
        for k=1:numel(toolkitPins)
            row=toolkitPins(k);expected=fullfile(toolkit,strrep(row.relative_to_tools,'/',filesep));actual=which(row.name);
            assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected))&& ...
                ~isempty(regexp(row.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(file_sha(expected),row.sha256), ...
                'sar20Pku:toolkit','SATK identity differs: %s',row.name);
        end
        gate=library.settingsLookup();assert(isstruct(gate)&&isfield(gate,'found')&&isfield(gate,'gatePass')&& ...
            (~gate.found||gate.gatePass),'sar20Pku:toolkitGate','SATK library gate failed.');
        Simulink.fileGenControl('set','CacheFolder',fullfile(jobRoot,'demod_cache'), ...
            'CodeGenFolder',fullfile(jobRoot,'demod_codegen'),'keepPreviousPath',true,'createDir',true);
        filegenChanged=true;cd(jobRoot);load_system(model);opened=true;require_owned(model);
        ws=get_param('SarAdc','ModelWorkspace');P=getVariable(ws,'P');D=getVariable(ws,'DecodeP');T=getVariable(ws,'TrainCaptureFile');
        scope='blk_123';parent=Simulink.ID.getFullName('SarAdc:123');view=char(model_read('SarAdc',scope,'0'));require_ok(view,{'status: ok','status: success'});
        required={'blk_177','blk_196','blk_197','blk_215'};present=unique(regexp(view,'blk_[0-9]+','match'),'stable');
        assert(all(ismember(required,present)),'sar20Pku:demodRead','model_read does not expose expected existing IDs.');
        raw=Simulink.ID.getFullName('SarAdc:177');plus=Simulink.ID.getFullName('SarAdc:196');
        counts=Simulink.ID.getFullName('SarAdc:197');oldPol=Simulink.ID.getFullName('SarAdc:215');
        names={'RawFields','PlusDither','Counts','PublicPol'};paths={raw,plus,counts,oldPol};
        for k=1:numel(paths),assert(strcmp(get_param(paths{k},'Parent'),parent)&&strcmp(get_param(paths{k},'Name'),names{k}), ...
                'sar20Pku:demodBlock','SID meaning or scope differs.');end
        rp=get_param(raw,'PortHandles');pp=get_param(plus,'PortHandles');cp=get_param(counts,'PortHandles');op=get_param(oldPol,'PortHandles');
        assert(numel(rp.Outport)>=5&&numel(pp.Outport)==1&&numel(cp.Inport)==1&&numel(op.Inport)>=2&& ...
            source_of(cp.Inport(1))==pp.Outport(1)&&source_of(op.Inport(1))==rp.Outport(4)&& ...
            source_of(op.Inport(2))==rp.Outport(5),'sar20Pku:demodWires', ...
            'Actual sum edge or ID/epoch sources differ from the frozen plan.');
        assert(isempty(find_system(parent,'SearchDepth',1,'Name','InputChopDemod')), ...
            'sar20Pku:demodExists','Demod block already exists.');
        op1=struct('op','add_block','type','M-S-Function','name','InputChopDemod','ref','demod', ...
            'params',struct('FunctionName','behavior_input_chop_demod_sfun','Parameters','DecodeP'));
        edited=true;reply1=char(model_edit('SarAdc',scope,jsonencode({op1}),'incremental'));
        if strcmp(strtrim(strtok(reply1,newline)),'status: partial'),result=partial_diag(result,scope,reply1);end
        require_ok(reply1,{'status: ok','status: success'});
        mid=char(model_read('SarAdc',scope,'0'));require_ok(mid,{'status: ok','status: success'});
        ids=unique(regexp(mid,'blk_[0-9]+','match'),'stable');newId='';
        for k=1:numel(ids)
            q=Simulink.ID.getFullName(['SarAdc:' extractAfter(ids{k},'blk_')]);
            if strcmp(get_param(q,'Parent'),parent)&&strcmp(get_param(q,'Name'),'InputChopDemod')
                assert(isempty(newId),'sar20Pku:demodDuplicate','Multiple demod blocks.');newId=ids{k};
            end
        end
        assert(~isempty(newId),'sar20Pku:demodRead','New demod block not visible in model_read.');
        demod=Simulink.ID.getFullName(['SarAdc:' extractAfter(newId,'blk_')]);dp=get_param(demod,'PortHandles');
        assert(strcmp(get_param(demod,'BlockType'),'M-S-Function')&& ...
            strcmp(get_param(demod,'FunctionName'),'behavior_input_chop_demod_sfun')&& ...
            strcmp(get_param(demod,'Parameters'),'DecodeP')&&numel(dp.Inport)==3&&numel(dp.Outport)==1, ...
            'sar20Pku:demodPorts','New S-function or actual ports differ.');
        ops={struct('op','disconnect','target','blk_196.y1 -> blk_197.u1'), ...
             struct('op','connect','target',['blk_196.y1 -> ' newId '.u1']), ...
             struct('op','connect','target',['blk_177.y4 -> ' newId '.u2']), ...
             struct('op','connect','target',['blk_177.y5 -> ' newId '.u3']), ...
             struct('op','connect','target',[newId '.y1 -> blk_197.u1'])};
        reply2=char(model_edit('SarAdc',scope,jsonencode(ops),'incremental'));
        if strcmp(strtrim(strtok(reply2,newline)),'status: partial'),result=partial_diag(result,scope,reply2);end
        require_ok(reply2,{'status: ok','status: success'});
        after=char(model_read('SarAdc',scope,'0'));require_ok(after,{'status: ok','status: success'});
        dp=get_param(demod,'PortHandles');
        assert(source_of(dp.Inport(1))==pp.Outport(1)&&source_of(dp.Inport(2))==rp.Outport(4)&& ...
            source_of(dp.Inport(3))==rp.Outport(5)&&source_of(cp.Inport(1))==dp.Outport(1)&& ...
            source_of(op.Inport(1))==rp.Outport(4)&&source_of(op.Inport(2))==rp.Outport(5), ...
            'sar20Pku:demodReadback','Final actual connections differ from the plan.');
        checked=char(model_check('SarAdc',scope,'["unconnected_ports","unconnected_lines"]'));require_ok(checked,{'status: healthy'});
        assert(sb256_same_bits(getVariable(ws,'P'),P)&&sb256_same_bits(getVariable(ws,'DecodeP'),D)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),T),'sar20Pku:demodWorkspace','Stored workspace changed.');
        save_system('SarAdc',model);result.status='SAVED_PENDING_XML_DIFF';result.model_sha256=file_sha(model);
        result.demod_id=newId;result.model_edit_add=reply1;result.model_edit_wire=reply2;result.model_read_after=after;result.model_check=checked;
    catch ex
        result.status='failed';result.error=getReport(ex,'extended','hyperlinks','off');
        if edited&&opened
            try
                folder=fullfile(jobRoot,'demod_partial');assert(~isfolder(folder)&&~isfile(folder));mkdir(folder);
                require_owned(model);partial=fullfile(folder,'SarAdc.slx');save_system('SarAdc',partial);
                result.partial_path=partial;result.partial_sha256=file_sha(partial);result.status='partial_saved';
            catch e,result.keep_worker_alive=true;safe=false;result.partial_error=getReport(e,'extended','hyperlinks','off');end
        end
    end
    if opened&&safe
        try,if bdIsLoaded('SarAdc'),close_system('SarAdc',0);end,catch e,result.close_error=e.message;result.keep_worker_alive=true;safe=false;end
    end
    if safe
        try
            if filegenChanged,Simulink.fileGenControl('set','CacheFolder',char(oldFilegen.CacheFolder),'CodeGenFolder',char(oldFilegen.CodeGenFolder),'keepPreviousPath',true,'createDir',false);end
            path(oldPath);cd(oldCwd);result.filegen_restored=true;
        catch e,result.filegen_restored=false;result.restore_error=e.message;end
    end
    result.owned_model_closed=~bdIsLoaded('SarAdc');
end
function source=source_of(port)
    line=get_param(port,'Line');assert(line~=-1,'sar20Pku:missingLine','Expected connected port.');source=get_param(line,'SrcPortHandle');
end
function result=partial_diag(result,scope,reply)
    result.partial_reply=reply;
    try,result.partial_model_read=char(model_read('SarAdc',scope,'0'));catch e,result.partial_read_error=getReport(e,'extended','hyperlinks','off');end
    try,result.partial_model_check=char(model_check('SarAdc',scope,'["unconnected_ports","unconnected_lines"]'));catch e,result.partial_check_error=getReport(e,'extended','hyperlinks','off');end
end
function require_ok(s,allowed),line=strtrim(strtok(char(s),newline));assert(any(strcmp(line,allowed)),'sar20Pku:SATK','SATK result: %s',line);end
function require_owned(file),assert(bdIsLoaded('SarAdc')&&strcmpi(canon(get_param('SarAdc','FileName')),canon(file)), ...
    'sar20Pku:owner','Loaded model is not the private copy.');end
function p=canon(p),p=strrep(char(java.io.File(char(p)).getCanonicalPath()),'\','/');end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300000000,'sar20Pku:size','Missing or oversized: %s',file);
    f=fopen(file,'rb');assert(f>=0,'sar20Pku:read','Cannot read: %s',file);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));
    h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
