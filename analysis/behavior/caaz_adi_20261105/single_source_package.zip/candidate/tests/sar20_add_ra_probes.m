function result=sar20_add_ra_probes(jobRoot,inputModelSha,toolkitPins)
% Add two read-only RA48 ToWorkspace taps in a private graph via SATK.
% toolkitPins: four struct rows {name,relative_to_tools,sha256}; frozen by caller.
% Saves only this job's model; no simulation, new state, or new solver hit.
    assert(ispc&&feature('getpid')~=27628&&~usejava('desktop')&&~bdIsLoaded('SarAdc'), ...
        'sar20Pku:probeSession','Require a fresh isolated headless process.');
    jobRoot=canon(jobRoot);assert(~isempty(regexp(jobRoot,'(?i)^D:/Temp/SAR20[A-Za-z0-9_]+$','once')), ...
        'sar20Pku:job','Job must be a fresh D:/Temp/SAR20* directory.');
    assert(ischar(inputModelSha)&&~isempty(regexp(inputModelSha,'^[0-9a-f]{64}$','once')), ...
        'sar20Pku:probeHash','Expected full input model SHA.');
    model=fullfile(jobRoot,'candidate','current','models','SarAdc.slx');
    assert(strcmp(file_sha(model),inputModelSha),'sar20Pku:probeModel','Private input model differs.');
    assert(isstruct(toolkitPins)&&numel(toolkitPins)==4&& ...
        isequal(sort({toolkitPins.name}),sort({'model_read','model_edit','model_check','library.settingsLookup'})), ...
        'sar20Pku:toolkit','Need the four exact frozen SATK pins.');
    toolkit='D:/Academic/Projects/sar20m1/SAR20/dependencies/toolkit/tools';
    result=struct('status','started','pid',feature('getpid'),'input_model_sha256',inputModelSha, ...
        'keep_worker_alive',false,'scope','two RA48 read-only wires, no solver hit or owner added');
    oldPath=path;oldCwd=pwd;opened=false;edited=false;safe=true;
    oldFilegen=Simulink.fileGenControl('getConfig');filegenChanged=false;
    try
        project=fullfile(jobRoot,'candidate');
        addpath(genpath(fullfile(project,'current','src')),fullfile(project,'config'),project, ...
            fullfile(project,'tests'),'-begin');rehash;
        addpath(fullfile(toolkit,'common'),fullfile(toolkit,'common','autolayout'), ...
            fullfile(toolkit,'model_read'),fullfile(toolkit,'model_edit'),fullfile(toolkit,'model_check'),'-begin');
        for k=1:numel(toolkitPins)
            row=toolkitPins(k);expected=fullfile(toolkit,strrep(row.relative_to_tools,'/',filesep));actual=which(row.name);
            assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected))&& ...
                ~isempty(regexp(row.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(file_sha(expected),row.sha256), ...
                'sar20Pku:toolkit','SATK identity differs: %s',row.name);
        end
        gate=library.settingsLookup();assert(isstruct(gate)&&isfield(gate,'found')&&isfield(gate,'gatePass')&& ...
            (~gate.found||gate.gatePass),'sar20Pku:toolkitGate','SATK library gate failed.');
        Simulink.fileGenControl('set','CacheFolder',fullfile(jobRoot,'probe_cache'), ...
            'CodeGenFolder',fullfile(jobRoot,'probe_codegen'),'keepPreviousPath',true,'createDir',true);
        filegenChanged=true;cd(jobRoot);load_system(model);opened=true;require_owned(model);
        ws=get_param('SarAdc','ModelWorkspace');P=getVariable(ws,'P');D=getVariable(ws,'DecodeP');T=getVariable(ws,'TrainCaptureFile');
        parent=Simulink.ID.getFullName('SarAdc:112');view=char(model_read('SarAdc','blk_112','0'));require_ok(view,{'status: ok','status: success'});
        ids=unique(regexp(view,'blk_[0-9]+','match'),'stable');oldId='';nextId='';
        for k=1:numel(ids)
            full=Simulink.ID.getFullName(['SarAdc:' extractAfter(ids{k},'blk_')]);
            if strcmp(full,[parent '/RaCtState']),oldId=ids{k};end
            if strcmp(full,[parent '/ChargeReturnRaReset']),nextId=ids{k};end
        end
        assert(~isempty(oldId)&&~isempty(nextId),'sar20Pku:probeSource','model_read did not expose RA sources.');
        oldBlock=Simulink.ID.getFullName(['SarAdc:' extractAfter(oldId,'blk_')]);
        nextBlock=Simulink.ID.getFullName(['SarAdc:' extractAfter(nextId,'blk_')]);
        assert(strcmp(get_param(oldBlock,'BlockType'),'UnitDelay')&&strcmp(get_param(nextBlock,'BlockType'),'SubSystem'), ...
            'sar20Pku:probeSource','RA owner or next-stage type differs.');
        for p={oldBlock,nextBlock},ph=get_param(p{1},'PortHandles');assert(~isempty(ph.Outport)&&get_param(ph.Outport(1),'Line')~=-1, ...
                'sar20Pku:probeSource','Expected output is not wired.');end
        a=struct('VariableName','pku_ra_old48','SaveFormat','Timeseries','MaxDataPoints','inf','Decimation','1','SampleTime','-1');
        b=a;b.VariableName='pku_ra_next48';
        ops={struct('op','add_block','type','ToWorkspace','name','PkuRaOld48','ref','old','params',a), ...
             struct('op','add_block','type','ToWorkspace','name','PkuRaNext48','ref','next','params',b), ...
             struct('op','connect','target',[oldId '.y1 -> #old.u1']), ...
             struct('op','connect','target',[nextId '.y1 -> #next.u1'])};
        edited=true;reply=char(model_edit('SarAdc','blk_112',jsonencode(ops),'incremental'));
        if strcmp(strtrim(strtok(reply,newline)),'status: partial')
            result.model_edit_response=reply;
            try,result.partial_model_read=char(model_read('SarAdc','blk_112','0'));catch e,result.partial_read_error=getReport(e,'extended','hyperlinks','off');end
            try,result.partial_model_check=char(model_check('SarAdc','blk_112','["unconnected_ports","unconnected_lines"]'));catch e,result.partial_check_error=getReport(e,'extended','hyperlinks','off');end
        end
        require_ok(reply,{'status: ok','status: success'});
        after=char(model_read('SarAdc','blk_112','0'));require_ok(after,{'status: ok','status: success'});
        for q={{'PkuRaOld48','pku_ra_old48'},{'PkuRaNext48','pku_ra_next48'}}
            pair=q{1};found=find_system(parent,'SearchDepth',1,'Name',pair{1});
            assert(numel(found)==1&&strcmp(get_param(found{1},'BlockType'),'ToWorkspace')&& ...
                strcmp(get_param(found{1},'VariableName'),pair{2})&&strcmp(get_param(found{1},'SaveFormat'),'Timeseries')&& ...
                strcmp(get_param(found{1},'MaxDataPoints'),'inf')&&strcmp(get_param(found{1},'Decimation'),'1')&& ...
                strcmp(get_param(found{1},'SampleTime'),'-1'),'sar20Pku:probeReadback','Probe settings differ.');
        end
        checked=char(model_check('SarAdc','blk_112','["unconnected_ports","unconnected_lines"]'));require_ok(checked,{'status: healthy'});
        assert(sb256_same_bits(getVariable(ws,'P'),P)&&sb256_same_bits(getVariable(ws,'DecodeP'),D)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),T),'sar20Pku:probeWorkspace','Stored model workspace changed.');
        save_system('SarAdc',model);result.status='SAVED_PENDING_XML_DIFF';result.model_sha256=file_sha(model);
        result.old_source=oldId;result.next_source=nextId;result.model_edit_response=reply;result.model_read_after=after;result.model_check=checked;
    catch ex
        result.status='failed';result.error=getReport(ex,'extended','hyperlinks','off');
        if edited&&opened
            try
                folder=fullfile(jobRoot,'probe_partial');assert(~isfolder(folder)&&~isfile(folder));mkdir(folder);
                require_owned(model);partial=fullfile(folder,'SarAdc.slx');save_system('SarAdc',partial);
                result.partial_path=partial;result.partial_sha256=file_sha(partial);result.status='partial_saved';
            catch e,result.keep_worker_alive=true;safe=false;result.partial_error=getReport(e,'extended','hyperlinks','off');end
        end
    end
    if opened&&safe
        try,if bdIsLoaded('SarAdc'),close_system('SarAdc',0);end,catch e,result.close_error=e.message;result.keep_worker_alive=true;safe=false;end
    end
    if safe
        try
            if filegenChanged,Simulink.fileGenControl('set','CacheFolder',char(oldFilegen.CacheFolder),'CodeGenFolder',char(oldFilegen.CodeGenFolder),'keepPreviousPath',true,'createDir',false);end
            path(oldPath);cd(oldCwd);result.filegen_restored=true;
        catch e,result.filegen_restored=false;result.restore_error=e.message;end
    end
    result.owned_model_closed=~bdIsLoaded('SarAdc');
end
function require_ok(s,allowed),line=strtrim(strtok(char(s),newline));assert(any(strcmp(line,allowed)),'sar20Pku:SATK','SATK result: %s',line);end
function require_owned(file),assert(bdIsLoaded('SarAdc')&&strcmpi(canon(get_param('SarAdc','FileName')),canon(file)), ...
    'sar20Pku:owner','Loaded model is not the private copy.');end
function p=canon(p),p=strrep(char(java.io.File(char(p)).getCanonicalPath()),'\','/');end
function h=file_sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300000000,'sar20Pku:size','Missing or oversized: %s',file);
    f=fopen(file,'rb');assert(f>=0,'sar20Pku:read','Cannot read: %s',file);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));
    h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
