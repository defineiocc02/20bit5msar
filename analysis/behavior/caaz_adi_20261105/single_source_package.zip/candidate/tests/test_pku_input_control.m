function report=test_pku_input_control()
% Pure control/mechanism checks; no Simulink, model load, or physical waveform.
% This does not claim that FE/backend/digital have been integrated.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    reference=fullfile(fileparts(pkg),'baseline');
    assert(~usejava('desktop')&&~bdIsLoaded('SarAdc'), ...
        'inputChopTest:model','Use a fresh headless process with no loaded SarAdc model.');
    % Same-path stale caches are not proof of current code. Use a fresh worker.
    targets={'behavior_az_schedule','behavior_input_chop_polarity','behavior_az_schedule_9197'};
    loaded=inmem('-completenames');if isstring(loaded),loaded=cellstr(loaded);end
    for j=1:numel(loaded)
        [~,stem]=fileparts(loaded{j});
        assert(~any(strcmpi(stem,targets)),'inputChopTest:cache', ...
            'Use a fresh process: target code is already cached (%s).',stem);
    end
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(pkg,'current','src')),reference,'-begin');rehash;
    for n={'behavior_az_schedule','behavior_input_chop_polarity'}
        f=which(n{1});assert(startsWith(lower(strrep(f,'\','/')), ...
            [lower(strrep(pkg,'\','/')) '/']), ...
            'inputChopTest:path','Candidate function resolved elsewhere: %s',n{1});
    end
    f=which('behavior_az_schedule_9197');
    assert(startsWith(lower(strrep(f,'\','/')),[lower(strrep(reference,'\','/')) '/']), ...
        'inputChopTest:path','Baseline alias resolved elsewhere.');
    assert(strcmp(sha(fullfile(reference,'behavior_az_schedule_9197.m')), ...
        'a2c61a07656e81bf1d79bf01c0d807212338bf85444a69de70097bfe2b18c76e')&& ...
        strcmp(sha(fullfile(pkg,'current','src','control','behavior_az_schedule.m')), ...
        '86ed64198657a6001cb2ad01180de75798f4d95e22701223bd59e3f8c4cbec3e')&& ...
        strcmp(sha(fullfile(pkg,'current','src','control','behavior_input_chop_polarity.m')), ...
        '272a46c2cf586c23aa61a7d1e19f56d0891e788d89574c97145ebb6d834c37a2')&& ...
        strcmp(sha(fullfile(fileparts(pkg),'BASELINE_MANIFEST.json')), ...
        '7b8fdf307e933a212f2f5eeee35a1f41df9b8a00d495e3cdaa4928c2b97c687f'), ...
        'inputChopTest:source','Candidate or archived baseline identity differs.');
    fixture=fullfile(pkg,'tests','fixtures','baseline_9197_parameters.mat');
    assert(strcmp(sha(fixture), ...
        'aa9f8f6d97108fbfae66701e8d09db123940a1b5f1b75fc9187c9b0203aba3c3'), ...
        'inputChopTest:fixture','Actual baseline P identity differs.');
    data=load(fixture,'P');assert(isfield(data,'P'),'inputChopTest:fixture','Missing baseline P.');
    actualP=data.P;
    assert(actualP.N==256&&actualP.front.single_bank&& ...
        strcmp(actualP.backend.az.mode,'ordinary')&& ...
        ~isfield(actualP.front,'input_chop_mode'), ...
        'inputChopTest:fixture','Actual P is not the declared 9197 ordinary baseline.');
    beforeRng=rng;
    % Full output structs and error identifiers for the five original modes.
    % The baseline P deliberately has no input_chop_mode field.
    modes={'off','ordinary','chop','hold','hold_chop'};
    epochs=[0 1 123];ids=[0:7 19];offsets=[-1e-9 0 15e-9 31.25*1e-9 90e-9];
    checks=0;successfulChecks=0;errorChecks=0;
    for k=1:numel(modes)
        P=base(modes{k});
        for ep=epochs
            for id=ids
                for offset=offsets
                    for ra=[false true]
                        for release=[false true]
                            phase=struct('offset_s',offset,'ra_on',ra,'release',release);
                            [oka,va]=invoke(@()behavior_az_schedule_9197(id,ep,phase,P));
                            [okb,vb]=invoke(@()behavior_az_schedule(id,ep,phase,P));
                            assert(oka==okb&&deep_bits(va,vb), ...
                                'inputChopTest:legacy','Legacy mode output/error changed.');
                            checks=checks+1;
                            if oka,successfulChecks=successfulChecks+1;
                            else,errorChecks=errorChecks+1;end
                        end
                    end
                end
            end
        end
    end
    assert(successfulChecks>0&&errorChecks>0,'inputChopTest:coverage', ...
        'Legacy comparison must include success and rejection paths.');
    % Repeat the schedule comparison using the complete saved 9197 P.
    actualChecks=0;
    for id=0:7
        for offset=[0 15e-9 31.25*1e-9 90e-9]
            phase=struct('offset_s',offset,'ra_on',offset==31.25*1e-9);
            a=behavior_az_schedule_9197(id,actualP.epoch,phase,actualP);
            b=behavior_az_schedule(id,actualP.epoch,phase,actualP);
            assert(deep_bits(a,b),'inputChopTest:actualBaseline', ...
                'Saved 9197 P produced a different schedule.');
            actualChecks=actualChecks+1;
        end
    end
    mode='pku_input_hold_chop_v1';P=base(mode);
    P.front=struct('input_chop_mode',mode,'dither_enabled',false);
    P.digital=struct('az_mode',mode,'dither_enabled',false);
    expected=[1 -1 1 -1 1 -1 1 -1];
    for ep=[0 1 7]
        for id=0:7
            [pol,pair,tag]=behavior_input_chop_polarity(id,ep,mode);
            assert(pol==expected(id+1)&&pair==floor(id/2)&& ...
                tag.target_id==id&&tag.epoch==ep&&tag.pair_id==pair&& ...
                tag.input_polarity==pol&&strcmp(tag.schema,'sar20-pku-input-chop/v1'), ...
                'inputChopTest:input','Wrong input polarity or identity.');
            off=behavior_input_chop_polarity(id,ep,'off');
            assert(off==1,'inputChopTest:off','Input chopping OFF must use +1.');
            % The concurrently acquiring next sample uses target ID id+1,
            % not the current service's ID, and no second RA sign flip.
            nextPol=behavior_input_chop_polarity(id+1,ep,mode);
            assert(nextPol==-pol,'inputChopTest:target','Next target used the current ID.');
            a=behavior_az_schedule(id,ep,struct('offset_s',15e-9,'ra_on',false),P);
            assert(a.sample_id==id&&a.epoch==ep&&a.pair_id==pair&& ...
                a.polarity==1&&a.qres_sign==1&&~a.chop_enabled&&a.hold_enabled&&a.write_eligible==(mod(id,2)==0)&& ...
                a.az_on==(mod(id,2)==0), ...
                'inputChopTest:route','AZ action or unflipped RA routing differs.');
            a=behavior_az_schedule(id,ep,struct('offset_s',31.25*1e-9,'ra_on',true),P);
            assert(~a.az_on&&~a.reset_signal&&a.az_end==(mod(id,2)==0)&& ...
                a.polarity==1&&a.qres_sign==1, ...
                'inputChopTest:read','RA start must follow AZ write or hold.');
            a=behavior_az_schedule(id,ep,struct('offset_s',90e-9,'ra_on',false,'release',true),P);
            assert(~a.az_on&&a.reset_signal&&a.polarity==1&&a.qres_sign==1, ...
                'inputChopTest:release','Release must retain the physical RA coordinate.');
        end
    end
    [p0,q0,t0]=behavior_input_chop_polarity(0,11,mode);
    [p1,q1,t1]=behavior_input_chop_polarity(0,12,mode);
    assert(p0==1&&p1==1&&q0==q1&&t0.epoch~=t1.epoch, ...
        'inputChopTest:epoch','Reset epoch is identity, never a polarity phase.');
    [pmax,qmax]=behavior_input_chop_polarity(2^32-1,2^32-1,mode);
    assert(pmax==-1&&qmax==floor((2^32-1)/2),'inputChopTest:maximum','uint32 boundary differs.');
    expect_error(@()behavior_input_chop_polarity(-1,0,mode),'inputChop:tag');
    expect_error(@()behavior_input_chop_polarity(1.5,0,mode),'inputChop:tag');
    expect_error(@()behavior_input_chop_polarity(2^32,0,mode),'inputChop:tag');
    expect_error(@()behavior_input_chop_polarity(0,-1,mode),'inputChop:tag');
    expect_error(@()behavior_input_chop_polarity(0,0,'hold_chop'),'inputChop:mode');
    Q=P;Q.front=rmfield(Q.front,'input_chop_mode');
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.backend.az.mode='ordinary';
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.backend.az.mode='hold_chop';
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.digital.az_mode='ordinary';
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.front.input_chop_mode='off';Q.backend.az.mode='ordinary';
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.front=rmfield(Q.front,'input_chop_mode');Q.backend.az.mode='ordinary';
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.front.dither_enabled=true;
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    Q=P;Q.digital.dither_enabled=true;
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',false),Q),'inputChop:modeJoin');
    expect_error(@()behavior_az_schedule(0,1,struct('offset_s',0,'ra_on',true),P),'behavior:azRoute:overlap');
    % Input polarity is applied before the full code is reconstructed.
    % Each pair has two different inputs and one identical AZ error. This
    % arithmetic oracle is not a simulation of the FE/CT or digital decoder.
    x=[0.1 0.3 -0.2 0.4];u=[0.07 0.07 -0.11 -0.11];
    d1=[0.08 -0.25 0.15 0.35];d=zeros(1,4);p=zeros(1,4);
    for id=0:3
        p(id+1)=behavior_input_chop_polarity(id,1,mode);
        residual=p(id+1)*x(id+1)-d1(id+1)+u(id+1);
        d(id+1)=d1(id+1)+residual;
        assert(abs(p(id+1)*d(id+1)-(x(id+1)+p(id+1)*u(id+1)))<1e-15, ...
            'inputChopTest:fullCode','Full D1 plus residue must share one input polarity.');
        if p(id+1)<0
            assert(abs((d1(id+1)+p(id+1)*residual)-p(id+1)*d(id+1))>0.1, ...
                'inputChopTest:doubleFlip','Legacy residual-only restore unexpectedly matched.');
        end
    end
    for k=1:2
        y=(p(2*k-1)*d(2*k-1)+p(2*k)*d(2*k))/2;
        assert(abs(y-(x(2*k-1)+x(2*k))/2)<1e-15, ...
            'inputChopTest:algebra','Pair-aligned common AZ error did not cancel.');
    end
    assert(isequaln(beforeRng,rng),'inputChopTest:rng','Global RNG changed.');
    report=struct('status','FUNCTION_ASSERTIONS_PASSED', ...
        'mode',mode,'baseline_9197_mode_error_comparisons',checks, ...
        'actual_saved_P_comparisons',actualChecks, ...
        'epoch_does_not_shift_input_polarity',true,'two_phase_pattern',[1 -1], ...
        'az_pair_action','even write, odd hold','ra_qres_and_return_polarity',1, ...
        'target_id_not_current_service',true,'postchop_dither','OFF_REQUIRED', ...
        'scope',['Control and algebra functions only; no sampled FE, stored AZ, ', ...
                 'digitally restored model output, MATLAB graph or performance claim.']);
end
function P=base(mode)
    P=struct();
    P.backend=struct('az',struct('mode',mode,'write_start_s',0, ...
        'write_end_s',31.25*1e-9),'ni',struct('az',~strcmp(mode,'off')));
end
function [ok,v]=invoke(f)
    try,v=f();ok=true;catch ex,v=ex.identifier;ok=false;end
end
function expect_error(f,id)
    [ok,v]=invoke(f);
    assert(~ok,'inputChopTest:noError','Expected %s but no error occurred.',id);
    assert(strcmp(v,id),'inputChopTest:error','Expected %s, got %s.',id,v);
end
function yes=deep_bits(a,b)
    yes=strcmp(class(a),class(b))&&isequal(size(a),size(b));if ~yes,return;end
    if isstruct(a)
        fields=fieldnames(a);yes=isequal(fields,fieldnames(b));if ~yes,return;end
        for j=1:numel(a)
            for k=1:numel(fields)
                if ~deep_bits(a(j).(fields{k}),b(j).(fields{k})),yes=false;return;end
            end
        end
    elseif isa(a,'double')
        yes=isreal(a)&&isreal(b)&& ...
            isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
    elseif isa(a,'single')
        yes=isreal(a)&&isreal(b)&& ...
            isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
    else
        yes=isequaln(a,b);
    end
end

function h=sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'inputChopTest:file','Missing or oversized file.');
    f=fopen(file,'rb');assert(f>=0,'inputChopTest:file','Cannot open file.');
    c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
