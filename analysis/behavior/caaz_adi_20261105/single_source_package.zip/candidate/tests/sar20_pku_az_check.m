function result=sar20_pku_az_check(out,P)
% Check actual 48-word RA UnitDelay output and final-next wires in private N8.
% Only existing ADC event times: probe must add no solver hit or state owner.
    [te,event]=series(out,'event_log',2);
    [to,old]=series(out,'pku_ra_old48',48);
    [tn,next]=series(out,'pku_ra_next48',48);
    [ta,az]=series(out,'az_commit_log',8);
    assert(sb256_same_bits(te,to)&&sb256_same_bits(te,tn)&&sb256_same_bits(te,ta), ...
        'sar20Pku:azAxis','RA tap and actual event log time axes differ.');
    groups=numel(P.groups);cycles=P.schedule.n_cycles;
    assert(P.N==8&&groups==48&&cycles==12&& ...
        isequal(event,[repelem((0:cycles-1).',groups) repmat((1:groups).',cycles,1)]), ...
        'sar20Pku:azCalendar','Expected original 12 x 48 actual ADC event groups.');
    assert(sb256_same_bits(old(1,:),P.xBK0(:).')&& ...
        sb256_same_bits(old(2:end,:),next(1:end-1,:)), ...
        'sar20Pku:azCommit','RA next-to-old delay state is not bitwise connected.');
    diff=next(:,3)-next(:,4);select=next(:,[38 39 40 41 42 43 48]);
    assert(sb256_same_bits(az(:,1),diff)&&sb256_same_bits(az(:,2:8),select), ...
        'sar20Pku:azLog','Existing AZ log disagrees with actual RA final-next state.');
    g=find(arrayfun(@(x)any(strcmp({x.events.type},'ra_start')),P.groups));
    cnv=find(arrayfun(@(x)any(strcmp({x.events.type},'cnv')),P.groups));
    assert(isscalar(g)&&isscalar(cnv),'sar20Pku:azCalendar','Unique CNV and RA-start groups required.');
    chop=strcmp(P.backend.az.mode,'pku_input_hold_chop_v1');
    assert(chop||strcmp(P.backend.az.mode,'ordinary'),'sar20Pku:azMode','Unexpected AZ mode.');
    initial=P.xBK0(43);delta=next(:,43)-old(:,43);
    expected=zeros(size(delta));
    for id=0:cycles-1
        i=find(event(:,1)==id & event(:,2)==g);assert(isscalar(i));
        if chop,count=initial+floor(id/2)+1;lastWrite=id-mod(id,2);
        else,count=initial+id+1;lastWrite=id;end
        assert(next(i,38)==1&&next(i,39)==floor(id/2)&&next(i,40)==P.epoch&& ...
            next(i,42)==0&&next(i,43)==count&&next(i,44)==lastWrite, ...
            'sar20Pku:azPair','RA-start AZ valid/pair/epoch/write count differs for ID %d.',id);
        if ~chop||mod(id,2)==0,expected(event(:,1)==id & event(:,2)==cnv)=1;end
        if chop&&mod(id,2)==1
            mask=event(:,1)==id;
            assert(all(next(mask,42)==0)&&all(next(mask,43)==count)&& ...
                all(next(mask,38)==1)&&all(next(mask,39)==floor(id/2)), ...
                'sar20Pku:azHold','Odd service refreshed or lost its shared AZ state.');
        end
    end
    assert(isequal(delta,expected),'sar20Pku:azWrites','Actual state write-count edges differ.');
    rows=event(:,2)==g;id=event(rows,1);values=next(rows,:);pol=ones(size(id));
    if chop,pol=1-2*mod(id,2);end
    summary=table(id,repmat(P.epoch,numel(id),1),floor(id/2),pol,values(:,38),values(:,43), ...
        values(:,44),values(:,3),values(:,4),values(:,41), ...
        'VariableNames',{'sample_id','epoch','pair_id','input_pol','az_valid','write_count', ...
        'last_write_id','az_half_p_v','az_half_n_v','az_age_s'});
    result=struct('status','PASS','rows',size(event,1),'adjacent_pairs',size(event,1)-1, ...
        'scope','actual RA UnitDelay old and final-next wires; no transistor-level state claim', ...
        'az_at_ra_start',summary);
end
function [t,x]=series(out,name,width)
    names=out.who;if isstring(names),names=cellstr(names);end
    assert(any(strcmp(names,name)),'sar20Pku:azLog','Missing actual logger %s.',name);
    s=out.get(name);assert(isa(s,'timeseries'),'sar20Pku:azLog','Expected timeseries %s.',name);
    t=s.Time(:);if s.IsTimeFirst,x=reshape(s.Data,numel(t),[]);else,x=reshape(permute(s.Data,[ndims(s.Data) 1:ndims(s.Data)-1]),numel(t),[]);end
    assert(isequal(size(x),[numel(t) width]),'sar20Pku:azWidth','Unexpected logger width %s.',name);
end
