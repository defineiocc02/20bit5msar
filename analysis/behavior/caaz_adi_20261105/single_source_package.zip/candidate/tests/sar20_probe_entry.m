function report=sar20_probe_entry(jobRoot,inputModelSha,toolkitPins)
% One private SATK probe edit in a fresh worker. Caller pins input/toolkit bytes.
% If a partial is unsaved, keep this worker alive for explicit recovery.
    receipt=fullfile(jobRoot,'probe_receipt.json');
    assert(~isfile(receipt)&&~isfolder(receipt),'sar20Pku:probeReceipt','Probe receipt already exists.');
    report=struct('status','started','pid',feature('getpid'),'keep_worker_alive',false);
    try
        report=sar20_add_ra_probes(jobRoot,inputModelSha,toolkitPins);
        try
            write_new(receipt,report);
        catch e
            if report.keep_worker_alive
                fprintf(2,'UNSAVED PRIVATE PARTIAL and receipt write failed: %s\n',getReport(e,'extended','hyperlinks','off'));
                wait_for_recovery(jobRoot);
            end
            rethrow(e)
        end
        if report.keep_worker_alive
            fprintf(2,'UNSAVED PRIVATE PARTIAL: worker retained until explicit recovery.\n');
            wait_for_recovery(jobRoot);
        end
        assert(strcmp(report.status,'SAVED_PENDING_XML_DIFF')&&report.owned_model_closed&& ...
            report.filegen_restored,'sar20Pku:probeFailed','Inspect probe receipt and partial.');
    catch e
        if ~isfile(receipt)
            try,write_new(receipt,struct('status','failed','id',e.identifier,'error',getReport(e,'extended','hyperlinks','off')));catch nested,fprintf(2,'%s\n',getReport(nested,'extended','hyperlinks','off'));end
        end
        rethrow(e)
    end
end
function wait_for_recovery(jobRoot)
    while ~isfile(fullfile(jobRoot,'ALLOW_PROBE_EXIT_AFTER_RECOVERY')),pause(5);end
end
function write_new(file,value)
    assert(~isfile(file)&&~isfolder(file),'sar20Pku:probeReceipt','Receipt exists.');
    f=fopen(file,'w','n','UTF-8');assert(f>=0,'sar20Pku:probeReceipt','Cannot write receipt.');
    c=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(value));
end
