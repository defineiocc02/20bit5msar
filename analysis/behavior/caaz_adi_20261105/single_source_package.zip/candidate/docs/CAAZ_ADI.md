# CAAZ 与 ADI：单主图接口和验证状态

本文件是本次输入侧 CAAZ 与 ADI 前端集成的唯一当前合同。**当前默认仍为已验证的成电 ordinary AZ、单 bank、5 MS/s、N=256；其余配置尚未完成联合资格，不可静默回退到默认。** 现有工作图 SHA-256 `91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e`，实际正常 N256 运行见 `analysis/behavior/public_normal_20261105/release_actual/`。该次 SNDR 99.1328 dB 是此行为模型的实际运行结果，不是 CAAZ/ADI 新结果或芯片测量。

## 三份原文与移植边界

1. 成电 CICC 2026，*A 3.6mW 5MS/s 100dB-SNDR 2-Step SAR ADC with Continuous-Time Second-Stage and Tracking Averaging*：[原文](<PAPERS/01_CICC2026/A_3.6mW_5MS_s_100dB-SNDR_2-Step_SAR_ADC_with_Continuous-Time_Second-Stage_and_Tracking_Averaging.pdf>)，第2页 Fig.2/3、第3页 Fig.4/7。保留其成电主体及当前 baseline 的 5 MS/s、12 次 D2/8 次 TA 调度及 7 次 TA next 命令；新 profile 必须另作实际状态核验；未披露码表/相位仍是模型假设。
2. ADI ISSCC 2024，*A 9.3nV/√Hz 20b 40MS/s 94.2dB DR Signal-Chain Friendly Precision SAR Converter*：[原文](<PAPERS/03_ADI_ISSCC2024/[00]_A_9.3nV_rtHz_20b_40MS_s_94.2dB_DR_Signal-Chain_Friendly_Precision_SAR_Converter.pdf>)，第1–2页及 Fig.9.8.1–2。参考 18 片资源池的采集/转换轮换；其独立两路量化分支、ADC2 位数、40 MS/s 及噪声指标不自动属于本模型。
3. 北大/清华 VLSI 2025，Wang 等，*An 88.8dB-SNDR 6-MS/s Pipelined SAR ADC with A Closed-Loop Dynamic Amplifier Featuring Highly-Linear Full-Scale Output Swing*：[原文](<PAPERS/04_PKU_AZ/Wang_2025_VLSI_C32-1.pdf>) 第2页 Fig.5/6；[同题讲稿](<PAPERS/04_PKU_AZ/C32_C32-1.pdf>) PDF第28–35页。参考 VIN 侧输入换向及隔次 AZ 保持；不将原放大器、6 MS/s 或其定量性能直接移植为成电模型结果。

以前 `CHOP_AZ_SPEC.md` 的残差侧、四相工程提案是历史方案；本次以**输入侧、两相**为准，不能混用两者的数字公式和模拟坐标。

## 四个 profile 与实际状态

| profile | AZ / chop | 前端 | 目前状态 |
|---|---|---|---|
| `cicc` | ordinary AZ，输入不斩波 | 单 bank | 唯一公共默认；保留已验证旧 P 与结果 |
| `caaz` | 输入侧两相 chop、偶写奇保持 | 单 bank | 私有资格候选，未合格前公共工厂明确拒绝 |
| `adi` | ordinary AZ | 18 物理 sDAC 池 | 私有 pool-only 资格候选，未合格前公共工厂拒绝 |
| `combined` | 输入侧两相 chop、偶写奇保持 | 18 物理 sDAC 池 | 私有联合资格候选，未合格前公共工厂拒绝 |

唯一新模式字符串 `pku_input_hold_chop_v1`：开启时 `P.front.input_chop_mode`、`P.backend.az.mode` 和 `P.digital.az_mode` 必须一致。旧 ordinary P 不新增字段；旧 residue `chop`/`hold_chop` 的四相和解调语义不改。未知或未合格模式报错，不能自动改成 `cicc`。私有 `sar20_qualification_profile(base,profile)` 只用于测试候选，不是已批准的公共 profile；是否可运行以本次集成后的真实守卫和回执为准。

## 输入坐标、状态和日历

输入侧极性以**目标采样**为键：`p(id)=1−2·mod(id,2)`，即 `+,-,+,-,...`；epoch 验证身份但不平移极性。正在采集的片使用其目标 `id=n+1` 的 p，当前转换片已保存 `id=n` 的采样状态；不可把 RAW ID 擅自减一。普通配置不改变旧 P 或输入算术。

成电日历仍为 200 ns/CNV、48 组 ADC 事件；baseline 按 12 D2/8 TA 判断及 7 次 TA next 命令安排；新 profile 的对应状态必须实测。CAAZ 偶数 service 在当前 0–31.25 ns 工程分配窗写 AZ，奇数 service 保持同一 `pair=floor(id/2)` 的 RA AZ 存储；`RST_SIG` 清除信号历史而非刷新 AZ 电荷。写入长度、保持误差和开关非重叠为行为候选，非原论文的逐纳秒时序证明。reset/中止、错 epoch、缺失或无效记录不得跨 pair 组合；当前每次仿真 epoch 固定，在线 reset/动态 epoch 支持需另验。

`behavior_public_pol` 对新模式的旧残差路由保持 +1；input p 只用于采集与完整数字码恢复。输入已斩波后，RA 的完整真实 `Qres`、有限 DAC 轨迹和返回前端 `Vtop` 都处于该物理坐标，不能再因 input POL 额外翻转。共享 RA 的原有负反馈及 D2/TA 物理符号保持；ADI 的实际 slice、capture ID/epoch、配置版本、AZ pair 和控制/数字记录必须同源匹配。两相数字恢复在量化前作用于完整输入域组合：`v_out=p(id)·(D1+CT+d)`；当前 post-chop dither 强制 OFF。若将来启用 tail dither，注入位置和符号必须先单独验证，不能复用残差侧 `D1+p·CT+d`。

保持每次真实 AZ 写入一次的物理状态和其有限建立历史；同 pair 的保持服务不能重抽。可重放的输入参考写入噪声需明确 sigma/温度、电容、增益、半支相关性、seed 和来源；RA OU、采样 kTC、比较器与 AZ 不因算法键域不同就被证明物理独立。零 sigma 只适合机制门，不支持宣称 AZ 噪声收益；有泄漏或两次传递系数差异时共同误差不保证全消。

## ADI 的范围和公开数据

成电原文给出 `total sampling capacitor 28 pF`，简图未给 P/N 全部几何；当前 normal 将 1039 Cu/Cs 1024 Cu 解释为**每半边**的口径是模型假设，不得写成论文明确披露每侧28 pF，也不得为匹配论文数值改基线参数。新 ADI 的当前建议几何是18片RDAC、2共享尾组、2完整QDAC：名义制备电容 119.178 pF/half、P+N 合计 238.356 pF；同采 55.296 pF/half、P+N 合计 110.592 pF。这里的 P+N 是物理电容总和，不等于两端口差模等效 C；具体几何和电容解释仍须电路与 PDK 验证。

当前模型扩展目标是 18 个**物理** sDAC 资源池，转换窗口内 8 采集、8 转换、2 备用；release 之后至下一 CNV 为 8 采集、10 停放。首个机制测试可限定 `fixed_ab`：1:8 与 9:16 交替，17:18 停放；这只是 pool-only 对照，尚非完整因果 shuffle，也不是原 ADI 两路量化器的隔离/串扰证明。后续真正18片 plan 只能选已完成采集的物理片。现 single bank 的八项是同一电容阵列数值分段，不能直接称为八个物理器件；第38列旧 17 Cu 断开、单次转换 1039 Cu 口径保持，不恢复 1056 Cu。

四组测试保留原始 `{D1,D2,DT,ID,epoch,valid}`、实际 code20 和完整配置/seed/source 身份。数字解码只使用名义参数，不读实际电容、噪声或隐含状态。单 bank A/B 对照共用当前虚拟芯片；ADI 两组共用同一物理片实例与 plan；跨架构的片间匹配、相关性和总电容资源须明确说明，不能以同 seed 冒充同一物理芯片。

CNV 节拍为 **5 MS/s**；逐帧保存 valid 状态，异常或预热不得补成有效数据。若另作非重叠 pair 平均，则输出为 **2.5 MS/s**，须单独标注带宽、频响和延迟；禁止将其误报为 5 MS/s 全带宽降噪。普通与 CAAZ 的收益比较必须同输入、同带宽、同后处理、有效记录完整，并区分噪声源及 AZ/RA 可能相关性。

## 资格测试接口

私有短测入口约定 `sar20_pku_case(jobRoot,profile,manifestSha)`，分别为 `cicc`、`caaz`、`adi`、`combined` 使用新进程及同一个候选主图；入口与四路源码集成、清单冻结后才可运行。A 以同一实际 N8 P、输入和 seed 对照旧 normal N8 的 RAW/code/time、日志和三根口逐位一致；其余三档在同一候选图真实运行并核 ID/epoch/plan/POL、实际 D1/D2/DT 与完整 signed code，不预设其等于 A。先保留原始 simout、P、源码哈希及失败回执；函数门和全部 N8 联合门通过之前，不改当前图或公共默认。输出容量/时间、异常和未覆盖机制按实际运行记录。
