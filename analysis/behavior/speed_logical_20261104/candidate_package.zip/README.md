# SAR20 后端 NI 标志验证：scalar logical 快路径

本包是独立临时候选，尚未运行 MATLAB/Simulink，也没有任何提速或逐位等价结果。它从已重基的 `/Users/zhaoyi/Obsidan/项目库临时文件夹/sar20_speed_ni_rebase_20261104.BSxduh` 复制，新建 baseline/candidate 两套 110 项 runtime；只改 candidate 的 `behavior_backend_step.m`。旧包与生产均未修改。

## 精确差异与边界

原代码每次 step 对八项 NI 标志调用 `isscalar(v) && ismember(v,[0 1])`。候选只在 `isa(v,'logical') && isscalar(v) && ~issparse(v)` 时不再执行该断言：MATLAB 内置的非稀疏 scalar logical 取值只有 false/true，原断言必然为真；稀疏 logical、其他类型、空值和向量仍逐字执行原断言及其错误 ID/消息。循环字段顺序、schema、动态命令与状态校验、每次 `exist` 依赖检查、公开 kernel/模型接口、物理算术和日志配置均未改。不同错误同时出现时的异常阶段与原代码保持同一结构，但异常堆栈行号会随源码编辑变化。

这不是将 P 校验移动到 setup，也不消除可动态变化的文件/路径 `exist` 检查。该快路径依赖 MATLAB 标准 `ismember` 对 scalar logical 的语义；如果会话路径 shadow/替换 `ismember`，跳过调用可能改变其副作用或异常，不能声称等价。运行时须检查并记录 `which('ismember','-all')`，禁止用不明同名函数替代标准实现。旧模型一次 profiler 记录 NI 字段循环 402,432 次、含子 4.577 s；这是历史带插桩数据，不等于此候选收益。候选改变的是类型分支与验证调用，能否加速需要实际无插桩配对测试。

## 固定身份

- 109 项本机当前源码（六项 NI 修复与 `f567…` 频谱）见 `SOURCE_LOCK.json`；源码树 SHA `84a4bb860f0ecd0989a0e6671510bef15587fe92608187edde22057bcc7dc2c3`。
- 两套图都使用历史 N8 实际运行时 SLX `d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0`，不推断此刻 Windows 图身份。
- baseline 后端 `b6fd6bcd73b8673542a93537a34f5a65d81a49d1a58ef6914230638fb26f4d75`；candidate 后端 `2528e8f389426747a634e873dc166f9c51c1a83bdfecf7f049f02c3b4ce77834`。
- 原 N8 源 ZIP 仅作祖先，六项 NI 重基后本包已不等于该 ZIP。NI 补丁本身的生产 smoke 与本候选是不同证据。

## 测试与可复现顺序

1. `python3 tests/verify_static.py` 只检查唯一差异、两套 110 项 runtime、测试别名和全部文件哈希；`tests/check_mismatch_fixture.py` 及 `mismatch_proxy.json` 只确认合成实际/replica 失配刺激可见，不是 PDK 或 MATLAB 证据。
2. 在新的独立 MATLAB 进程调用 `test_flag_validation`，逐一给八个标志输入非稀疏和稀疏 scalar logical 的 false/true、logical 空值/向量、数值 0/1/非法值、NaN/Inf、整型、single、复数、字符、字符串、cell 和 struct。每个输入比较完整 state/y 数值位、类型/形状，或同一异常 ID 与消息，并比较最后一个 warning 的 ID/消息；测试也记录 `ismember` 解析与核对全局 RNG。该门不能统计多条重复 warning，出现任何 warning 应保留并单独检查完整日志。
3. 用另一个干净进程调用 `test_backend_unit`：比较完整后端 state/y 的实际/replica 双向合成失配、kick、reset、非零 qB/vx、finite-DAC forcing、AZ 序列、OU ON 和异常。`test_event_stage` 对同一事件流的全部 48 状态字与 8 观察字，在每个 advance/commit 阶段逐字节比较。两者均非整图仿真。
4. 新进程只加入 `tests` 和 `tests/aliases`、不含 `sar20_cdac2_network` 时调用 `test_missing_dependency`；两版均须报 `behavior:dependency`，不能以 setup 判定替代该动态路径门。
5. `run_one_variant` 在**两个独立 MATLAB 进程**各跑一侧：复制并哈希同一完整 N8 P 后分别执行 baseline/candidate；`compare_runs` 比较全部 `SimulationOutput.who` 变量、timeseries Time/Data 和 root `yout` 的类型、形状及字节。N8 通过后对同一完整 N256 P 复测；至少三组交替 AB/BA 的未插桩计时才可描述本机速度分布。每次实测同时保存输入、模型、源码、运行回执和原始仿真输出。

示例（**本轮不要执行**，也不要在 PID 27628 中运行）：

```matlab
addpath(fullfile(pkg,'tests'));
test_flag_validation
% 另一个新进程：test_backend_unit；再一个新进程：test_event_stage
% 各另起进程：run_one_variant('baseline',pFile,'n8_base_01')
%            run_one_variant('candidate',pFile,'n8_cand_01')
% 然后：compare_runs('n8_base_01','n8_cand_01','n8_cmp_01')
```

脚本仅使用包内拷贝模型与源码，所有运行产物及 cache/codegen 留在包内唯一 `runs/`；不调用生产 `SAR20('apply')`。模型加载前后及仿真后记录 backend/CT 函数路径和缓存路径；此检查不证明缓存字节一致。每个文件读取上限 300 MB，异常应保留现场，不自动重复。
