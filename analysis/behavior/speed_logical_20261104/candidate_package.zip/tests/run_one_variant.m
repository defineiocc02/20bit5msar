function result=run_one_variant(variant,parameterFile,runId)
% Run ONE A/B side in a fresh disposable MATLAB process. No production model.
% variant: 'baseline' or 'candidate'; parameterFile: complete prepared P MAT.
% Results and file-generation folders are restricted to this package's runs/.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Speed:interactive','Refuse the known user session.');
    assert(any(strcmp(variant,{'baseline','candidate'})),'sar20Speed:variant','Bad variant.');
    assert(ischar(runId)&&~isempty(regexp(runId,'^[A-Za-z0-9_-]+$','once')), ...
        'sar20Speed:runId','Use a unique alphanumeric run ID.');
    systems=find_system('SearchDepth',0,'Type','block_diagram');
    for k=1:numel(systems)
        assert(bdIsLibrary(systems{k}),'sar20Speed:session','A model is already loaded.');
    end
    output=fullfile(pkg,'runs',runId);
    assert(~isfolder(output)&&~isfile(output),'sar20Speed:exists','Never overwrite a run.');
    [ok,msg,msgId]=mkdir(output);
    assert(ok&&isempty(msgId),'sar20Speed:mkdir','New run directory was not exclusively created: %s',msg);
    result=struct('status','preflight','variant',variant,'pid',feature('getpid'), ...
        'scope','isolated cloned runtime and model; no production apply/save');
    try
        fixtureHash=sha(parameterFile);
        fixtureCopy=fullfile(output,'P_fixture.mat');
        [ok,msg]=copyfile(parameterFile,fixtureCopy);assert(ok,'sar20Speed:copy','%s',msg);
        assert(strcmp(sha(parameterFile),fixtureHash)&&strcmp(sha(fixtureCopy),fixtureHash), ...
            'sar20Speed:fixtureCopy','Input P changed while copying.');
        data=load_bounded(fixtureCopy);P=data.P;
        assert(isfield(P,'N')&&any(P.N==[8 256]),'sar20Speed:N','Use N8 or N256.');
        for key={'training','cal_cfg','frozen','bank'}
            f=key{1};assert(isfield(P,f)&&isstruct(P.(f))&&isfield(P.(f),'enabled')&& ...
                ~P.(f).enabled,'sar20Speed:externalState','%s must be OFF.',f);
        end
        result.fixture_sha256=fixtureHash;result.N=P.N;
        runtime=fullfile(pkg,variant);src=fullfile(runtime,'current','src');
        modelFile=fullfile(runtime,'current','models','SarAdc.slx');
        assert(strcmp(sha(modelFile),'d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0'), ...
            'sar20Speed:model','Unexpected frozen model bytes.');
        index=jsondecode(fileread(fullfile(pkg,'RUNTIME_INDEX.json')));
        validate_runtime(pkg,variant,index);
        addpath(genpath(src),fullfile(runtime,'config'),'-begin');
        expected=fullfile(src,'physics','behavior_backend_step.m');
        result.binding_before_load=check_binding(src,true);
        result.ismember_before_load=standard_ismember();
        status=profile('status');
        assert(strcmp(status.ProfilerStatus,'off'),'sar20Speed:profiler','Timing requires profiler OFF.');
        cd(output);
        Simulink.fileGenControl('set','CacheFolder',fullfile(output,'cache'), ...
            'CodeGenFolder',fullfile(output,'codegen'),'keepPreviousPath',true,'createDir',true);
        cfg=Simulink.fileGenControl('getConfig');
        assert(under(cfg.CacheFolder,output)&&under(cfg.CodeGenFolder,output), ...
            'sar20Speed:fileGen','File-generation paths must remain inside this run.');
        load_system(modelFile);guard=onCleanup(@()close_system('SarAdc',0)); %#ok<NASGU>
        assert(strcmpi(strrep(get_param('SarAdc','FileName'),'\','/'),strrep(modelFile,'\','/')), ...
            'sar20Speed:modelPath','Loaded a different model.');
        result.binding_after_load=check_binding(src,false);
        result.ismember_after_load=standard_ismember();
        si=Simulink.SimulationInput('SarAdc');
        si=si.setVariable('P',P,'Workspace','SarAdc');
        si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        result.status='running';write_json(fullfile(output,'receipt.json'),result);
        started=tic;simout=sim(si);result.sim_s=toc(started);
        save(fullfile(output,'simout.mat'),'simout','-v7.3');
        result.simout_bytes=dir_size(fullfile(output,'simout.mat'));
        assert(isempty(simout.ErrorMessage),'sar20Speed:sim','%s',simout.ErrorMessage);
        assert(result.simout_bytes<=300e6,'sar20Speed:large','Saved output exceeds read limit.');
        V=behavior_record_view(simout,P);
        assert(size(V.raw,1)==P.N&&all(V.raw(:,6)==1)&& ...
            isequal(V.raw(:,4),(P.first_id:P.first_id+P.N-1).')&& ...
            all(V.raw(:,5)==P.epoch),'sar20Speed:records','Invalid record selection.');
        assert(strcmp(sha(fixtureCopy),fixtureHash),'sar20Speed:fixtureCopy','Copied P changed during simulation.');
        validate_runtime(pkg,variant,index);
        result.binding_after_sim=check_binding(src,false);
        result.ismember_after_sim=standard_ismember();
        assert(strcmp(sha(modelFile),'d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0'), ...
            'sar20Speed:model','Frozen model changed during simulation.');
        result.logs=simout.who;result.records=size(V.raw,1);result.simout_sha256=sha(fullfile(output,'simout.mat'));
        result.backend_sha256=sha(expected);result.model_sha256=sha(modelFile);
        result.status='completed_uncompared';write_json(fullfile(output,'receipt.json'),result);
    catch ex
        result.status='failed';result.error_id=ex.identifier;
        result.error=getReport(ex,'extended','hyperlinks','off');
        write_json(fullfile(output,'receipt.json'),result);rethrow(ex)
    end
end
function info=standard_ismember
    actual=which('ismember');root=lower(strrep(matlabroot,'\','/'));
    resolved=lower(strrep(actual,'\','/'));
    standard=startsWith(resolved,[root '/'])||startsWith(resolved,['built-in (' root '/']);
    assert(standard,'sar20Speed:ismember','Nonstandard ismember resolution: %s.',actual);
    info=struct('primary',actual,'all_paths',{which('ismember','-all')});
end
function info=check_binding(src,requireFresh)
    names={'behavior_backend_step','sar20_cdac2_network'};
    loaded=inmem('-completenames');
    info=struct('name',{},'primary',{},'cached_paths',{});
    for i=1:numel(names)
        name=names{i};expected=fullfile(src,'physics',[name '.m']);actual=which(name);
        assert(strcmpi(strrep(actual,'\','/'),strrep(expected,'\','/')), ...
            'sar20Speed:path','%s is not resolved from the isolated runtime.',name);
        cache={};
        for j=1:numel(loaded)
            [~,stem]=fileparts(loaded{j});
            if strcmpi(stem,name)
                assert(~requireFresh,'sar20Speed:cache','%s was already cached; start a fresh process.',name);
                assert(strcmpi(strrep(loaded{j},'\','/'),strrep(expected,'\','/')), ...
                    'sar20Speed:cache','%s is cached from another path.',name);
                cache{end+1}=loaded{j}; %#ok<AGROW>
            end
        end
        info(end+1)=struct('name',name,'primary',actual,'cached_paths',{cache}); %#ok<AGROW>
    end
end
function data=load_bounded(file)
    assert(dir_size(file)<=300e6,'sar20Speed:large','Fixture exceeds read limit.');
    data=load(file,'P');assert(isfield(data,'P')&&isstruct(data.P),'sar20Speed:fixture','Missing P.');
end
function validate_runtime(pkg,variant,index)
    rows=index.(variant);
    for k=1:numel(rows)
        f=fullfile(pkg,variant,char(rows(k).path));
        assert(isfile(f)&&strcmp(sha(f),char(rows(k).sha256)), ...
            'sar20Speed:runtime','Runtime hash mismatch: %s.',f);
    end
end
function tf=under(child,parent)
    c=lower(strrep(char(java.io.File(child).getCanonicalPath()),'\','/'));
    p=lower(strrep(char(java.io.File(parent).getCanonicalPath()),'\','/'));
    tf=strcmp(c,p)||startsWith(c,[p '/']);
end
function n=dir_size(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir,'sar20Speed:file','Missing file %s.',file);n=d.bytes;
end
function h=sha(file)
    assert(dir_size(file)<=300e6,'sar20Speed:large','File exceeds read limit.');
    f=fopen(file,'rb');assert(f>=0,'sar20Speed:read','Cannot read %s.',file);
    guard=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
function write_json(file,value)
    f=fopen(file,'w','n','UTF-8');assert(f>=0,'sar20Speed:receipt','Cannot write receipt.');
    guard=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(value));
end
