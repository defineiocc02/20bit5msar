function report=test_flag_validation
% Compare complete public kernel outcomes across NI flag classes and values.
% Only in a fresh, disposable MATLAB process; no model update or simulation.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Flag:interactive','Refuse the known user session.');
    assert(~bdIsLoaded('SarAdc'),'sar20Flag:modelLoaded','Use an empty session.');
    names={'behavior_backend_step_baseline','behavior_backend_step_candidate','sar20_cdac2_network'};
    uncached=[names {'behavior_backend_unpack','behavior_ra_noise_validate_backend'}];
    loaded=inmem('-completenames');
    for i=1:numel(loaded)
        [~,name]=fileparts(loaded{i});
        assert(~any(strcmpi(name,uncached)),'sar20Flag:cache','%s is already cached.',name);
    end
    oldPath=path;guard=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(pkg,'baseline','current','src')),'-begin');
    addpath(fullfile(pkg,'tests','aliases'),'-begin');
    for k=1:2
        expected=fullfile(pkg,'tests','aliases',[names{k} '.m']);
        assert(strcmpi(strrep(which(names{k}),'\','/'),strrep(expected,'\','/')), ...
            'sar20Flag:path','Unexpected test alias.');
    end
    expected=fullfile(pkg,'baseline','current','src','physics','sar20_cdac2_network.m');
    assert(strcmpi(strrep(which(names{3}),'\','/'),strrep(expected,'\','/')), ...
        'sar20Flag:path','Unexpected CT source.');
    expected=fullfile(pkg,'baseline','current','src','physics','behavior_backend_unpack.m');
    assert(strcmpi(strrep(which('behavior_backend_unpack'),'\','/'),strrep(expected,'\','/')), ...
        'sar20Flag:path','Unexpected backend state unpacker.');
    expected=fullfile(pkg,'baseline','current','src','physics','behavior_ra_noise_validate_backend.m');
    assert(strcmpi(strrep(which('behavior_ra_noise_validate_backend'),'\','/'),strrep(expected,'\','/')), ...
        'sar20Flag:path','Unexpected RA validator.');
    ismemberBinding=standard_ismember();
    q=load(fullfile(pkg,'fixtures','n8_parameters.mat'),'P');p=q.P.backend;
    assert(~p.ni.ra_noise&&~p.ni.az,'sar20Flag:fixture','Expected RA/AZ OFF fixture.');
    s=behavior_backend_unpack(q.P.xBK0);c=s.command;
    flags={'cap_mismatch','cinc_kick','az','ra_noise','az_noise', ...
        'reference_noise','nonlinear_ra','replica_delay'};
    values={false,true,sparse(false),sparse(true),logical([]),logical([0 1]),0,1,-1,2,NaN,Inf, ...
        int8(0),uint32(2),single(1),complex(0,1),'x',string('x'),{0},struct('value',1)};
    labels={'logical_false','logical_true','sparse_false','sparse_true','logical_empty','logical_vector','double_zero', ...
        'double_one','double_minus_one','double_two','nan','inf','int8_zero', ...
        'uint32_two','single_one','complex','char','string','cell','struct'};
    assert(numel(values)==numel(labels),'sar20Flag:matrix','Test matrix mismatch.');
    assert(isa(values{3},'logical')&&issparse(values{3})&&isscalar(values{3})&&~values{3}&& ...
        isa(values{4},'logical')&&issparse(values{4})&&isscalar(values{4})&&values{4}, ...
        'sar20Flag:sparseFixture','Sparse false/true fixtures must really be sparse logical scalars.');
    rows=struct('field',{},'case_name',{},'baseline_status',{},'error_id',{}, ...
        'warning_id',{},'warning_message',{});
    before=rng;
    for i=1:numel(flags)
        for j=1:numel(values)
            pp=p;pp.ni.(flags{i})=values{j};
            a=outcome(@()behavior_backend_step_baseline(s,c,0,pp));
            b=outcome(@()behavior_backend_step_candidate(s,c,0,pp));
            compare(a,b,[flags{i} '/' labels{j}]);
            rows(end+1)=struct('field',flags{i},'case_name',labels{j}, ...
                'baseline_status',a.status,'error_id',a.id, ...
                'warning_id',a.warning_id,'warning_message',a.warning_message); %#ok<AGROW>
        end
    end
    assert(isequaln(before,rng),'sar20Flag:rng','Global RNG changed.');
    report=struct('status','passed','cases',numel(rows),'rows',rows, ...
        'ismember_binding',ismemberBinding, ...
        'scope','exact state/y or error ID/message for isolated direct kernel; no timing claim');
end
function info=standard_ismember
    actual=which('ismember');root=lower(strrep(matlabroot,'\','/'));
    resolved=lower(strrep(actual,'\','/'));
    standard=startsWith(resolved,[root '/'])||startsWith(resolved,['built-in (' root '/']);
    assert(standard,'sar20Flag:ismember','Nonstandard ismember resolution: %s.',actual);
    info=struct('primary',actual,'all_paths',{which('ismember','-all')});
end
function result=outcome(fun)
    lastwarn('');
    try
        [s,y]=fun();result=struct('status','returned','id','','message','','state',s,'output',y);
    catch ex
        result=struct('status','error','id',ex.identifier,'message',ex.message,'state',[],'output',[]);
    end
    [result.warning_message,result.warning_id]=lastwarn;
end
function compare(a,b,where)
    assert(strcmp(a.status,b.status)&&strcmp(a.id,b.id)&&strcmp(a.message,b.message)&& ...
        strcmp(a.warning_id,b.warning_id)&&strcmp(a.warning_message,b.warning_message), ...
        'sar20Flag:error','Return/error contract differs at %s.',where);
    if strcmp(a.status,'returned')
        same_bits(a.state,b.state,[where '.state']);same_bits(a.output,b.output,[where '.output']);
    end
end
function same_bits(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'sar20Flag:type','Class or size differs at %s.',where);
    if isstruct(a)
        fa=fieldnames(a);assert(isequal(fa,fieldnames(b)),'sar20Flag:fields','Fields differ at %s.',where);
        for i=1:numel(a)
            for j=1:numel(fa),same_bits(a(i).(fa{j}),b(i).(fa{j}),[where '.' fa{j}]);end
        end
    elseif isnumeric(a)
        assert(isreal(a)==isreal(b)&&isequal(typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')), ...
            'sar20Flag:bits','Numeric bits differ at %s.',where);
        if ~isreal(a)
            assert(isequal(typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')), ...
                'sar20Flag:bits','Imaginary bits differ at %s.',where);
        end
    elseif iscell(a)
        for i=1:numel(a),same_bits(a{i},b{i},where);end
    else
        assert(isequaln(a,b),'sar20Flag:value','Value differs at %s.',where);
    end
end
