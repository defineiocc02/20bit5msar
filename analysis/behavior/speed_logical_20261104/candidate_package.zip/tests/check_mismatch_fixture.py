#!/usr/bin/env python3
"""Independent sensitivity screening only; not MATLAB or bit-equivalence evidence."""
import hashlib
import json
from pathlib import Path

import h5py
import numpy as np

fixture = Path(__file__).resolve().parents[1] / 'fixtures/n8_parameters.mat'
assert fixture.stat().st_size <= 300_000_000
digest = hashlib.sha256(fixture.read_bytes()).hexdigest()
with h5py.File(fixture, 'r') as h:
    group = h['P/backend/ct/net_nominal']
    names = ('cinc_f', 'bridge_f', 'main_f', 'sub_f', 'track_f',
             'parasitic_main_f', 'parasitic_sub_f', 'dummy_f')
    net = {name: np.array(group[name]).T for name in names}
    vref = float(np.array(h['P/backend/ct/reference_v'])[0, 0])


def vy(n):
    d = np.array([1., -1.] * 6)
    t = np.array([1., -1., 1., -1., 1., -1., 1.])
    qb = (3e-15, -2e-15)
    nodes = []
    for side in range(2):
        cs = n['cinc_f'].ravel()[side]
        cb = n['bridge_f'].ravel()[side]
        cm = n['main_f'][side]
        cl = n['sub_f'][side]
        ct = n['track_f'][side]
        polarity = 1 - 2 * side
        a = cs + np.sum(cm) + cb + n['parasitic_main_f'].ravel()[side]
        b = np.sum(cl) + np.sum(ct) + n['dummy_f'].ravel()[side] + cb + n['parasitic_sub_f'].ravel()[side]
        qin = np.array([cs * polarity * 0.137 / 2, 0.])
        qdac = -polarity * vref / 2 * np.array([cm @ d[:len(cm)], cl @ d[len(cm):]])
        qtrack = -polarity * vref / 2 * np.array([0., ct @ t])
        qmemory = np.array([-cb * qb[side] / b, qb[side]])
        nodes.append(np.linalg.solve([[a, -cb], [-cb, b]], qin + qdac + qtrack + qmemory)[0])
    return nodes[0] - nodes[1]


base = vy(net)
effects = []
for side_a, factor_a, side_r, factor_r in ((0, 1.03, 1, 0.98), (1, 0.97, 0, 1.02)):
    actual = {k: v.copy() for k, v in net.items()}
    replica = {k: v.copy() for k, v in net.items()}
    actual['main_f'][side_a, 0] *= factor_a
    replica['main_f'][side_r, 0] *= factor_r
    effects.append((vy(actual) - base, vy(replica) - base))
effects = np.array(effects)
assert np.isfinite(effects).all() and (np.abs(effects) > 1e-8).all()
assert (effects[0] * effects[1] < 0).all()
print(json.dumps({'status': 'proxy_sensitivity_pass', 'fixture_sha256': digest,
                  'nominal_vy_v': base, 'actual_replica_deltas_v': effects.tolist(),
                  'scope': 'synthetic CT perturbation visibility only; not MATLAB, PDK or performance'}, indent=2))
