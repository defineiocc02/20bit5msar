function report=compare_runs(baselineId,candidateId,comparisonId)
% Compare every SimulationOutput variable, including timeseries and root yout.
% All paths are restricted to this package's unique runs/ directory.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    ids={baselineId,candidateId,comparisonId};
    for i=1:numel(ids)
        assert(ischar(ids{i})&&~isempty(regexp(ids{i},'^[A-Za-z0-9_-]+$','once')), ...
            'sar20Speed:id','Use simple unique IDs.');
    end
    aDir=fullfile(pkg,'runs',baselineId);bDir=fullfile(pkg,'runs',candidateId);
    outDir=fullfile(pkg,'runs',comparisonId);
    assert(~isfolder(outDir)&&~isfile(outDir),'sar20Speed:exists','Never overwrite a comparison.');
    ar=jsondecode(fileread(fullfile(aDir,'receipt.json')));
    br=jsondecode(fileread(fullfile(bDir,'receipt.json')));
    assert(strcmp(ar.status,'completed_uncompared')&&strcmp(br.status,'completed_uncompared')&& ...
        strcmp(ar.variant,'baseline')&&strcmp(br.variant,'candidate'), ...
        'sar20Speed:receipt','Both requested variants must have completed.');
    assert(strcmp(ar.fixture_sha256,br.fixture_sha256)&&strcmp(ar.model_sha256,br.model_sha256)&& ...
        ar.N==br.N,'sar20Speed:identity','P/model/N differ between runs.');
    af=fullfile(aDir,'simout.mat');bf=fullfile(bDir,'simout.mat');
    assert(strcmp(sha(af),ar.simout_sha256)&&strcmp(sha(bf),br.simout_sha256), ...
        'sar20Speed:simout','Stored output identity changed.');
    aa=load(af,'simout');bb=load(bf,'simout');a=aa.simout;b=bb.simout;
    assert(isa(a,'Simulink.SimulationOutput')&&isa(b,'Simulink.SimulationOutput')&& ...
        isempty(a.ErrorMessage)&&isempty(b.ErrorMessage),'sar20Speed:output','Output is not an error-free simulation.');
    na=sort(a.who);nb=sort(b.who);
    assert(isequal(na,nb),'sar20Speed:logSet','Output variable sets differ.');
    required={'event_log','front_log','back_log','control_log','raw_log', ...
        'ready_log','record_log','record_ready_log','code_log','yout'};
    assert(all(ismember(required,na)),'sar20Speed:required','A required log or root output is missing.');
    for k=1:numel(na),same_value(a.get(na{k}),b.get(nb{k}),na{k});end
    [ok,msg,msgId]=mkdir(outDir);
    assert(ok&&isempty(msgId),'sar20Speed:mkdir','New comparison directory was not exclusively created: %s',msg);
    report=struct('status','all_actual_output_variables_bit_equal', ...
        'baseline',baselineId,'candidate',candidateId,'variables',{na}, ...
        'N',ar.N,'fixture_sha256',ar.fixture_sha256,'model_sha256',ar.model_sha256, ...
        'baseline_sim_s',ar.sim_s,'candidate_sim_s',br.sim_s, ...
        'scope','one paired isolated simulation; equality, not a stable speed distribution');
    f=fopen(fullfile(outDir,'comparison.json'),'w','n','UTF-8');
    assert(f>=0,'sar20Speed:receipt','Cannot write comparison.');
    guard=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(report));
end
function same_value(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'sar20Speed:type','Class or shape differs: %s.',where);
    if isa(a,'timeseries')
        assert(a.IsTimeFirst==b.IsTimeFirst,'sar20Speed:timeFirst','Time orientation differs: %s.',where);
        same_value(a.Time,b.Time,[where '.Time']);same_value(a.Data,b.Data,[where '.Data']);
    elseif isa(a,'Simulink.SimulationData.Dataset')
        assert(a.numElements==b.numElements,'sar20Speed:dataset','Dataset count differs: %s.',where);
        for j=1:a.numElements
            x=a.getElement(j);y=b.getElement(j);
            assert(strcmp(class(x),class(y))&&isprop(x,'Name')&&isprop(x,'Values')&& ...
                isequal(x.Name,y.Name),'sar20Speed:signal','Dataset signal differs: %s.',where);
            same_value(x.Values,y.Values,sprintf('%s[%d]',where,j));
        end
    elseif isnumeric(a)
        assert(isreal(a)==isreal(b),'sar20Speed:complex','Complexity differs: %s.',where);
        assert(isequal(typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')), ...
            'sar20Speed:bits','Real bits differ: %s.',where);
        if ~isreal(a)
            assert(isequal(typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')), ...
                'sar20Speed:bits','Imaginary bits differ: %s.',where);
        end
    elseif islogical(a)||ischar(a)||isstring(a)
        assert(isequaln(a,b),'sar20Speed:value','Value differs: %s.',where);
    else
        error('sar20Speed:unhandled','Cannot silently skip output class %s at %s.',class(a),where);
    end
end
function h=sha(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'sar20Speed:large','File absent or exceeds read limit: %s.',file);
    f=fopen(file,'rb');assert(f>=0,'sar20Speed:read','Cannot read %s.',file);
    guard=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
