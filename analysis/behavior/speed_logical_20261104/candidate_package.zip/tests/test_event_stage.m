function report=test_event_stage
% Compare all 48 state words and 8 observations after each ordered stage.
% This is a direct event-stage replay, not a Simulink run or timing result.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Event:interactive','Refuse the known user session.');
    assert(~bdIsLoaded('SarAdc'),'sar20Event:modelLoaded','Use an empty session.');
    names={'behavior_backend_stage_baseline','behavior_backend_stage_candidate', ...
        'behavior_backend_step_baseline','behavior_backend_step_candidate','sar20_cdac2_network'};
    uncached=[names {'behavior_backend_unpack','behavior_backend_pack'}];
    loaded=inmem('-completenames');
    for i=1:numel(loaded)
        [~,stem]=fileparts(loaded{i});
        assert(~any(strcmpi(stem,uncached)),'sar20Event:cache','%s is already cached.',stem);
    end
    oldPath=path;guard=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(pkg,'baseline','current','src')),'-begin');
    addpath(fullfile(pkg,'tests','aliases'),'-begin');
    for i=1:4
        expected=fullfile(pkg,'tests','aliases',[names{i} '.m']);
        assert(strcmpi(strrep(which(names{i}),'\','/'),strrep(expected,'\','/')), ...
            'sar20Event:path','Unexpected stage/step alias.');
    end
    expected=fullfile(pkg,'baseline','current','src','physics','sar20_cdac2_network.m');
    assert(strcmpi(strrep(which(names{5}),'\','/'),strrep(expected,'\','/')), ...
        'sar20Event:path','Unexpected CT function.');
    expected=fullfile(pkg,'baseline','current','src','physics','behavior_backend_unpack.m');
    assert(strcmpi(strrep(which('behavior_backend_unpack'),'\','/'),strrep(expected,'\','/')), ...
        'sar20Event:path','Unexpected backend state unpacker.');
    expected=fullfile(pkg,'baseline','current','src','physics','behavior_backend_pack.m');
    assert(strcmpi(strrep(which('behavior_backend_pack'),'\','/'),strrep(expected,'\','/')), ...
        'sar20Event:path','Unexpected backend state packer.');
    q=load(fullfile(pkg,'fixtures','n8_parameters.mat'),'P');P=q.P;p=P.backend;
    assert(~p.ni.ra_noise&&~p.ni.az&& ...
        (~p.dac_coupling.enabled||~any(p.dac_coupling.tau_dac_s>0)), ...
        'sar20Event:fixture','Expected RA/AZ/finite-DAC OFF.');
    before=rng;count=0;
    for mismatch=0:1
        p.ni.cap_mismatch=logical(mismatch);
        a=double(P.xBK0(:));b=a;initial=behavior_backend_unpack(a);c=initial.command;
        for k=1:48
            t=(k-1)*1.25e-9;
            sgn=repmat([1;-1],6,1);if mod(k,2)==0,sgn=-sgn;end
            track=[1;-1;1;-1;1;-1;1];if mod(k,3)==0,track=-track;end
            active=mod(k,4)~=0;reset=~active;
            v=[double(k)*1e-16;c.ctop_f;sgn;track;double(active);0;double(reset); ...
                floor((k-1)/16);double(P.epoch)];
            [a,oa]=behavior_backend_stage_baseline('advance',a,t,v,p);
            [b,ob]=behavior_backend_stage_candidate('advance',b,t,v,p);
            same(a,b,'advance_state');same(oa,ob,'advance_obs');count=count+1;
            [a,oa]=behavior_backend_stage_baseline('commit',a,t,v,p);
            [b,ob]=behavior_backend_stage_candidate('commit',b,t,v,p);
            same(a,b,'commit_state');same(oa,ob,'commit_obs');count=count+1;
        end
    end
    assert(isequaln(before,rng),'sar20Event:rng','Global RNG changed.');
    report=struct('status','passed','compared_stages',count, ...
        'scope','ordered direct stage outputs; full SLX logs require separate A/B');
end
function same(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b))&& ...
        isnumeric(a)&&isreal(a)&&isreal(b)&& ...
        isequal(typecast(a(:),'uint8'),typecast(b(:),'uint8')), ...
        'sar20Event:bits','Bits or shape differ at %s.',where);
end
