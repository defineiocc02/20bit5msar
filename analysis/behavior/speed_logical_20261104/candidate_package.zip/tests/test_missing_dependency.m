function report=test_missing_dependency
% Run separately in a fresh disposable process with ONLY tests/aliases on path.
% Do not put either project runtime or sar20_cdac2_network on the MATLAB path.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Speed:interactive','Refuse the known user session.');
    assert(isempty(which('sar20_cdac2_network')),'sar20Speed:fixture','Dependency must be absent.');
    loaded=inmem('-completenames');
    for i=1:numel(loaded)
        [~,name]=fileparts(loaded{i});
        assert(~any(strcmpi(name,{'sar20_cdac2_network','behavior_backend_step_baseline', ...
            'behavior_backend_step_candidate'})),'sar20Speed:cache', ...
            'Dependency or test alias is cached.');
    end
    addpath(fullfile(pkg,'tests','aliases'),'-begin');
    for name={'behavior_backend_step_baseline','behavior_backend_step_candidate'}
        expected=fullfile(pkg,'tests','aliases',[name{1} '.m']);
        assert(strcmpi(strrep(which(name{1}),'\','/'),strrep(expected,'\','/')), ...
            'sar20Speed:path','Unexpected alias resolution.');
    end
    q=load(fullfile(pkg,'fixtures','n8_parameters.mat'),'P');p=q.P.backend;
    assert(~p.ni.ra_noise&&~p.ni.az,'sar20Speed:fixture','Expected RA/AZ OFF fixture.');
    c=struct('qres_c',0,'ctop_f',1e-12,'d2_signs',zeros(12,1), ...
        'ta_signs',zeros(7,1),'ra_on',false,'az_on',false,'reset',true, ...
        'sample_id',-1,'epoch',0);
    [a,ma]=caught(@()behavior_backend_step_baseline([],c,0,p));
    [b,mb]=caught(@()behavior_backend_step_candidate([],c,0,p));
    assert(strcmp(a,'behavior:dependency')&&strcmp(a,b)&&strcmp(ma,mb), ...
        'sar20Speed:dependency','Missing-dependency error differs.');
    report=struct('status','passed','scope','direct kernel missing dependency; isolated process only');
end
function [id,message]=caught(fun)
    try,fun();catch ex,id=ex.identifier;message=ex.message;return;end
    error('sar20Speed:noError','Missing dependency did not fail.');
end
