function root=n8_jobroot(jobRoot,bundle)
% Accept only a real, unsymlinked task directory directly under D:/Temp.
    assert(ispc&&ischar(jobRoot)&&isfolder(jobRoot),'i1N8:job', ...
        'Use an existing Windows task directory D:/Temp/SAR20I1N8_<id>.');
    jf=java.io.File(jobRoot);jp=jf.toPath();
    absPath=char(jp.toAbsolutePath().normalize().toString());
    opts=javaArray('java.nio.file.LinkOption',0);
    realPath=char(jp.toRealPath(opts).toString());
    a=lower(strrep(absPath,'\','/'));b=lower(strrep(realPath,'\','/'));
    assert(strcmp(a,b),'i1N8:jobReparse','Task path may not traverse a symlink or reparse point.');
    assert(~isempty(regexp(b,'^d:/temp/sar20i1n8_[a-z0-9_-]+$','once')), ...
        'i1N8:job','Task root must be a direct uniquely named child of D:/Temp.');
    bf=java.io.File(bundle);bp=bf.toPath();
    bReal=lower(strrep(char(bp.toRealPath(opts).toString()),'\','/'));
    assert(startsWith(bReal,[b '/']),'i1N8:bundlePath','Bundle must be inside the same task root.');
    root=realPath;
end
