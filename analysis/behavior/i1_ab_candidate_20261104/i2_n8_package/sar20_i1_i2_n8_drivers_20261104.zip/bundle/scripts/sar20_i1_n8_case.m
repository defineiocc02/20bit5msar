function result=sar20_i1_n8_case(jobRoot,caseName)
% Run exactly one I2 arm in a new disposable batch. No production path writes.
% A later I1 driver is separate. No run occurs merely by loading this file.
    scripts=fileparts(mfilename('fullpath'));bundle=fileparts(scripts);bootstrap(scripts);
    assert(ischar(caseName)&&any(strcmp(caseName,{'baseline_i2','candidate_i2'})), ...
        'i1N8:case','Use baseline_i2 or candidate_i2.');
    jobRoot=n8_jobroot(jobRoot,bundle);
    assert(feature('getpid')~=27628&&~usejava('desktop'),'i1N8:interactive', ...
        'A newly launched headless batch is required.');
    systems=find_system('SearchDepth',0,'Type','block_diagram');
    for k=1:numel(systems),assert(bdIsLibrary(systems{k}),'i1N8:loaded','Start a fresh process with no model loaded.');end
    variant='baseline';if strcmp(caseName,'candidate_i2'),variant='candidate';end
    outdir=fullfile(jobRoot,caseName);
    assert(~isfolder(outdir)&&~isfile(outdir),'i1N8:exists','Never reuse a case directory.');
    [ok,msg,msgid]=mkdir(outdir);assert(ok&&isempty(msgid),'i1N8:mkdir','%s',msg);
    result=struct('status','started','case_name',caseName,'variant',variant, ...
        'pid',feature('getpid'),'model_identity','historical d4 SLX; candidate v4 source overlay', ...
        'scope','isolated N8, no model apply or save');
    oldPath=path;oldCwd=pwd;restore=onCleanup(@()restore_env(oldPath,oldCwd)); %#ok<NASGU>
    try
        manifest=n8_check_inputs(bundle,variant);
        original=fullfile(bundle,'fixture','parameters.mat');copy=fullfile(outdir,'P_fixture.mat');
        [ok,msg]=copyfile(original,copy);assert(ok,'i1N8:copy','%s',msg);
        assert(strcmp(n8_sha256(copy),manifest.fixture_sha256),'i1N8:copy','P fixture copy differs.');
        data=load(copy,'P');assert(isfield(data,'P')&&isstruct(data.P)&&isscalar(data.P), ...
            'i1N8:fixture','Complete saved P required.');
        P=data.P;
        assert(P.N==8&&P.first_id==4&&P.epoch==1&&P.Ts_s==200e-9&& ...
            ~P.transport.enabled&&~P.debug.adi_enabled&&~P.debug.aperture_enabled, ...
            'i1N8:fixtureScope','Original P must be the saved N8 direct-RAW debug-off fixture.');
        for key={'training','cal_cfg','frozen','bank'}
            name=key{1};assert(isfield(P,name)&&isfield(P.(name),'enabled')&&~P.(name).enabled, ...
                'i1N8:calibration','Saved %s must be off.',name);
        end
        assert(~isfield(P.front,'schedule_mode')&&~isfield(P.front,'acq_guard_s'), ...
            'i1N8:legacyMode','Use the unchanged old I2 P.');
        bound=n8_bind_runtime(bundle,variant,manifest.(variant),true);
        save(fullfile(outdir,'binding_before.mat'),'bound','-v7.3');
        cd(outdir);
        Simulink.fileGenControl('set','CacheFolder',fullfile(outdir,'cache'), ...
            'CodeGenFolder',fullfile(outdir,'codegen'),'keepPreviousPath',true,'createDir',true);
        cfg=Simulink.fileGenControl('getConfig');
        assert(inside(char(cfg.CacheFolder),outdir)&&inside(char(cfg.CodeGenFolder),outdir), ...
            'i1N8:fileGen','Simulation-generated files must stay in this case directory.');
        modelFile=fullfile(bundle,variant,'current','models','SarAdc.slx');
        modelCloser=onCleanup(@()close_model_owned(modelFile)); %#ok<NASGU>
        load_system(modelFile);
        assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile)), ...
            'i1N8:modelPath','Loaded model path differs.');
        ws=get_param('SarAdc','ModelWorkspace');savedP=getVariable(ws,'P');
        savedDecode=getVariable(ws,'DecodeP');savedCapture=getVariable(ws,'TrainCaptureFile');
        assert(n8_same_bits(savedP,P)&&n8_same_bits(savedDecode,P.digital)&& ...
            ischar(savedCapture)&&isempty(savedCapture),'i1N8:modelP', ...
            'Frozen SLX workspace must match the full saved P and DecodeP.');
        save(fullfile(outdir,'P_used.mat'),'P','-v7.3');
        sv=ver('simulink');assert(isscalar(sv),'i1N8:simulinkVersion','Simulink version required.');
        result.matlab_version=version;result.matlab_release=version('-release');
        result.simulink_version=sv.Version;
        result.solver=struct('name',get_param('SarAdc','Solver'), ...
            'type',get_param('SarAdc','SolverType'),'mode',get_param('SarAdc','SimulationMode'), ...
            'start',get_param('SarAdc','StartTime'),'stop',get_param('SarAdc','StopTime'));
        n8_write_json(fullfile(outdir,'started.json'),result);
        si=Simulink.SimulationInput('SarAdc');
        si=si.setVariable('P',P,'Workspace','SarAdc');
        si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        rngBefore=rng;save(fullfile(outdir,'rng_before.mat'),'rngBefore','-v7.3');
        clock=tic;simout=sim(si);result.sim_s=toc(clock);
        save(fullfile(outdir,'simout.mat'),'simout','-v7.3');
        assert(isempty(simout.ErrorMessage),'i1N8:sim','%s',simout.ErrorMessage);
        assert(isequaln(rngBefore,rng),'i1N8:rng','Global RNG changed.');
        assert(n8_same_bits(getVariable(ws,'P'),savedP)&& ...
            n8_same_bits(getVariable(ws,'DecodeP'),savedDecode)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),savedCapture),'i1N8:workspace', ...
            'Model workspace changed after SimulationInput run.');
        V=behavior_record_view(simout,P);
        assert(size(V.raw,1)==8&&all(V.raw(:,6)==1)&& ...
            isequal(V.raw(:,4),(4:11).')&&all(V.raw(:,5)==1), ...
            'i1N8:records','Eight valid actual records with IDs 4–11 are required.');
        assert(size(V.observed_raw,1)==12&&isequal(V.observed_raw(:,4),(0:11).')&& ...
            all(V.observed_raw(:,5)==1)&&all(V.observed_raw(:,6)==1), ...
            'i1N8:allRecords','All 12 actual RAW records must have valid ID/epoch.');
        [tEvent,ev]=n8_series(simout,'event_log',2);
        G=numel(P.groups);cycles=P.schedule.n_cycles;
        assert(G==48&&cycles==12&&isequal(ev,[repelem((0:cycles-1).',G) repmat((1:G).',cycles,1)]), ...
            'i1N8:events','Actual 12x48 event inventory differs.');
        expectedTime=zeros(size(tEvent));
        for k=1:numel(tEvent),expectedTime(k)=ev(k,1)*P.Ts_s+P.groups(ev(k,2)).time_s;end
        assert(n8_same_bits(tEvent,expectedTime),'i1N8:eventTime','Actual event times differ.');
        n8_check_inputs(bundle,variant);
        boundAfter=n8_bind_runtime(bundle,variant,manifest.(variant),false);
        save(fullfile(outdir,'binding_after.mat'),'boundAfter','-v7.3');
        assert(strcmp(n8_sha256(copy),manifest.fixture_sha256),'i1N8:copy','P fixture changed.');
        result.status='completed_uncompared';result.fixture_sha256=manifest.fixture_sha256;
        result.model_sha256=n8_sha256(modelFile);result.runtime_file_count=numel(manifest.(variant));
        result.bound_functions=numel(bound);result.simout_sha256=n8_sha256(fullfile(outdir,'simout.mat'));
        result.P_used_sha256=n8_sha256(fullfile(outdir,'P_used.mat'));
        result.rng_before_sha256=n8_sha256(fullfile(outdir,'rng_before.mat'));
        result.logs=simout.who;result.raw=V.raw;result.code20=V.code20;result.record_time_s=V.time_s;
        result.records=8;result.all_valid_raw_records=12;result.event_count=numel(tEvent);
        result.feedback_counts='UNOBSERVED: ADI debug OFF';
        result.global_rng_unchanged=true;result.actual_P_is_fixture=true;
        n8_write_json(fullfile(outdir,'complete.json'),result);
    catch ex
        failure=struct('status','failed','case_name',caseName,'id',ex.identifier, ...
            'message',getReport(ex,'extended','hyperlinks','off'));
        n8_write_json(fullfile(outdir,'failed.json'),failure);rethrow(ex);
    end
end
function restore_env(p,c),path(p);cd(c);end
function close_model_owned(modelFile)
    if ~bdIsLoaded('SarAdc'),return;end
    try
        own=strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile));
        clean=strcmp(get_param('SarAdc','Dirty'),'off');
        stopped=strcmp(get_param('SarAdc','SimulationStatus'),'stopped');
        if own&&clean&&stopped,close_system('SarAdc',0);end
    catch
        % Isolated batch exits; never close an unverified model.
    end
end
function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function yes=inside(p,parent)
    a=lower(canon(p));b=lower(canon(parent));yes=strcmp(a,b)||startsWith(a,[b '/']);
end
function bootstrap(scripts)
% The controller separately verifies bundle SHA/manifest before this call.
    list=dir(fullfile(scripts,'*.m'));loaded=inmem('-completenames');
    for k=1:numel(list)
        [~,name]=fileparts(list(k).name);expected=fullfile(scripts,list(k).name);
        actual=which(name);
        assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected)), ...
            'i1N8:scriptPath','Script resolves from unexpected path: %s',name);
        for j=1:numel(loaded)
            [~,stem]=fileparts(loaded{j});if ~strcmpi(stem,name),continue;end
            assert(strcmpi(name,'sar20_i1_n8_case')&&strcmpi(canon(loaded{j}),canon(expected)), ...
                'i1N8:scriptCache','A helper was cached before this fresh case: %s',loaded{j});
        end
    end
end
