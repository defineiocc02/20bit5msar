function manifest=n8_check_inputs(bundle,variant)
% Pin every local source/config/model byte, file inventory and historical P.
    pin='38f3c31200af2ee3a79f16b1f7b900c2b7cd65817b730ac906972822de6e6472';
    manifestFile=fullfile(bundle,'INPUTS.json');
    assert(strcmp(n8_sha256(manifestFile),pin),'i1N8:manifest','Input manifest mismatch.');
    manifest=jsondecode(fileread(manifestFile));
    assert(any(strcmp(variant,{'baseline','candidate'})),'i1N8:variant','Invalid runtime.');
    root=fullfile(bundle,variant);items=manifest.(variant);
    listed=cell(numel(items),1);
    for k=1:numel(items)
        rel=strrep(items(k).path,'/',filesep);listed{k}=items(k).path;
        f=fullfile(root,rel);
        assert(isfile(f)&&strcmp(n8_sha256(f),items(k).sha256), ...
            'i1N8:sourceHash','Wrong source/config/model bytes: %s',items(k).path);
    end
    listing=dir(fullfile(root,'**','*'));actual={};
    for k=1:numel(listing)
        if listing(k).isdir,continue;end
        full=fullfile(listing(k).folder,listing(k).name);
        assert(startsWith(full,[root filesep]),'i1N8:sourcePath','Source escaped root.');
        actual{end+1}=strrep(full(numel(root)+2:end),filesep,'/'); %#ok<AGROW>
    end
    assert(isequal(sort(actual(:)),sort(listed(:))),'i1N8:sourceInventory', ...
        'Runtime source/config/model inventory differs from manifest.');
    assert(strcmp(n8_sha256(fullfile(bundle,'fixture','parameters.mat')),manifest.fixture_sha256), ...
        'i1N8:fixture','Original P fixture bytes changed.');
    assert(strcmp(n8_sha256(fullfile(bundle,'fixture','historical_simout.mat')),manifest.historical_simout_sha256), ...
        'i1N8:historical','Historical reference output bytes changed.');
end
