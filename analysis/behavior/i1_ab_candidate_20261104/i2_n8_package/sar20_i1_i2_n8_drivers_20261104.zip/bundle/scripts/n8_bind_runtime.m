function bound=n8_bind_runtime(bundle,variant,items,requireFresh)
% Must be invoked in a new batch process. Verify all project function origins.
    root=fullfile(bundle,variant);src=fullfile(root,'current','src');
    loaded=inmem('-completenames');
    mfiles={};
    for k=1:numel(items)
        [~,name,ext]=fileparts(items(k).path);
        if strcmpi(ext,'.m'),mfiles{end+1}=name;end %#ok<AGROW>
    end
    for k=1:numel(loaded)
        [~,name]=fileparts(loaded{k});index=find(strcmpi(name,mfiles),1);
        if isempty(index),continue;end
        assert(~requireFresh,'i1N8:cached', ...
            'Project function already cached before isolated binding: %s',loaded{k});
        expected=which(name);
        assert(~isempty(expected)&&strcmpi(canon(expected),canon(loaded{k})), ...
            'i1N8:cached','Project function cached from a different path: %s',loaded{k});
    end
    addpath(genpath(src),fullfile(root,'config'),root,'-begin');rehash;
    bound=struct('name',{},'path',{});
    for k=1:numel(items)
        [~,name,ext]=fileparts(items(k).path);if ~strcmpi(ext,'.m'),continue;end
        expected=fullfile(root,strrep(items(k).path,'/',filesep));
        resolved=which(name);
        assert(~isempty(resolved)&&strcmpi(canon(resolved),canon(expected)), ...
            'i1N8:path','%s resolves outside the isolated runtime: %s',name,resolved);
        bound(end+1)=struct('name',name,'path',resolved); %#ok<AGROW>
    end
    assert(numel(bound)==numel(mfiles),'i1N8:bindings','Incomplete source bindings.');
end
function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
