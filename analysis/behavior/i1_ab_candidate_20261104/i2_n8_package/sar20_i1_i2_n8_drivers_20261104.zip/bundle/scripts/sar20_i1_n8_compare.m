function report=sar20_i1_n8_compare(jobRoot)
% Compare two completed I2 outputs; no model loading, ADC calls or simulation.
    scripts=fileparts(mfilename('fullpath'));bundle=fileparts(scripts);bootstrap(scripts);
    jobRoot=n8_jobroot(jobRoot,bundle);
    aDir=fullfile(jobRoot,'baseline_i2');bDir=fullfile(jobRoot,'candidate_i2');
    outDir=fullfile(jobRoot,'i2_compare');
    assert(~isfolder(outDir)&&~isfile(outDir),'i1N8:exists','Never overwrite a comparison.');
    [ok,msg,msgid]=mkdir(outDir);assert(ok&&isempty(msgid),'i1N8:mkdir','%s',msg);
    try
        manifest=n8_check_inputs(bundle,'baseline');n8_check_inputs(bundle,'candidate');
        arPath=fullfile(aDir,'complete.json');brPath=fullfile(bDir,'complete.json');
        n8_sha256(arPath);n8_sha256(brPath); % Enforce the 300 MB read boundary.
        ar=jsondecode(fileread(arPath));br=jsondecode(fileread(brPath));
        assert(br.pid==feature('getpid'),'i1N8:comparisonProcess', ...
            'Compare must run after candidate_i2 in its same isolated batch.');
        assert(strcmp(ar.status,'completed_uncompared')&&strcmp(br.status,'completed_uncompared')&& ...
            strcmp(ar.case_name,'baseline_i2')&&strcmp(br.case_name,'candidate_i2')&& ...
            strcmp(ar.fixture_sha256,br.fixture_sha256)&&strcmp(ar.model_sha256,br.model_sha256)&& ...
            ar.records==8&&br.records==8,'i1N8:identity','Case or P/model identity mismatch.');
        af=fullfile(aDir,'simout.mat');bf=fullfile(bDir,'simout.mat');
        assert(strcmp(n8_sha256(af),ar.simout_sha256)&&strcmp(n8_sha256(bf),br.simout_sha256), ...
            'i1N8:simoutHash','Saved outputs changed.');
        assert(strcmp(ar.fixture_sha256,manifest.fixture_sha256)&& ...
            strcmp(ar.model_sha256,manifest.model_sha256)&& ...
            strcmp(ar.matlab_version,br.matlab_version)&&strcmp(ar.matlab_release,br.matlab_release)&& ...
            strcmp(ar.simulink_version,br.simulink_version)&&n8_same_bits(ar.solver,br.solver), ...
            'i1N8:runtimeIdentity','Fixture/model/runtime/solver identities differ.');
        ap=fullfile(aDir,'P_used.mat');bp=fullfile(bDir,'P_used.mat');
        afix=fullfile(aDir,'P_fixture.mat');bfix=fullfile(bDir,'P_fixture.mat');
        assert(strcmp(n8_sha256(ap),ar.P_used_sha256)&&strcmp(n8_sha256(bp),br.P_used_sha256)&& ...
            strcmp(n8_sha256(afix),manifest.fixture_sha256)&&strcmp(n8_sha256(bfix),manifest.fixture_sha256), ...
            'i1N8:PHash','Saved P or fixture bytes changed.');
        pa=load(ap,'P');pb=load(bp,'P');fa=load(afix,'P');fb=load(bfix,'P');
        assert(n8_same_bits(pa.P,pb.P)&&n8_same_bits(pa.P,fa.P)&&n8_same_bits(pb.P,fb.P), ...
            'i1N8:fullP','Complete P values differ from each other or their original fixture.');
        raPath=fullfile(aDir,'rng_before.mat');rbPath=fullfile(bDir,'rng_before.mat');
        assert(strcmp(n8_sha256(raPath),ar.rng_before_sha256)&& ...
            strcmp(n8_sha256(rbPath),br.rng_before_sha256),'i1N8:rngHash','RNG snapshot changed.');
        ra=load(raPath,'rngBefore');rb=load(rbPath,'rngBefore');
        assert(n8_same_bits(ra.rngBefore,rb.rngBefore),'i1N8:rngIdentity','Initial RNG differs.');
        aa=load(af,'simout');bb=load(bf,'simout');a=aa.simout;b=bb.simout;
        assert(isa(a,'Simulink.SimulationOutput')&&isa(b,'Simulink.SimulationOutput')&& ...
            isempty(a.ErrorMessage)&&isempty(b.ErrorMessage),'i1N8:output','SimulationOutput error.');
        namesA=sort(a.who);namesB=sort(b.who);
        assert(isequal(namesA,namesB),'i1N8:logSet','Actual output variable inventories differ.');
        required={'event_log','front_log','back_log','control_log','raw_log','ready_log', ...
            'record_log','record_ready_log','code_log','tout','yout'};
        assert(all(ismember(required,namesA)),'i1N8:required','Required output missing.');
        for k=1:numel(namesA),same_value(a.get(namesA{k}),b.get(namesB{k}),namesA{k});end
        y=a.get('yout');assert(isa(y,'Simulink.SimulationData.Dataset')&&y.numElements==3, ...
            'i1N8:rootPorts','Actual model must provide three root outputs.');
        report=struct('status','PASS','scope','I2 full output variables and root Time/Data bits', ...
            'fixture_sha256',ar.fixture_sha256,'model_sha256',ar.model_sha256, ...
            'baseline_simout_sha256',ar.simout_sha256,'candidate_simout_sha256',br.simout_sha256, ...
            'variable_names',{namesA},'root_outputs',3,'N',8);
        n8_write_json(fullfile(outDir,'comparison.json'),report);
    catch ex
        failure=struct('status','FAIL','id',ex.identifier,'message',getReport(ex,'extended','hyperlinks','off'));
        n8_write_json(fullfile(outDir,'failure.json'),failure);rethrow(ex);
    end
end
function same_value(a,b,where)
% Same value semantics as the previously executed I2 speed-pair comparator.
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'i1N8:type','Class or shape differs: %s.',where);
    if isa(a,'timeseries')
        assert(a.IsTimeFirst==b.IsTimeFirst,'i1N8:timeFirst','Time orientation differs: %s.',where);
        same_value(a.Time,b.Time,[where '.Time']);same_value(a.Data,b.Data,[where '.Data']);
    elseif isa(a,'Simulink.SimulationData.Dataset')
        assert(a.numElements==b.numElements,'i1N8:dataset','Dataset count differs: %s.',where);
        for j=1:a.numElements
            x=a.getElement(j);y=b.getElement(j);
            assert(strcmp(class(x),class(y))&&isprop(x,'Name')&&isprop(x,'Values')&& ...
                isequal(x.Name,y.Name),'i1N8:signal','Dataset signal differs: %s.',where);
            same_value(x.Values,y.Values,sprintf('%s[%d]',where,j));
        end
    elseif isnumeric(a)
        assert(isreal(a)==isreal(b),'i1N8:complex','Complexity differs: %s.',where);
        assert(isequal(typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')), ...
            'i1N8:bits','Real bits differ: %s.',where);
        if ~isreal(a)
            assert(isequal(typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')), ...
                'i1N8:bits','Imaginary bits differ: %s.',where);
        end
    elseif islogical(a)||ischar(a)||isstring(a)
        assert(isequaln(a,b),'i1N8:value','Value differs: %s.',where);
    else,error('i1N8:unhandled','Cannot skip output class %s at %s.',class(a),where);
    end
end

function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function bootstrap(scripts)
% The controller separately verifies bundle SHA/manifest before this call.
    list=dir(fullfile(scripts,'*.m'));loaded=inmem('-completenames');
    for k=1:numel(list)
        [~,name]=fileparts(list(k).name);expected=fullfile(scripts,list(k).name);
        actual=which(name);
        assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected)), ...
            'i1N8:scriptPath','Script resolves from unexpected path: %s',name);
        for j=1:numel(loaded)
            [~,stem]=fileparts(loaded{j});if ~strcmpi(stem,name),continue;end
            assert(strcmpi(canon(loaded{j}),canon(expected)), ...
                'i1N8:scriptCache','Script cached from unexpected path: %s',loaded{j});
        end
    end
end
