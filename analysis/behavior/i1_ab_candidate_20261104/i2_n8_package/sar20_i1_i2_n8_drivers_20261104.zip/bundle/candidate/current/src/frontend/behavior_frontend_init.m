function [s,p] = behavior_frontend_init(p)
%BEHAVIOR_FRONTEND_INIT Initialize explicit 18-slice frontend state and parameters.
%Version: v1 (2026-10-27). Caller: behavior model initializer; pass returned p to step.
%Input: optional options struct; C_f[18,38]/Cp_f[18] [F], source [V,Hz,rad], tau [s].
%Outputs: cold state s and normalized p; phase=0 park/1 acquire/2 convert/3 captured.
%B_c/B_target_c[18,3] [C] store C*bottom-voltage sums: signal/tail/bias groups.
%Cold init clears charge/tags; runtime reset in step retains analog charge.
%Model: grouped differential RC/charge behavior; frozen C is not a calibration input.
%kTC: one differential capture kick with variance 2*kB*T/Csample_half per slice.
%I1 fixed_ab_i1 requires explicit positive acq_guard_s and a prepared cold state;
%custom warm-start state is not supported. Legacy P without mode remains I2.
%Default off preserves prior state ABI and capture arithmetic. Counter seed is explicit.
    if nargin==0,p=struct();end
    assert(isstruct(p)&&isscalar(p),'behaviorFE:config','p must be a scalar struct.');
    hadMode=isfield(p,'schedule_mode');hadGuard=isfield(p,'acq_guard_s');
    assert(~hadGuard||hadMode,'behaviorFE:i1GuardMode','An acquisition guard requires an explicit schedule mode.');
    defaults=struct('schema','sar20-behavior-frontend/v1','plan_rows',1024, ...
        'pool_seed',20269121,'dem_enabled',true,'dem_seed',20261222, ...
        'dither_enabled',true,'dither_seed',20261223,'dither_input_amplitude_v',0.001, ...
        'vref_v',4.096,'unit_cap_f',1e-15,'C_f',[],'Cp_f',zeros(18,1),'plan',[], ...
        'tau_sample_s',0,'tau_precharge_s',0,'tau_dac_s',0, ...
        'mismatch_enabled',false,'ktc_enabled',false,'temperature_K',298.15,'ktc_seed',20261027, ...
        'jitter',behavior_jitter_parameters(),'schedule_mode','pool_i2','acq_guard_s',0, ...
        'input',struct('offset_v',0,'amplitude_v',0.5,'frequency_hz',1e4,'phase_rad',0));
    names=fieldnames(p);
    assert(all(ismember(names,fieldnames(defaults))),'behaviorFE:unknownConfig','Unknown p field.');
    for k=1:numel(names),defaults.(names{k})=p.(names{k});end
    p=defaults;
    assert((ischar(p.schedule_mode)&&isrow(p.schedule_mode))|| ...
        (isstring(p.schedule_mode)&&isscalar(p.schedule_mode)), ...
        'behaviorFE:scheduleMode','Use an explicit schedule mode.');
    p.schedule_mode=char(p.schedule_mode);
    assert(any(strcmp(p.schedule_mode,{'pool_i2','fixed_ab_i1'})), ...
        'behaviorFE:scheduleMode','Use pool_i2 or fixed_ab_i1.');
    assert(isnumeric(p.acq_guard_s)&&isreal(p.acq_guard_s)&&isscalar(p.acq_guard_s)&& ...
        isfinite(p.acq_guard_s)&&p.acq_guard_s>=0, ...
        'behaviorFE:acqGuard','Guard must be a finite nonnegative seconds scalar.');
    p.acq_guard_s=double(p.acq_guard_s);
    if strcmp(p.schedule_mode,'fixed_ab_i1')
        assert(hadGuard&&p.acq_guard_s>0,'behaviorFE:acqGuard', ...
            'I1 requires an explicit strictly positive acquisition guard.');
    else
        assert(p.acq_guard_s==0,'behaviorFE:i2Guard', ...
            'I2 retains the original immediate acquisition and event times.');
    end
    assert(strcmp(p.schema,'sar20-behavior-frontend/v1'),'behaviorFE:schema','Unsupported schema.');
    assert(isscalar(p.plan_rows)&&isfinite(p.plan_rows)&&p.plan_rows==floor(p.plan_rows)&& ...
        p.plan_rows>=2&&p.plan_rows<=1e6,'behaviorFE:planRows','plan_rows must be integer 2..1e6.');
    for key={'pool_seed','dem_seed','dither_seed','ktc_seed'}
        v=p.(key{1});assert(isnumeric(v)&&isreal(v)&&isscalar(v)&&isfinite(v)&& ...
            v>=0&&v<=2^32-1&&v==floor(v),'behaviorFE:seed','Seeds must be uint32-valued.');
        p.(key{1})=double(v);
    end
    for key={'dem_enabled','dither_enabled','mismatch_enabled','ktc_enabled'}
        v=p.(key{1});assert((islogical(v)||isnumeric(v))&&isreal(v)&&isscalar(v)&& ...
            isfinite(double(v))&&any(double(v)==[0 1]),'behaviorFE:flag','Flags must be 0 or 1.');
        p.(key{1})=logical(v);
    end
    assert(isnumeric(p.temperature_K)&&isreal(p.temperature_K)&&isscalar(p.temperature_K)&& ...
        isfinite(p.temperature_K)&&p.temperature_K>=0, ...
        'behaviorFE:temperature','temperature_K must be a finite nonnegative Kelvin scalar.');
    p.temperature_K=double(p.temperature_K);
    for key={'vref_v','unit_cap_f'}
        v=p.(key{1});assert(isnumeric(v)&&isreal(v)&&isscalar(v)&&isfinite(v)&&v>0, ...
            'behaviorFE:positive','Vref and unit capacitance must be finite positive SI values.');
    end
    assert(isnumeric(p.dither_input_amplitude_v)&&isreal(p.dither_input_amplitude_v)&& ...
        isscalar(p.dither_input_amplitude_v)&&isfinite(p.dither_input_amplitude_v)&& ...
        p.dither_input_amplitude_v>=0,'behaviorFE:ditherAmplitude','Dither amplitude must be nonnegative V.');
    nominal=p.unit_cap_f*repmat([16 32*ones(1,31) 16 8 4 2 1 17],18,1);
    if isempty(p.C_f),p.C_f=nominal;end
    assert(isnumeric(p.C_f)&&isreal(p.C_f)&&isequal(size(p.C_f),[18 38])&& ...
        all(isfinite(p.C_f(:)))&&all(p.C_f(:)>0),'behaviorFE:C','C_f must be positive 18x38 F.');
    p.C_f=double(p.C_f);
    assert(p.mismatch_enabled||isequal(p.C_f,nominal),'behaviorFE:mismatchFlag', ...
        'Non-nominal C requires explicit mismatch_enabled=true; no random mismatch is generated.');
    assert(isnumeric(p.Cp_f)&&isreal(p.Cp_f)&&numel(p.Cp_f)==18&& ...
        all(isfinite(p.Cp_f(:)))&&all(p.Cp_f(:)>=0),'behaviorFE:Cp','Cp_f must contain 18 nonnegative F values.');
    p.Cp_f=double(p.Cp_f(:));
    for key={'tau_sample_s','tau_precharge_s','tau_dac_s'}
        v=p.(key{1});assert(isnumeric(v)&&isreal(v)&&(isscalar(v)||numel(v)==18)&& ...
            all(~isnan(v(:)))&&all(v(:)>=0),'behaviorFE:tau','tau must be scalar/18-vector >=0 s (Inf holds).');
        if isscalar(v),v=repmat(v,18,1);end
        p.(key{1})=double(v(:));
    end
    assert(~p.ktc_enabled||all(p.tau_sample_s==0), ...
        'behaviorFE:ktcFiniteSamplingUnsupported', ...
        'This equilibrium capture-noise mode requires tau_sample_s=0; finite-RC stochastic buildup is not implemented.');
    p.jitter=behavior_jitter_parameters(p.jitter);
    assert(~p.jitter.enabled||all(p.tau_sample_s==0), ...
        'behaviorFE:jitterFiniteSamplingUnsupported', ...
        'Endpoint aperture jitter currently requires tau_sample_s=0; finite-RC sampling at displaced endpoints is not implemented.');
    p.input=check_input(p.input);
    if strcmp(p.schedule_mode,'fixed_ab_i1')
        canonical=repmat([1:8;9:16],ceil(p.plan_rows/2),1);
        canonical=canonical(1:p.plan_rows,:);
    else
        canonical=make_plan(p.plan_rows,p.pool_seed);
    end
    if isempty(p.plan),p.plan=canonical;else
        assert(isnumeric(p.plan)&&isreal(p.plan)&&isequal(p.plan,canonical), ...
            'behaviorFE:plan','Supplied plan must equal same-seed canonical plan_rows x 8.');
    end
    % Preserve the legacy I2 configuration shape for saved P replay.
    if ~hadMode&&~hadGuard,p=rmfield(p,{'schedule_mode','acq_guard_s'});end
    p.group_C_f=[sum(p.C_f(:,1:33),2),sum(p.C_f(:,34:37),2),p.C_f(:,38)];
    s=struct('schema',p.schema,'time_s',0,'has_time',false,'input',p.input, ...
        'phase',zeros(18,1),'B_c',zeros(18,3),'B_target_c',zeros(18,3), ...
        'q_initial_c',zeros(18,1),'v_capture_v',zeros(18,1), ...
        'target_id',-ones(18,1),'target_epoch',-ones(18,1), ...
        'capture_id',-ones(18,1),'capture_epoch',-ones(18,1), ...
        'capture_valid',false(18,1),'aperture_s',nan(18,1), ...
        'active_id',-1,'active_epoch',-1,'d1_code',0,'has_dac_command',false, ...
        'event_count',0, ...
        'dem_shift',nan(18,1),'dither_input_v',zeros(18,1), ...
        'actual_aperture_s',nan(18,1),'acquire_open_s',nan(18,1));
end

function u=check_input(u)
    fields={'offset_v';'amplitude_v';'frequency_hz';'phase_rad'};
    assert(isstruct(u)&&isscalar(u)&&isequal(sort(fieldnames(u)),sort(fields)), ...
        'behaviorFE:input','input requires offset/amplitude V, frequency Hz and phase rad.');
    for k=1:numel(fields)
        v=u.(fields{k});assert(isnumeric(v)&&isreal(v)&&isscalar(v)&&isfinite(v), ...
            'behaviorFE:input','Input parameters must be finite real scalars.');
    end
    assert(u.frequency_hz>=0&&u.amplitude_v>=0,'behaviorFE:input','Frequency/amplitude cannot be negative.');
end

function plan=make_plan(n,seed)
% Same public Fisher-Yates/PM recurrence as sar20_make_slice_plan, pool=true.
    plan=zeros(n,8);plan(1,:)=1:8;
    for row=2:n
        candidates=setdiff(1:18,plan(row-1,:),'stable');
        for j=numel(candidates):-1:2
            seed=mod(16807*(mod(seed,2147483646)+1),2147483647);
            % Fisher-Yates step: swap the current slot with a keyed partner.
        q=1+mod(floor(seed),j);
        tmp=candidates(j);
        candidates(j)=candidates(q);
        candidates(q)=tmp;
        end
        plan(row,:)=candidates(1:8);
    end
end
