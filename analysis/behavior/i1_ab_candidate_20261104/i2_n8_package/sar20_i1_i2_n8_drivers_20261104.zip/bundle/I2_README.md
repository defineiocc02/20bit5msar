# 隔离 I2 N8 两臂驱动：未运行

同一历史生产 N8 d4 模型、完整 P：baseline 为当次 109 源快照，candidate 为此 109 源上叠加 v4 五个改动和一个新 guard。不得称运行 v4 包内 f358 模型或当前生产图。

外层必须创建全新 `D:/Temp/SAR20I1N8_<id>`，将本包解到其 `bundle/`；递归禁止 symlink/reparse 并在每批前后按 `BUNDLE_MANIFEST.json` 验每个文件和 ZIP 哈希。分别启动全新一次性 headless MATLAB batch；严禁连接或清理已有交互会话。第一批调用 `sar20_i1_n8_case(jobRoot,'baseline_i2')`，第二批按顺序调用 `sar20_i1_n8_case(jobRoot,'candidate_i2'); sar20_i1_n8_compare(jobRoot);`。比较器必须与 candidate_i2 在同一新 batch 的同一 PID；失败不得覆盖原目录重试。实际 shell quoting 由控制器负责。

两臂固定 P/model/源码身份；比较全部实际输出变量及 3 根 yout 的数据与时间数值位，核完整 P、RNG、版本/solver、12×48 实际事件和 12 条有效原码。ADI observer 为 OFF，不能根据日历宣称物理反馈实测。历史 simout 仅固定身份，未作历史逐位对照。全部 MATLAB 验证尚未执行；函数缓存仅证明解析路径，不能独立证明 MATLAB 内存指令字节。
