#!/usr/bin/env python3
"""Read-only source identity and independent equation checks; NOT a MATLAB run."""
from pathlib import Path
import hashlib, json, math
import h5py
import numpy as np
from scipy.integrate import quad

HERE=Path(__file__).resolve().parents[1]
PROD=Path('/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020')
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
changes={
 'frontend/behavior_frontend_init.m','frontend/behavior_frontend_step.m',
 'model/behavior_prepare_configuration.m','model/behavior_training_configuration.m',
 'model/behavior_dac_backend_parameters.m'}
prodsrc=PROD/'current/src'; src=HERE/'current/src'
files=[p.relative_to(prodsrc).as_posix() for p in prodsrc.rglob('*') if p.is_file()]
expected=set(files)|{'model/behavior_i1_guard.m'}
actual={p.relative_to(src).as_posix() for p in src.rglob('*') if p.is_file()}
assert actual==expected,(sorted(expected-actual),sorted(actual-expected))
unchanged=[p for p in files if p not in changes]
assert all(sha(prodsrc/p)==sha(src/p) for p in unchanged)
assert all(sha(prodsrc/p)!=sha(src/p) for p in changes)
assert sha(PROD/'current/models/SarAdc.slx')==sha(HERE/'current/models/SarAdc.slx')
oldinit=(prodsrc/'frontend/behavior_frontend_init.m').read_text()
newinit=(src/'frontend/behavior_frontend_init.m').read_text()
assert oldinit[oldinit.index('function plan=make_plan('):]==newinit[newinit.index('function plan=make_plan('):]
assert "if ~hadMode&&~hadGuard,p=rmfield(p,{'schedule_mode','acq_guard_s'});end" in newinit
oldstep=(prodsrc/'frontend/behavior_frontend_step.m').read_text()
newstep=(src/'frontend/behavior_frontend_step.m').read_text()
oldadvance='''v0=s.B_c(j,1)/C(1);v=rc_sine(v0,s.time_s,t,tau,s.input);
        s.B_c(j,1)=C(1)*v;
        s.B_c(j,2:3)=relax(s.B_c(j,2:3),s.B_target_c(j,2:3),dt,p.tau_precharge_s(j));'''
norm=lambda s: ''.join(s.split())
assert norm(oldadvance) in norm(oldstep) and norm(oldadvance) in norm(newstep)
assert "if ~is_i1(p),s=apply_ideal_acquire(s,ids,cmd.t_s,p);end" in newstep
assert 'if t<s.acquire_open_s(j),continue;end' in newstep
guard=(src/'model/behavior_i1_guard.m').read_text()
assert "'behaviorI1:guardResolution'" in guard
assert 'all(cnv<actualOpen&actualOpen<nextCnv)' in guard
assert "'behaviorI1:sourceBinding'" in guard
assert "'behaviorI1:guardWithoutMode'" in guard
assert "'behaviorI1:initialCold'" in guard
assert "isequal(typecast(P.xFE0(:),'uint64'),typecast(coldWords(:),'uint64'))" in guard
assert 'isequaln(double(u),double(v))&&isequaln(double(u),w)' in guard
Ts=200e-9
def representable(guard,ncycles):
    return all(n*Ts<n*Ts+guard<(n+1)*Ts for n in range(-1,ncycles))
assert not representable(1e-30,12)
assert not representable(math.nextafter(Ts,0),12)
assert representable(5e-9,12)
for path in ['control/behavior_calendar.m','control/behavior_event_groups.m',
             'control/behavior_sar_step.m','frontend/behavior_frontend_stage.m',
             'physics/behavior_backend_step.m','physics/behavior_backend_stage.m']:
 assert sha(src/path)==sha(prodsrc/path),path
for n in ['behavior_frontend_init','behavior_frontend_step']:
 original=(HERE/'baseline/frontend'/f'{n}.m').read_text()
 named=(HERE/'baseline/frontend'/f'{n}_baseline.m').read_text()
 assert named.replace(n+'_baseline',n,1)==original

fixture=PROD/'analysis/behavior/speed_nominal_20261104/n256_base/P_fixture.mat'
with h5py.File(fixture) as m:
 f=m['P/front']; plan=np.asarray(f['plan']).T.astype(int)
 dem=int(np.asarray(f['dem_enabled']).reshape(-1)[0])
 fixed=np.array([np.arange(1,9) if i%2==0 else np.arange(9,17) for i in range(len(plan))])
 assert dem==0 and np.array_equal(plan[0],np.arange(1,9))
 matches=int(np.all(plan==fixed,axis=1).sum())
 uses={str(k):int((plan==k).sum()) for k in (17,18)}
 assert matches==1 and all(v>0 for v in uses.values())

# Independent equation verification, no candidate MATLAB file is executed here.
def x(t):return 0.12+0.73*math.sin(2*math.pi*7.1e6*t+0.61)
def closed(v0,t0,t,tau):
 if tau==0:return x(t)
 if math.isinf(tau):return v0
 w=2*math.pi*7.1e6;a=w*tau
 part=lambda s:0.12+0.73/math.hypot(1,a)*math.sin(w*s+0.61-math.atan(a))
 return part(t)+(v0-part(t0))*math.exp(-(t-t0)/tau)
def oracle(v0,t0,t,tau):
 if t<=t0:return v0
 d=t-t0
 integral=quad(lambda u: math.exp(-(d-u)/tau)*x(t0+u)/tau,0,d,
               epsabs=2e-12,epsrel=2e-12)[0]
 return v0*math.exp(-d/tau)+integral
results=[]
for tau in (3e-9,20e-9,80e-9):
 for opening in (5e-9,37e-9,195e-9):
  for end in (opening+1e-9,opening+4.5e-9,opening+12e-9):
   v0=-0.31
   a=closed(v0,opening,end,tau);b=oracle(v0,opening,end,tau)
   diff=abs(a-b);assert diff<2e-12,(tau,opening,end,diff)
   mid=opening+(end-opening)*0.4
   split=closed(closed(v0,opening,mid,tau),mid,end,tau)
   assert abs(split-a)<2e-12
   results.append(diff)
assert closed(-0.31,5e-9,8e-9,0)==x(8e-9)
assert closed(-0.31,5e-9,8e-9,math.inf)==-0.31
print(json.dumps({
 'source_check':{'unchanged_src_files':len(unchanged),'changed_src_files':sorted(changes),
 'new_src_files':['model/behavior_i1_guard.m'],'i2_plan_function_bytes_equal':True,
 'i2_advance_arithmetic_source_preserved':True,'model_bytes_equal':True},
 'recorded_i2_fixture':{'plan_rows':len(plan),'dem_enabled':dem,
 'first_three_rows':plan[:3].tolist(),'fixed_ab_matches':matches,'uses':uses,
 'fixture_sha256':sha(fixture)},
 'independent_formula_oracle':{'cases':len(results),'max_abs_diff_v':max(results),
 'tau_zero_and_inf_abstract_cases':True,
 'binary64_guard_oracle':{'tiny_and_near_period_rejected':True,'5ns_12_cycles_representable':True}},
 'not_executed':['candidate MATLAB','Simulink','I2 all-output bit comparison','I1 actual ADC graph'],
 'boundary':'Static identity and independent equations only; no claim about candidate MATLAB runtime.'
},ensure_ascii=False,indent=2))
