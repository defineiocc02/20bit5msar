function result=sar20_i1_n8_i1(jobRoot,bundle)
% I1 N8 in a new isolated batch, only after both I2 arms match bit-for-bit.
% No model save, probe insertion, connection change, or production write.
    scripts=fileparts(mfilename('fullpath'));
    assert(ischar(bundle)&&isfolder(bundle),'i1N8:bundle','Explicit fixed I2 bundle path required.');
    bootstrap_i1(scripts,fullfile(bundle,'scripts'));
    jobRoot=n8_jobroot(jobRoot,bundle);
    assert(feature('getpid')~=27628&&~usejava('desktop'),'i1N8:interactive', ...
        'A newly launched headless batch is required.');
    systems=find_system('SearchDepth',0,'Type','block_diagram');
    for k=1:numel(systems),assert(bdIsLibrary(systems{k}),'i1N8:loaded','Start with no model loaded.');end
    compareFile=fullfile(jobRoot,'i2_compare','comparison.json');
    assert(isfile(compareFile),'i1N8:gate','I2 comparison must first pass.');
    n8_sha256(compareFile); % Enforce the 300 MB read boundary.
    gate=jsondecode(fileread(compareFile));
    assert(strcmp(gate.status,'PASS')&&gate.N==8,'i1N8:gate','I2 comparison did not pass.');
    aFile=fullfile(jobRoot,'baseline_i2','simout.mat');
    bFile=fullfile(jobRoot,'candidate_i2','simout.mat');
    assert(strcmp(n8_sha256(aFile),gate.baseline_simout_sha256)&& ...
        strcmp(n8_sha256(bFile),gate.candidate_simout_sha256), ...
        'i1N8:gate','Compared I2 outputs changed.');
    previousReceipt=fullfile(jobRoot,'candidate_i2','complete.json');
    n8_sha256(previousReceipt);prevReceipt=jsondecode(fileread(previousReceipt));
    assert(strcmp(prevReceipt.status,'completed_uncompared')&& ...
        strcmp(prevReceipt.simout_sha256,gate.candidate_simout_sha256), ...
        'i1N8:gate','Candidate I2 receipt differs from the accepted gate.');
    prevUsed=fullfile(jobRoot,'candidate_i2','P_used.mat');
    prevFixture=fullfile(jobRoot,'candidate_i2','P_fixture.mat');
    assert(strcmp(n8_sha256(prevUsed),prevReceipt.P_used_sha256)&& ...
        strcmp(n8_sha256(prevFixture),gate.fixture_sha256), ...
        'i1N8:gate','Compared candidate I2 P or fixture bytes changed.');
    outdir=fullfile(jobRoot,'candidate_i1');
    assert(~isfolder(outdir)&&~isfile(outdir),'i1N8:exists','Never reuse a case directory.');
    [ok,msg,msgid]=mkdir(outdir);assert(ok&&isempty(msgid),'i1N8:mkdir','%s',msg);
    result=struct('status','started','case_name','candidate_i1','pid',feature('getpid'), ...
        'model_identity','v4 candidate source on historical d4 SLX', ...
        'scope','I1 5 ns assumed guard; ADI/aperture logs ON; no probe insertion');
    oldPath=path;oldCwd=pwd;restore=onCleanup(@()restore_env(oldPath,oldCwd)); %#ok<NASGU>
    try
        manifest=n8_check_inputs(bundle,'candidate');
        assert(strcmp(gate.fixture_sha256,manifest.fixture_sha256)&& ...
            strcmp(gate.model_sha256,manifest.model_sha256),'i1N8:gate','Gate identity differs.');
        source=fullfile(bundle,'fixture','parameters.mat');copy=fullfile(outdir,'P_fixture.mat');
        [ok,msg]=copyfile(source,copy);assert(ok,'i1N8:copy','%s',msg);
        assert(strcmp(n8_sha256(copy),manifest.fixture_sha256),'i1N8:copy','P fixture copy differs.');
        data=load(copy,'P');assert(isfield(data,'P')&&isstruct(data.P)&&isscalar(data.P), ...
            'i1N8:fixture','Complete saved P required.');
        P0=data.P;
        assert(P0.N==8&&P0.first_id==4&&P0.epoch==1&&P0.Ts_s==200e-9&& ...
            ~P0.transport.enabled&&~P0.debug.adi_enabled&&~P0.debug.aperture_enabled&& ...
            ~P0.front.jitter.enabled&&all(P0.front.tau_sample_s==0)&&all(P0.front.tau_precharge_s==0), ...
            'i1N8:fixtureScope','Expected unchanged I2 N8, ideal sampling and debug off.');
        for key={'training','cal_cfg','frozen','bank'}
            name=key{1};assert(isfield(P0,name)&&isfield(P0.(name),'enabled')&&~P0.(name).enabled, ...
                'i1N8:calibration','Saved %s must be off.',name);
        end
        bound=n8_bind_runtime(bundle,'candidate',manifest.candidate,true);
        save(fullfile(outdir,'binding_before.mat'),'bound','-v7.3');
        P=P0;P.front.schedule_mode='fixed_ab_i1';P.front.acq_guard_s=5e-9;P.front.plan=[];
        P.debug.adi_enabled=true;P.debug.aperture_enabled=true;
        P=behavior_prepare_configuration(P);
        % Preserve the actual derived P even if the difference whitelist fails.
        save(fullfile(outdir,'P_derived.mat'),'P','P0','-v7.3');
        changes=n8_diff_paths(P0,P,'P');
        allowed={'P.front.plan','P.front.schedule_mode','P.front.acq_guard_s','P.xFE0', ...
            'P.backend.dac_coupling.public_plan','P.cal_cfg.public_cfg.pool_schedule','P.i1_binding', ...
            'P.debug.adi_enabled','P.debug.adi_max_points','P.debug.aperture_enabled','P.debug.aperture_max_points'};
        n8_write_json(fullfile(outdir,'parameter_differences.json'), ...
            struct('paths',{changes},'allowed',{allowed},'baseline_fixture_sha256',manifest.fixture_sha256));
        assert(all(ismember(changes,allowed)),'i1N8:parameterDiff','Unexpected P differences.');
        assert(P.debug.adi_enabled&&P.debug.aperture_enabled&& ...
            strcmp(P.front.schedule_mode,'fixed_ab_i1')&&P.front.acq_guard_s==5e-9&& ...
            ~P.training.enabled&&~P.cal_cfg.enabled&&~P.frozen.enabled&&~P.bank.enabled, ...
            'i1N8:i1Config','I1 mode, debug, or calibration contract differs.');
        cd(outdir);
        Simulink.fileGenControl('set','CacheFolder',fullfile(outdir,'cache'), ...
            'CodeGenFolder',fullfile(outdir,'codegen'),'keepPreviousPath',true,'createDir',true);
        cfg=Simulink.fileGenControl('getConfig');
        assert(inside(char(cfg.CacheFolder),outdir)&&inside(char(cfg.CodeGenFolder),outdir), ...
            'i1N8:fileGen','Simulation-generated files must stay in this case directory.');
        modelFile=fullfile(bundle,'candidate','current','models','SarAdc.slx');
        modelCloser=onCleanup(@()close_model_owned(modelFile)); %#ok<NASGU>
        load_system(modelFile);
        assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile)), ...
            'i1N8:modelPath','Loaded model path differs.');
        ws=get_param('SarAdc','ModelWorkspace');savedP=getVariable(ws,'P');
        savedDecode=getVariable(ws,'DecodeP');savedCapture=getVariable(ws,'TrainCaptureFile');
        assert(n8_same_bits(savedP,P0)&&n8_same_bits(savedDecode,P0.digital)&& ...
            ischar(savedCapture)&&isempty(savedCapture),'i1N8:modelP', ...
            'Frozen SLX workspace must match the original full P and DecodeP.');
        sv=ver('simulink');assert(isscalar(sv),'i1N8:simulinkVersion','Simulink version required.');
        result.matlab_version=version;result.matlab_release=version('-release');
        result.simulink_version=sv.Version;
        result.solver=struct('name',get_param('SarAdc','Solver'), ...
            'type',get_param('SarAdc','SolverType'),'mode',get_param('SarAdc','SimulationMode'), ...
            'start',get_param('SarAdc','StartTime'),'stop',get_param('SarAdc','StopTime'));
        assert(strcmp(result.matlab_version,prevReceipt.matlab_version)&& ...
            strcmp(result.matlab_release,prevReceipt.matlab_release)&& ...
            strcmp(result.simulink_version,prevReceipt.simulink_version)&& ...
            n8_same_bits(result.solver,prevReceipt.solver),'i1N8:runtimeIdentity', ...
            'I1 runtime/solver identity differs from the compared I2 run.');
        n8_write_json(fullfile(outdir,'started.json'),result);
        si=Simulink.SimulationInput('SarAdc');
        si=si.setVariable('P',P,'Workspace','SarAdc');
        si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        rngBefore=rng;oldRngFile=fullfile(jobRoot,'candidate_i2','rng_before.mat');
        assert(strcmp(n8_sha256(oldRngFile),prevReceipt.rng_before_sha256), ...
            'i1N8:rngHash','I2 initial RNG snapshot changed.');
        prevRng=load(oldRngFile,'rngBefore');
        assert(n8_same_bits(rngBefore,prevRng.rngBefore),'i1N8:rngIdentity','Initial RNG differs from I2.');
        save(fullfile(outdir,'rng_before.mat'),'rngBefore','-v7.3');
        clock=tic;simout=sim(si);result.sim_s=toc(clock);
        save(fullfile(outdir,'simout.mat'),'simout','-v7.3');
        assert(isempty(simout.ErrorMessage),'i1N8:sim','%s',simout.ErrorMessage);
        assert(isequaln(rngBefore,rng),'i1N8:rng','Global RNG changed.');
        assert(n8_same_bits(getVariable(ws,'P'),savedP)&& ...
            n8_same_bits(getVariable(ws,'DecodeP'),savedDecode)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),savedCapture),'i1N8:workspace', ...
            'Frozen SLX workspace changed after SimulationInput run.');
        V=behavior_record_view(simout,P);
        assert(size(V.raw,1)==8&&all(V.raw(:,6)==1)&& ...
            isequal(V.raw(:,4),(4:11).')&&all(V.raw(:,5)==1), ...
            'i1N8:records','Eight valid actual records with IDs 4–11 are required.');
        n8_check_inputs(bundle,'candidate');
        boundAfter=n8_bind_runtime(bundle,'candidate',manifest.candidate,false);
        save(fullfile(outdir,'binding_after.mat'),'boundAfter','-v7.3');
        assert(strcmp(n8_sha256(copy),manifest.fixture_sha256),'i1N8:copy','P fixture changed.');
        result.status='completed_pending_analysis';result.fixture_sha256=manifest.fixture_sha256;
        result.model_sha256=n8_sha256(modelFile);result.simout_sha256=n8_sha256(fullfile(outdir,'simout.mat'));
        result.P_derived_sha256=n8_sha256(fullfile(outdir,'P_derived.mat'));
        result.rng_before_sha256=n8_sha256(fullfile(outdir,'rng_before.mat'));
        result.logs=simout.who;result.raw=V.raw;result.code20=V.code20;result.record_time_s=V.time_s;
        result.records=8;result.global_rng_unchanged=true;
        result.release_charge_status='UNOBSERVED: no direct FE charge state probe';
        n8_write_json(fullfile(outdir,'sim_complete.json'),result);
        prev=load(bFile,'simout');
        analysis=sar20_i1_n8_validate(simout,P,prev.simout);
        save(fullfile(outdir,'analysis.mat'),'analysis','-v7.3');
        n8_write_json(fullfile(outdir,'analysis.json'),analysis);
        assert(analysis.all_observed_pass,'i1N8:observedGate','I1 observed gate failed.');
        result.status='observed_gate_pass_charge_unobserved';
        result.analysis_mat_sha256=n8_sha256(fullfile(outdir,'analysis.mat'));
        result.analysis_json_sha256=n8_sha256(fullfile(outdir,'analysis.json'));
        result.i2_comparison_sha256=n8_sha256(compareFile);
        n8_write_json(fullfile(outdir,'complete.json'),result);
    catch ex
        failure=struct('status','failed','case_name','candidate_i1','id',ex.identifier, ...
            'message',getReport(ex,'extended','hyperlinks','off'));
        n8_write_json(fullfile(outdir,'failed.json'),failure);rethrow(ex);
    end
end
function restore_env(p,c),path(p);cd(c);end
function close_model_owned(modelFile)
    if ~bdIsLoaded('SarAdc'),return;end
    try
        own=strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile));
        clean=strcmp(get_param('SarAdc','Dirty'),'off');
        stopped=strcmp(get_param('SarAdc','SimulationStatus'),'stopped');
        if own&&clean&&stopped,close_system('SarAdc',0);end
    catch
        % Isolated batch exits; never close an unverified model.
    end
end
function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function yes=inside(p,parent)
    a=lower(canon(p));b=lower(canon(parent));yes=strcmp(a,b)||startsWith(a,[b '/']);
end

function bootstrap_i1(extension,bundleScripts)
% Controller first verifies both immutable manifests; this checks resolution.
    dirs={extension,bundleScripts};loaded=inmem('-completenames');
    for d=1:numel(dirs)
        list=dir(fullfile(dirs{d},'*.m'));
        for k=1:numel(list)
            [~,name]=fileparts(list(k).name);expected=fullfile(dirs{d},list(k).name);
            actual=which(name);
            assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected)), ...
                'i1N8:scriptPath','Script resolves from unexpected path: %s',name);
            for j=1:numel(loaded)
                [~,stem]=fileparts(loaded{j});if ~strcmpi(stem,name),continue;end
                assert(strcmpi(name,'sar20_i1_n8_i1')&&strcmpi(canon(loaded{j}),canon(expected)), ...
                    'i1N8:scriptCache','A helper was cached before this fresh I1 case: %s',loaded{j});
            end
        end
    end
end
