function out=n8_diff_paths(a,b,prefix)
% Report each differing scalar-struct field path; values remain in saved MATs.
    if n8_same_bits(a,b),out={};return;end
    if isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)
        ak=fieldnames(a);bk=fieldnames(b);
        if isequal(sort(ak),sort(bk))&&~isequal(ak,bk),out={prefix};return;end
        keys=union(ak,bk);out={};
        for k=1:numel(keys)
            name=keys{k};p=[prefix '.' name];
            if ~isfield(a,name)||~isfield(b,name),out{end+1}=p; %#ok<AGROW>
            else,out=[out n8_diff_paths(a.(name),b.(name),p)];end %#ok<AGROW>
        end
    else,out={prefix};end
end
