# 隔离 I1 N8 第三批驱动（未执行）

本扩展不修改已冻结的 I2 bundle。外层先对扩展 ZIP、逐文件清单做与 I2 相同的解包安全检查，将文件解入同一 jobRoot 的 `i1_scripts/`，并以全新一次性 headless MATLAB batch 在路径中添加 `jobRoot/bundle/scripts` 和 `jobRoot/i1_scripts`。入口：

```matlab
sar20_i1_n8_i1(jobRoot,fullfile(jobRoot,'bundle'))
```

驱动要求 I2 原/候选全部实际输出变量及三个根口位比较 PASS，且读取时两份 simout、候选 P 和原始 fixture 仍匹配各自 SHA。它从同一个完整原 P 派生 I1：固定 A/B、guard=5 ns（行为假设）、校准与数字 bank 关闭、ADI58 和 aperture28 观察开启；保存完整派生参数和全部字段差异，使用同一个历史 d4 SLX 和 v4 候选源。I1 是不同 P，不能称三个 case 的 P 全同。保存实际 simout 后验证 record、事件、A/B ID、开采时刻元数据、名义孔径、ADI 12D2/8TA/7反馈和 ReturnContext Vtop。捕获前后电荷及其提交状态因没有直接探针列为 `UNOBSERVED`；当前 tau_sample=0，未验证有限采样 RC。

既有 aperture28 的开采时刻来自 `Sample.next353` 状态字段，并不是 5 ns 处另行采集的开关波形；没有新增时钟/状态采样事件，也不能说直接观察了开关波形。guard 的绝对值是行为设定，不是版图/PDK 测量。当前文件尚未在 MATLAB 运行，失败保留原 simout、参数、回执和错误，禁止覆盖重试；直接多字段篡改模式的风险未修，不得据此部署。
