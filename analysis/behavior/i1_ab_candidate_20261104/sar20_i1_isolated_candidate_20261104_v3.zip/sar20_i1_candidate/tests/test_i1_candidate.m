function test_i1_candidate()
% Run ONLY in a new isolated MATLAB process after reviewing this candidate.
% Exercises the actual candidate functions. No model is opened or written.
    root=fileparts(fileparts(mfilename('fullpath')));
    addpath(genpath(fullfile(root,'current','src')));
    addpath(fullfile(root,'config'));
    addpath(fullfile(root,'baseline','frontend'),'-end');
    assert(strcmp(which('behavior_frontend_init'),fullfile(root,'current','src','frontend','behavior_frontend_init.m')));
    assert(strcmp(which('behavior_frontend_step'),fullfile(root,'current','src','frontend','behavior_frontend_step.m')));
    assert(strcmp(which('behavior_frontend_init_baseline'),fullfile(root,'baseline','frontend','behavior_frontend_init_baseline.m')));
    assert(strcmp(which('behavior_frontend_step_baseline'),fullfile(root,'baseline','frontend','behavior_frontend_step_baseline.m')));
    base=struct('dem_enabled',false,'dither_enabled',false, ...
        'tau_sample_s',20e-9,'tau_precharge_s',20e-9, ...
        'input',struct('offset_v',1,'amplitude_v',0,'frequency_hz',0,'phase_rad',0));
    [so,po]=behavior_frontend_init_baseline(base);
    [sn,pn]=behavior_frontend_init(base);
    assert(same_bits(po,pn)&&same_bits(so,sn),'I2 init or normalized P bits changed');
    seq={ ...
        cmd('acquire_open',-200e-9,0),cmd('capture',0,0),cmd('convert_join',0,0), ...
        cmd('acquire_open',0,1),dac(12.5e-9,0,512), ...
        cmd('observe',90e-9,0),ret(90e-9,0,0.11), ...
        cmd('capture',200e-9,1),cmd('convert_join',200e-9,1), ...
        cmd('acquire_open',200e-9,2),change_input(204e-9,1,0.75), ...
        cmd('observe',205e-9,1),ret(290e-9,1,-0.08), ...
        cmd('capture',400e-9,2),cmd('convert_join',400e-9,2)};
    for k=1:numel(seq)
        [so,yo]=behavior_frontend_step_baseline(so,seq{k},po);
        [sn,yn]=behavior_frontend_step(sn,seq{k},pn);
        assert(same_bits(so,sn)&&same_bits(yo,yn),'I2 bit mismatch at event %d',k);
    end
    fprintf('PASS I2 baseline/candidate %d actual frontend events\n',numel(seq));

    opt=base;opt.schedule_mode='fixed_ab_i1';opt.acq_guard_s=5e-9;opt.plan_rows=12;
    [s,p]=behavior_frontend_init(opt);
    assert(isequal(p.plan(1:4,:),[1:8;9:16;1:8;9:16]));
    assert(all(~ismember(p.plan(:),[17 18])));
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',-200e-9,0),p);
    assert(all(s.B_c(1:8,:)==0,'all'));
    [s,o]=behavior_frontend_step(s,cmd('capture',0,0),p);
    expected=1-exp(-195e-9/20e-9);
    assert(abs(o.vheld_v-expected)<1e-12,'Guarded first capture incorrect');
    [s,~]=behavior_frontend_step(s,cmd('convert_join',0,0),p);
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',0,1),p);
    [s,~]=behavior_frontend_step(s,dac(12.5e-9,0,512),p);
    [s,~]=behavior_frontend_step(s,cmd('observe',90e-9,0),p);
    before=s.B_c(1:8,:);vt=0.11;
    [s,out]=behavior_frontend_step(s,ret(90e-9,0,vt),p);
    expectedReturn=before-p.group_C_f(1:8,:)*vt;
    assert(isequaln(out.q_return_c,expectedReturn)&&isequaln(s.B_c(1:8,:),expectedReturn));
    [s,~]=behavior_frontend_step(s,cmd('capture',200e-9,1),p);
    [s,~]=behavior_frontend_step(s,cmd('convert_join',200e-9,1),p);
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',200e-9,2),p);
    assert(all(s.acquire_open_s(1:8)==205e-9));
    [s,~]=behavior_frontend_step(s,cmd('observe',204e-9,1),p);
    assert(isequaln(s.B_c(1:8,:),expectedReturn),'Charge changed inside guard');
    [s,~]=behavior_frontend_step(s,cmd('observe',205e-9,1),p);
    assert(isequaln(s.B_c(1:8,:),expectedReturn),'Finite-RC charge changed at opening edge');
    [s,~]=behavior_frontend_step(s,ret(290e-9,1,-0.08),p);
    [s,o]=behavior_frontend_step(s,cmd('capture',400e-9,2),p);
    initV=expectedReturn(:,1)./p.group_C_f(1:8,1);
    targetV=1+(initV-1)*exp(-195e-9/20e-9);
    assert(max(abs(s.v_capture_v(1:8)-targetV))<1e-12);
    assert(o.id==2&&o.valid&&all(s.capture_id(1:8)==2));
    chargeBeforeReset=s.B_c;
    [s,~]=behavior_frontend_step(s,cmd('reset',400e-9,2),p);
    assert(same_bits(chargeBeforeReset,s.B_c)&&all(~s.capture_valid)&&all(s.phase==0));
    fprintf('PASS I1 fixed banks, guarded RC, charge return, reuse and frontend reset\n');

    % A source change during a pending opening must not touch retained charge.
    ideal=opt;ideal.tau_sample_s=0;ideal.tau_precharge_s=0;
    [s,pIdeal]=behavior_frontend_init(ideal);
    [s,~]=behavior_frontend_step(s,cmd('acquire_open',0,0),pIdeal);
    [s,~]=behavior_frontend_step(s,change_input(1e-9,0,2),pIdeal);
    assert(all(s.B_c(1:8,:)==0,'all'));
    [s,~]=behavior_frontend_step(s,cmd('observe',4e-9,0),pIdeal);
    assert(all(s.B_c(1:8,:)==0,'all'));
    [s,~]=behavior_frontend_step(s,cmd('observe',5e-9,0),pIdeal);
    assert(all(s.B_c(1:8,1)==2*pIdeal.group_C_f(1:8,1)));
    fprintf('PASS I1 pending opening and ideal-source transition\n');

    P0=behavior_prepare_configuration(adc_parameters());
    P=adc_parameters();P.front.schedule_mode='fixed_ab_i1';P.front.acq_guard_s=5e-9;
    P.front.plan=[];P=behavior_prepare_configuration(P);
    assert(isequaln(P0.calendar,P.calendar)&&isequaln(P0.groups,P.groups));
    assert(isequaln(P.backend.dac_coupling.public_plan,P.front.plan));
    assert(strcmp(P.cal_cfg.public_cfg.pool_schedule,'inactive_fixed_ab_i1_no_calibration'));
    assert(~P.training.enabled&&~P.cal_cfg.enabled&&~P.frozen.enabled&&~P.bank.enabled);
    behavior_dac_backend_parameters(P);
    Q=P;Q.front.acq_guard_s=6e-9;
    expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:staleBinding');
    finiteP=adc_parameters();finiteP.front.schedule_mode='fixed_ab_i1';
    finiteP.front.acq_guard_s=5e-9;finiteP.front.plan=[];finiteP.front.tau_sample_s(:)=20e-9;
    finiteP=behavior_prepare_configuration(finiteP);
    behavior_dac_backend_parameters(finiteP);
    Q=finiteP;Q.input.offset_v=Q.input.offset_v+0.5;
    expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:sourceBinding');
    Q=finiteP;Q.front.input.offset_v=Q.front.input.offset_v+0.5;
    expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:sourceBinding');
    Q=finiteP;Q.xFE0(3)=Q.xFE0(3)+0.5;
    expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:sourceBinding');
    for key={'training','cal_cfg','frozen','bank'}
        Q=P;Q.(key{1}).enabled=true;
        expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:calibration');
    end
    Q=P;Q.front.schedule_mode='pool_i2';Q.front.acq_guard_s=0;
    expect_error(@()behavior_dac_backend_parameters(Q),'behaviorI1:staleBinding');
    Q=adc_parameters();Q.front.schedule_mode='fixed_ab_i1';Q.front.acq_guard_s=200e-9;Q.front.plan=[];
    expect_error(@()behavior_prepare_configuration(Q),'behaviorI1:acqGuard');
    Q=adc_parameters();Q.front.schedule_mode='fixed_ab_i1';Q.front.acq_guard_s=0;Q.front.plan=[];
    expect_error(@()behavior_prepare_configuration(Q),'behaviorFE:acqGuard');
    Q=adc_parameters();Q.front.schedule_mode='fixed_ab_i1';Q.front.acq_guard_s=1e-30;Q.front.plan=[];
    expect_error(@()behavior_prepare_configuration(Q),'behaviorI1:guardResolution');
    Q=adc_parameters();Q.front.schedule_mode='fixed_ab_i1';Q.front.acq_guard_s=Q.Ts_s-eps(Q.Ts_s);Q.front.plan=[];
    expect_error(@()behavior_prepare_configuration(Q),'behaviorI1:guardResolution');
    Q=P;Q.cal_cfg.enabled=true;
    expect_error(@()behavior_prepare_configuration(Q),'behaviorI1:calibration');
    Q=adc_parameters();Q.front.schedule_mode='fixed_ab_i1';Q.front.acq_guard_s=5e-9;
    expect_error(@()behavior_prepare_configuration(Q),'behaviorFE:plan');
    fprintf('PASS preparation guards and original calendar\n');
end
function c=cmd(event,t,id),c=struct('event',event,'t_s',t,'id',id,'epoch',1);end
function c=dac(t,id,w),c=cmd('dac_commit',t,id);c.d1_code=w;end
function c=ret(t,id,v),c=cmd('release',t,id);c.vtop_v=v;end
function c=change_input(t,id,v)
    c=cmd('input_change',t,id);
    c.input=struct('offset_v',v,'amplitude_v',0,'frequency_hz',0,'phase_rad',0);
end
function expect_error(f,id)
    try
        f();
    catch ex
        assert(strcmp(ex.identifier,id),'Expected %s, got %s',id,ex.identifier);
        return;
    end
    error('testI1:expectedError','Expected %s.',id);
end

function yes=same_bits(a,b)
% Exact numeric bit comparison, including NaN payloads and signed zero.
    yes=strcmp(class(a),class(b))&&isequal(size(a),size(b));
    if ~yes,return;end
    if isstruct(a)
        names=fieldnames(a);yes=isequal(names,fieldnames(b));
        if ~yes,return;end
        for i=1:numel(a)
            for k=1:numel(names)
                if ~same_bits(a(i).(names{k}),b(i).(names{k})),yes=false;return;end
            end
        end
    elseif iscell(a)
        for i=1:numel(a)
            if ~same_bits(a{i},b{i}),yes=false;return;end
        end
    elseif isa(a,'double')
        yes=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
    elseif isa(a,'single')
        yes=isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
    else
        yes=isequaln(a,b);
    end
end
