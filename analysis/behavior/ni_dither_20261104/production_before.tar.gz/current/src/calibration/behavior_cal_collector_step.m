function [next,out]=behavior_cal_collector_step(kind,s,rawReady,raw6,ref4,opt)
%BEHAVIOR_CAL_COLLECTOR_STEP Candidate numeric training collector, explicit state.
% kind='init'|'observe'|'update'. Only UPDATE may append/fit; OBSERVE reads state.
% RAW6=[D1;D2;DT;sample_id;epoch;valid]. REF4=[value_V;sample_id;epoch;valid].
% opt EXACT fields enabled,N_train,first_id,epoch,public_cfg,reference_provenance,
% thresholds. public_cfg is the current public_calibration_config output only,
% never analog P/C/held/Qres. External Ref4 provenance must be caller-evidenced.
% Fixed enabled buffers N_train x6/x4; disabled 0x6/0x4, h 0x1 (no train matrix).
% Train membership is fixed ID interval; invalid/gap/tag mismatch is an error,
% never dropped/reordered. Exact repeated ready payload is idempotent. One fit.
% Current behavior_public_cal_fit is training-only: no accepted/frozen commit.
% Pure no DWork/persistent/global/RNG/I/O here. Wrapper UPDATE owns state only;
% wrapper OUTPUTS must call observe or emit scalar state, never update/fit.
    assert(any(strcmp(kind,{'init','observe','update'})),'calCollect:kind','Unknown collector call.');
    if strcmp(kind,'init')
        validate_options(opt);
        assert(isempty(s),'calCollect:init','Init requires empty explicit state.');
        n=0;if opt.enabled,n=opt.N_train;end
        h=0;if opt.enabled,h=684;end
        next=struct('definition',[double(opt.enabled) opt.N_train opt.first_id opt.epoch], ...
            'raw_buffer',nan(n,6),'reference_buffer',nan(n,4), ...
            'n_collected',0,'fit_calls',0,'fit_status_code',0,'fit_rank',NaN, ...
            'fit_condition',NaN,'fit_training_rms_v',NaN,'h_candidate',nan(h,1), ...
            'ready_for_independent_holdout',false,'accepted',false);
        out=observe(next,opt);return;
    end
    assert(isstruct(s)&&isscalar(s),'calCollect:state','Initialized explicit collector state required.');
    assert(isequal(s.definition,[double(opt.enabled) opt.N_train opt.first_id opt.epoch]), ...
        'calCollect:reinitialize','Collector enable/count/start/epoch changes require explicit reinit.');
    next=s;
    out=observe(s,opt);
    if strcmp(kind,'observe')||~opt.enabled||s.fit_calls~=0,return;end
    assert((isnumeric(rawReady)||islogical(rawReady))&&isreal(rawReady)&& ...
        isscalar(rawReady)&&ismember(rawReady,[0 1]),'calCollect:ready','RawReady must be binary.');
    if ~rawReady,return;end
    assert(isequal(size(s.raw_buffer),[opt.N_train 6])&& ...
        isequal(size(s.reference_buffer),[opt.N_train 4]),'calCollect:bufferShape','Enabled buffers must retain their initialized fixed size.');
    assert(isa(raw6,'double')&&isreal(raw6)&&numel(raw6)==6&&all(isfinite(raw6(:))), ...
        'calCollect:raw','Ready requires finite actual double RAW6.');
    raw6=raw6(:);
    id=raw6(4);
    assert(id>=0&&id==floor(id),'calCollect:id','Actual sample ID must be nonnegative integer.');
    if id<opt.first_id||id>=opt.first_id+opt.N_train,return;end
    assert(isa(ref4,'double')&&isreal(ref4)&&numel(ref4)==4&&all(isfinite(ref4(:))), ...
        'calCollect:ref','Selected ready record requires actual finite tagged Ref4.');
    ref4=ref4(:);
    assert(all(raw6==floor(raw6))&&raw6(1)>=0&&raw6(1)<=2047&& ...
        raw6(2)>=0&&raw6(2)<=4095&&raw6(3)>=0&&raw6(3)<=255&& ...
        raw6(6)==1&&raw6(5)==opt.epoch,'calCollect:rawValidity','Training RAW range/valid/epoch mismatch.');
    assert(ref4(4)==1&&ref4(2)==id&&ref4(3)==raw6(5)&& ...
        abs(ref4(1))<=opt.public_cfg.vref_v,'calCollect:refJoin','External reference must be valid, in range and exact ID/epoch joined.');
    if s.n_collected>0&&id==opt.first_id+s.n_collected-1
        assert(words_equal(raw6,s.raw_buffer(s.n_collected,:).')&& ...
            words_equal(ref4,s.reference_buffer(s.n_collected,:).'), ...
            'calCollect:duplicateConflict','Repeated actual ready ID changed RAW/reference payload.');
        out.duplicate_same_record=true;return;
    end
    assert(id==opt.first_id+s.n_collected,'calCollect:sequence', ...
        'Training IDs must be consecutive; missing/old/out-of-order ID is not skipped.');
    row=s.n_collected+1;
    next.raw_buffer(row,:)=raw6.';next.reference_buffer(row,:)=ref4.';
    next.n_collected=row;
    if row==opt.N_train
        next.fit_calls=1; % No second invocation, even after a rank rejection.
        raw=struct('raw_D1',next.raw_buffer(:,1),'raw_D2',next.raw_buffer(:,2), ...
            'raw_DT',next.raw_buffer(:,3),'sample_id',next.raw_buffer(:,4), ...
            'epoch',next.raw_buffer(:,5),'valid',next.raw_buffer(:,6));
        trainRef=struct('source','declared_external_reference', ...
            'provenance',opt.reference_provenance,'sample_id',next.reference_buffer(:,2), ...
            'epoch',next.reference_buffer(:,3),'value_v',next.reference_buffer(:,1));
        R=behavior_public_cal_fit(raw,opt.public_cfg,trainRef,opt.thresholds);
        assert(~R.accepted&&isempty(R.frozen),'calCollect:trainingBoundary','Fit must remain training-only, unaccepted and unfrozen.');
        next.fit_status_code=status_code(R.status);next.fit_rank=R.rank;
        if isfield(R,'condition_number_scaled'),next.fit_condition=R.condition_number_scaled;end
        if isfield(R,'training_rms_v'),next.fit_training_rms_v=R.training_rms_v;end
        if ~isempty(R.h_fit)
            assert(isequal(size(R.h_fit),[684 1]),'calCollect:fitWidth','Require full684 candidate only.');
            next.h_candidate=R.h_fit;
        end
        next.ready_for_independent_holdout=R.ready_for_independent_holdout;
        out=observe(next,opt);out.fit_invoked_this_update=true;out.fit_report_this_update=R;
    else,out=observe(next,opt);end
    out.record_collected_this_update=true;
end
function out=observe(s,opt)
% Fixed small observer output; no buffers/features/coefficients streamed per hit.
    out=struct('status7',[double(opt.enabled);s.n_collected;s.fit_calls; ...
        s.fit_status_code;s.fit_rank;double(s.ready_for_independent_holdout);0], ...
        'record_collected_this_update',false,'duplicate_same_record',false, ...
        'fit_invoked_this_update',false,'fit_report_this_update',[]);
end
function validate_options(o)
    keys={'enabled';'N_train';'first_id';'epoch';'public_cfg';'reference_provenance';'thresholds'};
    assert(isstruct(o)&&isscalar(o)&&isequal(sort(fieldnames(o)),sort(keys)), ...
        'calCollect:options','Use exactly the declared minimal options, never full P.');
    assert(isscalar(o.enabled)&&ismember(o.enabled,[0 1]),'calCollect:enable','Explicit binary enabled required.');
    assert(isscalar(o.N_train)&&isfinite(o.N_train)&&o.N_train>=1&&o.N_train==floor(o.N_train)&& ...
        isscalar(o.first_id)&&isfinite(o.first_id)&&o.first_id>=0&&o.first_id==floor(o.first_id)&& ...
        isscalar(o.epoch)&&isfinite(o.epoch)&&o.epoch>=0&&o.epoch<=2^32-1&&o.epoch==floor(o.epoch), ...
        'calCollect:bounds','Explicit fixed training count/start/epoch required.');
    publicKeys={'schema';'vref_v';'fs_hz';'plan_rows';'pool_seed';'pool_schedule'; ...
        'dem_enabled';'dem_seed';'dem_schedule';'dither_enabled';'dither_seed'; ...
        'dither_input_amplitude_v';'dither_schedule';'az_mode';'backend_weights_ra_v';'nominal_ra_gain';'tracking_mode'};
    assert(isstruct(o.public_cfg)&&isscalar(o.public_cfg)&& ...
        isequal(sort(fieldnames(o.public_cfg)),sort(publicKeys)), ...
        'calCollect:publicOnly','Use current cfg17 public projection, no analog state/reference truth fields.');
    assert((ischar(o.reference_provenance)||isstring(o.reference_provenance))&& ...
        isscalar(string(o.reference_provenance))&&(~o.enabled||strlength(string(o.reference_provenance))>0), ...
        'calCollect:provenance','Enabled collector requires explicit external reference provenance.');
    thresholdKeys={'relative_singular_cutoff';'maximum_condition_number';'training_rms_limit_v'};
    assert(isstruct(o.thresholds)&&isscalar(o.thresholds)&& ...
        isequal(sort(fieldnames(o.thresholds)),sort(thresholdKeys)), ...
        'calCollect:thresholds','Exactly three predeclared thresholds required.');
    for k=1:numel(thresholdKeys)
        v=o.thresholds.(thresholdKeys{k});
        assert(isnumeric(v)&&isreal(v)&&isscalar(v)&&isfinite(v),'calCollect:threshold','Thresholds must be explicit finite scalars.');
    end
    assert(o.thresholds.relative_singular_cutoff>0&&o.thresholds.relative_singular_cutoff<1&& ...
        o.thresholds.maximum_condition_number>=1&&o.thresholds.training_rms_limit_v>0, ...
        'calCollect:threshold','Invalid training thresholds.');
    assert(~o.enabled||o.first_id+o.N_train<=o.public_cfg.plan_rows-1, ...
        'calCollect:plan','Enabled public plan must cover training and next acquisition.');
end
function same=words_equal(a,b),same=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));end
function code=status_code(status)
    statuses={'rank_deficient_row_bound','rank_deficient','ill_conditioned', ...
        'nonpositive_effective_h','nonpositive_sample_denominator','training_budget_exceeded', ...
        'training_coverage_incomplete','training_candidate_requires_independent_holdout'};
    code=find(strcmp(status,statuses),1);assert(~isempty(code),'calCollect:fitStatus','Unknown current fit status.');
end
