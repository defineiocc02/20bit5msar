function report=check_behavior_backend_directions(p)
%CHECK_BEHAVIOR_BACKEND_DIRECTIONS Small real-kernel NI direction check, v1.
% Caller: direct MATLAB, e.g. check_behavior_backend_directions(P.backend).
% Inputs: named parameters accepted by behavior_backend_step. No model build,
% RNG, FFT, assumed SNDR, or edits to parameters retained by the caller.
% Each paired case uses the identical command and dt=2 ns; only the named
% parameter changes. AZ write/hold and switching have their actual dt0 edges.
% Outputs: original state/output structs and numeric comparisons, not fitted
% performance. A0 DC values are the kernel's reported finite-gain asymptotes;
% their finite-time endpoints are retained separately and are not called DC.
    timer=tic;
    dt=2e-9;
    p.ra.A0=1e5;p.ra.UGB_hz=1.2e9;
    p.ra.vos_input_v=0;p.ra.slew_v_per_s=Inf;
    p.ni.az=false;p.ni.cinc_kick=false;p.ni.cap_mismatch=false;
    p.ni.ra_noise=false;p.ni.az_noise=false;p.ni.reference_noise=false;
    p.ni.nonlinear_ra=false;p.ni.replica_delay=false;
    cmd=struct('qres_c',0.1*p.ra.Cf_f,'ctop_f',31*p.ra.Cf_f, ...
        'd2_signs',zeros(12,1),'ta_signs',zeros(7,1), ...
        'ra_on',true,'az_on',false,'reset',false);

    high=advance_case(p,cmd,dt);
    pLowA=p;pLowA.ra.A0=1e3;
    low=advance_case(pLowA,cmd,dt);
    highDc=high.output.finite_gain*high.output.target_v;
    lowDc=low.output.finite_gain*low.output.target_v;
    target=high.output.target_v;
    highDcError=abs(highDc-target);lowDcError=abs(lowDc-target);
    assert(lowDcError>highDcError&&low.output.vx_v<high.output.vx_v, ...
        'behavior:directionA0','Lower A0 must increase DC gain error and reduce this positive step endpoint.');

    pSlow=p;pSlow.ra.UGB_hz=600e6;
    slow=advance_case(pSlow,cmd,dt);
    assert(slow.output.tau_ra_s>high.output.tau_ra_s&& ...
        slow.output.vx_v<high.output.vx_v&& ...
        abs(slow.output.vx_v-highDc)>abs(high.output.vx_v-highDc), ...
        'behavior:directionUGB','Lower UGB must slow the same positive step at the same dt.');

    pAz=p;pAz.ni.az=true;
    pAz.az.initial_input_half_v=zeros(2,1);
    pAz.az.target_input_half_v=[20e-6;-20e-6];
    pAz.az.write_tau_s=[1e-9;1e-9];pAz.az.leak_tau_s=[Inf;Inf];
    azWrite=cmd;azWrite.ra_on=false;azWrite.az_on=true;azWrite.reset=true;
    [azInitial,~]=behavior_backend_step([],azWrite,0,pAz);
    [azWritten,writeOutput]=behavior_backend_step(azInitial,azWrite,dt,pAz);
    azHold=azWrite;azHold.az_on=false;
    [azHoldStart,~]=behavior_backend_step(azWritten,azHold,0,pAz);
    [azHeld,holdOutput]=behavior_backend_step(azHoldStart,azHold,dt,pAz);
    targetAz=pAz.az.target_input_half_v;
    assert(all(abs(azWritten.az_input_half_v)>0)&& ...
        all(abs(azWritten.az_input_half_v)<abs(targetAz))&& ...
        all(sign(azWritten.az_input_half_v)==sign(targetAz)), ...
        'behavior:directionAZWrite','AZ write must approach its explicit signed target.');
    assert(isequal(typecast(azWritten.az_input_half_v,'uint64'), ...
        typecast(azHeld.az_input_half_v,'uint64')), ...
        'behavior:directionAZHold','Infinite-leak-time AZ hold must preserve stored bits.');

    pMatch=p;pMatch.ni.cinc_kick=true;pMatch.ct.replica_enabled=true;
    matched=switch_case(pMatch,cmd,dt);
    pMain=pMatch;pMain.ct.replica_enabled=false;
    mainOnly=switch_case(pMain,cmd,dt);
    pNoKick=pMain;pNoKick.ni.cinc_kick=false;
    kickOff=switch_case(pNoKick,cmd,dt);
    assert(all(matched.output.kick_half_v==0)&&mainOnly.output.kick_diff_v~=0&& ...
        all(kickOff.output.kick_half_v==0), ...
        'behavior:directionReplica','Require matched cancellation, main-only kick and explicit kick-off.');
    assert(kickOff.state.vx_v==kickOff.before_state.vx_v&& ...
        mainOnly.state.vx_v==mainOnly.before_state.vx_v+mainOnly.output.kick_diff_v, ...
        'behavior:directionSameOutput','CINC kick must update the same RA state only when enabled.');

    report=struct('status','backend_parameter_directions_passed','dt_s',dt, ...
        'command',cmd,'elapsed_s',toc(timer),'target_budget_s',1, ...
        'A0',struct('high',high,'low',low,'high_dc_formula_v',highDc, ...
            'low_dc_formula_v',lowDc,'high_dc_error_v',highDcError, ...
            'low_dc_error_v',lowDcError), ...
        'UGB',struct('fast',high,'slow',slow), ...
        'AZ',struct('parameters',pAz.az,'initial_state',azInitial, ...
            'written_state',azWritten,'write_output',writeOutput, ...
            'hold_start_state',azHoldStart,'held_state',azHeld,'hold_output',holdOutput), ...
        'CINC',struct('matched_replica',matched,'replica_disabled',mainOnly,'kick_disabled',kickOff), ...
        'scope','Local parameter direction and event-state checks only; no whole-ADC spectrum or transistor claim.');
end

function r=advance_case(p,cmd,dt)
    [initial,~]=behavior_backend_step([],cmd,0,p);
    [state,output]=behavior_backend_step(initial,cmd,dt,p);
    r=struct('ra_parameters',p.ra,'initial_state',initial,'state',state,'output',output);
end

function r=switch_case(p,cmd,dt)
    [initial,~]=behavior_backend_step([],cmd,0,p);
    [before,~]=behavior_backend_step(initial,cmd,dt,p);
    switched=cmd;switched.d2_signs(1)=1;
    [state,output]=behavior_backend_step(before,switched,0,p);
    r=struct('replica_enabled',p.ct.replica_enabled,'kick_enabled',p.ni.cinc_kick, ...
        'command_before',cmd,'command_after',switched,'before_state',before, ...
        'state',state,'output',output);
end
