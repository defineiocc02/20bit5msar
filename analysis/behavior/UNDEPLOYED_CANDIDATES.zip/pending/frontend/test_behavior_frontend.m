function report = test_behavior_frontend()
%TEST_BEHAVIOR_FRONTEND Small real-kernel event checks, v1 2026-10-27.
% Caller: native MATLAB with frontend/ and digital/ on path. No Simulink run.
% Runs init/step/stage/pack directly; checks returned-state reuse, finite sine
% RC split intervals, parked retention, same-ID DEM and public dither on/off.
% Release vtop is an explicit test stub; this does not verify a coupled backend.
% No random inputs, hidden state, source files, ADC code synthesis or long scan.
    assert(exist('behavior_public_dither','file')==2,'behaviorFE:testDitherHelper', ...
        'Add sibling digital/ to path for the production public dither reference.');
    u=struct('offset_v',0.07,'amplitude_v',0.62,'frequency_hz',1.1e6,'phase_rad',0.4);
    options=struct('plan_rows',32,'input',u,'tau_sample_s',35e-9, ...
        'tau_precharge_s',17e-9,'tau_dac_s',6e-9, ...
        'dem_enabled',true,'dither_enabled',true,'dither_seed',1,'ktc_enabled',false);
    [s,p]=behavior_frontend_init(options);
    c=command('acquire_open',-200e-9,0);[s,~]=behavior_frontend_step(s,c,p);
    c=command('capture',0,0);[s,captured]=behavior_frontend_step(s,c,p);
    oldHeld=s.v_capture_v;ids0=p.plan(1,:).';
    c=command('convert_join',0,0);[s,~]=behavior_frontend_step(s,c,p);
    c=command('dac_commit',0,0);c.d1_code=1137;[s,firstDac]=behavior_frontend_step(s,c,p);
    firstShift=s.dem_shift(ids0);
    c=command('dac_commit',4e-9,0);c.d1_code=1032;[s,secondDac]=behavior_frontend_step(s,c,p);
    assert(isequal(firstShift,s.dem_shift(ids0)),'behaviorFE:testDEMTrial', ...
        'Changing a trial changed the same-sample DEM phase.');
    c=command('observe',30e-9,0);[s,preRelease]=behavior_frontend_step(s,c,p);
    preB=s.B_c(ids0,:);preQ=s.q_initial_c(ids0);topStub=0.025;
    c=command('release',30e-9,0);c.vtop_v=topStub;
    [released,releaseOut]=behavior_frontend_step(s,c,p);
    expectedReturn=preB-p.group_C_f(ids0,:)*topStub;
    close_to(released.B_c(ids0,:),expectedReturn,'behaviorFE:testReturnCharge');
    assert(isequal(released.B_c(ids0,:),releaseOut.q_return_c)&& ...
        isequal(released.q_initial_c(ids0),preQ),'behaviorFE:testReturnOwner', ...
        'Release did not update the single B owner or changed frozen q_initial.');
    assert(all(released.phase(ids0)==0)&&~any(released.capture_valid(ids0)), ...
        'behaviorFE:testReleasePhase','Release did not park and retire capture tags.');

    % ID2 must reuse >=6 members of ID0 under the public disjoint-neighbor plan.
    % This intentionally tests frontend reacquisition in isolation, skipping ID1.
    ids2=p.plan(3,:).';reused=intersect(ids0,ids2);assert(~isempty(reused));
    beforeOpen=released.B_c;parked=setdiff((1:18).',ids2);
    c=command('acquire_open',30e-9,2);[opened,~]=behavior_frontend_step(released,c,p);
    assert(isequal(opened.B_c(reused,:),beforeOpen(reused,:)), ...
        'behaviorFE:testAcquireInitial','Finite-RC acquisition overwrote returned initial charge.');
    returnedInitialV=opened.B_c(reused,1)./p.group_C_f(reused,1);
    assert(any(abs(returnedInitialV-oldHeld(reused))>1e-6), ...
        'behaviorFE:testNotOldVin','Reacquisition still used the old sampled Vin.');

    % Same actual kernel, one long interval vs two intervals, nonzero sine RC.
    c=command('observe',110e-9,2);[whole,~]=behavior_frontend_step(opened,c,p);
    c=command('observe',65e-9,2);[split,~]=behavior_frontend_step(opened,c,p);
    c=command('observe',110e-9,2);[split,~]=behavior_frontend_step(split,c,p);
    close_to(whole.B_c,split.B_c,'behaviorFE:testSineSplit');
    assert(isequal(whole.B_c(parked,:),beforeOpen(parked,:)), ...
        'behaviorFE:testParked','An unselected parked slice changed charge.');
    c=command('capture',110e-9,2);[whole,wholeHeld]=behavior_frontend_step(whole,c,p);
    [split,splitHeld]=behavior_frontend_step(split,c,p);
    close_to(whole.v_capture_v(ids2),split.v_capture_v(ids2),'behaviorFE:testHeldSplit');
    close_to(wholeHeld.qres_c,splitHeld.qres_c,'behaviorFE:testChargeSplit');
    assert(isequaln(behavior_frontend_unpack(behavior_frontend_pack(whole),p),whole), ...
        'behaviorFE:testPack','The fixed state ABI lost named state.');

    % Stage CNV opens ID1 while reporting the captured/converting ID0.
    [start,ps]=behavior_frontend_init(options);
    ctx=[-200e-9;0;1;2;0;0];
    [xs,~]=behavior_frontend_stage('advance',behavior_frontend_pack(start),ctx,ps);
    ctx=[0;0;1;1;0;0];[xs,obs]=behavior_frontend_stage('advance',xs,ctx,ps);
    cnv=behavior_frontend_unpack(xs,ps);nextIds=ps.plan(2,:).';
    pd=struct('dither_enabled',true,'dither_seed',ps.dither_seed, ...
        'dither_amplitude_v',ps.dither_input_amplitude_v);
    d0=behavior_public_dither(0,pd);d1=behavior_public_dither(1,pd);
    assert(d0~=d1,'behaviorFE:testDitherFixture','Test seed must distinguish current and next ID.');
    assert(all(cnv.target_id(nextIds)==1)&&all(cnv.dither_input_v(nextIds)==d1), ...
        'behaviorFE:testDitherTargetID','CNV precharged the next acquisition using the wrong sample ID.');
    close_to(cnv.B_target_c(nextIds,2),-ps.group_C_f(nextIds,2)*(d1*1024/15), ...
        'behaviorFE:testDitherPhysical');
    assert(obs(7)==d0,'behaviorFE:testDitherObserveID','Current output reported next-ID digital dither.');
    assert(nnz(cnv.phase==2)==8&&nnz(cnv.phase==1)==8&&nnz(cnv.phase==0)==2, ...
        'behaviorFE:testOwnership','CNV did not produce 8 convert / 8 acquire / 2 parked.');

    off=options;off.dem_enabled=false;off.dither_enabled=false;
    [so,po]=behavior_frontend_init(off);
    c=command('acquire_open',-200e-9,0);[so,~]=behavior_frontend_step(so,c,po);
    assert(all(so.B_target_c(ids0,2)==0),'behaviorFE:testOffPrecharge', ...
        'Disabled dither produced a nonzero acquisition tail target.');
    c=command('capture',0,0);[so,~]=behavior_frontend_step(so,c,po);
    c=command('convert_join',0,0);[so,~]=behavior_frontend_step(so,c,po);
    c=command('dac_commit',0,0);c.d1_code=1137;[so,offOut]=behavior_frontend_step(so,c,po);
    assert(all(so.dem_shift(ids0)==0)&&all(so.dither_input_v==0)&&offOut.dither_input_v==0, ...
        'behaviorFE:testOff','DEM/dither disabled state is not explicit zero.');
    assert(all(so.B_target_c(setdiff((1:18).',ids0),2)==0), ...
        'behaviorFE:testOffTarget','Disabled dither produced a parked precharge target.');

    report=struct('schema','sar20-behavior-frontend-test/v1','status','passed', ...
        'scope','small real frontend kernel event checks; no ADC performance claim', ...
        'checks',struct('return_charge',true,'return_reacquire_initial',true, ...
            'finite_sine_rc_split',true,'parked_retention',true,'same_sample_dem',true, ...
            'next_sample_dither',true,'dem_dither_off',true,'ownership_8_8_2',true,'state317',true), ...
        'commands',struct('raw_d1',[1137 1032],'coarse',[35 32],'fine',[17 8], ...
            'release_time_s',30e-9,'release_vtop_stub_v',topStub,'next_acquire_id',2), ...
        'capture',struct('id',0,'slice_ids',ids0,'held_v',captured.vheld_v, ...
            'q_initial_c',preQ,'qres_after_first_dac_c',firstDac.qres_c, ...
            'qres_after_second_dac_c',secondDac.qres_c,'qres_before_release_c',preRelease.qres_c), ...
        'returned',struct('slice_ids',ids0,'B_post_c',preB,'q_return_c',releaseOut.q_return_c, ...
            'reused_slice_ids',reused,'next_initial_v',returnedInitialV,'old_sample_v',oldHeld(reused)), ...
        'split',struct('held_whole_v',wholeHeld.vheld_v,'held_split_v',splitHeld.vheld_v, ...
            'max_B_difference_c',max(abs(whole.B_c(:)-split.B_c(:)))), ...
        'public',struct('same_sample_dem_shift',firstShift,'dither_id0_v',d0,'dither_id1_v',d1, ...
            'next_tail_target_c',cnv.B_target_c(nextIds,2)));
end

function c=command(event,t,id)
    c=struct('event',event,'t_s',t,'id',id,'epoch',1);
end

function close_to(actual,wanted,id)
    assert(isequal(size(actual),size(wanted))&&all(isfinite(actual(:)))&&all(isfinite(wanted(:))), ...
        id,'Comparison requires same-sized finite arrays.');
    scale=max([abs(actual(:));abs(wanted(:));realmin]);
    assert(all(abs(actual(:)-wanted(:))<=64*eps(scale)),id,'Kernel results differ beyond roundoff.');
end
