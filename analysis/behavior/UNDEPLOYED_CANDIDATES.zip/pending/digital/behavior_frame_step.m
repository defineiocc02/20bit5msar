function [s,out]=behavior_frame_step(s,event,p)
%BEHAVIOR_FRAME_STEP v1 — explicit-state, frame-level N-2 LVDS abstraction.
% Caller: future frame138 graph adapter/standalone event test; NOT yet connected.
% event fields type,time_s,id,epoch,en (EN is integer 0/10/4 for 0000/1010/0100).
% type=cnv snapshots only cache[id-2]; raw_commit also requires public raw six
% fields; frame138 emits the snapshot at CNV+138ns; en_change switches/reset.
% p fields sample_period_s=200ns, frame_offset_s=138ns, setup_s=10ns.
% State s is caller-owned; no persistent/DWork/RNG/I/O. EN0 clears the cache and
% slot calendar. Epoch is supplied by the public system reset controller.
% Payload W31:21=D1,W20:9=D2,W8:1=DT,W0=VALID. Frame pack/unpack is real;
% individual CLK/DCO/DATA edges, eye/CDC, pad timing are NOT modeled here.
% raw_commit never emits rx_ready. Startup slots0/1 emit VALID0, never latest
% available data. Test mode emits A55A5AA5; its payload is NOT an ADC sample.
    if nargin<3||isempty(p)
        p=struct('sample_period_s',200e-9,'frame_offset_s',138e-9,'setup_s',10e-9);
    end
    assert(isstruct(p)&&isscalar(p)&&all(isfield(p,{'sample_period_s','frame_offset_s','setup_s'}))&& ...
        p.sample_period_s==200e-9&&p.frame_offset_s==138e-9&&p.setup_s==10e-9, ...
        'behaviorFrame:parameters','Require explicit 200ns/138ns/10ns frame contract.');
    required={'type','time_s','id','epoch','en'};
    assert(isstruct(event)&&isscalar(event)&&all(isfield(event,required)), ...
        'behaviorFrame:event','Event requires type,time_s,id,epoch,en.');
    kind=char(event.type);
    assert(any(strcmp(kind,{'cnv','raw_commit','frame138','en_change'})), ...
        'behaviorFrame:type','Unknown frame event.');
    assert(isnumeric(event.time_s)&&isreal(event.time_s)&&isscalar(event.time_s)&&isfinite(event.time_s), ...
        'behaviorFrame:time','Event time must be finite seconds.');
    check_uint(event.id,2^32-1,'id');check_uint(event.epoch,2^32-1,'epoch');
    check_uint(event.en,15,'en');
    assert(ismember(event.en,[0 4 10]),'behaviorFrame:en','Only EN0000,0100,1010 implemented.');
    if isempty(s),s=initial_state();end
    assert(strcmp(s.schema,'sar20-behavior-frame-state/v1')&&event.time_s>=s.time_s, ...
        'behaviorFrame:stateTime','Use frame state; events cannot go backwards.');
    out=empty_output(event);
    if event.en==0
        s=initial_state();s.time_s=event.time_s;s.epoch=double(event.epoch);
        out.reset=true;return;
    end
    if s.en==0
        assert(any(strcmp(kind,{'cnv','en_change'})), ...
            'behaviorFrame:enable','Enable at en_change or first CNV.');
        s.en=double(event.en);s.epoch=double(event.epoch);
    end
    assert(s.en==event.en&&s.epoch==event.epoch,'behaviorFrame:resetJoin', ...
        'Mode or epoch change requires EN0 reset first.');
    out.mode=s.en;s.time_s=double(event.time_s);
    switch kind
        case 'en_change'
            % Nonzero enable established above. It does not produce a frame.
        case 'raw_commit'
            assert(isfield(event,'raw'),'behaviorFrame:raw','raw_commit needs actual public RAW.');
            raw=event.raw;validate_raw(raw);
            assert(raw.sample_id==event.id&&raw.epoch==event.epoch, ...
                'behaviorFrame:rawJoin','RAW must join public event ID/epoch.');
            assert(event.id<=s.last_cnv&&event.id>=max(0,s.last_cnv-1), ...
                'behaviorFrame:commitWindow','RAW commit is not in the current/previous conversion window.');
            k=mod(double(event.id),4)+1;
            assert(~s.cache_present(k)||s.cache_id(k)~=event.id, ...
                'behaviorFrame:duplicateCommit','Each ID may commit one actual RAW word only.');
            s.cache_present(k)=true;s.cache_id(k)=double(event.id);
            s.cache_word(k)=pack(raw);s.cache_time_s(k)=double(event.time_s);
            out.raw_committed=true;
        case 'cnv'
            assert(~s.slot_active,'behaviorFrame:unfinishedSlot','Complete frame138 before next CNV.');
            assert(event.id==s.last_cnv+1,'behaviorFrame:cnvSequence', ...
                'CNV IDs must start0 and advance exactly once; reset on loss, do not infer alignment.');
            if s.last_cnv>=0
                assert(abs((event.time_s-s.last_cnv_time_s)-p.sample_period_s)<=time_tol(event.time_s), ...
                    'behaviorFrame:cnvPeriod','CNV period must remain 200ns.');
            end
            s.last_cnv=double(event.id);s.last_cnv_time_s=double(event.time_s);
            s.slot_active=true;s.slot_id=double(event.id);s.slot_time_s=double(event.time_s);
            s.slot_target=double(event.id)-2;s.slot_word=uint32(0);
            if s.en==4
                s.slot_word=uint32(hex2dec('A55A5AA5'));
            elseif s.slot_target>=0
                k=mod(s.slot_target,4)+1;
                if s.cache_present(k)&&s.cache_id(k)==s.slot_target&& ...
                        s.cache_time_s(k)<=event.time_s-p.setup_s+time_tol(event.time_s)
                    s.slot_word=s.cache_word(k);
                end
            end
            out.slot_opened=true;out.slot_id=s.slot_id;out.target_id=s.slot_target;
        case 'frame138'
            assert(s.slot_active&&event.id==s.slot_id, ...
                'behaviorFrame:slot','frame138 must join the pending public CNV slot.');
            assert(abs(event.time_s-(s.slot_time_s+p.frame_offset_s))<=time_tol(event.time_s), ...
                'behaviorFrame:frameTime','RX frame completion requires CNV+138ns.');
            out.rx_ready=true;out.slot_id=s.slot_id;out.target_id=s.slot_target;
            out.word=s.slot_word;out.test_mode=(s.en==4);
            out.raw=unpack(s.slot_word,s.slot_target,s.epoch);
            out.valid=logical(out.raw.valid);out.sample_valid=out.valid&&~out.test_mode&&s.slot_target>=0;
            if s.slot_target>=0
                out.bank=mod(s.slot_target,2);out.polarity=1-2*out.bank;
                out.pair_id=floor(s.slot_target/2);
            end
            s.slot_active=false;
    end
end
function s=initial_state()
    s=struct('schema','sar20-behavior-frame-state/v1','time_s',-Inf,'en',0,'epoch',0, ...
        'last_cnv',-1,'last_cnv_time_s',NaN,'slot_active',false,'slot_id',-1, ...
        'slot_time_s',NaN,'slot_target',-2,'slot_word',uint32(0), ...
        'cache_present',false(4,1),'cache_id',-ones(4,1), ...
        'cache_word',zeros(4,1,'uint32'),'cache_time_s',nan(4,1));
end
function o=empty_output(e)
    o=struct('rx_ready',false,'sample_valid',false,'valid',false,'word',uint32(0), ...
        'raw',[],'slot_id',-1,'target_id',-2,'epoch',double(e.epoch),'mode',0, ...
        'bank',-1,'polarity',0,'pair_id',-1,'test_mode',false, ...
        'slot_opened',false,'raw_committed',false,'reset',false, ...
        'scope','frame-level N-2 codec; no serial-edge/pad/CDC acceptance');
end
function validate_raw(r)
    names={'raw_D1';'raw_D2';'raw_DT';'sample_id';'epoch';'valid'};
    assert(isstruct(r)&&isscalar(r)&&isequal(sort(fieldnames(r)),sort(names)), ...
        'behaviorFrame:rawFields','RAW must contain exactly six public fields.');
    limits=[2047 4095 255 2^32-1 2^32-1 1];
    for k=1:6,check_uint(r.(names{k}),limits(k),names{k});end
end
function check_uint(v,maximum,name)
    assert((isnumeric(v)||islogical(v))&&isreal(v)&&isscalar(v)&&isfinite(v)&& ...
        v>=0&&v<=maximum&&v==floor(v),'behaviorFrame:integer','Invalid public %s.',name);
end
function w=pack(r)
    w=bitor(bitor(bitshift(uint32(r.raw_D1),21),bitshift(uint32(r.raw_D2),9)), ...
        bitor(bitshift(uint32(r.raw_DT),1),uint32(r.valid)));
end
function r=unpack(w,id,epoch)
    r=struct('raw_D1',double(bitand(bitshift(w,-21),uint32(2047))), ...
        'raw_D2',double(bitand(bitshift(w,-9),uint32(4095))), ...
        'raw_DT',double(bitand(bitshift(w,-1),uint32(255))), ...
        'sample_id',id,'epoch',epoch,'valid',double(bitand(w,uint32(1))));
end
function t=time_tol(time),t=16*eps(max(abs(time),1e-9));end
