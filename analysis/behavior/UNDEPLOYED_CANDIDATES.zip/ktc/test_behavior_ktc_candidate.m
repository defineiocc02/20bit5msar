function report=test_behavior_ktc_candidate()
%TEST_BEHAVIOR_KTC_CANDIDATE Native kernel tests only; no SLX or ADC run.
% Add official frontend for pack/unpack, then put this candidate folder FIRST.
% Does not change MATLAB path or global RNG. Uses 128 short independent captures.
    here=fileparts(mfilename('fullpath'));
    assert(strcmp(fileparts(which('behavior_frontend_step')),here)&& ...
        strcmp(fileparts(which('behavior_frontend_init')),here), ...
        'behaviorFE:ktcCandidatePath','Candidate init/step must resolve to this folder.');
    options=struct('plan_rows',130,'unit_cap_f',28e-12/(8*1056), ...
        'input',struct('offset_v',0,'amplitude_v',0,'frequency_hz',0,'phase_rad',0), ...
        'dem_enabled',false,'dither_enabled',false,'ktc_enabled',false);
    [base,pOff]=behavior_frontend_init(options);pOn=pOff;pOn.ktc_enabled=true;
    before=rng;z=zeros(128,8);aggregate=zeros(128,1);first=struct();
    kB=1.380649e-23;
    for n=0:127
        c=struct('event','acquire_open','t_s',-200e-9,'id',n,'epoch',1);
        [acquired,~]=behavior_frontend_step(base,c,pOff);
        c.event='capture';c.t_s=0;
        [off,~]=behavior_frontend_step(acquired,c,pOff);
        [on,y]=behavior_frontend_step(acquired,c,pOn);
        ids=pOn.plan(n+1,:).';C=pOn.group_C_f(ids,1);
        deltaB=on.B_c(ids,1)-off.B_c(ids,1);dv=on.v_capture_v(ids)-off.v_capture_v(ids);
        sigma=sqrt((2*kB*pOn.temperature_K)./C);
        close_to(deltaB,C.*dv,max(abs(on.B_c(:))),'behaviorFE:ktcChargeOwner');
        close_to(on.q_initial_c(ids)-off.q_initial_c(ids),deltaB, ...
            max(abs(on.q_initial_c)),'behaviorFE:ktcQinitial');
        assert(isequal(on.B_c(:,2:3),off.B_c(:,2:3)), ...
            'behaviorFE:ktcTailBias','Capture noise changed tail/bias charge.');
        parked=setdiff((1:18).',ids);
        assert(isequal(on.B_c(parked,:),off.B_c(parked,:)), ...
            'behaviorFE:ktcParked','Capture noise changed unselected slices.');
        z(n+1,:)=(dv./sigma).';aggregate(n+1)=sum(deltaB)/sum(C);
        if n==0
            [recomputed,yr]=behavior_frontend_step(acquired,c,pOn);
            assert(isequal(typecast(behavior_frontend_pack(on),'uint64'), ...
                typecast(behavior_frontend_pack(recomputed),'uint64'))&&isequaln(y,yr), ...
                'behaviorFE:ktcRecompute','Outputs recomputation changed the same keyed capture.');
            doubled=false;try,behavior_frontend_step(on,c,pOn);catch e,doubled=strcmp(e.identifier,'behaviorFE:captureOwnership');end
            assert(doubled,'behaviorFE:ktcDoubleCapture','A committed capture was sampled again.');
            hot=pOn;hot.temperature_K=4*pOn.temperature_K;
            [hotState,~]=behavior_frontend_step(acquired,c,hot);
            close_to(hotState.B_c(ids,1)-off.B_c(ids,1),2*deltaB, ...
                max(abs(hotState.B_c(:))),'behaviorFE:ktcTemperature');
            other=pOn;other.ktc_seed=pOn.ktc_seed+1;
            [otherState,~]=behavior_frontend_step(acquired,c,other);
            assert(~isequal(otherState.B_c(ids,1),on.B_c(ids,1)), ...
                'behaviorFE:ktcSeed','Changing the explicit seed did not change noise.');
            e=struct('event','acquire_open','t_s',-200e-9,'id',0,'epoch',2);
            [epochState,~]=behavior_frontend_step(base,e,pOn);e.event='capture';e.t_s=0;
            [epochState,~]=behavior_frontend_step(epochState,e,pOn);
            assert(~isequal(epochState.B_c(ids,1),on.B_c(ids,1)), ...
                'behaviorFE:ktcEpoch','Changing epoch did not change the keyed capture.');
            finite=pOn;finite.tau_sample_s(:)=1e-9;rejected=false;
            try,behavior_frontend_step(acquired,c,finite);catch err
                rejected=strcmp(err.identifier,'behaviorFE:ktcFiniteSamplingUnsupported');
            end
            assert(rejected,'behaviorFE:ktcUnsupportedJointMode', ...
                'Equilibrium kicks silently accepted finite-RC stochastic sampling.');
            first=struct('ids',ids,'sigma_diff_v',sigma,'noise_diff_v',dv, ...
                'delta_B_sample_c',deltaB,'off_B_sample_c',off.B_c(ids,1), ...
                'on_B_sample_c',on.B_c(ids,1),'held_on_v',y.vheld_v);
        end
    end
    assert(isequal(before,rng),'behaviorFE:ktcGlobalRng','The kernel changed global MATLAB RNG.');
    mu=mean(z(:));variance=var(z(:),1);
    assert(abs(mu)<0.12&&variance>0.75&&variance<1.25, ...
        'behaviorFE:ktcStatistics','Small deterministic capture batch failed loose mean/variance smoke limits.');
    % This is a small statistical smoke gate, not a whiteness/noise signoff.
    CsTotal=sum(pOn.group_C_f(pOn.plan(1,:),1));
    report=struct('status','passed','scope','capture kernel only; whole-SLX off-bitexact gate still required', ...
        'ktc_seed',pOn.ktc_seed,'temperature_K',pOn.temperature_K,'samples',128, ...
        'normal_count',numel(z),'normalized_mean',mu,'normalized_variance',variance, ...
        'aggregate_rms_v',sqrt(mean(aggregate.^2)), ...
        'aggregate_expected_rms_v',sqrt(2*kB*pOn.temperature_K/CsTotal), ...
        'same_capture_recompute_bitexact',true,'double_capture_rejected',true, ...
        'seed_epoch_distinct',true,'temperature_scaling',true,'global_rng_unchanged',true, ...
        'finite_rc_joint_mode_rejected',true, ...
        'state_width',numel(behavior_frontend_pack(base)),'first_capture',first, ...
        'whole_model_default_off_bitexact','NOT_RUN');
end

function close_to(actual,wanted,scale,id)
    scale=max([scale;abs(actual(:));abs(wanted(:));realmin]);
    assert(all(abs(actual(:)-wanted(:))<=64*eps(scale)),id,'Capture charge differs beyond roundoff.');
end
