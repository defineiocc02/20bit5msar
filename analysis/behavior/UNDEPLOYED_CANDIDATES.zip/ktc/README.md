# Sampling kT/C private candidate — not deployed

Only `behavior_frontend_init.m` and `behavior_frontend_step.m` are candidate replacements for the corresponding files in the formal project's `current/src/frontend`. The standard 317-double state ABI, existing pack/unpack, capture timing, DAC/RA feedback and M8 schedule remain unchanged. This directory is not a new ADC project or public entrypoint. No current/Windows file was changed.

## Interface and physical convention

- `p.ktc_enabled=false` by default.
- `p.temperature_K=298.15` default, finite real Kelvin >=0.
- `p.ktc_seed=20261027` default, explicit uint32-valued scalar.
- The existing `p.group_C_f(slice,1)=sum(C_f(slice,1:33))` is **one half's actual signal-sampling capacitance**, not Ctop and not both halves summed. P/N samples are modeled as independent; differential voltage variance is `2*kB*T/Csample_half` (kB=1.380649e-23 J/K).
- Each selected slice gets its own keyed differential Gaussian. The eight-slice charge-weighted input noise variance is consequently `2*kB*T/sum(Csample_half_j)`, assuming independent slice samples. This is the equilibrium aperture-noise approximation and requires tau_sample_s=0 (fully-settled sampling). Enabled kTC with finite sampling RC is explicitly rejected: retaining previous random charge while adding a full equilibrium kick would otherwise overcount thermal noise. Finite-RC stochastic build-up, correlation, reference/RA/CT noise and sampling jitter are not modeled by this switch.

After the real `capture` phase/tag assertion and after the noiseless sample RC advancement, add `deltaB_sample=Csample_half*deltaVdiff` to the same owner's `B_c(:,1)`. Then execute the existing `q_initial=sum(B)` and `v_capture=B_sample/Csample` statements unchanged. Thus actual charge memory, SAR input and residual see the same sampled perturbation. Tail/bias and unselected slices are unchanged. No extra digital-only noise is added.

The counter key is `(ktc_seed, physical_slice, sample_id, epoch)`. Explicit modulo-2^32 avalanche mixing generates two open-interval uniform words; Box-Muller gives one Gaussian. Each uint64 multiplication is bounded below 2^64 before explicit wrap. There is no rand/randn/RandStream/global RNG, mutable noise cursor, or new persistent state. Recomputing Outputs from the same UnitDelay old state produces the same perturbation; passing the committed captured state to capture again is rejected by the existing phase guard. Changing epoch selects a new noise sample. The hash is noncryptographic and requires native statistical checks; no formal independence claim is inferred from the implementation alone.

## Default-off gate

When disabled, the capture branch does not evaluate a noise word or perform any added B arithmetic. All existing step code outside the inserted `if p.ktc_enabled` block is byte-identical to its pinned formal source. No 317-state layout or obs-port change is made. This is a static compatibility argument, **not** a substitute for the required actual same-SLX off comparison of raw D1/D2/DT, code and critical nodes. No whole-model run has been performed from this folder.

Source pins used:

```text
init 9a6a7fd645ea974c50015051cd6659ab4a75324b8e035d8130cd3424fbd0a667
step 5406310ce2c54750d36ff3e90c9c93c92af6b44d80b47be1614f6f242630e771
```

Native kernel preparation: official frontend supplies unchanged pack/unpack; place this folder before it on the MATLAB path and ensure init/step resolve here, then run `r=test_behavior_ktc_candidate()`. The test itself does not modify paths or RNG. It invokes real capture kernels for charge ownership, same-key recomputation, duplicate capture rejection, seed/epoch changes, sqrt(T) scaling and a small 1024-normal mean/variance smoke check. It does not generate ADC codes. Integration is exclusively root's later same-model apply/run work; the actual-C input stays on the analog side and is never passed to digital calibration.
