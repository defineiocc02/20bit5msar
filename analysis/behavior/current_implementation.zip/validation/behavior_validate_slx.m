function report=behavior_validate_slx(out,P,refCapture)
% Validate actual SarBehavior SimulationOutput against a closed event capture.
% Logs: raw_log[6],ready_log[1],code_log[1],front_log[7],back_log[8],
% control_log[13],event_log[2]. Ready is raw_latch, not pin/RX frame-ready.
% Event identity=(cycle,group), never nearest-time matching/interpolation.
% Floating differences are reported without introducing an acceptance tolerance.
    assert(isa(out,'Simulink.SimulationOutput')&&isempty(out.ErrorMessage), ...
        'BehaviorSlx:output','Require completed actual Simulink output without simulation error.');
    names={'raw_log','ready_log','code_log','front_log','back_log','control_log','event_log'};
    widths=[6 1 1 7 8 13 2];data=cell(size(names));axes=cell(size(names));
    for k=1:numel(names),[axes{k},data{k}]=series(out.get(names{k}),widths(k),names{k});end
    t=axes{1};axisComparisons=cell(numel(names),1);
    for k=1:numel(names)
        axisComparisons{k}=difference(axes{k},t,[names{k} ' native time axis']);
        assert(isequal(size(axes{k}),size(t)),'BehaviorSlx:axes','Logger row counts differ.');
    end
    raw=data{1};ready=data{2};codes=data{3};front=data{4};back=data{5};control=data{6};event=data{7};
    groups=behavior_event_groups(behavior_calendar(P.control),false);
    cycles=P.first_id+P.N;G=numel(groups);
    expectedCycle=repelem((0:cycles-1).',G);expectedGroup=repmat((1:G).',cycles,1);
    assert(isequal(event,[expectedCycle expectedGroup]), ...
        'BehaviorSlx:eventInventory','Actual event rows must cover every cycle/group exactly once in order.');
    expectedTime=zeros(size(t));
    for k=1:numel(t),expectedTime(k)=event(k,1)*P.Ts_s+groups(event(k,2)).time_s;end
    eventTime=difference(t,expectedTime,'native event time / saved calendar expression');
    assert(all(ismember(ready,[0 1])),'BehaviorSlx:ready','Actual raw-ready must be binary.');
    selected=ready==1&raw(:,4)>=P.first_id&raw(:,4)<P.first_id+P.N;
    actualRows=find(selected);actual=raw(selected,:);actualCodes=codes(selected);
    expectedIds=(P.first_id:P.first_id+P.N-1).';
    assert(size(actual,1)==P.N&&isequal(actual(:,4),expectedIds)&&all(actual(:,5)==P.epoch), ...
        'BehaviorSlx:records','Require exactly N ready records with contiguous actual IDs and epoch.');
    assert(all(actual(:,6)==1)&&all(actual(:,1)>=0&actual(:,1)<2^11)&& ...
        all(actual(:,2)>=0&actual(:,2)<2^12)&&all(actual(:,3)>=0&actual(:,3)<2^8)&& ...
        all(actual(:)==floor(actual(:)))&&all(actualCodes==floor(actualCodes))&& ...
        all(actualCodes>=0&actualCodes<2^20),'BehaviorSlx:raw','Invalid actual public raw/code values.');
    reference=refCapture.samples;
    assert(numel(reference)==P.N&&isequal([reference.sample_id].',expectedIds)&& ...
        all([reference.epoch]==P.epoch),'BehaviorSlx:reference','Closed reference has different sample identity.');
    expectedRaw=[[reference.D1].' [reference.D2].' [reference.DT].' ...
        [reference.sample_id].' [reference.epoch].' double([reference.valid].')];
    rawEqual=isequal(actual,expectedRaw);codeEqual=isequal(actualCodes,[reference.code20].');
    ref=refCapture.trace;
    required={'sample_id','epoch','kind','index','time_s','held','vres','vx','vy', ...
        'post_vx','post_vy','d1trial','d1raw','d2raw','dtraw'};
    assert(all(isfield(ref,required)),'BehaviorSlx:referenceTrace','Reference trace lacks explicit phase fields.');
    n=numel(t);refHeld=zeros(n,1);refVres=zeros(n,1);refVx=zeros(n,1);refVy=zeros(n,1);
    refControl=zeros(n,6);vresComparable=true(n,1);mapping=cell(n,1);refEventTimes=cell(n,1);
    for k=1:n
        id=event(k,1);group=groups(event(k,2));tokens=group.events;
        matched=zeros(numel(tokens),1);
        for j=1:numel(tokens)
            token=tokens(j);
            found=find([ref.sample_id]==id&[ref.epoch]==P.epoch& ...
                strcmp({ref.kind},token.type)&[ref.index]==token.index);
            assert(isscalar(found),'BehaviorSlx:eventMapping','Missing/duplicate reference event cycle%g %s index%g.',id,token.type,token.index);
            matched(j)=found;
        end
        last=ref(matched(end));refHeld(k)=last.held;
        % Frontend log is after DAC commit/charge return. Existing runner vres
        % is PRE-command at a DAC-changing event; do not equate those phases.
        if any(strcmp(last.kind,{'coarse_latch','fine_prepare','fine_feedback'}))
            vresComparable(k)=false;
        else,refVres(k)=last.vres;end
        beforeDecide=find(ismember({tokens.type},{'fine_decide','d2_decide','ta_compare','raw_latch','release'}),1,'first');
        if isempty(beforeDecide)
            refVx(k)=last.post_vx;refVy(k)=last.post_vy;phase='after_due_prepare_before_decide=last_endpoint_commit';
        else
            q=ref(matched(beforeDecide));refVx(k)=q.vx;refVy(k)=q.vy;
            phase=['after_due_prepare_before_decide=pre_' q.kind];
        end
        refControl(k,:)=[last.d1trial last.d1raw last.d2raw last.dtraw id P.epoch];
        refEventTimes{k}=difference([ref(matched).time_s].',repmat(expectedTime(k),numel(matched),1), ...
            sprintf('reference tokens cycle%g group%g',id,event(k,2)));
        mapping{k}=struct('cycle',id,'group',event(k,2),'event_kinds',{{tokens.type}}, ...
            'backend_reference_phase',phase,'frontend_residual_comparable',vresComparable(k));
    end
    nodeComparisons=struct('held',difference(front(:,1),refHeld,'committed held cache, Frontend obs1'), ...
        'residual',difference(front(vresComparable,2),refVres(vresComparable),'post-command FE residual on semantically matching rows'), ...
        'ra_vx',difference(back(:,1),refVx,'RA VX after due/prepare before decide/reset'), ...
        'ct_vy',difference(back(:,2),refVy,'CT VY after due/prepare before decide/reset'));
    nodeNames=fieldnames(nodeComparisons);
    for k=1:numel(nodeNames)
        name=nodeNames{k};sourceRows=(1:n).';
        if strcmp(name,'residual'),sourceRows=find(vresComparable);end
        if ~isempty(nodeComparisons.(name).first_difference)
            globalRow=sourceRows(nodeComparisons.(name).first_difference.row_1based);
            nodeComparisons.(name).first_difference.capture_row_1based=globalRow;
            nodeComparisons.(name).first_difference.native_time_s=t(globalRow);
            nodeComparisons.(name).first_difference.cycle=event(globalRow,1);
            nodeComparisons.(name).first_difference.group=event(globalRow,2);
        end
    end
    controlEqual=isequal(control(:,[1 5 6 7 9 10]),refControl);
    rawLatchTiming=struct('actual_ready_time_s',t(actualRows),'reference_raw_latch_time_s',zeros(P.N,1));
    for k=1:P.N
        ev=reference(k).events;ii=find(strcmp({ev.kind},'raw_latch'));
        assert(isscalar(ii),'BehaviorSlx:rawLatch','Reference raw latch is not unique.');
        rawLatchTiming.reference_raw_latch_time_s(k)=ev(ii).time_s;
    end
    rawLatchTiming.comparison=difference(rawLatchTiming.actual_ready_time_s, ...
        rawLatchTiming.reference_raw_latch_time_s,'actual raw-ready / reference raw latch');
    floatExact=eventTime.exact_equal&&rawLatchTiming.comparison.exact_equal;
    for k=1:numel(axisComparisons),floatExact=floatExact&&axisComparisons{k}.exact_equal;end
    for k=1:numel(refEventTimes),floatExact=floatExact&&refEventTimes{k}.exact_equal;end
    fields=fieldnames(nodeComparisons);
    for k=1:numel(fields),floatExact=floatExact&&nodeComparisons.(fields{k}).exact_equal;end
    report=struct('schema','sar20-actual-slx-event-validation/v1','status','actual_slx_functional_mismatch', ...
        'sample_count',P.N,'actual_public_records',actual,'actual_code20',actualCodes, ...
        'raw_words_tags_valid_exact',rawEqual,'integer_code20_exact',codeEqual, ...
        'post_decide_public_control_exact',controlEqual,'event_group_count',G, ...
        'logger_axes',{axisComparisons},'native_event_time',eventTime,'raw_latch_timing',rawLatchTiming, ...
        'reference_group_event_times',{refEventTimes},'nodes',nodeComparisons,'phase_mapping',{mapping}, ...
        'all_compared_float_values_exact',floatExact,'tolerance_used',[], ...
        'frontend_residual_skipped_rows_1based',find(~vresComparable), ...
        'frontend_residual_skip_reason','Existing runner stores pre-DAC-command residual at DAC-changing events; graph logs post-command residual', ...
        'committed_reset_state_comparison','not_recorded; BackLog is before final RaReset and is never treated as committed reset state', ...
        'transport_scope','Ready is actual raw_latch; raw six-field/frame-codec boundary only, not serial N-2 RX acceptance');
    if rawEqual&&codeEqual&&controlEqual
        report.status='actual_slx_functional_pass_float_differences_pending_review';
        if floatExact,report.status='actual_slx_functional_and_compared_nodes_exact';end
    end
end

function [t,data]=series(s,width,name)
    assert(isa(s,'timeseries')&&isnumeric(s.Data)&&isreal(s.Data), ...
        'BehaviorSlx:logger','Missing/malformed actual timeseries %s.',name);
    t=s.Time(:);data=squeeze(s.Data);
    if width==1,data=data(:);elseif size(data,1)~=numel(t),data=data.';end
    assert(size(data,1)==numel(t)&&size(data,2)==width&&all(isfinite(data(:)))&& ...
        all(isfinite(t))&&all(diff(t)>=0),'BehaviorSlx:shape','Invalid time/data shape %s.',name);
end

function r=difference(actual,reference,label)
    assert(isequal(size(actual),size(reference)),'BehaviorSlx:comparisonShape','Shape mismatch: %s.',label);
    mask=actual~=reference;idx=find(mask,1);delta=actual-reference;
    r=struct('label',label,'count',numel(actual),'exact_equal',~any(mask(:)), ...
        'max_abs_delta',max([0;abs(delta(:))]),'first_difference',[]);
    if ~isempty(idx)
        [row,col]=ind2sub(size(actual),idx);
        r.first_difference=struct('row_1based',row,'column_1based',col, ...
            'actual',actual(idx),'reference',reference(idx),'delta',delta(idx));
    end
end
