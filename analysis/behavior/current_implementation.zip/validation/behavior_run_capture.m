function [capture,elapsed]=behavior_run_capture(P)
% Actual event runner for the new behavior model; no old physical-kernel calls.
% P: front(options or normalized), backend, control, digital, input, Ts_s,
% N, first_id, epoch, seed. Runs real warmup IDs0..first_id-1, records next N.
% Frame codec only: pack actual raw32 then unpack for nominal public decode.
% No Tx/Rx clock, ready/latency emulation or claimed N-2 transport acceptance.
    started=tic;globalBefore=rng;
    assert(all(isfield(P,{'front','backend','control','digital','input','Ts_s','N','first_id','epoch','seed'})), ...
        'BehaviorRun:config','Incomplete explicit event-run configuration.');
    assert(P.N>=1&&P.N==floor(P.N)&&P.first_id>=0&&P.first_id==floor(P.first_id)&&P.Ts_s>0, ...
        'BehaviorRun:count','Invalid sample count/start/period.');
    frontOptions=P.front;
    if isfield(frontOptions,'group_C_f'),frontOptions=rmfield(frontOptions,'group_C_f');end
    frontOptions.input=P.input;
    [fs,fp]=behavior_frontend_init(frontOptions);
    assert(all(fp.tau_dac_s==0),'BehaviorRun:unclosedConvolution', ...
        'Baseline runner requires tau_dac_s=0; finite DAC-to-RA convolution is not implemented.');
    calendar=behavior_calendar(P.control);cs=[];bs=[];version=0;decisionSerial=0;
    ordinal=0;
    [fs,fo]=front('acquire_open',-P.Ts_s,0,struct());
    initial=struct('qres_c',0,'ctop_f',fo.ctop_f,'d2_signs',zeros(12,1), ...
        'ta_signs',zeros(7,1),'ra_on',false,'az_on',false,'reset',true);
    [bs,bo]=behavior_backend_step([],initial,0,P.backend);
    samples=struct('sample_id',{},'epoch',{},'D1',{},'D2',{},'DT',{}, ...
        'code20',{},'valid',{},'frame_word',{},'events',{},'decode',{});
    eventPrototype=struct('time_s',0,'kind','','index',-1,'decision',-1, ...
        'consumed_decision_id',-1,'decision_id',-1,'state_version_before',0, ...
        'state_version_after',0,'rng_before',[],'rng_after',[], ...
        'held',0,'vres',0,'vx',0,'vy',0,'post_vx',0,'post_vy',0, ...
        'd1trial',0,'d1raw',0,'d2raw',0,'dtraw',0,'phase','','sample_id',0,'epoch',0);
    allTrace=repmat(eventPrototype,0,1);
    for id=0:(P.first_id+P.N-1)
        trace=repmat(eventPrototype,0,1);d2Ids=-ones(12,1);taIds=-ones(8,1);record=[];decoded=[];word=[];
        for j=1:numel(calendar)
            ev=calendar(j);t=id*P.Ts_s+ev.offset_s;
            ev.absolute_time_s=t;ev.sample_id=id;ev.epoch=P.epoch;
            if strcmp(ev.type,'cnv')
                [fs,fo]=front('capture',t,id,struct());
                [fs,fo]=front('convert_join',t,id,struct());
                [fs,~]=front('acquire_open',t,id+1,struct());
                [fs,fo]=front('observe',t,id,struct());
            else
                [fs,fo]=front('observe',t,id,struct());
            end
            assert(fo.valid&&isfinite(fo.qres_c),'BehaviorRun:frontend','No physical sample/residual at actual event.');
            % Advance only the committed OLD command over the elapsed interval.
            dt=t-bs.time_s;
            assert(dt>=0,'BehaviorRun:time','Event time went backwards.');
            [bs,bo]=behavior_backend_step(bs,bs.command,dt,P.backend);
            before=bo.predicted;
            comparison=struct('sample_v',fo.coarse_input_v,'vres_v',fo.vres_v, ...
                'vy_v',before.vy_v,'valid',true,'late',false);
            oldVersion=version;
            [cs,co]=behavior_sar_step(cs,ev,comparison,P.control);
            decisionId=-1;consumed=-1;
            if any(strcmp(ev.type,{'fine_decide','d2_decide','ta_compare'}))
                decisionSerial=decisionSerial+1;decisionId=decisionSerial;
                if strcmp(ev.type,'d2_decide'),d2Ids(ev.index+1)=decisionId;end
                if strcmp(ev.type,'ta_compare'),taIds(ev.index+1)=decisionId;end
            elseif strcmp(ev.type,'d2_feedback'),consumed=d2Ids(ev.index+1);
            elseif strcmp(ev.type,'ta_feedback'),consumed=taIds(ev.index+1);
            end
            if co.trial_changed
                [fs,fo]=front('dac_commit',t,id,struct('d1_code',co.trial));
            end
            % Only now apply this endpoint's real new residual and committed signs.
            if strcmp(ev.type,'release')
                [fs,~]=front('release',t,id,struct('vtop_v',before.vtop_v));
                command=initial;command.ctop_f=fo.ctop_f;
            else
                command=struct('qres_c',fo.qres_c,'ctop_f',fo.ctop_f, ...
                    'd2_signs',co.d2_signs,'ta_signs',co.tracking_signs, ...
                    'ra_on',logical(co.ra_on),'az_on',false,'reset',~logical(co.ra_on));
            end
            [bs,bo]=behavior_backend_step(bs,command,0,P.backend);
            version=version+1;
            row=eventPrototype;row.time_s=t;row.kind=ev.type;row.index=ev.index;
            row.sample_id=id;row.epoch=P.epoch;row.decision=co.decision;
            row.decision_id=decisionId;row.consumed_decision_id=consumed;
            row.state_version_before=oldVersion;row.state_version_after=version;
            row.held=fo.vheld_v;row.vres=comparison.vres_v;row.vx=before.vx_v;row.vy=before.vy_v;
            row.post_vx=bo.vx_v;row.post_vy=bo.vy_v;
            row.d1trial=co.trial;row.d1raw=co.d1raw;row.d2raw=co.d2raw;row.dtraw=co.dtraw;row.phase=ev.type;
            trace(end+1,1)=row;
            if co.record_ready
                record=co.record;
                word=bitor(bitor(bitshift(uint32(record.raw_D1),21),bitshift(uint32(record.raw_D2),9)), ...
                    bitor(bitshift(uint32(record.raw_DT),1),uint32(record.valid)));
                % Actual codec roundtrip; ID/epoch remain local event context, not wire bits.
                raw=struct('raw_D1',double(bitand(bitshift(word,-21),uint32(2047))), ...
                    'raw_D2',double(bitand(bitshift(word,-9),uint32(4095))), ...
                    'raw_DT',double(bitand(bitshift(word,-1),uint32(255))), ...
                    'sample_id',id,'epoch',P.epoch,'valid',double(bitand(word,uint32(1))));
                decoded=behavior_decode(raw,P.digital);
                % Exercise repeated pure observations with copies of all committed states.
                frozen=struct('frontend',fs,'backend',bs,'controller',cs);r0=rng;
                q=struct('event','observe','t_s',t,'id',id,'epoch',P.epoch,'ordinal',ordinal+1);
                [~,fa]=behavior_frontend_step(fs,q,fp);[~,fb]=behavior_frontend_step(fs,q,fp);
                [~,ba]=behavior_backend_step(bs,bs.command,0,P.backend);
                [~,bb]=behavior_backend_step(bs,bs.command,0,P.backend);r1=rng;
                assert(isequaln(fa,fb)&&isequaln(ba,bb)&&isequaln(r0,r1)&& ...
                    isequaln(frozen,struct('frontend',fs,'backend',bs,'controller',cs)), ...
                    'BehaviorRun:outputsPurity','Repeated observation changed state/RNG or output.');
                probe=row;probe.kind='outputs';probe.index=-1;probe.decision=-1;
                probe.decision_id=-1;probe.consumed_decision_id=-1;
                probe.state_version_before=version;probe.state_version_after=version;
                probe.rng_before=r0;probe.rng_after=r1;trace(end+1,1)=probe;
            end
        end
        assert(~isempty(record)&&~isempty(decoded),'BehaviorRun:raw','Missing actual raw latch.');
        allTrace=[allTrace;trace]; %#ok<AGROW>
        if id>=P.first_id
            samples(end+1,1)=struct('sample_id',id,'epoch',P.epoch, ...
                'D1',record.raw_D1,'D2',record.raw_D2,'DT',record.raw_DT, ...
                'code20',decoded.code20,'valid',logical(record.valid), ...
                'frame_word',word,'events',trace,'decode',decoded); %#ok<AGROW>
        end
    end
    flags=P.backend.ni;
    flags.frontend_mismatch=logical(fp.mismatch_enabled);flags.frontend_ktc=logical(fp.ktc_enabled);
    flags.finite_ra_gain=isfinite(P.backend.ra.A0);
    flags.finite_ra_bandwidth=isfinite(P.backend.ra.UGB_hz);
    flags.ra_slew_limit=isfinite(P.backend.ra.slew_v_per_s);
    flags.ra_input_offset=P.backend.ra.vos_input_v~=0;
    flags.ra_reset_memory=P.backend.ra.tau_reset_s>0;
    flags.sample_settling=any(fp.tau_sample_s>0);
    flags.precharge_settling=any(fp.tau_precharge_s>0);
    flags.dac_settling=any(fp.tau_dac_s>0);
    flags.frontend_cp=any(fp.Cp_f>0);
    flags.backend_output_parasitic=any(P.backend.ct.output_parasitic_half_f>0);
    enabled=structfun(@(v)logical(v),flags);mode='off';if any(enabled),mode='on';end
    features=struct('dem_enabled',logical(fp.dem_enabled),'dem_seed',fp.dem_seed, ...
        'dither_enabled',logical(fp.dither_enabled),'dither_seed',fp.dither_seed, ...
        'dither_input_amplitude_v',fp.dither_input_amplitude_v, ...
        'scope','Deterministic switching/public-code features; not random-noise coverage');
    inventory=repmat(struct('name','','implemented',true,'enabled_this_run',false, ...
        'swept',false,'source','','value',[],'scope','Behavioral approximation only'),0,1);
    flagNames=fieldnames(flags);
    unsupported={'frontend_ktc','ra_noise','az_noise','reference_noise','nonlinear_ra','replica_delay'};
    for k=1:numel(flagNames)
        name=flagNames{k};value=flags.(name);source=['P.backend.ni.' name];
        switch name
            case 'finite_ra_gain',source='P.backend.ra.A0';value=P.backend.ra.A0;
            case 'finite_ra_bandwidth',source='P.backend.ra.UGB_hz';value=P.backend.ra.UGB_hz;
            case 'ra_slew_limit',source='P.backend.ra.slew_v_per_s';value=P.backend.ra.slew_v_per_s;
            case 'ra_input_offset',source='P.backend.ra.vos_input_v';value=P.backend.ra.vos_input_v;
            case 'ra_reset_memory',source='P.backend.ra.tau_reset_s';value=P.backend.ra.tau_reset_s;
            case 'sample_settling',source='P.front.tau_sample_s';value=fp.tau_sample_s;
            case 'precharge_settling',source='P.front.tau_precharge_s';value=fp.tau_precharge_s;
            case 'dac_settling',source='P.front.tau_dac_s';value=fp.tau_dac_s;
            case 'frontend_cp',source='P.front.Cp_f';value=fp.Cp_f;
            case 'backend_output_parasitic',source='P.backend.ct.output_parasitic_half_f';value=P.backend.ct.output_parasitic_half_f;
            case 'frontend_mismatch',source='P.front.mismatch_enabled and frozen C_f';value=fp.mismatch_enabled;
            case 'frontend_ktc',source='P.front.ktc_enabled';value=fp.ktc_enabled;
        end
        inventory(end+1,1)=struct('name',name,'implemented',~ismember(name,unsupported), ...
            'enabled_this_run',logical(flags.(name)),'swept',false,'source',source,'value',value, ...
            'scope','Behavioral approximation only');
        if strcmp(name,'dac_settling')
            inventory(end).scope='Frontend supports finite tau; this runner requires tau_dac=0 (convolution not closed)';
        elseif ismember(name,unsupported)
            inventory(end).scope='Not implemented; enabling is rejected by the kernel';
        end
    end
    elapsed=toc(started);
    capture=struct('schema','sar20-behavior-event-capture/v1','samples',samples,'trace',allTrace, ...
        'ni_mode',mode,'ni',flags,'seed',P.seed,'input_identity',P.input, ...
        'nonideal_inventory',inventory,'features',features, ...
        'Ts_s',P.Ts_s,'first_id',P.first_id,'epoch',P.epoch,'elapsed_s',elapsed, ...
        'global_rng_unchanged',isequaln(globalBefore,rng),'parameters',P, ...
        'transport_scope','frame codec only; no Tx/Rx serial timing, ready pulse, or N-2 latency claim', ...
        'scope','New behavior event runner; ideal-settling DAC baseline, finite RA pole, CT feedback; no old physical-kernel equivalence');
    assert(capture.global_rng_unchanged,'BehaviorRun:globalRNG','Actual run changed global RNG.');

    function [next,out]=front(kind,time,id,extra)
        ordinal=ordinal+1;
        cmd=struct('event',kind,'t_s',time,'id',id,'epoch',P.epoch,'ordinal',ordinal);
        fields=fieldnames(extra);for z=1:numel(fields),cmd.(fields{z})=extra.(fields{z});end
        [next,out]=behavior_frontend_step(fs,cmd,fp);
    end
end
