function files=behavior_sample_plot(runPath,id)
%BEHAVIOR_SAMPLE_PLOT v1 (2026-10-27): actual event-observed sample viewer.
% Input runPath: simout.mat/simout, parameters.mat/P, summary.json (SAR20 entry).
% id defaults4. Only reads saved logs/config; never loads/runs a model.
% Stairs join discrete event observations, not reconstructed continuous states.
% BackLog is after due/prepare and before decide/final reset, not committed reset.
% Returns PNG, 48-group observation CSV and full calendar-token event CSV paths.
    if nargin<2,id=4;end
    assert(isscalar(id)&&isfinite(id)&&id>=0&&id==floor(id),'BehaviorPlot:id','Invalid sample ID.');
    runPath=char(runPath);loaded=load(fullfile(runPath,'simout.mat'),'simout');
    parameters=load(fullfile(runPath,'parameters.mat'),'P');out=loaded.simout;P=parameters.P;
    metaPath=fullfile(runPath,'summary.json');meta=jsondecode(fileread(metaPath));
    assert(strcmp(meta.status,'complete')&&meta.simulation_completed, ...
        'BehaviorPlot:summary','Require completed actual SAR20 run summary.');
    assert(isa(out,'Simulink.SimulationOutput')&&isempty(out.ErrorMessage), ...
        'BehaviorPlot:capture','Require actual error-free Simulink output.');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log','control_log', ...
        'd1_log','d2_log','dt_log'};widths=[2 6 1 1 7 8 13 1 1 1];
    values=cell(size(names));time=[];
    for k=1:numel(names)
        [t,values{k}]=read_series(out.get(names{k}),widths(k),names{k});
        if k==1,time=t;else,assert(isequal(time,t),'BehaviorPlot:axes','Actual logger axes differ.');end
    end
    event=values{1};use=event(:,1)==id;
    assert(any(use),'BehaviorPlot:sample','Requested sample was not captured.');
    groups=behavior_event_groups(behavior_calendar(P.control),false);
    assert(isequal(event(use,2),(1:numel(groups)).'),'BehaviorPlot:groups','Sample has missing/repeated actual event groups.');
    rows=find(use);time=time(use);raw=values{2}(use,:);ready=values{3}(use);
    code=values{4}(use);fe=values{5}(use,:);bk=values{6}(use,:);ctrl=values{7}(use,:);
    d1=values{8}(use);d2=values{9}(use);dt=values{10}(use);
    assert(all(raw(:,4)==id)&&all(raw(:,5)==P.epoch),'BehaviorPlot:tags','Actual public tags differ.');
    latch=find(ready==1);assert(isscalar(latch),'BehaviorPlot:ready','Require one actual raw latch for this sample.');
    assert(raw(latch,6)==1,'BehaviorPlot:valid','Actual final raw record is invalid.');
    final=raw(latch,:);finalCode=code(latch);dith=public_dither(id,P.digital);
    voltage=((d1(latch)+d2(latch))+dt(latch))+dith;
    formulaCode=min(2^20-1,max(0,round(voltage*2^20/P.digital.fsr_diff_v+2^19)));
    assert(finalCode==floor(finalCode)&&finalCode>=0&&finalCode<2^20, ...
        'BehaviorPlot:code','Actual final code is not an unsigned Q20 integer.');
    kinds=cell(numel(groups),1);indices=cell(numel(groups),1);
    evKind={};evIndex=[];evBit=[];evTime=[];evPlannedTime=[];evGroup=[];
    d2Markers=[];taMarkers=[];updateMarkers=[];
    for g=1:numel(groups)
        tokens=groups(g).events;kinds{g}=strjoin({tokens.type},' | ');
        indices{g}=strtrim(sprintf('%g ',[tokens.index]));
        for j=1:numel(tokens)
            token=tokens(j);evKind{end+1,1}=token.type; %#ok<AGROW>
            evIndex(end+1,1)=token.index;evBit(end+1,1)=token.bit; %#ok<AGROW>
            evTime(end+1,1)=time(g);evPlannedTime(end+1,1)=id*P.Ts_s+token.offset_s; %#ok<AGROW>
            evGroup(end+1,1)=g; %#ok<AGROW>
            switch token.type
                case 'd2_decide',d2Markers(end+1,:)=[g token.index]; %#ok<AGROW>
                case 'ta_compare',taMarkers(end+1,:)=[g token.index]; %#ok<AGROW>
                case 'ta_feedback',updateMarkers(end+1,:)=[g token.index]; %#ok<AGROW>
            end
        end
    end
    assert(size(d2Markers,1)==12&&size(taMarkers,1)==8&&size(updateMarkers,1)==7, ...
        'BehaviorPlot:calendar','Saved model calendar is not 12D2/8TA/7updates.');
    expectedTime=zeros(size(time));for g=1:numel(groups),expectedTime(g)=id*P.Ts_s+groups(g).time_s;end
    metadataFiles={metaPath};modelHash=char(meta.model_sha256);
    [~,runName]=fileparts(runPath);hashText='';
    if ~isempty(modelHash),hashText=[' | model SHA ' modelHash(1:min(12,numel(modelHash)))];end
    prefix=fullfile(runPath,sprintf('sample_%g',id));
    files=struct('png',[prefix '.png'],'csv',[prefix '_nodes.csv'], ...
        'event_csv',[prefix '_events.csv'],'sample_id',id,'epoch',P.epoch, ...
        'raw_D1',final(1),'raw_D2',final(2),'raw_DT',final(3),'actual_code20',finalCode, ...
        'd1_v',d1(latch),'d2_v',d2(latch),'dt_v',dt(latch),'public_dither_v',dith, ...
        'formula_code20',formulaCode,'contribution_equation_matches_code',formulaCode==finalCode, ...
        'native_time_equals_calendar',isequal(time,expectedTime), ...
        'native_calendar_time_max_abs_delta_s',max(abs(time-expectedTime)), ...
        'metadata_files',{metadataFiles},'model_sha256',modelHash, ...
        'model_version',P.schema,'input',P.input,'seed',P.seed, ...
        'config_sha256',meta.config_sha256,'utc',meta.utc,'finished_utc',meta.finished_utc, ...
        'capture_boundary',meta.capture_boundary, ...
        'observation_scope','Discrete native event observations; BackLog is pre-decide/pre-final-reset probe, not final committed reset state', ...
        'event_source','Declared calendar tokens mapped by actual EventLog group identity; not separately instrumented internal event timestamps');
    % Input is explicitly evaluated from saved source parameters only at the
    % actual logged timestamps. It is labelled separately from measured nodes.
    source=P.input.offset_v+P.input.amplitude_v*sin(2*pi*P.input.frequency_hz*time+P.input.phase_rad);
    nodes=table(time,(time-id*P.Ts_s)*1e9,event(use,2),source,fe(:,1),fe(:,2),bk(:,1),bk(:,2), ...
        ctrl(:,1),raw(:,1),raw(:,2),raw(:,3),ready,code,d1,d2,dt,kinds,indices, ...
        'VariableNames',{'native_time_s','time_from_CNV_ns','group','declared_source_at_events_v', ...
        'held_committed_cache_v','residual_post_DAC_v','VX_pre_decide_reset_v','VY_pre_decide_reset_v', ...
        'D1_trial','D1_raw','D2_raw','DT_raw','raw_latch_ready','code20_diagnostic_unless_ready', ...
        'd1_branch_v','d2_branch_v','dt_branch_v','calendar_kinds','calendar_indices'});
    writetable(nodes,files.csv);
    tokenRows=evGroup;events=table(evTime,evPlannedTime,evGroup,evKind,evIndex,evBit, ...
        repmat(id,numel(evGroup),1),repmat(P.epoch,numel(evGroup),1), ...
        fe(tokenRows,1),fe(tokenRows,2),bk(tokenRows,1),bk(tokenRows,2), ...
        'VariableNames',{'native_group_time_s','declared_token_time_s','group','calendar_kind','index0','bit0', ...
        'sample_id','epoch','held_committed_cache_v','residual_post_DAC_v','VX_pre_decide_reset_v','VY_pre_decide_reset_v'});
    writetable(events,files.event_csv);
    fig=figure('Visible','off','Color','white','Position',[100 100 1250 1000]);
    closer=onCleanup(@()close(fig)); %#ok<NASGU>
    layout=tiledlayout(fig,4,1,'TileSpacing','compact','Padding','compact');
    x=(time-id*P.Ts_s)*1e9;
    a=nexttile(layout);stairs(a,x,source,'--','LineWidth',1);hold(a,'on');
    stairs(a,x,fe(:,1),'LineWidth',1.3);stairs(a,x,fe(:,2),'LineWidth',1.3);
    grid(a,'on');ylabel(a,'Input / FE (V)');
    legend(a,{'Saved source at event times','Committed held cache','Actual residual (post DAC)'},'Location','best');
    a=nexttile(layout);stairs(a,x,bk(:,1),'LineWidth',1.3);hold(a,'on');stairs(a,x,bk(:,2),'LineWidth',1.3);
    grid(a,'on');ylabel(a,'Backend (V)');legend(a,{'VX pre decide/reset','VY pre decide/reset'},'Location','best');
    title(a,'Probe phase: after due feedback/trial, before comparison and final reset; no committed reset trace');
    a=nexttile(layout);stairs(a,x,ctrl(:,1),'LineWidth',1);hold(a,'on');
    stairs(a,x,raw(:,1),'LineWidth',1);stairs(a,x,raw(:,2),'LineWidth',1);stairs(a,x,raw(:,3),'LineWidth',1);
    grid(a,'on');ylabel(a,'RAW / trial');legend(a,{'D1 trial','D1 RAW','D2 RAW','DT RAW'},'Location','eastoutside');
    a=nexttile(layout);hold(a,'on');
    scatter(a,x(d2Markers(:,1)),ones(12,1),32,'b','filled');
    scatter(a,x(taMarkers(:,1)),2*ones(8,1),32,[.9 .45 0],'filled');
    scatter(a,x(updateMarkers(:,1)),3*ones(7,1),32,[0 .55 .2],'filled');
    for q=1:size(d2Markers,1),text(a,x(d2Markers(q,1)),1.12,sprintf('%g',d2Markers(q,2)),'FontSize',8,'HorizontalAlignment','center');end
    for q=1:8,text(a,x(taMarkers(q,1)),2.12,sprintf('%g',taMarkers(q,2)),'FontSize',8,'HorizontalAlignment','center');end
    for q=1:7,text(a,x(updateMarkers(q,1)),3.12,sprintf('%g',updateMarkers(q,2)),'FontSize',8,'HorizontalAlignment','center');end
    plot(a,[x(latch) x(latch)],[.6 3.5],'k--');
    yticks(a,[1 2 3]);yticklabels(a,{'12 D2 compares','8 TA compares','7 TA feedbacks'});ylim(a,[.6 3.5]);grid(a,'on');
    xlabel(a,'Time from actual sample CNV (ns); markers from saved calendar + actual event-group log');
    axesList=findall(fig,'Type','axes');for q=1:numel(axesList),xlim(axesList(q),[min(x) max(x)]);end
    equation=sprintf('RAW D1=%g, D2=%g, DT=%g | code20=%g | Vhat=(%.9g)+(%.9g)+(%.9g)+(%.9g)=%.9g V', ...
        final(1),final(2),final(3),finalCode,d1(latch),d2(latch),dt(latch),dith,voltage);
    title(layout,{sprintf('%s | ID %g epoch %g | %s%s',runName,id,P.epoch,P.schema,hashText), ...
        equation,sprintf('code=clip(round(Vhat*2^20/%.9g+2^19)); actual branch equation match=%d | A0=%g, UGB=%g Hz', ...
        P.digital.fsr_diff_v,files.contribution_equation_matches_code,P.backend.ra.A0,P.backend.ra.UGB_hz)},'Interpreter','none');
    subtitle(layout,{sprintf('%s to %s | %s | config SHA %s',meta.utc,meta.finished_utc, ...
        meta.capture_boundary,meta.config_sha256(1:min(12,numel(meta.config_sha256)))), ...
        'Stairs show discrete event observations only; source is declared input evaluated at those timestamps.'},'Interpreter','none');
    exportgraphics(fig,files.png,'Resolution',170);
end

function [time,data]=read_series(series,width,name)
    assert(isa(series,'timeseries'),'BehaviorPlot:logger','Missing actual logger %s.',name);
    time=series.Time(:);data=squeeze(series.Data);
    if width==1,data=data(:);elseif size(data,1)~=numel(time),data=data.';end
    assert(isequal(size(data),[numel(time) width])&&isreal(data)&&all(isfinite(data(:)))&& ...
        all(isfinite(time))&&all(diff(time)>=0),'BehaviorPlot:shape','Malformed actual logger %s.',name);
end

function value=public_dither(id,p)
    value=0;if ~p.dither_enabled,return;end
    modulus=2147483647;word=mod(double(p.dither_seed),modulus-1)+1;
    for k=1:id+1,word=mod(16807*word,modulus);end
    value=(floor(4*word/modulus)-1.5)*p.dither_amplitude_v;
end
