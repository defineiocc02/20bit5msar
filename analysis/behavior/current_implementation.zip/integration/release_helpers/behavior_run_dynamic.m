function report = behavior_run_dynamic(N)
%BEHAVIOR_RUN_DYNAMIC Actual saved-SLX dynamic run through the new SAR20 entry.
% Version v1, 2026-10-27. Call behavior_run_dynamic(256) in the new project.
% Extends the already loaded baseline P; never calls adc_parameters/apply or
% regenerates chip parameters. Source defaults remain unchanged (currently N8).
% The same main SLX is saved with resolved N256 P and then run by SAR20('run').
% Captures RAW-ready codes; does not claim serial LVDS or N-2 acceptance.
    if nargin<1,N=256;end
    assert(isscalar(N)&&isnumeric(N)&&isreal(N)&&isfinite(N)&&N>=256&& ...
        N==2^round(log2(N)),'SAR20Dynamic:N','Use an explicit power-of-two N>=256.');
    root=fileparts(mfilename('fullpath'));
    entry=fullfile(root,'SAR20.m');factory=fullfile(root,'config','adc_parameters.m');
    assert(isfile(entry)&&isfile(factory)&&same_file(which('SAR20'),entry), ...
        'SAR20Dynamic:entry','Select this new project SAR20 entry first.');
    sourceBefore=fileread(factory);entryBefore=fileread(entry);
    defaultN=regexp(sourceBefore,'(?m)^\s*N\s*=\s*(\d+)\s*;','tokens','once');
    if isempty(defaultN),declaredDefaultN=[];else,declaredDefaultN=str2double(defaultN{1});end
    globalBefore=rng;
    SAR20('open');
    model='SarAdc';modelFile=fullfile(root,'current','models',[model '.slx']);
    assert(bdIsLoaded(model)&&same_file(get_param(model,'FileName'),modelFile)&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped')&&strcmp(get_param(model,'Dirty'),'off'), ...
        'SAR20Dynamic:model','Require the stopped saved main SLX from this project.');
    ws=get_param(model,'ModelWorkspace');baseline=getVariable(ws,'P');
    assert(baseline.N==8,'SAR20Dynamic:baseline','Start from the accepted saved N8 baseline.');
    assert(isfield(baseline.front,'C_f')&&isfield(baseline.front,'plan'), ...
        'SAR20Dynamic:frontend','Require frozen frontend capacitances and a public plan.');
    cycles=baseline.input.frequency_hz*N/baseline.fs_hz;
    assert(baseline.input.frequency_hz>0&&baseline.input.frequency_hz<baseline.fs_hz/2&& ...
        round(cycles)>0&&round(cycles)<N/2&&abs(cycles-round(cycles))<1e-9, ...
        'SAR20Dynamic:coherence','The retained input must already be coherent; no automatic retuning.');

    preparationStarted=tic;
    P=baseline;P.N=double(N);
    % Only calendar extent changes. Frozen C_f/Cp_f, all time constants,
    % feature seeds, and source parameters are passed back unchanged.
    front=P.front;
    if isfield(front,'group_C_f'),front=rmfield(front,'group_C_f');end
    front.plan_rows=max(double(front.plan_rows),double(N)+double(P.first_id)+4);
    front.plan=[];
    [~,P.front]=behavior_frontend_init(front);
    rows=size(baseline.front.plan,1);
    assert(isequaln(P.front.plan(1:rows,:),baseline.front.plan), ...
        'SAR20Dynamic:planPrefix','Same-seed extended plan changed the accepted prefix.');
    assert(isequaln(front_identity(P.front),front_identity(baseline.front)), ...
        'SAR20Dynamic:chip','Extending the public plan changed frozen frontend/chip/source fields.');
    P=behavior_prepare_configuration(P);
    immutable={'backend','control','digital','input','seed','epoch','Ts_s','first_id','fs_hz','fsr_diff_v','ni'};
    for k=1:numel(immutable)
        name=immutable{k};assert(isfield(baseline,name)&&isequaln(P.(name),baseline.(name)), ...
            'SAR20Dynamic:identity','Resolved dynamic configuration changed P.%s.',name);
    end
    assert(isequaln(front_identity(P.front),front_identity(baseline.front)), ...
        'SAR20Dynamic:preparedChip','Preparation changed the frozen frontend.');
    assert(P.N==N&&size(P.front.plan,1)>=P.n_cycles+1, ...
        'SAR20Dynamic:prepared','Resolved count/plan does not cover the actual run.');
    assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
    save_system(model,modelFile,'SaveModelWorkspace',true);
    preparationElapsed=toc(preparationStarted);

    compileStarted=tic;compileReceipt=SAR20('check');compileElapsed=toc(compileStarted);
    % Sole numerical execution path: run reads the resolved saved P above.
    entryStarted=tic;runReceipt=SAR20('run');entryElapsed=toc(entryStarted);
    assert(strcmp(runReceipt.status,'complete')&&runReceipt.simulation_completed&&runReceipt.records==N, ...
        'SAR20Dynamic:run','The unique entry did not complete the requested actual record.');
    saved=getVariable(ws,'P');
    assert(isequaln(saved,P),'SAR20Dynamic:savedP','Entry execution changed the saved resolved P.');
    assert(strcmp(sourceBefore,fileread(factory))&&strcmp(entryBefore,fileread(entry)), ...
        'SAR20Dynamic:source','Default factory or unique entry source was modified.');
    globalUnchanged=isequaln(globalBefore,rng);
    assert(globalUnchanged,'SAR20Dynamic:rng','Preparation/check/run changed the global RNG.');
    report=struct('status','actual_saved_slx_dynamic_run_complete','requested_records',N, ...
        'baseline_saved_N',baseline.N,'factory_literal_default_N_readonly',declaredDefaultN, ...
        'saved_model_N',P.N,'factory_was_called',false,'apply_was_called',false, ...
        'factory_source_unchanged',true,'same_frozen_chip_and_nonideal_parameters',true, ...
        'same_input_and_feature_seeds',true,'extended_plan_rows',size(P.front.plan,1), ...
        'original_plan_prefix_rows_equal',rows,'n_cycles',P.n_cycles, ...
        'start_time_s',0,'stop_time_s',P.stop_time_s,'global_rng_unchanged',globalUnchanged, ...
        'preparation_and_save_s',preparationElapsed,'separate_check_s',compileElapsed, ...
        'sim_call_s',runReceipt.elapsed_s,'run_entry_wall_s',entryElapsed, ...
        'entry_overhead_outside_sim_s',entryElapsed-runReceipt.elapsed_s, ...
        'check',compileReceipt,'run',runReceipt, ...
        'configuration_scope','Saved Model Workspace override; config/adc_parameters.m is unchanged. A later apply restores its declared defaults.', ...
        'timing_scope','sim_call_s is timed inside the unique entry around sim(); explicit preparation/save and check are separate. Remaining entry time includes snapshots, extraction, spectrum and files; it is not analysis-only.', ...
        'transport_scope','RAW-ready capture, not serial LVDS/N-2 transport acceptance');
    copyfile([mfilename('fullpath') '.m'],fullfile(runReceipt.run_path,'behavior_run_dynamic.m'));
    save(fullfile(runReceipt.run_path,'dynamic_configuration_receipt.mat'),'report','-v7.3');
    write_json(fullfile(runReceipt.run_path,'dynamic_configuration_receipt.json'),report);
end

function p=front_identity(p)
    p=rmfield(p,{'plan','plan_rows'});
end
function yes=same_file(a,b)
    yes=strcmpi(char(java.io.File(a).getCanonicalPath()),char(java.io.File(b).getCanonicalPath()));
end
function write_json(path,value)
    fid=fopen(path,'w','n','UTF-8');assert(fid>=0,'SAR20Dynamic:write','Cannot write receipt.');
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));
end
