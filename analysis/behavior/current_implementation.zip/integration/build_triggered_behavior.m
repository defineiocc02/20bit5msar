function build_triggered_behavior(stage,project)
%BUILD_TRIGGERED_BEHAVIOR v1.0 — repair the measured wrong state task boundary.
% SATK cannot move existing blocks between parents. Preserve the failed graph,
% then recreate only its unchanged specs inside one explicit event-trigger scope.
% No sampling time, comparison, feedback delay or numerical formula changes.
    model='SarBehavior';file=fullfile(stage,'models',[model '.slx']);
    t=fullfile(project,'dependencies','toolkit','tools');
    addpath(fullfile(t,'common'),fullfile(t,'common','autolayout'),fullfile(t,'model_edit'), ...
        fullfile(t,'model_read'),fullfile(t,'model_check'));
    addpath(fullfile(project,'current','runtime_work','native_decode_r1'));
    g=library.settingsLookup();assert(~g.found||g.gatePass);
    if ~bdIsLoaded(model),open_system(file);end
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped'),'behavior:busy','Model is active.');
    marker=fullfile(stage,'models','trigger_boundary_complete.json');
    if isfile(marker),return;end
    audit=fullfile(stage,'models','trigger_audit');if ~isfolder(audit),mkdir(audit);end
    before=fullfile(audit,'before_trigger.slx');if ~isfile(before),copyfile(file,before);end
    root=model_read(model,'root','0');
    step=sar20_satk_named_block_id(root,'EventStep');assert(~isempty(step),'behavior:triggerProbe','Trigger interface was not discovered.');
    % The prior actual model_read reported EventStep control_ports.u3: trigger.
    b={blk('Driver','Constant',struct('Value','[P.input.offset_v;P.input.amplitude_v;P.input.frequency_hz;P.input.phase_rad]')), ...
        blk('Calendar','M-S-Function',struct('Parameters','P.schedule','FunctionName','behavior_event_source')), ...
        sub('EventStep',{'SineCfg','Event'},{})};
    ids=behavior_scope(model,'root',b,{'Driver',1,'EventStep',1;'Calendar',1,'EventStep',2},audit);
    model_read(model,'root','0');
    op=struct('op','connect','target',sprintf('%s.y2 -> %s.u3',ids.Calendar,step));
    result=model_edit(model,'root',jsonencode({op}),'incremental');
    record('trigger_connection.txt',result);
    record('trigger_readback.txt',model_read(model,'root','0'));
    if contains(char(result),'status: partial')||contains(char(result),'status: error')
        record('trigger_partial_check.txt',model_check(model,'root','["unconnected_ports","unconnected_lines"]'));
        save_system(model,file,'SaveModelWorkspace',true);error('behavior:triggerConnect','%s',char(result));
    end
    b={port('SineCfg','Inport',1,4),port('Event','Inport',2,2), ...
        blk('Trigger','TriggerPort',struct('TriggerType','either','InitialTriggerSignalState','zero','ZeroCross','off')), ...
        sub('Adc',{'SineCfg','Calendar'},{'Raw','Ready','Frontend','Backend','Control','Event'}), ...
        sub('Fpga',{'Raw'},{'code20','d1_v','d2_v','dt_v'}), ...
        logblk('RawLog','raw_log'),logblk('ReadyLog','ready_log'), ...
        logblk('FrontLog','front_log'),logblk('BackLog','back_log'), ...
        logblk('ControlLog','control_log'),logblk('EventLog','event_log'), ...
        logblk('CodeLog','code_log'),logblk('D1Log','d1_log'), ...
        logblk('D2Log','d2_log'),logblk('DTLog','dt_log')};
    e={'SineCfg',1,'Adc',1;'Event',1,'Adc',2;'Adc',1,'Fpga',1;'Adc',1,'RawLog',1; ...
        'Adc',2,'ReadyLog',1;'Adc',3,'FrontLog',1;'Adc',4,'BackLog',1; ...
        'Adc',5,'ControlLog',1;'Adc',6,'EventLog',1;'Fpga',1,'CodeLog',1; ...
        'Fpga',2,'D1Log',1;'Fpga',3,'D2Log',1;'Fpga',4,'DTLog',1};
    children=behavior_scope(model,step,b,e,audit);
    [b,e]=behavior_adc_specs();behavior_scope(model,children.Adc,b,e,audit);
    d=behavior_decode_specs();behavior_scope(model,children.Fpga,d.blocks,d.edges,audit);
    % Remove the failed untriggered counterparts only after their replacement exists.
    root=model_read(model,'root','0');ops={};
    obsolete={'Adc','Fpga','RawLog','ReadyLog','FrontLog','BackLog','ControlLog', ...
        'EventLog','CodeLog','D1Log','D2Log','DTLog'};
    for k=1:numel(obsolete)
        id=sar20_satk_named_block_id(root,obsolete{k});
        if ~isempty(id),ops{end+1}=struct('op','delete','target',id);end %#ok<AGROW>
    end
    if ~isempty(ops)
        result=model_edit(model,'root',jsonencode(ops),'full');record('remove_failed_boundary.txt',result);
        assert(~contains(char(result),'status: partial')&&~contains(char(result),'status: error'),'behavior:remove','%s',char(result));
    end
    record('final_graph.txt',model_read(model,'root','inf'));
    result=model_check(model,'root','["unconnected_ports","unconnected_lines"]');record('final_check.txt',result);
    assert(isempty(regexp(char(result),'(?m)^\s*severity:\s*error\b','once')),'behavior:connections','%s',char(result));
    save_system(model,file,'SaveModelWorkspace',true);
    f=fopen(marker,'w');fprintf(f,'{"status":"trigger_boundary_built_compile_pending"}');fclose(f);
    function record(n,txt)
        f=fopen(fullfile(audit,n),'w','n','UTF-8');assert(f>=0);fprintf(f,'%s',char(txt));fclose(f);
    end
end
function b=blk(n,t,p),b=struct('name',n,'type',t,'params',p);end
function b=port(n,t,k,w),b=blk(n,t,struct('Port',num2str(k),'PortDimensions',num2str(w)));end
function b=sub(n,i,o),b=blk(n,'SubSystem',struct());b.interface=struct('inputs',{i},'outputs',{o});end
function b=logblk(n,v),b=blk(n,'ToWorkspace',struct('VariableName',v,'SaveFormat','Timeseries','MaxDataPoints','inf','SampleTime','-1'));end
