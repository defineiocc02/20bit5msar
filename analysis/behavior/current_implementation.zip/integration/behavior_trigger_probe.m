function behavior_trigger_probe()
% Discover the actual SATK trigger interface before connecting special ports.
    stage=fileparts(fileparts(mfilename('fullpath')));project='D:/Academic/Projects/sar20m1/SAR20';
    old=path;c=onCleanup(@()path(old)); %#ok<NASGU>
    addpath(genpath(stage));addpath(fullfile(project,'current','matlab'));
    t=fullfile(project,'dependencies','toolkit','tools');
    addpath(fullfile(t,'common'),fullfile(t,'common','autolayout'),fullfile(t,'model_edit'), ...
        fullfile(t,'model_read'),fullfile(t,'model_check'));
    g=library.settingsLookup();assert(~g.found||g.gatePass);
    m='SarBehavior';file=fullfile(stage,'models',[m '.slx']);
    if bdIsLoaded(m),close_system(m,0);end
    clear behavior_event_source
    open_system(file);
    view=model_read(m,'root','0');write('before.txt',view);
    id=sar20_satk_named_block_id(view,'EventStep');
    if isempty(id)
        ops={struct('op','create_subsystem','name','EventStep','ref','step', ...
            'interface',struct('inputs',{{'SineCfg','Event'}},'outputs',{{}}))};
        write('create_step.txt',model_edit(m,'root',jsonencode(ops),'incremental'));
        view=model_read(m,'root','0');id=sar20_satk_named_block_id(view,'EventStep');
    end
    view=model_read(m,id,'0');write('step_before.txt',view);
    if isempty(sar20_satk_named_block_id(view,'Trigger'))
        op=struct('op','add_block','type','TriggerPort','name','Trigger','ref','trigger', ...
            'params',struct('TriggerType','either','InitialTriggerSignalState','zero','ZeroCross','off'));
        write('create_trigger.txt',model_edit(m,id,jsonencode({op}),'full'));
    end
    write('root_after.txt',model_read(m,'root','0'));
    write('step_after.txt',model_read(m,id,'0'));
    write('connectivity.txt',model_check(m,'root','["unconnected_ports","unconnected_lines"]'));
    save_system(m,file,'SaveModelWorkspace',true);
    function write(n,txt)
        f=fopen(fullfile(pwd,n),'w','n','UTF-8');assert(f>=0);fprintf(f,'%s',char(txt));fclose(f);
    end
end
