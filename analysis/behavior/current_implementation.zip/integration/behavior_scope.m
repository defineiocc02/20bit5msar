function ids = behavior_scope(model, scope, blocks, edges, audit)
%DECODE_SCOPE 将一层数字重构框图写入已读取的 SATK scope。
% 版本：1.1（2026-10-23）。调用：ids=decode_scope(model,scope,blocks,edges,audit)。
% blocks 为本模块的具名原生块；edges 每行为 {源名,源端口,目的名,目的端口}。
% 本函数只负责构图事务与证据；物理/数字算法分别写在各模块的 specs 中。
% 不删除已有块，不覆盖冲突连接。partial 后立即 read/check/save，允许按原图续建。
    view = read_scope();
    ops = {};
    for k = 1:numel(blocks)
        b = blocks{k};
        if strcmp(b.type,'M-S-Function') && isfield(b.params,'Parameters')
            % MATLAB initializes a Level-2 block when FunctionName is assigned.
            % Install its dialog expressions first, as in the existing builders.
            f=fieldnames(b.params);
            b.params=orderfields(b.params,[{'Parameters'};f(~strcmp(f,'Parameters'))]);
        end
        if strcmp(b.type,'Selector') && isfield(b.params,'InputPortWidth')
            % R2024a逐项校验参数：扩宽先声明宽度；缩窄须先移除默认[1 2 3]索引。
            fields=fieldnames(b.params);
            first={'InputPortWidth'};
            width=str2double(b.params.InputPortWidth);
            if isfinite(width) && width<3 && isfield(b.params,'Indices')
                first={'Indices';'InputPortWidth'};
            end
            b.params=orderfields(b.params,[first;fields(~ismember(fields,first))]);
        end
        id = sar20_satk_named_block_id(view, b.name);
        if isempty(id)
            if strcmp(b.type, 'SubSystem')
                op = struct('op','create_subsystem','name',b.name,'ref',b.name, ...
                    'interface',b.interface);
            else
                op = struct('op','add_block','type',native_type(b.type),'name',b.name, ...
                    'ref',b.name,'params',b.params);
            end
            ops{end+1,1} = op; %#ok<AGROW>
        elseif ~isempty(fieldnames(b.params))
            ops{end+1,1} = struct('op','configure','target',id,'params',b.params); %#ok<AGROW>
        end
    end
    if ~isempty(ops)
        apply(ops, 'blocks');
    end
    view = read_scope();
    ids = struct();
    for k = 1:numel(blocks)
        name = blocks{k}.name;
        ids.(name) = sar20_satk_named_block_id(view, name);
        assert(~isempty(ids.(name)), 'ADC:DecodeMissingBlock', 'Missing %s.', name);
    end
    ops = {};
    for k = 1:size(edges,1)
        src = ids.(edges{k,1}); dst = ids.(edges{k,3});
        dp = get_param(resolve(dst), 'PortHandles');
        assert(numel(dp.Inport) >= edges{k,4}, 'ADC:DecodePort', ...
            '%s has no input %d.', edges{k,3}, edges{k,4});
        line = get_param(dp.Inport(edges{k,4}), 'Line');
        if line <= 0
            ops{end+1,1} = struct('op','connect','target',sprintf('%s.y%d -> %s.u%d', ...
                src,edges{k,2},dst,edges{k,4}), 'params',struct('Name',edges{k,1})); %#ok<AGROW>
        else
            sp = get_param(line, 'SrcPortHandle');
            while sp <= 0
                line = get_param(line, 'LineParent');
                sp = get_param(line, 'SrcPortHandle');
            end
            actual = Simulink.ID.getSID(get_param(sp, 'Parent'));
            assert(strcmp(actual,[model ':' extractAfter(src,'blk_')]) && ...
                get_param(sp,'PortNumber') == edges{k,2}, 'ADC:DecodeWireConflict', ...
                'Existing connection disagrees with %s -> %s.', edges{k,1},edges{k,3});
        end
    end
    if ~isempty(ops)
        apply(ops, 'connections');
    end
    read_scope();
    save_system(model, get_param(model,'FileName'), 'SaveModelWorkspace',true);
    report = model_check(model,scope,'["unconnected_ports","unconnected_lines"]');
    record('check',report);
    hasChildren=any(cellfun(@(b)strcmp(b.type,'SubSystem'),blocks));
    if ~hasChildren
        okay(report);
        assert(isempty(regexp(char(report),'(?m)^\s*severity:\s*error\b','once')), ...
            'ADC:DecodeConnectivity','Connectivity errors: %s',char(report));
    end
    % model_check递归进入子层。父层刚创建的空子系统接口暂时未接通；
    % 该报告只记录施工状态。每个叶层严格检查，全部完成后主构图器再严格检查Digital。

    function view = read_scope()
        view = model_read(model,scope,'0'); record('read',view); okay(view);
    end
    function apply(operations,label)
        read_scope();
        record([label '_ops'],jsonencode(operations));
        paths=find_system(resolve(scope),'SearchDepth',1,'Type','Block');
        types=cellfun(@(p)get_param(p,'BlockType'),paths,'UniformOutput',false);
        % 新scope只有自身和接口时整体排布；已部分构建时保留原有位置。
        emptyScope=all(ismember(types,{'SubSystem','Inport','Outport'}));
        layout='incremental'; if emptyScope, layout='full'; end
        result = model_edit(model,scope,jsonencode(operations),layout);
        record(label,result);
        if contains(char(result),'status: partial') || contains(char(result),'status: error')
            record('partial_read',model_read(model,scope,'inf'));
            record('partial_check',model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));
            save_system(model,get_param(model,'FileName'),'SaveModelWorkspace',true);
            error('ADC:DecodePartial','Saved partial scope %s: %s',scope,char(result));
        end
        okay(result);
    end
    function name = resolve(id)
        if strcmp(id,'root'),name=model;return;end
        name = Simulink.ID.getFullName([model ':' extractAfter(id,'blk_')]);
    end
    function record(label,value)
        if ~isfolder(audit), mkdir(audit); end
        file=fullfile(audit,sprintf('%04d_%s_%s.txt',numel(dir(fullfile(audit,'*.txt')))+1,scope,label));
        fid=fopen(file,'w','n','UTF-8'); assert(fid~=-1);
        c=onCleanup(@()fclose(fid)); %#ok<NASGU>
        fprintf(fid,'%s',char(value));
    end
end

function type=native_type(type)
% 清单允许可读显示名；SATK内建块接口明确使用BlockType。
    if strcmp(type,'Math Function')
        type='Math';
    elseif strcmp(type,'Logical Operator')
        type='Logic';
    else
        type=strrep(type,' ','');
    end
end

function okay(value)
    token=regexp(char(value),'(?m)^status:\s*(\w+)','tokens','once');
    assert(~isempty(token)&&any(strcmp(token{1},{'ok','success','healthy'})), ...
        'ADC:DecodeSATK','%s',char(value));
end
