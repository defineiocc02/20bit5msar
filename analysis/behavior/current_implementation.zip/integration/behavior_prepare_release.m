function behavior_prepare_release()
% Prepare and exercise the single-entry package before touching the old project.
    stage=fileparts(fileparts(mfilename('fullpath')));pub=fullfile(stage,'public');
    project='D:/Academic/Projects/sar20m1/SAR20';
    oldPath=path;oldPwd=pwd;cleanup=onCleanup(@restore); %#ok<NASGU>
    addpath(genpath(stage));addpath(fullfile(project,'current','matlab'));
    binding=jsondecode(fileread(fullfile(project,'state','current_binding.json')));
    data=load(binding.workspace_snapshot_file,'SAR20_P');p=data.SAR20_P;
    nominal=struct('sample_period_s',p.sample_period_s, ...
        'sar1',struct('delta_v',p.sar1.delta_v),'sar2',struct('limit_v',p.sar2.limit_v), ...
        'dac2',struct('net_nominal',p.dac2.net_nominal,'reference_v',p.dac2.reference_v, ...
            'initial_floating_charge_b_c',p.dac2.initial_floating_charge_b_c), ...
        'ra',struct('intrinsic_output_cap_f',p.ra.intrinsic_output_cap_f), ...
        'calibration',struct('mode','off'),'fpga',p.fpga);
    save(fullfile(pub,'config','nominal.mat'),'nominal','-v7');
    modelFolder=fullfile(pub,'current','models');if ~isfolder(modelFolder),mkdir(modelFolder);end
    dest=fullfile(modelFolder,'SarAdc.slx');
    if ~isfile(dest)
        if ~bdIsLoaded('SarBehavior'),open_system(fullfile(stage,'models','SarBehavior.slx'));end
        assert(strcmp(get_param('SarBehavior','SimulationStatus'),'stopped'));
        save_system('SarBehavior',dest,'SaveModelWorkspace',true);
    end
    if ~bdIsLoaded('SarAdc'),open_system(dest);end
    t=fullfile(project,'dependencies','toolkit','tools');
    addpath(fullfile(t,'common'),fullfile(t,'common','autolayout'),fullfile(t,'model_edit'), ...
        fullfile(t,'model_read'),fullfile(t,'model_check'));
    g=library.settingsLookup();assert(~g.found||g.gatePass);
    model_read('SarAdc','root','0');
    setup='addpath(genpath(fullfile(fileparts(fileparts(get_param(bdroot,''FileName''))),''src'')),''-begin'');';
    op=struct('op','configure','target','config:SarAdc', ...
        'params',struct('InitFcn',setup,'PostLoadFcn',setup));
    response=model_edit('SarAdc','root',jsonencode({op}),'incremental');
    assert(~contains(char(response),'status: error')&&~contains(char(response),'status: partial'),'behavior:callback','%s',char(response));
    save_system('SarAdc',dest,'SaveModelWorkspace',true);close_system('SarAdc',0);
    % The package must resolve its own entry and kernels, not the prior project.
    cd(pub);addpath(pub,'-begin');clear SAR20
    assert(strcmpi(which('SAR20'),fullfile(pub,'SAR20.m')));
    applied=SAR20('apply');checked=SAR20('check');run=SAR20('run');
    assert(strcmp(run.status,'complete'));
    ref=load(fullfile(project,'runs','behavior_probe_20261026T162332Z','actual','capture.mat'),'capture');
    assert(isequal(run.code20,[ref.capture.samples.code20]),'behavior:releaseCode','New entry changed actual codes.');
    image=SAR20('sample',4,run.run_path);
    result=struct('status','single_entry_package_actual_n8_pass','apply',applied, ...
        'check',checked,'run',run,'sample',image,'old_project_modified',false);
    f=fopen(fullfile(pub,'PACKAGE_CHECK.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(result));fclose(f);
    function restore(),cd(oldPwd);path(oldPath);end
end
