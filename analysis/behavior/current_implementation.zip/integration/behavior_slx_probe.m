function behavior_slx_probe()
%BEHAVIOR_SLX_PROBE v1.0 — compile/run the real event diagram, save actual errors.
% Resumes one staged SLX; old public project and models are not edited.
    stage=fileparts(fileparts(mfilename('fullpath')));
    project='D:/Academic/Projects/sar20m1/SAR20';
    output=fullfile(pwd,'actual');if ~isfolder(output),mkdir(output);end
    models=fullfile(stage,'models');if ~isfolder(models),mkdir(models);end
    old=path;restore=onCleanup(@()path(old)); %#ok<NASGU>
    addpath(genpath(stage));addpath(fullfile(project,'current','matlab'));
    report=struct('status','running','stage','build');write_report();
    try
        binding=jsondecode(fileread(fullfile(project,'state','current_binding.json')));
        S=load(binding.workspace_snapshot_file,'SAR20_P');
        P=behavior_parameters(S.SAR20_P,8);
        modelFile=fullfile(models,'SarBehavior.slx');
        if isfile(fullfile(models,'build_audit','final_connectivity.txt'))
            if bdIsLoaded('SarBehavior')
                assert(strcmp(get_param('SarBehavior','SimulationStatus'),'stopped'), ...
                    'behavior:busy','Do not touch a running model.');
                close_system('SarBehavior',0);
            end
            clear behavior_control_stage behavior_control_stage_sfun behavior_event_source
            open_system(modelFile);
        else
            modelFile=build_behavior_model(P,models,project);
        end
        build_triggered_behavior(stage,project);
        report.model_file=modelFile;report.stage='compile';write_report();
        set_param('SarBehavior','SimulationCommand','update');
        feval('SarBehavior',[],[],[],'compile');
        stateBlocks=find_system('SarBehavior','BlockType','UnitDelay');
        functionBlocks=find_system('SarBehavior','BlockType','S-Function');
        inspected=[stateBlocks;functionBlocks];sampleTimes=struct('block',{},'sample_time',{});
        for k=1:numel(inspected)
            sampleTimes(k)=struct('block',inspected{k}, ...
                'sample_time',get_param(inspected{k},'CompiledSampleTime'));
        end
        feval('SarBehavior',[],[],[],'term');
        report.sample_times=sampleTimes;write_report();
        report.stage='actual_simulation';write_report();
        before=rng;t=tic;out=sim('SarBehavior');elapsed=toc(t);
        report.elapsed_s=elapsed;report.global_rng_unchanged=isequal(before,rng);
        save(fullfile(output,'simout.mat'),'out','elapsed','P','-v7.3');
        ready=out.ready_log;raw=out.raw_log;codes=out.code_log;
        use=ready.Data(:)>0 & raw.Data(:,4)>=P.first_id & raw.Data(:,4)<P.first_id+P.N;
        rows=raw.Data(use,:);actualCodes=codes.Data(use,:);
        report.selected_raw=rows;report.codes=actualCodes(:).';
        assert(size(rows,1)==P.N,'behavior:recordCount','Expected eight actual raw latches.');
        assert(all(rows(:,6)==1),'behavior:valid','An output record is invalid.');
        ref=load(fullfile(project,'runs','behavior_probe_20261026T162332Z','actual','capture.mat'),'capture');
        target=ref.capture.samples;
        assert(isequal(actualCodes(:),[target.code20].')&& ...
            isequal(rows(:,1:3),[[target.D1].' [target.D2].' [target.DT].']), ...
            'behavior:kernelParity','SLX raw words/codes differ from actual pure-kernel capture.');
        report.raw_and_code_match_actual_kernel=true;
        report.independent=behavior_validate_slx(out,P,ref.capture);
        report.stage='export';write_report();
        print('-sSarBehavior','-dpng',fullfile(output,'Top.png'));
        view=model_read('SarBehavior','root','0');
        step=sar20_satk_named_block_id(view,'EventStep');
        stepName=Simulink.ID.getFullName(['SarBehavior:' extractAfter(step,'blk_')]);
        print(['-s' stepName],'-dpng',fullfile(output,'System.png'));
        view=model_read('SarBehavior',step,'0');
        for pair={'Adc','ADC';'Fpga','FPGA'}.'
            id=sar20_satk_named_block_id(view,pair{1});
            sid=extractAfter(id,'blk_');name=Simulink.ID.getFullName(['SarBehavior:' sid]);
            print(['-s' name],'-dpng',fullfile(output,[pair{2} '.png']));
        end
        save_system('SarBehavior',modelFile,'SaveModelWorkspace',true);
        copyfile(modelFile,fullfile(output,'SarBehavior.as_run.slx'));
        report.status='actual_simulink_n8_complete';report.stage='complete';
        report.scope='Behavior baseline; no full LVDS, calibration, NI scan or paper-performance claim';
        write_report();
    catch cause
        report.status='failed';report.identifier=cause.identifier;
        report.error=getReport(cause,'extended','hyperlinks','off');
        if bdIsLoaded('SarBehavior')&&strcmp(get_param('SarBehavior','SimulationStatus'),'stopped')
            save_system('SarBehavior',fullfile(models,'SarBehavior.slx'),'SaveModelWorkspace',true);
        end
        save(fullfile(output,'partial.mat'),'report','-v7');write_report();rethrow(cause);
    end
    function write_report()
        fid=fopen(fullfile(output,'result.json'),'w','n','UTF-8');assert(fid>=0);
        fprintf(fid,'%s',jsonencode(report));fclose(fid);
    end
end
