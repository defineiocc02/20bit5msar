function report=SAR20(action,varargin)
%SAR20 v2 — sole public entry for the editable behavioral Simulink project.
% SAR20 / SAR20('open'|'setup'|'apply'|'check'|'run')
% SAR20('sample',id[,runPath]) plots one sample from an actual saved run.
% Root-relative current/models/SarAdc.slx, current/src and config/adc_parameters.m.
% apply derives parameters; run ALWAYS uses the saved model workspace P.
% SHA records identity; editing source/model does not require hash rebasing.
    if nargin==0||isempty(action),action='open';end
    action=lower(char(action));
    assert(ismember(action,{'setup','open','apply','check','run','sample'}), ...
        'SAR20:action','Unknown action.');
    root=fileparts(mfilename('fullpath'));src=fullfile(root,'current','src');
    config=fullfile(root,'config');model='SarAdc';modelFile=fullfile(root,'current','models',[model '.slx']);
    assert(isfolder(src)&&isfolder(config),'SAR20:layout','Missing current/src or config.');
    addpath(genpath(src),config,'-begin');
    report=struct('action',action,'status','setup_complete','project_root',root);
    if strcmp(action,'setup'),return;end
    if strcmp(action,'sample')
        assert(~isempty(varargin),'SAR20:sampleID','Use SAR20(''sample'',id[,runPath]).');
        id=varargin{1};assert(isscalar(id)&&isfinite(id)&&id>=0&&id==floor(id),'SAR20:sampleID','ID must be nonnegative integer.');
        if numel(varargin)>=2,runPath=char(varargin{2});else
            pointer=fullfile(root,'runs','latest_behavior_run.json');
            assert(isfile(pointer),'SAR20:noRun','No completed behavioral run has been recorded.');
            latest=jsondecode(fileread(pointer));runPath=latest.run_path;
        end
        runtime_entry('behavior_sample_plot',src);
        behavior_sample_plot(runPath,id);
        report=struct('action','sample','status','sample_plot_requested','run_path',runPath,'sample_id',id);return;
    end
    assert(isfile(modelFile),'SAR20:model','Missing unique current/models/SarAdc.slx.');
    guard_model(model,modelFile);
    wasLoaded=bdIsLoaded(model);
    if strcmp(action,'open'),open_system(modelFile);report.status='model_opened';return;end
    if ~wasLoaded,load_system(modelFile);end
    cleanup=onCleanup(@()close_owned(model,wasLoaded)); %#ok<NASGU>
    ws=get_param(model,'ModelWorkspace');
    switch action
        case 'apply'
            runtime_entry('adc_parameters',config);runtime_entry('behavior_prepare_configuration',src);
            P=adc_parameters();P=behavior_prepare_configuration(P);
            assert(isstruct(P)&&isscalar(P)&&isfield(P,'digital'),'SAR20:parameters','Factory must return complete P with digital settings.');
            assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
            save_system(model,modelFile,'SaveModelWorkspace',true);
            applied=struct('utc',utc_now(),'model_sha256',sha(modelFile),'config',P);
            state=fullfile(root,'state');if ~isfolder(state),mkdir(state);end
            write_json(fullfile(state,'applied_config.json'),applied);
            report=struct('action','apply','status','parameters_applied','model_sha256',applied.model_sha256);
        case 'check'
            P=getVariable(ws,'P'); %#ok<NASGU>
            set_param(model,'SimulationCommand','update');
            report=struct('action','check','status','actual_model_update_pass','model_sha256',sha(modelFile),'simulation_run',false);
        case 'run'
            P=getVariable(ws,'P');
            runtime_entry('behavior_spectrum',src);
            report=run_saved(model,modelFile,P,root,src,config);
    end
end

function report=run_saved(model,modelFile,P,root,src,config)
    runPath=fullfile(root,'runs',['behavior_' char(java.util.UUID.randomUUID())]);mkdir(runPath);
    report=struct('action','run','status','started','utc',utc_now(),'run_path',runPath, ...
        'model_kind','behavioral','simulation_completed',false,'model_sha256',sha(modelFile), ...
        'capture_boundary','raw_latch; not serial LVDS/N-2 acceptance');
    file=fullfile(runPath,'summary.json');write_json(file,report);
    try
        save(fullfile(runPath,'parameters.mat'),'P','-v7.3');
        write_json(fullfile(runPath,'parameters.json'),P);
        report.config_sha256=sha(fullfile(runPath,'parameters.mat'));
        report.config_identity='parameters.mat preserves full resolved P; JSON is a readable projection';
        copyfile(modelFile,fullfile(runPath,'SarAdc.slx'));
        assert(strcmp(sha(fullfile(runPath,'SarAdc.slx')),report.model_sha256), ...
            'SAR20:snapshot','Copied model differs from the actual source.');
        report.source_files=snapshot_source(root,src,config,runPath);
        report.source_zip_sha256=sha(fullfile(runPath,'source.zip'));
        report.status='running';write_json(file,report);
        started=tic;simout=sim(model,'ReturnWorkspaceOutputs','on');report.elapsed_s=toc(started);
        save(fullfile(runPath,'simout.mat'),'simout','-v7.3');
        if isprop(simout,'ErrorMessage')&&~isempty(simout.ErrorMessage)
            error('SAR20:simulation','%s',simout.ErrorMessage);
        end
        report.simulation_completed=true;
        [selected,metadata]=select_actual(simout,P);
        save(fullfile(runPath,'selected.mat'),'selected','metadata','-v7.3');
        report.records=numel(selected.code20);report.sample_ids=selected.raw(:,4).';
        report.raw_words=selected.raw;report.code20=selected.code20.';
        report.selected_sha256=sha(fullfile(runPath,'selected.mat'));
        if P.N>=256
            metrics=behavior_spectrum(selected.code20,metadata);
            save(fullfile(runPath,'spectrum.mat'),'metrics','-v7.3');
            report.spectrum_status=metrics.status;
            for field={'snr_db','sndr_db','sfdr_db','thd_db','enob'}
                if isfield(metrics,field{1}),report.(field{1})=metrics.(field{1});end
            end
        else,report.spectrum_status='not_run_short_capture';end
        report.status='complete';report.finished_utc=utc_now();write_json(file,report);
        write_json(fullfile(root,'runs','latest_behavior_run.json'),struct('run_path',runPath,'summary_sha256',sha(file)));
    catch cause
        report.status='failed';report.error_identifier=cause.identifier;
        report.error=getReport(cause,'extended','hyperlinks','off');write_json(file,report);rethrow(cause);
    end
end

function [selected,metadata]=select_actual(simout,P)
% RAW readiness remains distinct from a future RX frame138 readiness signal.
    [raw,t]=series(simout.get('raw_log'),6);[ready,tr]=series(simout.get('ready_log'),1);
    [code,tc]=series(simout.get('code_log'),1);
    assert(isequal(t,tr)&&isequal(t,tc),'SAR20:axes','RAW/ready/code logger axes differ.');
    assert(all(ismember(ready,[0 1])),'SAR20:ready','Ready must be binary.');
    take=ready==1&raw(:,4)>=P.first_id&raw(:,4)<P.first_id+P.N;
    r=raw(take,:);c=code(take);
    assert(size(r,1)==P.N&&isequal(r(:,4),(P.first_id:P.first_id+P.N-1).')&& ...
        all(r(:,5)==P.epoch),'SAR20:records','Expected exactly N consecutive ready IDs with matching epoch.');
    assert(all(r(:,6)==1),'SAR20:invalid','Selected capture contains invalid RAW; keep simout and diagnose.');
    assert(all(isfinite(c)&c==floor(c)&c>=0&c<2^20),'SAR20:code','Code20 outside unsigned20 range.');
    selected=struct('raw',r,'code20',c,'time_s',t(take),'raw_fields',{{'D1','D2','DT','ID','epoch','valid'}});
    metadata=struct('fs_hz',P.fs_hz,'fsr_diff_v',P.fsr_diff_v,'stimulus',P.input);
end
function [x,t]=series(ts,width)
    assert(isa(ts,'timeseries'),'SAR20:logger','Expected native timeseries logger.');
    t=double(ts.Time(:));d=double(ts.Data);
    if ts.IsTimeFirst,x=reshape(d,numel(t),[]);else
        order=[ndims(d) 1:ndims(d)-1];x=reshape(permute(d,order),numel(t),[]);
    end
    assert(isequal(size(x),[numel(t) width]),'SAR20:loggerWidth','Unexpected logger width.');
end
function rows=snapshot_source(root,src,config,runPath)
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(config,'*.mat'))];
    names=cell(numel(files)+1,1);rows=struct('path',{},'sha256',{});
    for k=1:numel(files)
        path=fullfile(files(k).folder,files(k).name);names{k}=relative(path,root);
        rows(end+1)=struct('path',names{k},'sha256',sha(path)); %#ok<AGROW>
    end
    names{end}='SAR20.m';rows(end+1)=struct('path','SAR20.m','sha256',sha(fullfile(root,'SAR20.m')));
    zip(fullfile(runPath,'source.zip'),names,root);
    write_json(fullfile(runPath,'source_manifest.json'),struct('files',rows));
end
function guard_model(model,file)
    if ~bdIsLoaded(model),return;end
    assert(strcmpi(canon(get_param(model,'FileName')),canon(file)),'SAR20:sameName','A different same-name model is loaded.');
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped'),'SAR20:busy','Target model is busy; finish its run first.');
    assert(strcmp(get_param(model,'Dirty'),'off'),'SAR20:dirty','Save or discard target model edits explicitly first.');
end
function close_owned(model,wasLoaded)
    if ~wasLoaded&&bdIsLoaded(model)&&strcmp(get_param(model,'SimulationStatus'),'stopped')
        close_system(model,0);
    end
end
function runtime_entry(name,folder)
    path=which(name);assert(~isempty(path)&&under(path,folder),'SAR20:runtimePath','%s resolves outside the current runtime.',name);
end
function tf=under(path,folder)
    path=canon(path);folder=canon(folder);tf=startsWith(lower(path),[lower(folder) filesep]);
end
function p=relative(path,root),p=char(extractAfter(string(path),strlength(string(root))+1));end
function p=canon(p),p=char(java.io.File(p).getCanonicalPath());end
function s=sha(path)
    fid=fopen(path,'rb');assert(fid>=0,'SAR20:read','Cannot read %s.',path);cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid),bytes=fread(fid,1024*1024,'*uint8');md.update(bytes);end
    s=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
function write_json(path,value)
    fid=fopen(path,'w','n','UTF-8');assert(fid>=0,'SAR20:write','Cannot write %s.',path);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));
end
function s=utc_now(),s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));end
