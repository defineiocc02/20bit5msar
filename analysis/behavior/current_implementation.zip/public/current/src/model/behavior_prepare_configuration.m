function P=behavior_prepare_configuration(P)
%BEHAVIOR_PREPARE_CONFIGURATION Pure schedule and UnitDelay IC construction.
% Version v1 2026-10-27. Caller: public run/build entry after adc_parameters.
% Inputs named P; output P plus calendar/groups/schedule/n_cycles/stop_time_s
% and xFE0/xBK0/xSC0 numeric initial states. SI units, integer event IDs.
% Acquisition is genuinely opened at -Ts; no old captured state is loaded.
    assert(isstruct(P)&&isscalar(P)&&isfinite(P.Ts_s)&&P.Ts_s>0&& ...
        isfinite(P.N)&&P.N>=1&&P.N==floor(P.N)&& ...
        isfinite(P.first_id)&&P.first_id>=0&&P.first_id==floor(P.first_id), ...
        'adc:configuration','Need positive Ts, integer N>=1 and first_id>=0.');
    assert(P.control.sample_period_s==P.Ts_s,'adc:samplePeriod', ...
        'Controller and configuration sample periods must agree.');
    assert(all(P.front.tau_dac_s==0),'adc:dacSettlingScope', ...
        'Finite DAC-to-RA convolution is not integrated; baseline requires tau_dac_s=0.');
    assert(~P.backend.ni.az,'adc:azScope', ...
        'AZ write-calendar integration is pending; do not enable it through a label alone.');
    P.calendar=behavior_calendar(P.control);
    P.groups=behavior_event_groups(P.calendar,false);
    P.n_cycles=P.first_id+P.N;
    P.stop_time_s=(P.n_cycles-1)*P.Ts_s+P.groups(end).time_s;
    P.schedule=struct('sample_period_s',P.Ts_s,'n_cycles',P.n_cycles, ...
        'groups',P.groups,'stop_time_s',P.stop_time_s);

    f=P.front;
    if isfield(f,'group_C_f'),f=rmfield(f,'group_C_f');end
    f.input=P.input;
    [fe,P.front]=behavior_frontend_init(f);
    assert(size(P.front.plan,1)>=P.n_cycles+1,'adc:planLength', ...
        'Frontend plan must cover the record and next-acquisition bank.');
    cmd=struct('event','acquire_open','t_s',-P.Ts_s,'id',0,'epoch',P.epoch);
    [fe,~]=behavior_frontend_step(fe,cmd,P.front);
    P.xFE0=behavior_frontend_pack(fe);

    initialIds=P.front.plan(1,:);
    initialCtop=sum(P.front.group_C_f(initialIds,:),'all')+sum(P.front.Cp_f(initialIds));
    cmd=struct('qres_c',0,'ctop_f',initialCtop, ...
        'd2_signs',zeros(12,1),'ta_signs',zeros(7,1), ...
        'ra_on',false,'az_on',false,'reset',true);
    [bk,~]=behavior_backend_step([],cmd,0,P.backend);
    P.xBK0=behavior_backend_pack(bk);
    [sc,~]=behavior_sar_step([],struct('type','reset'),struct(),P.control);
    P.xSC0=behavior_sar_pack(sc);
end
