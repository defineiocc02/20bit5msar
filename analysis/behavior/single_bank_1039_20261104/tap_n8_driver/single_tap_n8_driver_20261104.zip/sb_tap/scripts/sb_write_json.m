function sb_write_json(filename,value)
% Called only inside a newly created private case directory, or a new gate file.
    assert(~isfile(filename)&&~isfolder(filename),'i1N8:existing','Refuse to overwrite %s',filename);
    fid=fopen(filename,'w','n','UTF-8');assert(fid>=0,'i1N8:write','Cannot write %s',filename);
    closer=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fwrite(fid,unicode2native(jsonencode(value),'UTF-8'),'uint8');
end
