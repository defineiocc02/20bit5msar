function digest=sb_sha256(filename)
% SHA-256 over one fixed local file; never reads a file larger than 300 MB.
    info=dir(filename);
    assert(isscalar(info)&&~info.isdir&&info.bytes<=300000000, ...
        'i1N8:fileSize','Missing file or file exceeds 300 MB: %s',filename);
    fid=fopen(filename,'rb');assert(fid>=0,'i1N8:fileOpen','Cannot open %s',filename);
    closer=onCleanup(@()fclose(fid)); %#ok<NASGU>
    bytes=fread(fid,Inf,'*uint8');
    md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(bytes(:),'int8'));
    digest=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
