function entries=sb_check_runtime(runtime,manifestFile,modelSha)
% 110 actual source/config files from fixed v2 manifest; model is audited variant.
    mf=manifestFile;
    assert(strcmp(sb_sha256(mf),'2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514'), ...
        'sbN8:manifest','Single-bank v2 manifest differs.');
    manifest=jsondecode(fileread(mf));all=manifest.items;entries=struct('path',{},'sha256',{});
    for k=1:numel(all)
        rel=all(k).path;
        if strcmp(rel,'SAR20.m')||startsWith(rel,'config/')||startsWith(rel,'current/src/')
            target=fullfile(runtime,strrep(rel,'/',filesep));
            assert(isfile(target)&&strcmp(sb_sha256(target),all(k).sha256), ...
                'sbN8:sourceHash','Wrong runtime source/config bytes: %s',rel);
            entries(end+1)=struct('path',rel,'sha256',all(k).sha256); %#ok<AGROW>
        end
    end
    assert(numel(entries)==110,'sbN8:sourceCount','Require 110 pinned source/config files.');
    expected={entries.path};actual={'SAR20.m'};
    for sub={'current/src','config'}
        base=fullfile(runtime,strrep(sub{1},'/',filesep));listing=dir(fullfile(base,'**','*'));
        for k=1:numel(listing)
            if listing(k).isdir,continue;end
            f=fullfile(listing(k).folder,listing(k).name);
            assert(startsWith(f,[runtime filesep]),'sbN8:sourcePath','Source escaped runtime root.');
            actual{end+1}=strrep(f(numel(runtime)+2:end),filesep,'/'); %#ok<AGROW>
        end
    end
    assert(isequal(sort(actual(:)),sort(expected(:))),'sbN8:sourceInventory','Runtime inventory differs.');
    model=fullfile(runtime,'current','models','SarAdc.slx');
    assert(isfile(model)&&strcmp(sb_sha256(model),modelSha)&& ...
        ~strcmp(modelSha,'d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0'), ...
        'sbN8:modelHash','Require the separately audited modified graph, not old d4.');
end
