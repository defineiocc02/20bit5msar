function root=sb_jobroot(jobRoot)
% Isolated Windows task root: real path directly under D:/Temp, no symlink alias.
    assert(ispc&&ischar(jobRoot)&&isfolder(jobRoot),'sbN8:job', ...
        'Use D:/Temp/SAR20SBN8_<unique_id> in a new headless process.');
    f=java.io.File(jobRoot);p=f.toPath();absolute=char(p.toAbsolutePath().normalize().toString());
    opts=javaArray('java.nio.file.LinkOption',0);real=char(p.toRealPath(opts).toString());
    a=lower(strrep(absolute,'\','/'));b=lower(strrep(real,'\','/'));
    assert(strcmp(a,b),'sbN8:reparse','Job path may not traverse reparse points or symlinks.');
    assert(~isempty(regexp(b,'^d:/temp/sar20sbn8_[a-z0-9_-]+$','once')), ...
        'sbN8:job','Job root must be a direct uniquely named child of D:/Temp.');
    root=real;
end
