# 单前端1039Cu N8：只读tap阶段，未执行

此包仅在同一 jobRoot 的 plain N8 实际完成后使用；不修改plain输入、实际simout或runtime。P、模型及回执身份同plain：真实原P `dfa91dda...`、v2 源manifest `2cbdffe5...`、SATK图及独立审计由外层输入完整SHA。解包前后核清单与归档，逐层拒绝symlink/reparse；必须新起一次性headless MATLAB进程，与旧GUI和plain进程隔离。

将本包 `scripts/` 解到 `jobRoot/tap_scripts/`，并仅在新进程开头加入该路径：

```matlab
addpath(fullfile(jobRoot,'tap_scripts'),'-begin');
sb_n8_case(jobRoot,modelSha,satkReceiptSha,graphAuditSha,'tap');
```

入口自动验证plain `complete.json`及其simout/P哈希；从同一原P派生，仅开启`P.debug.adi_enabled`和`P.debug.aperture_enabled`这两个现有**只读观察**，重新prepare并保存完整P及字段差异。这个历史字段名不代表开启ADI：前端单bank、pool/DEM/dither/jitter保持关闭，采样率仍5MS/s。除 `adi_wire_log`、`aperture_log` 的观察输出外，所有实际输出变量及3根根口的Time/Data均需与plain逐位一致。

实际tap检查12个周期×48组：数值分段索引1–8及ID/epoch；D2/TA/反馈的实际stage-next计数在RAW事件为12/8/7；RA命令sign与前一真实控制字逐事件对照；非零VY的真实位与符号对照，VY为0单列不猜。aperture28的开采时间是 Sample.next353 保存的状态元数据，不是开关边沿波形。stage-next和命令线是真实计算端口，但不是独立观测的UnitDelay已提交历史；release逐片电荷与跨周保持仍标UNOBSERVED。

本包仅为静态审计通过的驱动，尚未运行MATLAB/Simulink；失败保留实际P/simout与错误、禁止覆盖重试。N8不是FFT、静态线性度、论文性能或signoff结论。
