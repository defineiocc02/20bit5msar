function result=sb_n8_case(jobRoot,modelSha,satkReceiptSha,graphAuditSha,phase)
% One isolated single-bank N8 run in a newly launched headless batch.
% phase='plain' uses the real prepared P unchanged; phase='tap' only changes
% two existing read-only debug enables and proves non-debug outputs bit-equal.
% The external controller must first verify both frozen manifests and recursively
% reject symlink/reparse entries in runtime/inputs/scripts. No production writes.
    scripts=fileparts(mfilename('fullpath'));bootstrap(scripts);
    jobRoot=sb_jobroot(jobRoot);
    assert(ischar(phase)&&strcmp(phase,'plain'), ...
        'sbN8:phase','This frozen package supports plain only.');
    for h={modelSha,satkReceiptSha,graphAuditSha}
        assert(ischar(h{1})&&~isempty(regexp(h{1},'^[0-9a-f]{64}$','once')), ...
            'sbN8:hash','Use an explicit lowercase SHA256.');
    end
    assert(feature('getpid')~=27628&&~usejava('desktop'),'sbN8:session', ...
        'A newly launched isolated headless MATLAB process is required.');
    systems=find_system('SearchDepth',0,'Type','block_diagram');
    for k=1:numel(systems),assert(bdIsLibrary(systems{k}),'sbN8:loaded','Start with no loaded model.');end
    runtime=fullfile(jobRoot,'runtime');inputs=fullfile(jobRoot,'inputs');
    manifest=fullfile(inputs,'MANIFEST.json');fixture=fullfile(inputs,'single_bank_P.mat');
    satk=fullfile(inputs,'satk_receipt.json');audit=fullfile(inputs,'graph_audit.json');
    assert(strcmp(sb_sha256(fixture),'dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f')&& ...
        strcmp(sb_sha256(satk),satkReceiptSha)&&strcmp(sb_sha256(audit),graphAuditSha), ...
        'sbN8:inputHash','P, SATK receipt or graph audit identity differs.');
    sr=jsondecode(fileread(satk));ga=jsondecode(fileread(audit));
    assert(strcmp(sr.status,'SATK_BIAS_SAVED_PENDING_INDEPENDENT_GRAPH_AUDIT')&& ...
        strcmp(sr.model_sha256,modelSha)&&strcmp(sr.bias,'DecodeP.d1_bias_v')&& ...
        strcmp(sr.prepared_P_sha256,'dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f')&& ...
        strcmp(sr.manifest_sha256,'2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514')&& ...
        sr.owned_model_closed&&sr.filegen_restored&&sr.path_cwd_restored, ...
        'sbN8:satkReceipt','SATK receipt is incomplete or bound to another graph/P.');
    assert(strcmp(ga.status,'saved_scope_graph_checks_passed')&&ga.modified_model_checked&& ...
        strcmp(ga.baseline_sha256,'d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0')&& ...
        strcmp(ga.modified_sha256,modelSha)&& ...
        strcmp(ga.scope_comparison.old_bias,'-17*DecodeP.vref_v/1024')&& ...
        strcmp(ga.scope_comparison.new_bias,'DecodeP.d1_bias_v'), ...
        'sbN8:graphAudit','Independent graph audit is incomplete or not bound.');
    entries=sb_check_runtime(runtime,manifest,modelSha);
    if strcmp(phase,'tap')
        priorFile=fullfile(jobRoot,'plain','complete.json');sb_sha256(priorFile);
        prior=jsondecode(fileread(priorFile));
        assert(strcmp(prior.status,'plain_pass_feedback_unobserved')&& ...
            strcmp(prior.model_sha256,modelSha)&&strcmp(prior.fixture_sha256, ...
            'dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f')&& ...
            strcmp(sb_sha256(fullfile(jobRoot,'plain','simout.mat')),prior.simout_sha256)&& ...
            strcmp(sb_sha256(fullfile(jobRoot,'plain','P_used.mat')),prior.P_used_sha256), ...
            'sbN8:plainGate','Plain result or its bound files changed.');
    end
    outdir=fullfile(jobRoot,phase);
    assert(~isfolder(outdir)&&~isfile(outdir),'sbN8:exists','Never overwrite a case.');
    [ok,msg,msgid]=mkdir(outdir);assert(ok&&isempty(msgid),'sbN8:mkdir','%s',msg);
    result=struct('status','started','phase',phase,'pid',feature('getpid'), ...
        'model_sha256',modelSha,'fixture_sha256','dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f', ...
        'source_manifest_sha256','2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514', ...
        'satk_receipt_sha256',satkReceiptSha,'graph_audit_sha256',graphAuditSha, ...
        'scope','one single-bank 5MS/s isolated graph; no ADI conversion or 10MS/s');
    oldPath=path;oldCwd=pwd;restore=onCleanup(@()restore_env(oldPath,oldCwd)); %#ok<NASGU>
    try
        bound=sb_bind_runtime(runtime,entries,true);save(fullfile(outdir,'binding_before.mat'),'bound','-v7.3');
        data=load(fixture,'P');assert(isfield(data,'P')&&isstruct(data.P)&&isscalar(data.P), ...
            'sbN8:fixture','Actual prepared P is required.');
        P0=data.P;check_P0(P0);
        if strcmp(phase,'tap')
            P=P0;P.debug.adi_enabled=true;P.debug.aperture_enabled=true;
            P=behavior_prepare_configuration(P);
            changes=sb_diff_paths(P0,P,'P');
            allowed={'P.debug.adi_enabled','P.debug.adi_max_points', ...
                'P.debug.aperture_enabled','P.debug.aperture_max_points'};
            save(fullfile(outdir,'P_used.mat'),'P','P0','-v7.3');
            sb_write_json(fullfile(outdir,'P_difference.json'),struct('paths',{changes},'allowed',{allowed}));
            assert(all(ismember(changes,allowed)),'sbN8:Pdiff','Tap changed physical or other P fields.');
        else
            P=P0;save(fullfile(outdir,'P_used.mat'),'P','P0','-v7.3');
        end
        cd(outdir);Simulink.fileGenControl('set','CacheFolder',fullfile(outdir,'cache'), ...
            'CodeGenFolder',fullfile(outdir,'codegen'),'keepPreviousPath',true,'createDir',true);
        cfg=Simulink.fileGenControl('getConfig');
        assert(inside(char(cfg.CacheFolder),outdir)&&inside(char(cfg.CodeGenFolder),outdir), ...
            'sbN8:fileGen','File generation must remain inside this private case.');
        modelFile=fullfile(runtime,'current','models','SarAdc.slx');
        closer=onCleanup(@()close_owned(modelFile)); %#ok<NASGU>
        load_system(modelFile);
        assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile))&& ...
            strcmp(get_param('SarAdc/EventStep/Fpga/D1CaptureBias','Bias'),'DecodeP.d1_bias_v'), ...
            'sbN8:model','Loaded model or actual SID185 bias differs.');
        ws=get_param('SarAdc','ModelWorkspace');oldP=getVariable(ws,'P');oldD=getVariable(ws,'DecodeP');
        oldCapture=getVariable(ws,'TrainCaptureFile');
        assert(sb_same_bits(oldP,P0)&&sb_same_bits(oldD,P0.digital)&&ischar(oldCapture)&&isempty(oldCapture), ...
            'sbN8:workspace','Saved graph workspace does not contain the real prepared P.');
        sv=ver('simulink');assert(isscalar(sv),'sbN8:version','Simulink version required.');
        result.matlab_version=version;result.matlab_release=version('-release');result.simulink_version=sv.Version;
        result.solver=struct('name',get_param('SarAdc','Solver'),'type',get_param('SarAdc','SolverType'), ...
            'mode',get_param('SarAdc','SimulationMode'),'start',get_param('SarAdc','StartTime'), ...
            'stop',get_param('SarAdc','StopTime'));
        sb_write_json(fullfile(outdir,'started.json'),result);
        si=Simulink.SimulationInput('SarAdc');
        si=si.setVariable('P',P,'Workspace','SarAdc');si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        rngBefore=rng;save(fullfile(outdir,'rng_before.mat'),'rngBefore','-v7.3');
        if strcmp(phase,'tap')
            prFile=fullfile(jobRoot,'plain','rng_before.mat');
            assert(strcmp(sb_sha256(prFile),prior.rng_before_sha256),'sbN8:rngHash','Plain RNG snapshot changed.');
            pr=load(prFile,'rngBefore');assert(sb_same_bits(rngBefore,pr.rngBefore), ...
                'sbN8:rng','Initial RNG differs between plain and tap runs.');
            assert(strcmp(result.matlab_version,prior.matlab_version)&& ...
                strcmp(result.matlab_release,prior.matlab_release)&& ...
                strcmp(result.simulink_version,prior.simulink_version)&&sb_same_bits(result.solver,prior.solver), ...
                'sbN8:runtime','Plain and tap runtime or solver differ.');
        end
        clock=tic;simout=sim(si);result.sim_s=toc(clock);
        save(fullfile(outdir,'simout.mat'),'simout','-v7.3');
        assert(isempty(simout.ErrorMessage),'sbN8:simulation','%s',simout.ErrorMessage);
        assert(isequaln(rngBefore,rng),'sbN8:rng','Global RNG changed.');
        assert(sb_same_bits(getVariable(ws,'P'),oldP)&&sb_same_bits(getVariable(ws,'DecodeP'),oldD)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),oldCapture),'sbN8:workspace','Saved workspace changed.');
        sb_check_runtime(runtime,manifest,modelSha);boundAfter=sb_bind_runtime(runtime,entries,false);
        save(fullfile(outdir,'binding_after.mat'),'boundAfter','-v7.3');
        assert(strcmp(sb_sha256(fixture),result.fixture_sha256),'sbN8:fixture','Prepared P changed.');
        V=behavior_record_view(simout,P);
        assert(size(V.raw,1)==8&&all(V.raw(:,6)==1)&&isequal(V.raw(:,4),(4:11).'), ...
            'sbN8:records','Require eight actual valid IDs 4–11.');
        result.simout_sha256=sb_sha256(fullfile(outdir,'simout.mat'));
        result.P_used_sha256=sb_sha256(fullfile(outdir,'P_used.mat'));
        result.rng_before_sha256=sb_sha256(fullfile(outdir,'rng_before.mat'));
        result.logs=simout.who;result.raw=V.raw;result.code20=V.code20;result.record_time_s=V.time_s;
        result.release_charge='UNOBSERVED_NO_DIRECT_FE_STATE_PROBE';
        sb_write_json(fullfile(outdir,'sim_complete.json'),result);
        if strcmp(phase,'plain')
            validation=sb_validate_plain(simout,P);result.status='plain_pass_feedback_unobserved';
        else
            other=load(fullfile(jobRoot,'plain','simout.mat'),'simout');
            equality=sb_compare_outputs(other.simout,simout);
            validation=sb_validate_tap(simout,P);
            result.status='tap_pass_stage_next_wires_only';result.observer_nondisturbance=equality;
        end
        save(fullfile(outdir,'validation.mat'),'validation','-v7.3');
        sb_write_json(fullfile(outdir,'validation.json'),validation);
        result.validation_mat_sha256=sb_sha256(fullfile(outdir,'validation.mat'));
        result.validation_json_sha256=sb_sha256(fullfile(outdir,'validation.json'));
        sb_write_json(fullfile(outdir,'complete.json'),result);
    catch ex
        failure=struct('status','failed','phase',phase,'id',ex.identifier, ...
            'message',getReport(ex,'extended','hyperlinks','off'));
        sb_write_json(fullfile(outdir,'failed.json'),failure);rethrow(ex);
    end
end
function check_P0(P)
    assert(P.N==8&&P.Ts_s==200e-9&&P.epoch==1&&P.first_id==4&& ...
        P.front.single_bank&&P.control.single_bank&&P.front.single_guard_s==0&& ...
        ~P.front.dem_enabled&&~P.front.dither_enabled&&~P.front.jitter.enabled&& ...
        ~P.debug.adi_enabled&&~P.debug.aperture_enabled&&~P.transport.enabled&& ...
        ~P.training.enabled&&~P.cal_cfg.enabled&&~P.frozen.enabled&&~P.bank.enabled&& ...
        P.digital.d1_bias_v==0&&all(P.front.C_f(:,38)==0), ...
        'sbN8:P','Saved P is not the passed single-bank 1039Cu 5MS/s configuration.');
end
function restore_env(p,c),path(p);cd(c);end
function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function yes=inside(p,parent),a=lower(canon(p));b=lower(canon(parent));yes=strcmp(a,b)||startsWith(a,[b '/']);end
function close_owned(modelFile)
    if ~bdIsLoaded('SarAdc'),return;end
    try
        if strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile))&& ...
            strcmp(get_param('SarAdc','Dirty'),'off')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')
            close_system('SarAdc',0);
        end
    catch
        % The disposable batch exits; never close an unverified model.
    end
end
function bootstrap(scripts)
    list=dir(fullfile(scripts,'*.m'));loaded=inmem('-completenames');
    for k=1:numel(list)
        [~,name]=fileparts(list(k).name);expected=fullfile(scripts,list(k).name);actual=which(name);
        assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected)), ...
            'sbN8:scriptPath','Script resolves from another path: %s',name);
        for j=1:numel(loaded)
            [~,stem]=fileparts(loaded{j});if ~strcmpi(stem,name),continue;end
            assert(strcmpi(name,'sb_n8_case')&&strcmpi(canon(loaded{j}),canon(expected)), ...
                'sbN8:scriptCache','A helper is already cached: %s',loaded{j});
        end
    end
end
