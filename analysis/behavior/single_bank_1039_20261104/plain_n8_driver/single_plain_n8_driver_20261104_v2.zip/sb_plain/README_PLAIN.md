# 单前端1039Cu N8：仅plain短跑，未执行

函数测试产物原P SHA `dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f`，源码manifest SHA `2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514`。运行图SHA必须取SATK真实回执并由独立graph audit绑定；不使用旧d4图。本包只接受 `phase='plain'`，不运行tap、ADI前端或10M。

外层创建全新 `D:/Temp/SAR20SBN8_<id>`，放：`runtime/current/src`、`runtime/config`、`runtime/SAR20.m` 及已审图 `runtime/current/models/SarAdc.slx`；`inputs/MANIFEST.json`、`inputs/single_bank_P.mat`、`inputs/satk_receipt.json`、`inputs/graph_audit.json`；将本包解到 `scripts/` 的父目录，令 `.m` 均在 `jobRoot/scripts`。递归拒绝reparse/symlink，核源/图/P/所有脚本及回执SHA；每批前后再核，专用新headless batch，不动原会话。

```matlab
addpath(fullfile(jobRoot,'scripts'),'-begin');
sb_n8_case(jobRoot,modelSha,satkReceiptSha,graphAuditSha,'plain');
```

先保存实际原P/simout，再核12×48实际EventLog与12条有效RAW、selected ID4–11及return Vtop坐标。`P.debug.adi_enabled` 和 `P.debug.aperture_enabled` 都为false，因此12D2/8TA/7反馈只是保存日历token，真实阶段计数/单组复用和逐片返回电荷均标UNOBSERVED。`CodeValid`是数字bank路由语义，不应误判RAW valid。没有FFT/DNL/INL或论文性能结论。
