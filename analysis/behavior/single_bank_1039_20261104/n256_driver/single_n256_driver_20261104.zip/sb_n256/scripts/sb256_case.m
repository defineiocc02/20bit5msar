function result=sb256_case(jobRoot)
% One actual single-bank N256 run, isolated headless batch, not production.
% Fixed model/P/source identities are based on independently audited 5MS/s N8.
% The external controller verifies driver manifest, file hashes and every
% reparse/symlink boundary before and after this process. No implicit retry.
    scripts=fileparts(mfilename('fullpath'));bootstrap(scripts);jobRoot=sb256_jobroot(jobRoot);
    assert(feature('getpid')~=27628&&~usejava('desktop'),'sb256:session', ...
        'Use a newly launched isolated headless MATLAB batch.');
    systems=find_system('SearchDepth',0,'Type','block_diagram');
    for k=1:numel(systems),assert(bdIsLibrary(systems{k}),'sb256:loaded','Start with no loaded model.');end
    runtime=fullfile(jobRoot,'runtime');inputs=fullfile(jobRoot,'inputs');
    modelSha='48537818b3212e1e4c8231dec433d1fde36d95814cdcce8c529bb2898eb097d3';
    fixtureSha='dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f';
    sourceSha='2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514';
    satkSha='c0502a7519395b297aca991492826799778826e563a7e877a05b993ca5bcfd49';
    graphSha='27be1fa393e4bf2df1910bdbf6d759ec8cf7296adcb5e8a0f5706161a54bc8ed';
    n8ReceiptSha='eb77410ab643ce7484f025a3e19d4927338d317322b40623e3374ddeaa53e51b';
    n8SimSha='d472f01a80a832cd483783e4ceca0640a692e0094d1a64f5400411e5201a934c';
    n8PSha='236ddfb427dfc07e7f7e27dd58746deb30946891717d255b53789aa8127a1e9f';
    manifest=fullfile(inputs,'MANIFEST.json');fixture=fullfile(inputs,'single_bank_P.mat');
    satk=fullfile(inputs,'satk_receipt.json');graph=fullfile(inputs,'graph_audit.json');
    n8receipt=fullfile(inputs,'n8_complete.json');n8sim=fullfile(inputs,'n8_simout.mat');
    n8p=fullfile(inputs,'n8_P_used.mat');
    paths={manifest,fixture,satk,graph,n8receipt,n8sim,n8p};
    pins={sourceSha,fixtureSha,satkSha,graphSha,n8ReceiptSha,n8SimSha,n8PSha};
    for k=1:numel(paths),assert(strcmp(sb256_sha256(paths{k}),pins{k}), ...
            'sb256:inputHash','Pinned input differs: %s',paths{k});end
    sr=jsondecode(fileread(satk));ga=jsondecode(fileread(graph));nr=jsondecode(fileread(n8receipt));
    assert(strcmp(sr.status,'SATK_BIAS_SAVED_PENDING_INDEPENDENT_GRAPH_AUDIT')&& ...
        strcmp(sr.model_sha256,modelSha)&&strcmp(sr.bias,'DecodeP.d1_bias_v')&& ...
        strcmp(sr.prepared_P_sha256,fixtureSha)&&strcmp(sr.manifest_sha256,sourceSha)&& ...
        sr.owned_model_closed&&sr.filegen_restored&&sr.path_cwd_restored, ...
        'sb256:satk','SATK source/P/model receipt differs.');
    assert(strcmp(ga.status,'saved_scope_graph_checks_passed')&&ga.modified_model_checked&& ...
        strcmp(ga.baseline_sha256,'d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0')&& ...
        strcmp(ga.modified_sha256,modelSha)&&strcmp(ga.satk_receipt_sha256,satkSha)&& ...
        strcmp(ga.prepared_P_file_sha256,fixtureSha)&& ...
        strcmp(ga.scope_comparison.old_bias,'-17*DecodeP.vref_v/1024')&& ...
        strcmp(ga.scope_comparison.new_bias,'DecodeP.d1_bias_v'), ...
        'sb256:graphAudit','Independent graph audit is missing or differs.');
    assert(strcmp(nr.status,'plain_pass_feedback_unobserved')&&strcmp(nr.model_sha256,modelSha)&& ...
        strcmp(nr.fixture_sha256,fixtureSha)&&strcmp(nr.simout_sha256,n8SimSha)&& ...
        strcmp(nr.P_used_sha256,n8PSha)&&strcmp(nr.source_manifest_sha256,sourceSha)&& ...
        strcmp(nr.satk_receipt_sha256,satkSha)&&strcmp(nr.graph_audit_sha256,graphSha), ...
        'sb256:n8','Prior actual N8 identity differs.');
    entries=sb256_check_runtime(runtime,manifest,modelSha);
    outdir=fullfile(jobRoot,'n256');
    assert(~isfolder(outdir)&&~isfile(outdir),'sb256:exists','Never overwrite a previous case.');
    [ok,msg,msgid]=mkdir(outdir);assert(ok&&isempty(msgid),'sb256:mkdir','%s',msg);
    result=struct('status','started','pid',feature('getpid'),'utc_started',utc_now(), ...
        'model_sha256',modelSha,'fixture_sha256',fixtureSha,'source_manifest_sha256',sourceSha, ...
        'satk_receipt_sha256',satkSha,'graph_audit_sha256',graphSha, ...
        'n8_receipt_sha256',n8ReceiptSha,'n8_simout_sha256',n8SimSha,'n8_P_sha256',n8PSha, ...
        'scope','single-bank 5MS/s actual model; Fig7 context only, not paper 20k-point data');
    oldPath=path;oldCwd=pwd;restore=onCleanup(@()restore_env(oldPath,oldCwd)); %#ok<NASGU>
    try
        bound=sb256_bind_runtime(runtime,entries,true);save(fullfile(outdir,'binding_before.mat'),'bound','-v7.3');
        original=load(fixture,'P');prior=load(n8p,'P');
        assert(isfield(original,'P')&&isfield(prior,'P')&&sb256_same_bits(original.P,prior.P), ...
            'sb256:fullP','Real N8 P is not the supplied original P.');
        P0=original.P;check_P0(P0);
        P=P0;P.N=256;P.front.plan_rows=264;P.front.plan=[];
        assert(P.input.frequency_hz==97656.25&&P.fs_hz==5e6&& ...
            P.input.frequency_hz*P.N/P.fs_hz==5,'sb256:coherence', ...
            'Original stimulus must be coherent bin5 at N256; no retuning.');
        P=behavior_prepare_configuration(P);
        save(fullfile(outdir,'P_used.mat'),'P','P0','-v7.3');
        changes=sb256_diff_paths(P0,P,'P');
        [before,after]=sb256_diff_values(P0,P,changes);
        save(fullfile(outdir,'P_diff.mat'),'changes','before','after','-v7.3');
        allowed={'P.N','P.front.plan_rows','P.front.plan','P.n_cycles','P.stop_time_s', ...
            'P.schedule.n_cycles','P.schedule.stop_time_s','P.backend.dac_coupling.public_plan', ...
            'P.training.reference.records','P.cal_cfg.N_train','P.cal_cfg.public_cfg.plan_rows'};
        sb256_write_json(fullfile(outdir,'P_difference.json'), ...
            struct('paths',{changes},'allowed',{allowed},'source_fixture_sha256',fixtureSha));
        assert(all(ismember(changes,allowed)),'sb256:Pdiff','Unexpected physical or other P change.');
        assert(P.N==256&&P.front.plan_rows==264&&P.schedule.n_cycles==260&& ...
            P.input.frequency_hz*P.N/P.fs_hz==5,'sb256:preparedP','Prepared N256 configuration differs.');
        cd(outdir);Simulink.fileGenControl('set','CacheFolder',fullfile(outdir,'cache'), ...
            'CodeGenFolder',fullfile(outdir,'codegen'),'keepPreviousPath',true,'createDir',true);
        cfg=Simulink.fileGenControl('getConfig');
        assert(inside(char(cfg.CacheFolder),outdir)&&inside(char(cfg.CodeGenFolder),outdir), ...
            'sb256:fileGen','Generated files must stay in this private case.');
        modelFile=fullfile(runtime,'current','models','SarAdc.slx');
        closer=onCleanup(@()close_owned(modelFile)); %#ok<NASGU>
        load_system(modelFile);biasBlock=Simulink.ID.getFullName('SarAdc:185');
        assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile))&& ...
            strcmp(get_param(biasBlock,'Bias'),'DecodeP.d1_bias_v'), ...
            'sb256:model','Loaded graph or SID185 bias differs.');
        ws=get_param('SarAdc','ModelWorkspace');oldP=getVariable(ws,'P');oldD=getVariable(ws,'DecodeP');
        oldCapture=getVariable(ws,'TrainCaptureFile');
        assert(sb256_same_bits(oldP,P0)&&sb256_same_bits(oldD,P0.digital)&& ...
            ischar(oldCapture)&&isempty(oldCapture),'sb256:workspace','Saved graph workspace P differs.');
        sv=ver('simulink');assert(isscalar(sv),'sb256:version','Simulink version required.');
        result.matlab_version=version;result.matlab_release=version('-release');result.simulink_version=sv.Version;
        result.solver=struct('name',get_param('SarAdc','Solver'),'type',get_param('SarAdc','SolverType'), ...
            'mode',get_param('SarAdc','SimulationMode'),'start',get_param('SarAdc','StartTime'), ...
            'stop',get_param('SarAdc','StopTime'));
        assert(strcmp(result.matlab_version,nr.matlab_version)&& ...
            strcmp(result.matlab_release,nr.matlab_release)&&strcmp(result.simulink_version,nr.simulink_version)&& ...
            sb256_same_bits(result.solver,nr.solver),'sb256:runtime','N256 runtime or solver differs from N8.');
        result.P_used_sha256=sb256_sha256(fullfile(outdir,'P_used.mat'));
        result.P_diff_sha256=sb256_sha256(fullfile(outdir,'P_diff.mat'));
        result.sample_rate_hz=P.fs_hz;result.input_frequency_hz=P.input.frequency_hz;
        result.input_amplitude_vpeak=P.input.amplitude_v;result.input_phase_rad=P.input.phase_rad;
        result.input_amplitude_dbfs=20*log10(P.input.amplitude_v/(P.fsr_diff_v/2));
        result.N=256;result.first_id=P.first_id;result.epoch=P.epoch;result.seed=P.seed;
        result.ktc_seed=P.front.ktc_seed;result.ktc_enabled=P.front.ktc_enabled;
        result.pool_seed=P.front.pool_seed;result.dem_seed=P.front.dem_seed;
        result.dither_seed=P.front.dither_seed;result.jitter_seed=P.front.jitter.seed;
        result.ra_noise_enabled=P.backend.ni.ra_noise;result.az_enabled=P.backend.ni.az;
        result.comparator_noise_enabled=P.ni.comparator_noise;
        result.cu_f=8*P.front.unit_cap_f;result.Cf_f=P.backend.ra.Cf_f;
        result.A0=P.backend.ra.A0;result.UGB_hz=P.backend.ra.UGB_hz;
        result.tau_sample_s=P.front.tau_sample_s;result.tau_dac_s=P.front.tau_dac_s;
        result.tau_reset_s=P.backend.ra.tau_reset_s;result.guard_s=P.front.single_guard_s;
        result.dem_enabled=P.front.dem_enabled;result.dither_enabled=P.front.dither_enabled;
        result.jitter_enabled=P.front.jitter.enabled;result.calibration_enabled=P.cal_cfg.enabled;
        result.transport_enabled=P.transport.enabled;result.bank_enabled=P.bank.enabled;
        sb256_write_json(fullfile(outdir,'started.json'),result);
        si=Simulink.SimulationInput('SarAdc');
        si=si.setVariable('P',P,'Workspace','SarAdc');si=si.setVariable('DecodeP',P.digital,'Workspace','SarAdc');
        si=si.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
        rngBefore=rng;save(fullfile(outdir,'rng_before.mat'),'rngBefore','-v7.3');
        timer=tic;simout=sim(si);result.sim_s=toc(timer);
        save(fullfile(outdir,'simout.mat'),'simout','-v7.3');
        assert(isempty(simout.ErrorMessage),'sb256:simulation','%s',simout.ErrorMessage);
        % Preserve actual raw/ready/code wires before any post-run acceptance gate.
        raw_log=simout.get('raw_log');ready_log=simout.get('ready_log');
        record_log=simout.get('record_log');record_ready_log=simout.get('record_ready_log');
        code_log=simout.get('code_log');
        save(fullfile(outdir,'raw_capture.mat'),'raw_log','ready_log','record_log', ...
            'record_ready_log','code_log','-v7.3');
        assert(isequaln(rngBefore,rng),'sb256:rng','Global RNG changed.');
        assert(sb256_same_bits(getVariable(ws,'P'),oldP)&&sb256_same_bits(getVariable(ws,'DecodeP'),oldD)&& ...
            isequaln(getVariable(ws,'TrainCaptureFile'),oldCapture),'sb256:workspace','Saved workspace changed.');
        sb256_check_runtime(runtime,manifest,modelSha);boundAfter=sb256_bind_runtime(runtime,entries,false);
        save(fullfile(outdir,'binding_after.mat'),'boundAfter','-v7.3');
        for k=1:numel(paths),assert(strcmp(sb256_sha256(paths{k}),pins{k}), ...
                'sb256:inputHash','Pinned input changed: %s',paths{k});end
        priorOutput=load(n8sim,'simout');
        [selected,metadata,metrics,validation]=sb256_analyze(simout,P,priorOutput.simout,P0);
        save(fullfile(outdir,'selected.mat'),'selected','metadata','-v7.3');
        save(fullfile(outdir,'spectrum.mat'),'metrics','validation','-v7.3');
        plotUtc=utc_now();files=sb256_plot(metrics,P,result.matlab_release,plotUtc,result.sim_s,outdir);
        sb256_write_json(fullfile(outdir,'validation.json'),validation);
        sb256_write_json(fullfile(outdir,'spectrum.json'),metrics);
        result.status='actual_256_codes_characterized';result.utc_finished=utc_now();
        result.plot_utc=plotUtc;result.simout_sha256=sb256_sha256(fullfile(outdir,'simout.mat'));
        result.raw_capture_sha256=sb256_sha256(fullfile(outdir,'raw_capture.mat'));
        result.selected_sha256=sb256_sha256(fullfile(outdir,'selected.mat'));
        result.spectrum_mat_sha256=sb256_sha256(fullfile(outdir,'spectrum.mat'));
        result.spectrum_json_sha256=sb256_sha256(fullfile(outdir,'spectrum.json'));
        result.validation_sha256=sb256_sha256(fullfile(outdir,'validation.json'));
        result.rng_before_sha256=sb256_sha256(fullfile(outdir,'rng_before.mat'));
        result.plot=files;result.records=256;result.selected_ids=[4 259];
        result.global_rng_unchanged_during_simulation=true;result.saved_workspace_unchanged=true;
        result.snr_db=metrics.snr_db;result.sndr_db=metrics.sndr_db;
        result.sfdr_db=metrics.sfdr_db;result.thd_db=metrics.thd_db;result.enob=metrics.enob;
        result.release_charge='UNOBSERVED_NO_DIRECT_FE_STATE_PROBE';
        result.scope='256-point actual single-bank behavioral spectrum; not paper 20k/complete NI/PDK';
        sb256_write_json(fullfile(outdir,'complete.json'),result);
    catch ex
        failure=struct('status','failed','id',ex.identifier,'message',getReport(ex,'extended','hyperlinks','off'), ...
            'simout_saved',isfile(fullfile(outdir,'simout.mat')),'P_saved',isfile(fullfile(outdir,'P_used.mat')));
        sb256_write_json(fullfile(outdir,'failed.json'),failure);rethrow(ex);
    end
end
function check_P0(P)
    assert(P.N==8&&P.Ts_s==200e-9&&P.fs_hz==5e6&&P.epoch==1&&P.first_id==4&& ...
        P.front.single_bank&&P.control.single_bank&&P.front.single_guard_s==0&& ...
        ~P.front.dem_enabled&&~P.front.dither_enabled&&~P.front.jitter.enabled&& ...
        ~P.front.ktc_enabled&&~P.backend.ni.ra_noise&&~P.backend.ni.az&& ...
        ~P.backend.ni.az_noise&&~P.backend.ni.reference_noise&& ...
        ~P.ni.reference_recovery&&~P.ni.comparator_noise&& ...
        strcmp(P.backend.az.mode,'off')&&strcmp(P.digital.az_mode,'off')&& ...
        P.control.sar1.coarse_noise_rms_v==0&& ...
        ~P.debug.adi_enabled&&~P.debug.aperture_enabled&&~P.transport.enabled&& ...
        ~P.training.enabled&&~P.cal_cfg.enabled&&~P.frozen.enabled&&~P.bank.enabled&& ...
        P.digital.d1_bias_v==0&&all(P.front.C_f(:,38)==0), ...
        'sb256:P','Original P is not the tested single-bank noise/AZ-off 5MS/s profile.');
end
function s=utc_now(),s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));end
function restore_env(p,c),path(p);cd(c);end
function x=canon(p),x=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function yes=inside(p,parent),a=lower(canon(p));b=lower(canon(parent));yes=strcmp(a,b)||startsWith(a,[b '/']);end
function close_owned(modelFile)
    if ~bdIsLoaded('SarAdc'),return;end
    try
        if strcmpi(canon(get_param('SarAdc','FileName')),canon(modelFile))&& ...
            strcmp(get_param('SarAdc','Dirty'),'off')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')
            close_system('SarAdc',0);
        end
    catch
        % The disposable batch exits; never close an unverified model.
    end
end
function bootstrap(scripts)
    list=dir(fullfile(scripts,'*.m'));loaded=inmem('-completenames');
    for k=1:numel(list)
        [~,name]=fileparts(list(k).name);expected=fullfile(scripts,list(k).name);actual=which(name);
        assert(~isempty(actual)&&strcmpi(canon(actual),canon(expected)), ...
            'sb256:scriptPath','Script resolves from another path: %s',name);
        for j=1:numel(loaded)
            [~,stem]=fileparts(loaded{j});if ~strcmpi(stem,name),continue;end
            assert(strcmpi(name,'sb256_case')&&strcmpi(canon(loaded{j}),canon(expected)), ...
                'sb256:scriptCache','A helper is already cached: %s',loaded{j});
        end
    end
end
