#!/usr/bin/env python3
"""Only verify saved input identities/config; never execute MATLAB."""
from pathlib import Path
import hashlib,json,math
import h5py,numpy as np
project=Path('/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020')
a=project/'analysis/behavior/single_bank_1039_20261104'
files={'P':(a/'function_v2/single_bank_P.mat','dfa91dda5a686563b9b0fe17c5e8d906d94e6ff9168251bc27a0830099947e4f'),
'graph':(a/'graph_v2/SarAdc.slx','48537818b3212e1e4c8231dec433d1fde36d95814cdcce8c529bb2898eb097d3'),
'satk_receipt':(a/'graph_v2/satk_receipt.json','c0502a7519395b297aca991492826799778826e563a7e877a05b993ca5bcfd49'),
'graph_audit':(a/'graph_v2/graph_audit.json','27be1fa393e4bf2df1910bdbf6d759ec8cf7296adcb5e8a0f5706161a54bc8ed'),
'n8_receipt':(a/'n8_plain/plain/complete.json','eb77410ab643ce7484f025a3e19d4927338d317322b40623e3374ddeaa53e51b'),
'n8_simout':(a/'n8_plain/plain/simout.mat','d472f01a80a832cd483783e4ceca0640a692e0094d1a64f5400411e5201a934c'),
'n8_P_used':(a/'n8_plain/plain/P_used.mat','236ddfb427dfc07e7f7e27dd58746deb30946891717d255b53789aa8127a1e9f'),
'manifest':(a/'MANIFEST_v2.json','2cbdffe537b694cef6107ce893ea8bca7f8ef5d95f6ff7d993f020150c6dd514')}
for key,(path,want) in files.items():
 assert path.is_file() and path.stat().st_size<=300_000_000
 assert hashlib.sha256(path.read_bytes()).hexdigest()==want,key
with h5py.File(files['P'][0]) as f:
 P=f['P'];scalar=lambda p:float(np.asarray(P[p]).reshape(-1)[0]);arr=lambda p:np.asarray(P[p]).reshape(-1)
 assert scalar('N')==8 and scalar('first_id')==4 and scalar('epoch')==1
 assert scalar('Ts_s')==200e-9 and scalar('fs_hz')==5e6 and scalar('front/single_bank')==1
 assert scalar('input/frequency_hz')*256/scalar('fs_hz')==5
 assert scalar('input/amplitude_v')==3.650563842595822 and scalar('input/phase_rad')==0.731
 assert scalar('front/single_guard_s')==0 and np.all(arr('front/tau_sample_s')==0) and np.all(arr('front/tau_dac_s')==0)
 for p in ['front/dem_enabled','front/dither_enabled','front/ktc_enabled','front/jitter/enabled',
           'backend/ni/ra_noise','backend/ni/az','backend/ni/az_noise','backend/ni/reference_noise',
           'ni/comparator_noise','ni/reference_recovery','training/enabled','cal_cfg/enabled',
           'frozen/enabled','bank/enabled','transport/enabled']:
  assert scalar(p)==0,p
 assert scalar('backend/ra/A0')==1e4 and scalar('backend/ra/UGB_hz')==1.2e9
 assert scalar('backend/ra/Cf_f')==0.864e-12 and scalar('front/unit_cap_f')==27e-15/8
 receipt=json.loads(files['n8_receipt'][0].read_text());assert receipt['status']=='plain_pass_feedback_unobserved'
 assert receipt['model_sha256']==files['graph'][1] and receipt['fixture_sha256']==files['P'][1]
 result={'status':'static_inputs_pass','source_P_sha256':files['P'][1],'model_sha256':files['graph'][1],
  'n8_receipt_sha256':files['n8_receipt'][1],'N_requested':256,'plan_rows_requested':264,
  'fs_hz':scalar('fs_hz'),'fin_hz':scalar('input/frequency_hz'),'bin':5,
  'amplitude_vpeak_diff':scalar('input/amplitude_v'),'input_dbfs':20*math.log10(scalar('input/amplitude_v')/(scalar('fsr_diff_v')/2)),
  'A0':scalar('backend/ra/A0'),'UGB_hz':scalar('backend/ra/UGB_hz'),'Cf_f':scalar('backend/ra/Cf_f'),
  'unit_cap_combined_f':8*scalar('front/unit_cap_f'),'tau_sample_s':0,'tau_dac_s':0,
  'noise_az_calibration_adi_off':True,'scope':'read-only identity/config checks only; N256 MATLAB NOT_RUN'}
 print(json.dumps(result,indent=2))
