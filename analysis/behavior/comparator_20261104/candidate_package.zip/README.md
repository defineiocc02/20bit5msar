# SAR20 比较器候选：已安装 NI 基线重基

这是独立 `/tmp` 增量包，仅供审阅；未写生产目录、未操作 MATLAB/Simulink，本次也未运行测试。待生产 NI 的正式 N8 smoke 结果明确后，再安排后续测试。上一份融合包 `/tmp/sar20_cmp_ni_fusion_JXqQDG` 保留不动，其清单 SHA-256 为 `5d0ea3fba8cec862c629d38704c3f738cf10cda5a003a1adaec244242e746259`。

制作时只读核对：生产六个 NI 文件均与已安装的 NI 候选 6/6 SHA 一致；当前及本包源码快照中的 `behavior_spectrum.m` 均为 `f567aab44fc37579c00812b673264afa464ec99d074f07ad0fa6d6955fcd4f3e`。增量补丁不包含频谱文件，也不包含已安装且无需改变的 NI prepare、training、collector 和 public-calibration 源。`candidate/` 是完整的小型源码快照供未来隔离测试，**不得整树覆盖生产**；以后使用补丁前必须重新核对现行基线 SHA，避免覆盖后续修改。

## 增量与覆盖范围

`candidate.patch` 只包含五个现有文件和三个新 helper。`behavior_ra_noise_guard` 在 OU OFF/ON 委托真实 comparator 配置校验：无配置时拒绝虚假噪声标签；OU OFF 下允许真实合法配置，标签和各通道摘要应与 enable、RMS 一致；OU ON 与任何非零 comparator 噪声或 offset 联合继续拒绝。原有 NI/dither 与资格门不放宽。

`P.ni.comparator_noise` 表示细 SAR1 或 SAR2/TA 任一通道的噪声启用，不能解释为所有比较器覆盖。存在可选配置时 `P.ni.comparator_noise_scope` 分列 `sar1_fine`、`sar2_and_tracking`，并将 `flash_preconvert` 固定为 false；6 位 Flash 预转换噪声未建模。原生日历、噪声键、控制状态 ABI、默认比较路径和零激励旁路均沿用上一份融合草案，尚无该重基版本的 MATLAB 验证。

## Scope 的 derive / check 语义

- **有 comparator profile**：`derive` 根据合法 profile 重新生成 `comparator_noise_scope`，会覆盖此前缺失、陈旧甚至畸形的 scope；`check` 不修改它，要求逐字段与实际通道状态完全一致，缺失或畸形均拒绝。
- **无 comparator profile**：`derive` 和 `check` 都拒绝非零或畸形 scope 及虚假 aggregate 标签，不能凭标签凭空声称覆盖；没有 scope 字段的旧配置保持旧形状。
- 上述 scope 重算不适用于已存在的 `P.ni.comparator_noise` aggregate 畸形值：该值非二进制时，即使 derive 也拒绝；字段缺失时仅 derive 可补齐。

`tests/test_cmp_ni_fusion.m` 已补 scope 的畸形/缺失、带与不带 profile 的 derive/check 正反例；只编写，未执行。所有测试脚本对外部 P/simout/SLX 文件在读取或 SHA 前检查 `bytes <= 300000000`；本地候选的 `nominal.mat` 读取前亦检查。此类大小检查依赖受控 fixture 在检查到读取期间不被并发改写。

## 后续测试草案

- `test_ni_candidate.m`、`test_cmp_ni_fusion.m`：准备好的纯函数测试，当前未执行。
- `test_comparator_archive.m`：由归档初态和真实事件重建前态，覆盖 fine/D2/TA 的 offset/noise 到 RAW/pending/下一反馈；旧/新 double 比较检查 class、shape 和 `typecast` 位模式。重建 51 字前态不是直接测得的状态。
- `test_comparator_actual_state.m`：只有未来隔离图直接记录真实 `SAR_trial[51]` 及相关线网、并独立核对模型连线和输入 SHA 后才可使用；目前缺实际 fixture，测试应拒绝而非回退到重建态。
- Python 后验检查脚本仅作为未执行草案复制，不附运行结果。最终须在隔离进程中核对实际 resolved 源路径、完成相关函数级测试及原生主图回归；任何结果不得从上一候选自动继承。

## 测试来源与事件日志门（本次修订）

测试草案执行前后均按固定 SHA 的 `source_manifest.json` 检查全部 116 个候选、基线和测试 helper 的 `which` 路径及文件哈希，包括 comparator sample/key/config、RA guard 和 control stage。执行前若目标函数已经在 MATLAB 内存中，测试报错并要求全新隔离进程；不会执行 `clear` 修改现有会话缓存。执行后再次核对文件哈希、解析路径和仍在内存中的目标函数来源。此机制依赖隔离期间源码不可被并发改写；路径与前后哈希本身不构成对恶意瞬时替换的证明。每个测试应各自在新的 MATLAB 进程中运行。

归档测试要求 `event_log`、`front_log`、`back_log`、`control_log` 等实际 timeseries，逐周期严格核对全部 48 个事件组；缺失、重复或乱序直接报错，不再筛掉异常组。真实 51 字前态测试除完整事件组外，还要求六组指定的实际线网日志，任何缺失都报错。真实前态 fixture 目前仍不存在，文件哈希不能代替独立模型线网审计。

本次仅修改测试草案和新增来源清单；源码、八文件增量补丁及噪声键未改。MATLAB/Simulink 和测试仍未运行。`source_manifest.json` SHA-256 为 `f5c6551ab87ce293a0cfbc5b334d81718e9e9a4ce3f13670c0ba51ac7f6dd812`。
