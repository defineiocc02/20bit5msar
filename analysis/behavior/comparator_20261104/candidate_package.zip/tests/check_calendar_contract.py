#!/usr/bin/env python3
"""Read archived MATLAB HDF5 P, independently compare its fixed calendar.

This executes an independent Python oracle and mutation fixtures only. It does
not call MATLAB or execute/verify the candidate MATLAB guard, Simulink or SLX.
"""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import h5py

root = Path('/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020')

MAX_BYTES=300_000_000
def bounded(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_BYTES:
        raise ValueError(f'File missing or exceeds 300,000,000 bytes: {path}')
    return path
pfile = bounded(root / 'analysis/behavior/ra_ou_20261030/release_20261031/reference/off/P.mat')
sha = hashlib.sha256(pfile.read_bytes()).hexdigest()
assert sha == 'dc064aa8fa204ac36d3f06ad128bbfd90da672c40c052de21530e7db378c353d'

bounded(pfile)
with h5py.File(pfile, 'r') as f:
    def atom(node):
        if isinstance(node, h5py.Group):
            raise TypeError(node.name)
        data = node[()]
        if node.attrs.get('MATLAB_class') == b'char':
            return ''.join(chr(int(c)) for c in data.reshape(-1))
        assert data.size == 1, node.name
        return float(data.reshape(-1)[0])
    def field(node, key, i=None):
        d = node[key]
        if h5py.check_dtype(ref=d.dtype):
            assert i is not None
            return atom(f[d[0, i]])
        assert i is None
        return atom(d)
    def events(node):
        d = node['type']
        count = d.shape[1] if h5py.check_dtype(ref=d.dtype) else 1
        return [dict(type=field(node,'type',i if count>1 else None),
                     index=field(node,'index',i if count>1 else None),
                     bit=field(node,'bit',i if count>1 else None),
                     tick=field(node,'tick',i if count>1 else None),
                     priority=field(node,'priority',i if count>1 else None),
                     time_s=field(node,'time_s',i if count>1 else None),
                     offset_s=field(node,'offset_s',i if count>1 else None))
                for i in range(count)]
    def groups(node):
        d = node['events'];result=[]
        for i in range(d.shape[1]):
            result.append(dict(time_s=field(node,'time_s',i),
                               offset_s=field(node,'offset_s',i),
                               tick=field(node,'tick',i),
                               events=events(f[d[0,i]])))
        return result
    q=f['P']
    actual = dict(calendar=events(q['calendar']), adc_groups=groups(q['adc_groups']),
                  groups=groups(q['groups']), schedule_groups=groups(q['schedule/groups']),
                  Ts_s=atom(q['Ts_s']), N=atom(q['N']), first_id=atom(q['first_id']),
                  n_cycles=atom(q['n_cycles']), stop_time_s=atom(q['stop_time_s']),
                  schedule_period=atom(q['schedule/sample_period_s']),
                  schedule_cycles=atom(q['schedule/n_cycles']),
                  schedule_stop=atom(q['schedule/stop_time_s']),
                  control_period=atom(q['control/sample_period_s']),
                  transport_enabled=atom(q['transport/enabled']))

def canonical():
    out=[]
    def add(ns,kind,index=-1,bit=-1,priority=0):
        t=ns*1e-9
        out.append(dict(type=kind,index=float(index),bit=float(bit),tick=float(round(ns/.25)),
                        priority=float(priority),time_s=t,offset_s=t))
    add(0,'cnv')
    add(12.5,'coarse_latch',priority=20)
    for k in range(5):
        add(12.5+3.75*k,'fine_prepare',k,4-k,30)
        add(15+3.75*k,'fine_decide',k,4-k,40)
        add(16.25+3.75*k,'fine_feedback',k,4-k,10)
    add(31.25,'ra_start',priority=60)
    for k in range(12):
        add(43.75+2.5*k,'d2_prepare',k,11-k,30)
        add(45+2.5*k,'d2_decide',k,11-k,40)
        add(46.25+2.5*k,'d2_feedback',k,11-k,10)
    add(73.75,'d2_end',priority=60)
    for k in range(8):
        add(75+1.25*k,'ta_compare',k,7-k,40)
        if k<7:add(76.25+1.25*k,'ta_feedback',k,7-k,10)
    add(85,'tracking_end',priority=60)
    add(86.25,'raw_latch',priority=80)
    add(90,'release',priority=90)
    return sorted(out,key=lambda v:(v['tick'],v['priority']))

def group(ev):
    out=[]
    for e in ev:
        if not out or out[-1]['tick']!=e['tick']:
            out.append(dict(time_s=e['time_s'],offset_s=e['time_s'],tick=e['tick'],events=[]))
        out[-1]['events'].append(e)
    return out

cal=canonical();grp=group(cal)
def check(q):
    on=q['transport_enabled']
    expected=group(cal)
    if on:
        ev=dict(type='frame_ready',index=-1.0,bit=-1.0,tick=552.0,priority=70.0,
                time_s=138e-9,offset_s=138e-9)
        expected.append(dict(time_s=138e-9,offset_s=138e-9,tick=552.0,events=[ev]))
    cycles=q['first_id']+q['N']+2*on
    stop=(cycles-1)*q['Ts_s']+expected[-1]['time_s']
    return (q['calendar']==cal and q['adc_groups']==grp and q['groups']==expected and
            q['schedule_groups']==expected and q['n_cycles']==cycles and
            q['stop_time_s']==stop and q['schedule_period']==q['Ts_s'] and
            q['control_period']==q['Ts_s'] and q['schedule_cycles']==q['n_cycles'] and
            q['schedule_stop']==q['stop_time_s'])

assert len(cal)==73 and len(grp)==48 and check(actual)
keys={}
for g in grp:
    for e in g['events']:
        if e['type'] in ('fine_decide','d2_decide','ta_compare'):
            key=(e['type'],e['index']);assert key not in keys;keys[key]=e['tick']
assert len(keys)==25

def mutate_index(q,which,kind,index,new):
    arr=q[which];hits=[]
    for g in arr:
        for e in g['events']:
            if e['type']==kind and e['index']==index:hits.append(e)
    assert len(hits)==1;hits[0]['index']=float(new)

fixtures={}
bad=deepcopy(actual);mutate_index(bad,'groups','d2_decide',1,0)
fixtures['d2_decide_only']=not check(bad)
mutate_index(bad,'groups','d2_feedback',1,0)
fixtures['d2_decide_and_feedback']=not check(bad)
bad['schedule_groups']=deepcopy(bad['groups'])
fixtures['both_groups_identically_corrupt']=not check(bad)
bad=deepcopy(actual);mutate_index(bad,'groups','fine_decide',1,0)
mutate_index(bad,'groups','fine_feedback',1,0)
fixtures['fine_decide_and_feedback']=not check(bad)
bad=deepcopy(actual);mutate_index(bad,'schedule_groups','d2_decide',1,0)
fixtures['scheduler_groups_only']=not check(bad)
bad=deepcopy(actual);mutate_index(bad,'adc_groups','fine_decide',1,0)
fixtures['adc_groups_only']=not check(bad)
bad=deepcopy(actual);bad['groups'][2]['time_s']+=1e-12
fixtures['event_time_changed']=not check(bad)
bad=deepcopy(actual);bad['schedule_cycles']+=1
fixtures['scheduler_cycles_changed']=not check(bad)
bad=deepcopy(actual);bad['control_period']+=1e-12
fixtures['controller_period_changed']=not check(bad)
# Synthetic ON schedule checks only the generic calendar contract; it is not a
# real transport run and does not assert transport-state/qualification behavior.
on=deepcopy(actual);on['transport_enabled']=1.0
on_event=dict(type='frame_ready',index=-1.0,bit=-1.0,tick=552.0,priority=70.0,
              time_s=138e-9,offset_s=138e-9)
on['groups']=deepcopy(grp)+[dict(time_s=138e-9,offset_s=138e-9,tick=552.0,events=[on_event])]
on['schedule_groups']=deepcopy(on['groups'])
on['n_cycles']=on['first_id']+on['N']+2
on['stop_time_s']=(on['n_cycles']-1)*on['Ts_s']+on['groups'][-1]['time_s']
on['schedule_cycles']=on['n_cycles'];on['schedule_stop']=on['stop_time_s']
assert check(on)
bad=deepcopy(on);bad['schedule_groups'][-1]['time_s']+=1e-12
fixtures['on_frame_tamper']=not check(bad)
assert all(fixtures.values())
print(json.dumps({'source':str(pfile),'source_sha256':sha,'calendar_events':len(cal),
                  'event_groups':len(grp),'unique_comparator_keys_per_sample':len(keys),
                  'normal_archived_contract':True,'synthetic_transport_on_contract':True,
                  'independent_mutation_checks':fixtures,
                  'scope':'Python HDF5 and independent oracle only; no MATLAB candidate or SLX executed'},indent=2))
