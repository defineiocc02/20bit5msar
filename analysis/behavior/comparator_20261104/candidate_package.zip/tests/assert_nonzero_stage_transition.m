function assert_nonzero_stage_transition(P,cfg,xpre,ctx,nextctx,obs,cmp,nextobs,nextcmp,probe)
% Offline stage replay on caller-provided SAR pre-state and node values;
% the caller must establish whether the pre-state is recorded or reconstructed. Each forced perturbation crosses
% the actual input sign and is observed through RAW, pending and the next due.
    ev=probe.event;v=probe.voltage;native=probe.native;expected=1-native;
    assert(v~=0&&native==double(v>0),'sar20CmpTest:precondition','Need nonzero actual node and inferred sign.');
    switch ev.type
        case 'fine_decide',code=1;feedback='fine_feedback';
        case 'd2_decide',code=2;feedback='d2_feedback';
        case 'ta_compare',code=3;feedback='ta_feedback';
        otherwise,error('sar20CmpTest:event','Unexpected comparison event.');
    end
    g=P.groups(nextctx(2));
    assert(any(strcmp({g.events.type},feedback)&[g.events.index]==ev.index), ...
        'sar20CmpTest:feedbackFixture','Next actual group is not this decision feedback.');
    for variation=1:2
        c=cfg;
        if variation==1
            if code==1,c.sar1_offset_v=-2*v;else,c.sar2_offset_v=-2*v;end
        else
            % Select a deterministic key with opposite-signed noise, then scale
            % the RMS to force this one actual input across zero. This is a
            % directed branch test, not an assumed realistic RMS/statistic.
            found=false;
            for k=0:255
                seed=uint64(20261104+k);
                z=behavior_comparator_keyed_normal(seed,ev.epoch,ev.sample_id,code,ev.index);
                if z*v<0&&abs(z)>0.1,found=true;break;end
            end
            assert(found,'sar20CmpTest:noiseFixture','No suitable directed keyed noise sample.');
            c.seed_u64=seed;sigma=2*abs(v)/abs(z);
            assert(isfinite(sigma)&&sigma>0,'sar20CmpTest:noiseFixture','Invalid directed RMS.');
            if code==1,c.sar1_noise_rms_v=sigma;else,c.sar2_noise_rms_v=sigma;end
        end
        actual=P;actual.control.comparator=c;actual.ni.comparator_noise=false;
        actual=behavior_ra_noise_guard(actual,'derive');
        behavior_ra_noise_guard(actual,'check');
        before=behavior_sar_unpack(xpre);
        [x,signal,signs]=behavior_control_stage('decide',xpre,ctx,obs,cmp,actual);
        [xAgain,sAgain,zAgain]=behavior_control_stage('decide',xpre,ctx,obs,cmp,actual);
        assert(double_bits_equal(x,xAgain)&&double_bits_equal(signal,sAgain)&& ...
            double_bits_equal(signs,zAgain),'sar20CmpTest:stageRepeat','Same event changed on repeated Outputs.');
        now=behavior_sar_unpack(x);
        switch code
            case 1,word=now.d1raw;
            case 2,word=now.d2raw;
            case 3,word=now.dtraw;
        end
        assert(double(bitget(uint32(word),ev.bit+1))==expected&& ...
            strcmp(now.pending.type,feedback)&&now.pending.index==ev.index&& ...
            now.pending.decision==expected&&now.pending.word==word, ...
            'sar20CmpTest:stageDecision','Perturbation did not reach RAW and pending state.');
        [xDue,dueSignal,dueSigns]=behavior_control_stage('due',x,nextctx,nextobs,nextcmp,actual);
        due=behavior_sar_unpack(xDue);
        assert(isempty(due.pending.type)&&dueSignal(13)==1, ...
            'sar20CmpTest:stageDue','Pending feedback was not retired at its real event.');
        switch code
            case 1
                assert(due.d1_feedback_word==word&&due.trial==word, ...
                    'sar20CmpTest:fineFeedback','Fine RAW did not reach DAC feedback word.');
            case 2
                assert(due.d2_feedback_word==word&&dueSigns(ev.index+1)==2*expected-1, ...
                    'sar20CmpTest:d2Feedback','D2 RAW did not reach physical sign command.');
            case 3
                assert(due.feedback_count==before.feedback_count+1&& ...
                    dueSigns(12+ev.index+1)==2*expected-1, ...
                    'sar20CmpTest:taFeedback','TA RAW did not reach physical sign command.');
        end
    end
end

function ok=double_bits_equal(a,b)
    ok=isa(a,'double')&&isa(b,'double')&&isreal(a)&&isreal(b)&& ...
        isequal(size(a),size(b))&& ...
        isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
end
