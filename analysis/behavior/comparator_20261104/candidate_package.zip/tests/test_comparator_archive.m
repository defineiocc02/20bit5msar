function report=test_comparator_archive(projectRoot)
% TEST DRAFT ONLY -- not run during candidate preparation.
% Read archived ORIGINAL N8 physical event logs; never load/sim/save the SLX.
% SAR pre-state is RECONSTRUCTED from saved IC and event/control logs, not
% a directly observed 51-word state; use the separate actual-state fixture test.
% Test fixture's bit values are inferred from logged post-decision RAW, not
% independently observed comparator wires. Replay uses today's unchanged SAR
% core and frozen pre-candidate stage copy, not a claim of the as-run source.
% Only call inside an isolated MATLAB session, with this candidate on path.
    if nargin<1
        projectRoot='/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020';
    end
    here=fileparts(mfilename('fullpath'));
    root=fileparts(here);candidate=fullfile(root,'candidate');
    originalPath=path;restore=onCleanup(@()path(originalPath)); %#ok<NASGU>
    addpath(genpath(fullfile(candidate,'current','src')), ...
        fullfile(candidate,'config'),fullfile(root,'baseline'),here,'-begin');
    assert_source_bindings(root,'before');
    ref=fullfile(projectRoot,'analysis','behavior','ra_ou_20261030', ...
        'release_20261031','reference','off');
    pfile=fullfile(ref,'P.mat');sfile=fullfile(ref,'simout.mat');
    assert(strcmp(sha(pfile),'dc064aa8fa204ac36d3f06ad128bbfd90da672c40c052de21530e7db378c353d'), ...
        'sar20CmpTest:archiveP','Saved P identity changed.');
    assert(strcmp(sha(sfile),'5887b6a6cabb20dbd27308c94ac2bad431787cddbc340db1d02aaa3151377e3a'), ...
        'sar20CmpTest:archiveSimout','Saved simout identity changed.');
    assert_small_file(pfile);a=load(pfile,'P');
    assert_small_file(sfile);b=load(sfile,'simout');P=a.P;out=b.simout;
    assert(isa(out,'Simulink.SimulationOutput')&&isempty(out.ErrorMessage), ...
        'sar20CmpTest:archive','Require the genuine saved successful simout.');
    [te,E]=series(out,'event_log',2);
    [tf,F]=series(out,'front_log',7);
    [tb,B]=series(out,'back_log',8);
    [tc,C]=series(out,'control_log',13);
    F=at(te,tf,F);B=at(te,tb,B);C=at(te,tc,C);
    groups=P.groups;
    if isfield(P,'adc_groups'),groups=P.adc_groups;end
    assert(isfield(P,'transport')&&~P.transport.enabled&&numel(groups)==48&& ...
        isfield(P,'n_cycles')&&P.n_cycles==P.first_id+P.N, ...
        'sar20CmpTest:coverage','Expected the declared transport-OFF ADC48 fixture.');
    expected=[repelem((0:P.n_cycles-1).',48),repmat((1:48).',P.n_cycles,1)];
    assert(numel(te)==size(expected,1)&&isequal(E,expected), ...
        'sar20CmpTest:eventCoverage','Missing, repeated or reordered actual ADC event groups.');
    assert(all(isfinite([F(:);B(:);C(:)])),'sar20CmpTest:finite','Need real finite event wires.');
    cfg=struct('enabled',true,'sar1_offset_v',0,'sar1_noise_rms_v',0, ...
        'sar2_offset_v',0,'sar2_noise_rms_v',0,'seed_u64',uint64(20261104), ...
        'tie_decision',1);
    Q=P;Q.control.comparator=cfg;
    disabled=cfg;disabled.enabled=false;disabled.sar1_offset_v=1e-3;
    disabled.sar2_noise_rms_v=1e-3;Qoff=P;Qoff.control.comparator=disabled;
    X=double(P.xSC0(:));Xold=X;Xlegacy=X;Xoff=X;
    counts=zeros(1,3);nonzero=0;noiseChanges=0;stageCoverage=false(3,2);
    rngBefore=rng;
    [knownZ,knownHash]=behavior_comparator_keyed_normal(uint64(20261104),1,0,2,0);
    assert(strcmp(knownHash,'61e7ca79dbc6fe7c97d3939daa4dc949a4b96ed50b3edf2a54d4147c814fd646')&& ...
        abs(knownZ-(-1.1560934225053394))<1e-14, ...
        'sar20CmpTest:keyOracle','Comparator hash/normal differs from independent fixture.');
    for r=1:numel(te)
        id=E(r,1);gi=E(r,2);group=groups(gi);tokens=group.events;
        assert(id==floor(id)&&gi==floor(gi),'sar20CmpTest:event','Noninteger actual event tag.');
        cmp=[0;0;B(r,2)];probe=[];
        for j=1:numel(tokens)
            ev=tokens(j);ev.sample_id=id;ev.epoch=P.epoch;
            switch ev.type
                case 'fine_decide'
                    channel=1;typeIndex=1;native=double(bitget(uint32(C(r,5)),ev.bit+1));v=F(r,2);
                    cmp(1)=native;counts(1)=counts(1)+1;
                case 'd2_decide'
                    channel=2;typeIndex=2;native=double(bitget(uint32(C(r,6)),ev.bit+1));v=B(r,2);
                    cmp(2)=native;counts(2)=counts(2)+1;
                case 'ta_compare'
                    channel=2;typeIndex=3;native=double(bitget(uint32(C(r,7)),ev.bit+1));v=B(r,2);
                    cmp(2)=native;counts(3)=counts(3)+1;
                otherwise
                    continue;
            end
            if ~all(stageCoverage(typeIndex,:))&&v~=0&&native==double(v>0)&& ...
                    (typeIndex~=3||ev.index<7)
                probe=struct('event',ev,'native',native,'voltage',v,'typeIndex',typeIndex);
            end
            base=struct('sample_v',F(r,1),'vres_v',F(r,2),'vy_v',B(r,2), ...
                'decision1',cmp(1),'decision2',cmp(2),'valid',true,'late',false);
            [same,z]=behavior_comparator_sample(ev,base,cfg);
            assert(struct_bits_equal(same,base)&&~z.applied,'sar20CmpTest:zero','Zero profile changed native bit.');
            if v~=0
                flip=cfg;
                if channel==1,flip.sar1_offset_v=-2*v;field='decision1';
                else,flip.sar2_offset_v=-2*v;field='decision2';end
                [changed,dg]=behavior_comparator_sample(ev,base,flip);
                assert(changed.(field)==double(v<0)&&dg.effective_v==-v, ...
                    'sar20CmpTest:offset','Actual continuous voltage did not follow signed offset.');
                tie=cfg;
                if channel==1,tie.sar1_offset_v=-v;else,tie.sar2_offset_v=-v;end
                tie.tie_decision=0;[v0,d0]=behavior_comparator_sample(ev,base,tie);
                tie.tie_decision=1;[v1,d1]=behavior_comparator_sample(ev,base,tie);
                assert(d0.effective_v==0&&d1.effective_v==0&&v0.(field)==0&&v1.(field)==1, ...
                    'sar20CmpTest:tie','Perturbed exact-zero assumption is not explicit.');
                nonzero=nonzero+1;
            end
            noisy=cfg;
            if channel==1,noisy.sar1_noise_rms_v=1e-3;else,noisy.sar2_noise_rms_v=1e-3;end
            [n1,d1]=behavior_comparator_sample(ev,base,noisy);
            [n2,d2]=behavior_comparator_sample(ev,base,noisy);
            assert(struct_bits_equal(n1,n2)&&struct_bits_equal(d1,d2),'sar20CmpTest:repeat','Same actual event key changed.');
            assert(double_bits_equal(n1.vres_v,base.vres_v)&&double_bits_equal(n1.vy_v,base.vy_v)&& ...
                n1.valid==base.valid&&n1.late==base.late, ...
                'sar20CmpTest:boundary','Comparator altered physical inputs or control flags.');
            if channel==1,assert(n1.decision2==base.decision2,'sar20CmpTest:channel','SAR1 altered SAR2.');
            else,assert(n1.decision1==base.decision1,'sar20CmpTest:channel','SAR2 altered SAR1.');end
            noisy.seed_u64=uint64(20261105);
            [~,d3]=behavior_comparator_sample(ev,base,noisy);
            noiseChanges=noiseChanges+double(d1.noise_v~=d3.noise_v);
        end
        % Replay all three ordered stages from actual event IDs and actual input
        % wires. Each baseline bit comes from the same post-decision RAW bit.
        obs=double(F(r,:).');
        [X,y1,z1]=behavior_control_stage('due',X,double(E(r,:).'),obs,cmp,Q);
        [X,y2,z2]=behavior_control_stage('prepare',X,double(E(r,:).'),obs,cmp,Q);
        if ~isempty(probe)
            assert(r<numel(te)&&E(r+1,1)==id,'sar20CmpTest:feedbackFixture','Missing next actual event.');
            assert_nonzero_stage_transition(P,cfg,X,double(E(r,:).'),double(E(r+1,:).'), ...
                obs,cmp,double(F(r+1,:).'),[0;0;B(r+1,2)],probe);
            stageCoverage(probe.typeIndex,:)=[true true];
        end
        [X,y3,z3]=behavior_control_stage('decide',X,double(E(r,:).'),obs,cmp,Q);
        [Xold,o1,p1]=behavior_control_stage_original('due',Xold,double(E(r,:).'),obs,cmp,P);
        [Xold,o2,p2]=behavior_control_stage_original('prepare',Xold,double(E(r,:).'),obs,cmp,P);
        [Xold,o3,p3]=behavior_control_stage_original('decide',Xold,double(E(r,:).'),obs,cmp,P);
        [Xlegacy,l1,k1]=behavior_control_stage('due',Xlegacy,double(E(r,:).'),obs,cmp,P);
        [Xlegacy,l2,k2]=behavior_control_stage('prepare',Xlegacy,double(E(r,:).'),obs,cmp,P);
        [Xlegacy,l3,k3]=behavior_control_stage('decide',Xlegacy,double(E(r,:).'),obs,cmp,P);
        [Xoff,f1,g1]=behavior_control_stage('due',Xoff,double(E(r,:).'),obs,cmp,Qoff);
        [Xoff,f2,g2]=behavior_control_stage('prepare',Xoff,double(E(r,:).'),obs,cmp,Qoff);
        [Xoff,f3,g3]=behavior_control_stage('decide',Xoff,double(E(r,:).'),obs,cmp,Qoff);
        assert(double_bits_equal(l1,o1)&&double_bits_equal(k1,p1)&&double_bits_equal(l2,o2)&&double_bits_equal(k2,p2)&& ...
            double_bits_equal(l3,o3)&&double_bits_equal(k3,p3)&&double_bits_equal(Xlegacy,Xold), ...
            'sar20CmpTest:legacy','Missing comparator profile changed stage result.');
        assert(double_bits_equal(f1,o1)&&double_bits_equal(g1,p1)&&double_bits_equal(f2,o2)&&double_bits_equal(g2,p2)&& ...
            double_bits_equal(f3,o3)&&double_bits_equal(g3,p3)&&double_bits_equal(Xoff,Xold), ...
            'sar20CmpTest:disabled','Disabled comparator profile changed stage result.');
        assert(double_bits_equal(y1,o1)&&double_bits_equal(z1,p1)&&double_bits_equal(y2,o2)&&double_bits_equal(z2,p2)&& ...
            double_bits_equal(y3,o3)&&double_bits_equal(z3,p3)&&double_bits_equal(X,Xold), ...
            'sar20CmpTest:defaultStage','Zero comparator profile altered stage result.');
        assert(double_bits_equal(y3,double(C(r,:).')),'sar20CmpTest:archivedControl', ...
            'Replay differs from actual saved controller wires; audit provenance first.');
    end
    assert(isequal(counts,[60 144 96])&&nonzero>0&&noiseChanges>0&&all(stageCoverage(:)), ...
        'sar20CmpTest:coverage','Missing actual decisions, nonzero stage routes or keyed noise sensitivity.');
    assert(isequaln(rngBefore,rng),'sar20CmpTest:rng','Global MATLAB RNG changed.');
    qualification_tests(cfg,P);
    assert_source_bindings(root,'after');
    report=struct('status','passed','source','saved real N8 OFF physical event wires', ...
        'decisions_inferred_from_raw',true,'counts',counts,'noise_seed_changes',noiseChanges, ...
        'nonzero_stage_paths',stageCoverage, ...
        'scope','reconstructed pre-state replay; no actual 51-word probe or SLX simulation');
end

function qualification_tests(cfg,P)
    cfg.sar2_noise_rms_v=1e-3;
    % Use the actual archived prepared P; only comparator profile and NI label
    % are changed. Existing calendar, period and OFF qualification are retained.
    q=P;q.control.comparator=cfg;q.ni.comparator_noise=false;
    assert(~q.backend.ni.ra_noise&&~q.training.enabled&&~q.cal_cfg.enabled&& ...
        ~q.frozen.enabled&&~q.bank.enabled, ...
        'sar20CmpTest:archiveFlags','Reference must have the declared OFF qualifications.');
    q=behavior_comparator_configuration(q,'derive');
    assert(q.ni.comparator_noise,'sar20CmpTest:coverage','Noise coverage not derived.');
    behavior_comparator_configuration(q,'check');
    bad=q;bad.ni.comparator_noise=false;must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:coverage');
    bad=q;bad.control=rmfield(bad.control,'comparator');
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:coverage');
    legacy=bad;legacy.ni.comparator_noise=false;
    must_error(@()behavior_comparator_configuration(legacy,'check'),'sar20Cmp:scope');
    legacy.ni.comparator_noise_scope=empty_scope();
    assert(isequaln(legacy,behavior_comparator_configuration(legacy,'check')), ...
        'sar20CmpTest:legacyP','Legacy OFF profile unexpectedly changed.');
    bad=q;bad.backend.ni.ra_noise=true;must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:raNoiseCombination');
    bad=q;bad.control.comparator.sar2_noise_rms_v=0;bad.control.comparator.sar1_offset_v=1e-3;
    bad.ni.comparator_noise=false;bad.ni.comparator_noise_scope=empty_scope();bad.backend.ni.ra_noise=true;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:raNoiseCombination');
    for k={'training','cal_cfg','frozen','bank'}
        bad=q;bad.(k{1}).enabled=true;
        must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:unqualifiedCalibration');
    end
    bad=q;bad.control.comparator.sar1_noise_rms_v=-1;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:noise');
    calendar_guard_tests(q);
end

function calendar_guard_tests(q)
% Static candidate contract test draft: mutate copies only, not the source P.
    [gd,jd]=locate(q.groups,'d2_decide',1);
    [gf,jf]=locate(q.groups,'d2_feedback',1);
    bad=q;bad.groups(gd).events(jd).index=0;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad.groups(gf).events(jf).index=0;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    % Pairwise equality is insufficient: even identical corrupt scheduler and
    % controller groups must differ from the reconstructed canonical calendar.
    bad.schedule.groups=bad.groups;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    [gs,js]=locate(q.groups,'fine_decide',1);
    [gt,jt]=locate(q.groups,'fine_feedback',1);
    fine=q;fine.groups(gs).events(js).index=0;fine.groups(gt).events(jt).index=0;
    must_error(@()behavior_comparator_configuration(fine,'check'),'sar20Cmp:calendarContract');
    % No mutation or hidden repair in a check or derive call.
    must_error(@()behavior_comparator_configuration(bad,'derive'),'sar20Cmp:calendarContract');
    bad=q;bad.schedule.groups(gd).events(jd).index=0;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;bad.adc_groups(gd).events(jd).index=0;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;k=find(strcmp({bad.calendar.type},'d2_decide') & [bad.calendar.index]==1);
    assert(isscalar(k),'sar20CmpTest:fixture','Missing canonical second D2 decision.');
    bad.calendar(k).index=0;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;bad.groups(gd).time_s=bad.groups(gd).time_s+1e-12;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;bad.schedule.sample_period_s=bad.schedule.sample_period_s+1e-12;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;bad.schedule.n_cycles=bad.schedule.n_cycles+1;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    bad=q;bad.schedule.stop_time_s=bad.schedule.stop_time_s+1e-12;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    offset=q;offset.control.comparator.sar2_noise_rms_v=0;
    offset.control.comparator.sar1_offset_v=1e-3;offset.ni.comparator_noise=false;
    offset.ni.comparator_noise_scope=empty_scope();
    behavior_comparator_configuration(offset,'check');
    offset.groups(gd).events(jd).index=0;
    must_error(@()behavior_comparator_configuration(offset,'check'),'sar20Cmp:calendarContract');
    % Synthetic transport-ON schedule contract only, not a pin or SLX run.
    on=q;on.transport.enabled=true;
    on.groups=behavior_event_groups(on.calendar,true);
    on.n_cycles=on.first_id+on.N+2;
    on.stop_time_s=(on.n_cycles-1)*on.Ts_s+on.groups(end).time_s;
    on.schedule=struct('sample_period_s',on.Ts_s,'n_cycles',on.n_cycles, ...
        'groups',on.groups,'stop_time_s',on.stop_time_s);
    behavior_comparator_configuration(on,'check');
    bad=on;bad.schedule.groups(end).time_s=bad.schedule.groups(end).time_s+1e-12;
    must_error(@()behavior_comparator_configuration(bad,'check'),'sar20Cmp:calendarContract');
    % Preserve legacy disabled and zero-profile semantics even if a caller
    % deliberately supplies a corrupt schedule; this is not a calendar pass.
    disabled=q;disabled.control.comparator.enabled=false;disabled.ni.comparator_noise=false;
    disabled.ni.comparator_noise_scope=empty_scope();
    disabled.groups(gd).events(jd).index=0;
    assert(isequaln(disabled,behavior_comparator_configuration(disabled,'check')), ...
        'sar20CmpTest:disabledCompatibility','Disabled behavior changed.');
    zero=disabled;zero.control.comparator.enabled=true;
    zero.control.comparator.sar1_offset_v=0;zero.control.comparator.sar2_offset_v=0;
    zero.control.comparator.sar1_noise_rms_v=0;zero.control.comparator.sar2_noise_rms_v=0;
    assert(isequaln(zero,behavior_comparator_configuration(zero,'check')), ...
        'sar20CmpTest:zeroCompatibility','Zero-profile behavior changed.');
end
function [groupIndex,eventIndex]=locate(groups,type,index)
    hits=zeros(0,2);
    for i=1:numel(groups)
        ev=groups(i).events;js=find(strcmp({ev.type},type)&[ev.index]==index);
        for j=js(:).',hits(end+1,:)=[i j];end %#ok<AGROW>
    end
    assert(size(hits,1)==1,'sar20CmpTest:fixture','Expected exactly one %s event %g.',type,index);
    groupIndex=hits(1,1);eventIndex=hits(1,2);
end
function ok=struct_bits_equal(a,b)
% Scalar structs: class/shape checked for all fields; doubles compared by bits.
    ok=isstruct(a)&&isstruct(b)&&isscalar(a)&&isscalar(b)&&isequal(fieldnames(a),fieldnames(b));
    if ~ok,return;end
    names=fieldnames(a);
    for k=1:numel(names)
        x=a.(names{k});y=b.(names{k});
        if isa(x,'double')||isa(y,'double')
            same=double_bits_equal(x,y);
        else
            same=strcmp(class(x),class(y))&&isequal(size(x),size(y))&&isequaln(x,y);
        end
        if ~same,ok=false;return;end
    end
end
function ok=double_bits_equal(a,b)
% Class, realness, exact shape and IEEE-754 payloads, including signed zero/NaN.
    ok=isa(a,'double')&&isa(b,'double')&&isreal(a)&&isreal(b)&& ...
        isequal(size(a),size(b))&& ...
        isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
end
function s=empty_scope()
    s=struct('sar1_fine',false,'sar2_and_tracking',false,'flash_preconvert',false);
end
function must_error(f,id)
    try,f();catch ex,assert(strcmp(ex.identifier,id),'sar20CmpTest:wrongError','Expected %s got %s',id,ex.identifier);return;end
    error('sar20CmpTest:missingError','Expected %s',id);
end
function [t,x]=series(out,name,width)
    listed=out.who;if isstring(listed),listed=cellstr(listed);end
    assert(any(strcmp(listed,name)),'sar20CmpTest:missingWire','Missing actual event/wire logger %s.',name);
    a=out.get(name);assert(isa(a,'timeseries'),'sar20CmpTest:logger','Logger %s must be timeseries.',name);
    t=double(a.Time(:));d=double(a.Data);
    if a.IsTimeFirst,x=reshape(d,numel(t),[]);
    else,x=reshape(permute(d,[ndims(d) 1:ndims(d)-1]),numel(t),[]);end
    assert(isequal(size(x),[numel(t) width])&&all(isfinite(t))&&all(diff(t)>=0), ...
        'sar20CmpTest:shape','Invalid saved event logger %s',name);
end
function x=at(wanted,t,x)
    [present,ix]=ismember(wanted,t);assert(all(present),'sar20CmpTest:time','Missing event timestamp.');
    for i=1:numel(wanted),assert(nnz(t==wanted(i))==1,'sar20CmpTest:time','Ambiguous event timestamp.');end
    x=x(ix,:);
end
function h=sha(p)
    assert_small_file(p);
    fid=fopen(p,'rb');assert(fid>=0,'sar20CmpTest:file','Cannot read archive input.');
    guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
    bytes=fread(fid,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(bytes(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function assert_small_file(p)
    d=dir(p);assert(numel(d)==1&&~d.isdir&&d.bytes<=300000000, ...
        'sar20CmpTest:fileLimit','Input must be a regular file no larger than 300,000,000 bytes: %s',p);
end

function assert_source_bindings(root,phase)
% Each test runs in a clean process: never clear another task's loaded code.
% Before/after: pin manifest, source path, bytes and any in-memory function path.
    mf=fullfile(root,'source_manifest.json');assert_small_file(mf);
    assert(strcmp(sha(mf),'f5c6551ab87ce293a0cfbc5b334d81718e9e9a4ce3f13670c0ba51ac7f6dd812'), ...
        'sar20Source:manifest','Candidate source manifest differs from frozen bytes.');
    records=jsondecode(fileread(mf));rows=records.files;
    assert(numel(rows)==116&&any(strcmp(phase,{'before','after'})), ...
        'sar20Source:schema','Unexpected source inventory or check phase.');
    loaded=inmem('-completenames');if isstring(loaded),loaded=cellstr(loaded);end
    names={rows.name};
    for k=1:numel(loaded)
        lp=char(loaded{k});[~,nm,ext]=fileparts(lp);hit=find(strcmpi(nm,names));
        if isempty(hit),continue;end
        assert(isscalar(hit),'sar20Source:inventory','Ambiguous helper name %s.',nm);
        if strcmp(phase,'before')
            error('sar20Source:cacheDirty', ...
                'Helper %s is already loaded from %s; use a new isolated MATLAB process.',nm,lp);
        end
        if isempty(ext),lp=[lp '.m'];end
        expected=fullfile(root,strrep(char(rows(hit).relative_path),'/',filesep));
        assert(strcmp(canonical(lp),canonical(expected)), ...
            'sar20Source:cachePath','Loaded helper %s came from %s, not %s.',nm,lp,expected);
    end
    for k=1:numel(rows)
        name=char(rows(k).name);
        expected=fullfile(root,strrep(char(rows(k).relative_path),'/',filesep));
        actual=which(name);
        assert(~isempty(actual)&&strcmp(canonical(actual),canonical(expected)), ...
            'sar20Source:which','Helper %s resolves to %s, expected %s.',name,actual,expected);
        assert(strcmp(sha(expected),char(rows(k).sha256)), ...
            'sar20Source:sha','Helper %s differs from frozen bytes.',name);
    end
    assets=records.assets;
    for k=1:numel(assets)
        file=fullfile(root,strrep(char(assets(k).relative_path),'/',filesep));
        assert(strcmp(sha(file),char(assets(k).sha256)), ...
            'sar20Source:asset','Candidate configuration asset differs: %s.',file);
    end
end
function p=canonical(pathname)
    p=char(java.io.File(char(pathname)).getCanonicalPath());
end
