function report=test_cmp_ni_fusion()
%TEST_CMP_NI_FUSION DRAFT: pure candidate tests, never run during preparation.
% Must run in a NEW isolated MATLAB process; no SLX load/sim/save or production
% write. It tests the actual fused config/RA guards, not a duplicated oracle.
    here=fileparts(mfilename('fullpath'));root=fileparts(here);candidate=fullfile(root,'candidate');
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(candidate,'current','src')),fullfile(candidate,'config'), ...
        fullfile(root,'baseline'),here,'-begin');
    assert_source_bindings(root,'before');
    rngBefore=rng;
    assert_small_file(fullfile(candidate,'config','nominal.mat'));
    P=adc_parameters();Q0=behavior_prepare_configuration(P);
    assert(~isfield(Q0.control,'comparator')&&~Q0.ni.comparator_noise&& ...
        ~isfield(Q0.ni,'comparator_noise_scope'),'fusionTest:legacy','Legacy OFF profile changed.');
    behavior_ra_noise_guard(Q0,'check');behavior_dac_backend_parameters(Q0);
    % Neither a summary bit nor a scope claim may conjure a physical model.
    bad=Q0;bad.ni.comparator_noise=true;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20RA:comparatorNoise');
    must_error(@()behavior_ra_noise_guard(bad,'derive'),'sar20RA:comparatorNoise');
    bad=Q0;bad.ni.comparator_noise_scope=scope(false,false);bad.ni.comparator_noise_scope.flash_preconvert=true;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    must_error(@()behavior_ra_noise_guard(bad,'derive'),'sar20Cmp:scope');
    bad=Q0;bad.ni.comparator_noise_scope='malformed';
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    must_error(@()behavior_ra_noise_guard(bad,'derive'),'sar20Cmp:scope');

    cfg=struct('enabled',true,'sar1_offset_v',0,'sar1_noise_rms_v',1e-3, ...
        'sar2_offset_v',0,'sar2_noise_rms_v',0,'seed_u64',uint64(20261104),'tie_decision',1);
    Q=prepare_with(Q0,cfg);check_scope(Q,true,false);
    behavior_ra_noise_guard(Q,'check');behavior_dac_backend_parameters(Q);
    % A legitimate profile is sufficient to derive the aggregate and exact
    % per-channel scope even when initially supplied with a stale binary flag.
    stale=Q;stale.ni.comparator_noise=false;
    must_error(@()behavior_ra_noise_guard(stale,'check'),'sar20Cmp:coverage');
    derived=behavior_ra_noise_guard(stale,'derive');check_scope(derived,true,false);
    missing=Q;missing.ni=rmfield(missing.ni,{'comparator_noise','comparator_noise_scope'});
    must_error(@()behavior_ra_noise_guard(missing,'check'),'sar20Cmp:coverage');
    derived=behavior_ra_noise_guard(missing,'derive');check_scope(derived,true,false);
    bad=Q;bad.ni.comparator_noise=NaN;
    must_error(@()behavior_ra_noise_guard(bad,'derive'),'sar20Cmp:coverage');
    bad=Q;bad.ni.comparator_noise_scope.sar2_and_tracking=true;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    bad=Q;bad.ni.comparator_noise_scope.flash_preconvert=true;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    derived=behavior_ra_noise_guard(bad,'derive');check_scope(derived,true,false);
    bad=Q;bad.ni.comparator_noise_scope='malformed';
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    derived=behavior_ra_noise_guard(bad,'derive');check_scope(derived,true,false);
    bad=Q;bad.ni=rmfield(bad.ni,'comparator_noise_scope');
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:scope');
    derived=behavior_ra_noise_guard(bad,'derive');check_scope(derived,true,false);
    bad=Q;bad.control.comparator=rmfield(bad.control.comparator,'sar2_noise_rms_v');
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:config');
    bad=Q;bad.control.comparator.sar1_noise_rms_v=-1;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:noise');

    cfg.sar1_noise_rms_v=0;cfg.sar2_noise_rms_v=2e-3;
    Q=prepare_with(Q0,cfg);check_scope(Q,false,true);behavior_dac_backend_parameters(Q);
    cfg.sar1_noise_rms_v=1e-3;
    Q=prepare_with(Q0,cfg);check_scope(Q,true,true);
    cfg.enabled=false;
    Q=prepare_with(Q0,cfg);check_scope(Q,false,false);
    cfg.enabled=true;cfg.sar1_noise_rms_v=0;cfg.sar2_noise_rms_v=0;
    Q=prepare_with(Q0,cfg);check_scope(Q,false,false);
    cfg.sar1_offset_v=1e-3;
    Q=prepare_with(Q0,cfg);check_scope(Q,false,false);behavior_dac_backend_parameters(Q);
    % Existing eligibility cannot be bypassed by direct workspace edits.
    for key={'training','cal_cfg','frozen','bank'}
        bad=Q;bad.(key{1}).enabled=true;
        must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:unqualifiedCalibration');
    end
    % NI candidate's zero-dither ordinary path remains valid with comparator
    % noise, but no training/frozen/bank qualification follows from this check.
    cfg.sar1_offset_v=0;cfg.sar1_noise_rms_v=1e-3;
    Z=Q0;Z.front.dither_enabled=true;Z.front.dither_input_amplitude_v=0;
    Z.digital.dither_enabled=true;Z.digital.dither_seed=Z.front.dither_seed;Z.digital.dither_amplitude_v=0;
    Z.control.comparator=cfg;Z=behavior_prepare_configuration(Z);check_scope(Z,true,false);
    assert(~Z.training.enabled&&~Z.cal_cfg.enabled&&~Z.frozen.enabled&&~Z.bank.enabled, ...
        'fusionTest:zeroDither','Zero dither must remain ordinary-only.');
    behavior_dac_backend_parameters(Z);

    % RA OU with a zero comparator profile remains allowed; active noise OR
    % offset is rejected, including when all coverage fields were forged to
    % appear internally consistent. RA OU sigma=0 still counts as OU enabled.
    on=Q0;on.backend.ni.ra_noise=true;
    on.backend.ra_noise=struct('schema','sar20-ra-ou/v1', ...
        'sigma_vx_rms',1e-3,'seed_u64',uint64(20261030));
    zero=cfg;zero.sar1_noise_rms_v=0;zero.sar2_noise_rms_v=0;zero.sar1_offset_v=0;
    on.control.comparator=zero;on=behavior_prepare_configuration(on);check_scope(on,false,false);
    behavior_ra_noise_guard(on,'check');
    bad=on;bad.control.comparator.sar1_noise_rms_v=1e-3;
    bad.ni.comparator_noise=true;bad.ni.comparator_noise_scope=scope(true,false);
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:raNoiseCombination');
    must_error(@()behavior_prepare_configuration(bad),'sar20Cmp:raNoiseCombination');
    bad=on;bad.control.comparator.sar1_offset_v=1e-3;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:raNoiseCombination');
    bad.backend.ra_noise.sigma_vx_rms=0;bad.ni.ra_noise=false;
    must_error(@()behavior_ra_noise_guard(bad,'check'),'sar20Cmp:raNoiseCombination');
    assert(isequaln(rngBefore,rng),'fusionTest:rng','Pure config checks changed global RNG.');
    assert_source_bindings(root,'after');
    report=struct('status','passed','scope','pure guard tests only; no SLX simulation', ...
        'flash_preconvert_noise',false,'sar1_fine_and_sar2_tracking_only',true);
end
function Q=prepare_with(P,c)
    Q=P;Q.control.comparator=c;Q=behavior_prepare_configuration(Q);
end
function check_scope(P,fine,sar2)
    want=scope(fine,sar2);
    assert(P.ni.comparator_noise==(fine||sar2)&& ...
        isequaln(P.ni.comparator_noise_scope,want), ...
        'fusionTest:scope','Comparator aggregate and channel coverage differ.');
end
function s=scope(fine,sar2)
    s=struct('sar1_fine',logical(fine),'sar2_and_tracking',logical(sar2),'flash_preconvert',false);
end
function must_error(f,id)
    try,f();catch ex,assert(strcmp(ex.identifier,id),'fusionTest:errorID','Expected %s, got %s.',id,ex.identifier);return;end
    error('fusionTest:missingError','Expected error %s.',id);
end
function expect_path(name,want)
    got=which(name);assert(~isempty(got)&&strcmp(got,want),'fusionTest:path','Unexpected %s path: %s',name,got);
end

function assert_small_file(p)
    d=dir(p);assert(numel(d)==1&&~d.isdir&&d.bytes<=300000000, ...
        'fusionTest:fileLimit','Input must be a regular file no larger than 300,000,000 bytes: %s',p);
end

function h=sha(p)
    assert_small_file(p);fid=fopen(p,'rb');assert(fid>=0,'sar20Source:file','Cannot read %s.',p);
    guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
    bytes=fread(fid,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(bytes(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function assert_source_bindings(root,phase)
% Each test runs in a clean process: never clear another task's loaded code.
% Before/after: pin manifest, source path, bytes and any in-memory function path.
    mf=fullfile(root,'source_manifest.json');assert_small_file(mf);
    assert(strcmp(sha(mf),'f5c6551ab87ce293a0cfbc5b334d81718e9e9a4ce3f13670c0ba51ac7f6dd812'), ...
        'sar20Source:manifest','Candidate source manifest differs from frozen bytes.');
    records=jsondecode(fileread(mf));rows=records.files;
    assert(numel(rows)==116&&any(strcmp(phase,{'before','after'})), ...
        'sar20Source:schema','Unexpected source inventory or check phase.');
    loaded=inmem('-completenames');if isstring(loaded),loaded=cellstr(loaded);end
    names={rows.name};
    for k=1:numel(loaded)
        lp=char(loaded{k});[~,nm,ext]=fileparts(lp);hit=find(strcmpi(nm,names));
        if isempty(hit),continue;end
        assert(isscalar(hit),'sar20Source:inventory','Ambiguous helper name %s.',nm);
        if strcmp(phase,'before')
            error('sar20Source:cacheDirty', ...
                'Helper %s is already loaded from %s; use a new isolated MATLAB process.',nm,lp);
        end
        if isempty(ext),lp=[lp '.m'];end
        expected=fullfile(root,strrep(char(rows(hit).relative_path),'/',filesep));
        assert(strcmp(canonical(lp),canonical(expected)), ...
            'sar20Source:cachePath','Loaded helper %s came from %s, not %s.',nm,lp,expected);
    end
    for k=1:numel(rows)
        name=char(rows(k).name);
        expected=fullfile(root,strrep(char(rows(k).relative_path),'/',filesep));
        actual=which(name);
        assert(~isempty(actual)&&strcmp(canonical(actual),canonical(expected)), ...
            'sar20Source:which','Helper %s resolves to %s, expected %s.',name,actual,expected);
        assert(strcmp(sha(expected),char(rows(k).sha256)), ...
            'sar20Source:sha','Helper %s differs from frozen bytes.',name);
    end
    assets=records.assets;
    for k=1:numel(assets)
        file=fullfile(root,strrep(char(assets(k).relative_path),'/',filesep));
        assert(strcmp(sha(file),char(assets(k).sha256)), ...
            'sar20Source:asset','Candidate configuration asset differs: %s.',file);
    end
end
function p=canonical(pathname)
    p=char(java.io.File(char(pathname)).getCanonicalPath());
end
