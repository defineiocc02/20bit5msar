#!/usr/bin/env python3
"""Independent contract truth table and source-shape audit. No MATLAB execution.

The truth table is an independent Python specification, not execution of the
candidate guard. Source checks confirm expected routing/labels are present but
cannot establish MATLAB semantics, compile behavior, or Simulink connections.
"""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parents[1]

MAX_BYTES=300_000_000
def bounded(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_BYTES:
        raise ValueError(f'File missing or exceeds 300,000,000 bytes: {path}')
    return path
ni=Path('/tmp/sar20_ni_candidate.yAbWvD')
cmp=Path('/tmp/sar20_comparator_calendar_9ki1FW')
assert hashlib.sha256(bounded(ni/'MANIFEST.json').read_bytes()).hexdigest()=='3c49049e391c568fc5f9ffe49fef23e8fb9264419b5297a981ae004cdb423000'
assert hashlib.sha256(bounded(cmp/'MANIFEST.json').read_bytes()).hexdigest()=='e9eee3f1a646d63c0d63f263551f4ef1928e5e039141a9e9fa7449d38964e6bb'
R=bounded(root/'candidate/current/src/model/behavior_ra_noise_guard.m').read_text()
C=bounded(root/'candidate/current/src/model/behavior_comparator_configuration.m').read_text()
N=bounded(root/'candidate/current/src/model/behavior_applied_note.m').read_text()
T=bounded(root/'tests/test_comparator_archive.m').read_text()
assert "P=behavior_comparator_configuration(P,mode);" in R
assert "'Missing comparator model cannot claim noise coverage.'" in R
assert "'Comparator noise is not implemented.'" not in R
assert "'RA OU profile requires comparator_noise coverage OFF.'" in R
assert "'sar1_fine',logical(fine),'sar2_and_tracking',logical(sar2)" in C
assert "'flash_preconvert',false" in C and "validate_active_calendar(P);" in C
assert 'SAR1 fine offset=' in N and 'SAR2/TA offset=' in N and 'Flash comparator noise not modeled' in N
assert 'assert_nonzero_stage_transition(' in T and "typecast(a(:),'uint64')" in T
same=[]
for p in ['current/src/model/behavior_prepare_configuration.m',
          'current/src/model/behavior_training_configuration.m',
          'current/src/calibration/public_calibration_config.m',
          'current/src/calibration/behavior_cal_collector_step.m']:
    assert bounded(root/'candidate'/p).read_bytes()==bounded(ni/'candidate'/p).read_bytes(),p
    same.append(p)
for p in ['current/src/control/behavior_comparator_sample.m',
          'current/src/control/behavior_comparator_keyed_normal.m',
          'current/src/control/behavior_control_stage.m',
          'current/src/control/behavior_control_stage_sfun.m']:
    assert bounded(root/'candidate'/p).read_bytes()==bounded(cmp/p).read_bytes(),p
    same.append(p)

def expected_check(profile,enabled,s1,s2,offset,ou,label,scope,valid=True):
    if not profile:
        return not label and scope in (None,(False,False,False))
    if not valid or s1<0 or s2<0:return False
    fine=bool(enabled and s1>0);sar2=bool(enabled and s2>0)
    if label != (fine or sar2) or scope != (fine,sar2,False):return False
    active=bool(enabled and (s1>0 or s2>0 or offset!=0))
    return not (active and ou)

cases=[
 ('legacy_off',False,False,0,0,0,False,False,None,True,True),
 ('missing_model_fake_label',False,False,0,0,0,False,True,None,True,False),
 ('missing_model_fake_flash',False,False,0,0,0,False,False,(False,False,True),True,False),
 ('fine_noise_only',True,True,.001,0,0,False,True,(True,False,False),True,True),
 ('sar2_noise_only',True,True,0,.001,0,False,True,(False,True,False),True,True),
 ('both_noise_channels',True,True,.001,.002,0,False,True,(True,True,False),True,True),
 ('fake_other_channel',True,True,.001,0,0,False,True,(True,True,False),True,False),
 ('fake_flash_coverage',True,True,.001,0,0,False,True,(True,False,True),True,False),
 ('stale_false_label',True,True,.001,0,0,False,False,(True,False,False),True,False),
 ('stale_true_label_zero_noise',True,True,0,0,0,False,True,(False,False,False),True,False),
 ('disabled_nonzero_sigma',True,False,.001,.002,0,False,False,(False,False,False),True,True),
 ('enabled_zero',True,True,0,0,0,False,False,(False,False,False),True,True),
 ('offset_only',True,True,0,0,.001,False,False,(False,False,False),True,True),
 ('ra_ou_plus_noise',True,True,.001,0,0,True,True,(True,False,False),True,False),
 ('ra_ou_plus_offset',True,True,0,0,.001,True,False,(False,False,False),True,False),
 ('ra_ou_plus_zero',True,True,0,0,0,True,False,(False,False,False),True,True),
 ('invalid_negative_sigma',True,True,-1,0,0,False,False,(False,False,False),True,False),
 ('invalid_profile',True,True,.001,0,0,False,True,(True,False,False),False,False),
]
result={}
for name,*args,want in cases:
    got=expected_check(*args);assert got==want,name;result[name]=got
print(json.dumps({'status':'independent_spec_table_and_static_source_checks_pass',
                  'cases':result,'unchanged_ni_and_comparator_files':same,
                  'scope':'Python specification and source-shape audit only; no MATLAB guard, stage or SLX execution'},indent=2))
