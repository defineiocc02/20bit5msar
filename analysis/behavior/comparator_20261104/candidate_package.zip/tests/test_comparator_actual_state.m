function report=test_comparator_actual_state(fixtureDir,pSha,simSha,modelSha)
%TEST_COMPARATOR_ACTUAL_STATE DRAFT: read a separately instrumented saved run.
% No model is opened or simulated here. There is currently NO such fixture in
% this candidate. The 51-word pre-state must be a real graph wire logger, not a
% reconstruction from RAW/control logs. All three supplied hashes must come
% from a separately reviewed fixture receipt. File hashes pin identity only;
% an independent graph/wire review is still required to prove logger origin.
    assert(nargin==4,'cmpActual:fixtureRequired', ...
        'Supply fixtureDir and reviewed SHA256 values for parameters, simout and instrumented SLX.');
    here=fileparts(mfilename('fullpath'));root=fileparts(here);candidate=fullfile(root,'candidate');
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(candidate,'current','src')),fullfile(candidate,'config'), ...
        fullfile(root,'baseline'),here,'-begin');
    assert_source_bindings(root,'before');
    pfile=fullfile(fixtureDir,'parameters.mat');sfile=fullfile(fixtureDir,'simout.mat');
    model=fullfile(fixtureDir,'SarAdc.slx');
    assert(strcmp(sha(pfile),char(pSha))&&strcmp(sha(sfile),char(simSha))&& ...
        strcmp(sha(model),char(modelSha)), ...
        'cmpActual:hash','The saved fixture does not match reviewed identity hashes.');
    assert_small_file(pfile);a=load(pfile,'P');
    assert_small_file(sfile);b=load(sfile,'simout');P=a.P;out=b.simout;
    assert(isa(out,'Simulink.SimulationOutput')&&isempty(out.ErrorMessage), ...
        'cmpActual:output','Require actual error-free saved simulation output.');
    assert(~P.backend.ni.ra_noise&&~P.training.enabled&&~P.cal_cfg.enabled&& ...
        ~P.frozen.enabled&&~P.bank.enabled&&~P.transport.enabled, ...
        'cmpActual:profile','This directed fixture requires OU/calibration/transport OFF.');
    if isfield(P.control,'comparator')
        c=P.control.comparator;
        assert(~c.enabled||(c.sar1_offset_v==0&&c.sar1_noise_rms_v==0&& ...
            c.sar2_offset_v==0&&c.sar2_noise_rms_v==0), ...
            'cmpActual:profile','Baseline comparator must be OFF or zero.');
    end
    % Required actual-wire logs, to be added ONLY in the isolated fixture model:
    %   cmp_pre_state51_log : Sar1TrialRaCt/SAR_trial -> Sar2Tracking input 1
    %   cmp_obs7_log        : SarDecisionTracking/DAC_obs, input 3
    %   cmp_input3_log      : SarDecisionTracking/Cmp, input 4
    %   cmp_post_state51_log: SarDecisionTracking/SAR_next, output 3
    %   cmp_post_ctrl13_log : SarDecisionTracking/Ctrl, output 1
    %   cmp_post_sign19_log : SarDecisionTracking/DAC_signs, output 2
    % Independent model-wire review must bind these names to these actual ports.
    [t,E]=series(out,'event_log',2);
    [ta,A]=series(out,'cmp_pre_state51_log',51);A=at(t,ta,A);
    [to,O]=series(out,'cmp_obs7_log',7);O=at(t,to,O);
    [tc,C]=series(out,'cmp_input3_log',3);C=at(t,tc,C);
    [tb,B]=series(out,'cmp_post_state51_log',51);B=at(t,tb,B);
    [ty,Y]=series(out,'cmp_post_ctrl13_log',13);Y=at(t,ty,Y);
    [tz,Z]=series(out,'cmp_post_sign19_log',19);Z=at(t,tz,Z);
    assert(isfield(P,'n_cycles')&&P.n_cycles==P.first_id+P.N&&numel(P.groups)==48, ...
        'cmpActual:eventCoverage','Expected the declared transport-OFF ADC48 fixture.');
    expected=[repelem((0:P.n_cycles-1).',48),repmat((1:48).',P.n_cycles,1)];
    assert(isequal(E,expected)&&numel(t)==size(expected,1), ...
        'cmpActual:eventCoverage','Missing, repeated or reordered actual ADC event groups.');
    assert(all(isfinite([A(:);O(:);C(:);B(:);Y(:);Z(:)])), ...
        'cmpActual:shape','Need finite actual ADC wire observations.');
    cfg=struct('enabled',true,'sar1_offset_v',0,'sar1_noise_rms_v',0, ...
        'sar2_offset_v',0,'sar2_noise_rms_v',0,'seed_u64',uint64(20261104),'tie_decision',1);
    stageCoverage=false(3,2);verified=0;rngBefore=rng;
    for r=1:numel(t)
        context=double(E(r,:).');pre=double(A(r,:).');obs=double(O(r,:).');cmp=double(C(r,:).');
        [post,signal,signs]=behavior_control_stage('decide',pre,context,obs,cmp,P);
        assert(bits(post,double(B(r,:).'))&&bits(signal,double(Y(r,:).'))&& ...
            bits(signs,double(Z(r,:).')), ...
            'cmpActual:wireMismatch','Recorded actual pre/post wires do not match current stage.');
        verified=verified+1;
        if r==numel(t)||E(r+1,1)~=E(r,1),continue;end
        events=P.groups(E(r,2)).events;
        for j=1:numel(events)
            ev=events(j);ev.sample_id=E(r,1);ev.epoch=P.epoch;
            switch ev.type
                case 'fine_decide',type=1;v=obs(2);native=cmp(1);
                case 'd2_decide',type=2;v=cmp(3);native=cmp(2);
                case 'ta_compare',type=3;v=cmp(3);native=cmp(2);
                otherwise,continue;
            end
            if all(stageCoverage(type,:))||v==0||native~=double(v>0)|| ...
                    (type==3&&ev.index>=7),continue;end
            probe=struct('event',ev,'voltage',v,'native',native,'typeIndex',type);
            assert_nonzero_stage_transition(P,cfg,pre,context,double(E(r+1,:).'), ...
                obs,cmp,double(O(r+1,:).'),double(C(r+1,:).'),probe);
            stageCoverage(type,:)=[true true];
        end
    end
    assert(all(stageCoverage(:))&&verified>=48,'cmpActual:coverage', ...
        'Need real logged fine/D2/TA pre-state, both directed branches, and >=48 events.');
    assert(isequaln(rngBefore,rng),'cmpActual:rng','Global RNG changed.');
    assert_source_bindings(root,'after');
    report=struct('status','passed','actual_prestate_rows',verified, ...
        'offset_and_noise_stage_paths',stageCoverage,'p_sha256',char(pSha), ...
        'simout_sha256',char(simSha),'model_sha256',char(modelSha), ...
        'scope','saved instrumented wires only; no new SLX simulation; wire provenance requires independent graph review');
end
function ok=bits(a,b)
    ok=isa(a,'double')&&isa(b,'double')&&isreal(a)&&isreal(b)&& ...
        isequal(size(a),size(b))&&isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
end
function [t,x]=series(out,name,width)
    listed=out.who;if isstring(listed),listed=cellstr(listed);end
    assert(any(strcmp(listed,name)),'cmpActual:missingWire','Missing actual-wire logger %s.',name);
    a=out.get(name);assert(isa(a,'timeseries'),'cmpActual:wireType','%s must be timeseries.',name);
    t=double(a.Time(:));d=double(a.Data);
    if a.IsTimeFirst,x=reshape(d,numel(t),[]);
    else,x=reshape(permute(d,[ndims(d) 1:ndims(d)-1]),numel(t),[]);end
    assert(isequal(size(x),[numel(t) width])&&all(isfinite(t))&&all(diff(t)>0), ...
        'cmpActual:wireShape','Malformed actual-wire logger %s.',name);
end
function x=at(wanted,t,x)
    [present,ix]=ismember(wanted,t);assert(all(present),'cmpActual:wireTime','Missing actual event time.');
    for k=1:numel(wanted),assert(nnz(t==wanted(k))==1,'cmpActual:wireTime','Ambiguous event time.');end
    x=x(ix,:);
end
function h=sha(p)
    assert_small_file(p);
    fid=fopen(p,'rb');assert(fid>=0,'cmpActual:file','Cannot read fixture %s.',p);
    guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
    bytes=fread(fid,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');
    md.update(typecast(bytes(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function assert_small_file(p)
    d=dir(p);assert(numel(d)==1&&~d.isdir&&d.bytes<=300000000, ...
        'cmpActual:fileLimit','Input must be a regular file no larger than 300,000,000 bytes: %s',p);
end

function assert_source_bindings(root,phase)
% Each test runs in a clean process: never clear another task's loaded code.
% Before/after: pin manifest, source path, bytes and any in-memory function path.
    mf=fullfile(root,'source_manifest.json');assert_small_file(mf);
    assert(strcmp(sha(mf),'f5c6551ab87ce293a0cfbc5b334d81718e9e9a4ce3f13670c0ba51ac7f6dd812'), ...
        'sar20Source:manifest','Candidate source manifest differs from frozen bytes.');
    records=jsondecode(fileread(mf));rows=records.files;
    assert(numel(rows)==116&&any(strcmp(phase,{'before','after'})), ...
        'sar20Source:schema','Unexpected source inventory or check phase.');
    loaded=inmem('-completenames');if isstring(loaded),loaded=cellstr(loaded);end
    names={rows.name};
    for k=1:numel(loaded)
        lp=char(loaded{k});[~,nm,ext]=fileparts(lp);hit=find(strcmpi(nm,names));
        if isempty(hit),continue;end
        assert(isscalar(hit),'sar20Source:inventory','Ambiguous helper name %s.',nm);
        if strcmp(phase,'before')
            error('sar20Source:cacheDirty', ...
                'Helper %s is already loaded from %s; use a new isolated MATLAB process.',nm,lp);
        end
        if isempty(ext),lp=[lp '.m'];end
        expected=fullfile(root,strrep(char(rows(hit).relative_path),'/',filesep));
        assert(strcmp(canonical(lp),canonical(expected)), ...
            'sar20Source:cachePath','Loaded helper %s came from %s, not %s.',nm,lp,expected);
    end
    for k=1:numel(rows)
        name=char(rows(k).name);
        expected=fullfile(root,strrep(char(rows(k).relative_path),'/',filesep));
        actual=which(name);
        assert(~isempty(actual)&&strcmp(canonical(actual),canonical(expected)), ...
            'sar20Source:which','Helper %s resolves to %s, expected %s.',name,actual,expected);
        assert(strcmp(sha(expected),char(rows(k).sha256)), ...
            'sar20Source:sha','Helper %s differs from frozen bytes.',name);
    end
    assets=records.assets;
    for k=1:numel(assets)
        file=fullfile(root,strrep(char(assets(k).relative_path),'/',filesep));
        assert(strcmp(sha(file),char(assets(k).sha256)), ...
            'sar20Source:asset','Candidate configuration asset differs: %s.',file);
    end
end
function p=canonical(pathname)
    p=char(java.io.File(char(pathname)).getCanonicalPath());
end
