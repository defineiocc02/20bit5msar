#!/usr/bin/env python3
"""Check directed MATLAB-test fixtures against archived actual event data.

Python reconstructs RAW bit updates and due-event identities from saved logs;
it does NOT execute MATLAB comparator/control code or advance analog states.
"""
from pathlib import Path
from contextlib import redirect_stdout
import hashlib
import io
import json
import math
import runpy
import struct
import sys
import numpy as np

sys.dont_write_bytecode=True
root=Path('/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020')

MAX_BYTES=300_000_000
def bounded(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_BYTES:
        raise ValueError(f'File missing or exceeds 300,000,000 bytes: {path}')
    return path
helper=bounded(root/'analysis/behavior/finite_dac_review_20261028/verify_as_run.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='3ca8dc8a6f553e75466438a0d74b9bf6a0a6ab5f65b8c151429981af330f7467'
sys.path.insert(0,str(helper.parent))
import verify_as_run as u
here=Path(__file__).resolve().parent
with redirect_stdout(io.StringIO()):
    cal=runpy.run_path(str(bounded(here/'check_calendar_contract.py')))
groups=cal['grp']
ref=bounded(root/'analysis/behavior/ra_ou_20261030/release_20261031/reference/off/simout.mat')
assert hashlib.sha256(ref.read_bytes()).hexdigest()=='5887b6a6cabb20dbd27308c94ac2bad431787cddbc340db1d02aaa3151377e3a'
bounded(ref)
logs=u.read_logs(ref)
for name in ('front_log','back_log','control_log'):
    assert u.same(logs['event_log']['time'],logs[name]['time'])
events=logs['event_log']['data'];front=logs['front_log']['data'];back=logs['back_log']['data'];control=logs['control_log']['data']

def normal(seed,epoch,sample,code,index):
    payload=b'SAR20-COMPARATOR-v1\0'+struct.pack('>5Q',seed,epoch,sample,code,index)
    d=hashlib.sha256(payload).digest();a,b=struct.unpack('>QQ',d[:16]);scale=2**52
    x=((a>>12)+0.5)/scale;y=((b>>12)+0.5)/scale
    return math.sqrt(-2*math.log(x))*math.cos(2*math.pi*y)

found={}
spec={'fine_decide':(1,'fine_feedback',4),'d2_decide':(2,'d2_feedback',5),'ta_compare':(3,'ta_feedback',6)}
for r,(sample,gi) in enumerate(events):
    if r==0 or r+1==len(events) or int(events[r+1,0])!=int(sample):continue
    for ev in groups[int(gi)-1]['events']:
        typ=ev['type']
        if typ not in spec or typ in found:continue
        code,fb,col=spec[typ];idx=int(ev['index']);bit=int(ev['bit'])
        if typ=='ta_compare' and idx>=7:continue
        v=float(front[r,1] if code==1 else back[r,1]);native=(int(control[r,col])>>bit)&1
        if v==0 or native!=int(v>0):continue
        nxt=groups[int(events[r+1,1])-1]['events']
        assert any(x['type']==fb and int(x['index'])==idx for x in nxt)
        before=int(control[r-1,col]);after=int(control[r,col]);mask=1<<bit
        assert (before&~mask)|(native<<bit)==after
        flipped=1-native;new_word=(before&~mask)|(flipped<<bit)
        assert (new_word>>bit)&1==flipped
        assert int((v-2*v)>0)==flipped
        for k in range(256):
            seed=20261104+k;z=normal(seed,1,int(sample),code,idx)
            if z*v<0 and abs(z)>.1:break
        else:raise AssertionError('No directed seed')
        sigma=2*abs(v)/abs(z)
        assert int((v+sigma*z)>0)==flipped
        found[typ]=dict(sample_id=int(sample),group=int(gi),index=idx,bit=bit,
                        actual_input_v=v,inferred_native_bit=native,forced_bit=flipped,
                        prior_raw_word=before,archived_raw_word=after,directed_raw_word=new_word,
                        next_feedback=fb,next_group=int(events[r+1,1]),
                        directed_feedback_sign=None if code==1 else 2*flipped-1,
                        noise_seed=seed,directed_noise_rms_v=sigma)
assert len(found)==3
zero_counts={name:int(np.sum((logs[name]['data']==0)&np.signbit(logs[name]['data'])))
             for name in ('front_log','back_log','control_log','raw_log')}
print(json.dumps({'fixture_cases':found,'negative_zero_counts':zero_counts,
                  'scope':'Saved event inputs and independent bit algebra; no MATLAB stage, no analog or SLX simulation'},indent=2))
