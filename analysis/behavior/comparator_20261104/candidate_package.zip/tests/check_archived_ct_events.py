#!/usr/bin/env python3
"""Independent Python arithmetic on archived VY event data; no MATLAB is run.

Noise fixture uses RA OU ON archived events only as recorded voltages, not a
combined OU/comparator simulation or a comparator runtime verification.
"""
import hashlib
import json
import math
import struct
from pathlib import Path

root = Path('/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020')

MAX_BYTES=300_000_000
def bounded(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_BYTES:
        raise ValueError(f'File missing or exceeds 300,000,000 bytes: {path}')
    return path
p = bounded(root / 'analysis/behavior/ra_ou_20261030/all_events_independent.json')
b = p.read_bytes()
assert hashlib.sha256(b).hexdigest() == '04120b9a6f1fa719e4efbdb88103d6a39527d4a409136a5713b2167e6fcf327e'
data = json.loads(b)

def noise(seed, epoch, sample_id, kind, index):
    msg = b'SAR20-COMPARATOR-v1\0' + struct.pack('>5Q', seed, epoch, sample_id, kind, index)
    digest = hashlib.sha256(msg).digest()
    a, c = struct.unpack('>QQ', digest[:16])
    scale = 2**52
    u, v = ((a >> 12) + .5) / scale, ((c >> 12) + .5) / scale
    assert 0 < u < 1 and 0 < v < 1
    return math.sqrt(-2 * math.log(u)) * math.cos(2 * math.pi * v)

counts = {'d2_decide': 0, 'ta_compare': 0}
nonzero = flips = changed = 0
for e in data['events']:
    for key, raw, code, countcol in [('d2_decide', 'd2_decision', 2, 0), ('ta_compare', 'ta_decision', 3, 1)]:
        if key not in e['tokens']:
            continue
        counts[key] += 1
        v = e['vy_actual_v']
        bit = e[raw]
        index = e['tap_counts_d2_ta_feedback'][countcol] - 1
        assert 0 <= index < (12 if code == 2 else 8)
        if v != 0:
            nonzero += 1
            assert bit == (v > 0), (e['id'], key, index, v, bit)
            assert ((v + (-2*v)) > 0) != bit
        z = noise(20261104, 1, e['id'], code, index)
        assert z == noise(20261104, 1, e['id'], code, index)
        changed += z != noise(20261105, 1, e['id'], code, index)
        flips += ((v + 1e-3*z) > 0) != bit
assert counts == {'d2_decide':144, 'ta_compare':96}
assert nonzero and changed
print(json.dumps({'source': str(p), 'source_sha256':hashlib.sha256(b).hexdigest(),
                  'counts': counts, 'nonzero_actual_vy': nonzero,
                  'offset_flip_checks': nonzero, 'new_seed_changes': changed,
                  'independent_python_noise_flips': flips,
                  'scope':'archive-based arithmetic only; no MATLAB / SLX or joint-noise validation'}, indent=2))
