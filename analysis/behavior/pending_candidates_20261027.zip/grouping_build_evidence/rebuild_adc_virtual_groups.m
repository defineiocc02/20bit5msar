function report=rebuild_adc_virtual_groups(model,adcScope,proposalFile,auditDir)
%REBUILD_ADC_VIRTUAL_GROUPS Fresh-copy entry for the one known 58-block ADC.
% v2: every helper is FILE LEVEL; no nested shared loop-index variables.
% To continue an existing partial use resume_adc_virtual_groups instead.
    assert(~strcmp(model,'SarAdc')&&bdIsLoaded(model)&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped')&&strcmp(get_param(model,'Dirty'),'off'), ...
        'groupADC:candidate','Use a stopped saved COPY with a different model name.');
    assert(startsWith(adcScope,'blk_'),'groupADC:scope','Supply actual ADC model_read scope ID.');
    if ~isfolder(auditDir),mkdir(auditDir);end
    proposal=jsondecode(fileread(proposalFile));
    assert(numel(proposal.groups)==6,'groupADC:proposal','Use the six-stage ADC proposal.');
    adc=resolve_id(model,adcScope);initialView=read_scope(model,adcScope,auditDir,'before');
    modelFile=get_param(model,'FileName');
    portablePath=strrep(modelFile,'\','/');
    assert(~contains(lower(portablePath),'/current/'),'groupADC:current','Candidate SLX must be outside current/.');
    preimage=fullfile(auditDir,'candidate_before.slx');
    assert(~isfile(preimage),'groupADC:audit','Use a fresh audit directory; preserve prior candidate checkpoints.');
    copyfile(modelFile,preimage);
    initialP=getVariable(get_param(model,'ModelWorkspace'),'P');
    paths=find_system(adc,'SearchDepth',1,'Type','Block');paths=paths(~strcmp(paths,adc));
    assert(numel(paths)<=80,'groupADC:bound','This candidate is bounded to the known flat ADC, not a general graph transformer.');
    blocks=struct('name',{},'path',{},'id',{},'type',{},'params',{},'group',{},'live_id',{});
    for k=1:numel(paths)
        path=paths{k};name=get_param(path,'Name');type=get_param(path,'BlockType');id=native_id(path);
        assert(has_id(initialView,id),'groupADC:readID','An original ID is missing from live readback.');
        assert(~strcmp(type,'SubSystem')&&~strcmp(type,'TriggerPort'), ...
            'groupADC:flat','ADC must be flat and must not contain the enclosing Trigger.');
        group=0;
        for j=1:numel(proposal.groups)
            names=proposal.groups(j).existing_members;
            if strcmp(name,'ZeroCommand')&&any(strcmp(names,'Zero24')),group=j;
            elseif any(strcmp(names,name)),group=j;end
        end
        parent=any(strcmp(type,{'Inport','Outport','UnitDelay'}))||strcmp(name,'Zero3');
        if parent,group=0;elseif group==0,group=7;end
        params=struct();if group>0,params=parameters(path,type);end
        blocks(end+1)=struct('name',name,'path',path,'id',id,'type',type,'params',params,'group',group,'live_id',id); %#ok<AGROW>
    end
    stateNames={blocks(strcmp({blocks.type},'UnitDelay')).name};
    assert(isequal(sort(stateNames),sort({'SampleCharge','RaCtState','SarState'})), ...
        'groupADC:states','Exactly the original three state UnitDelays must remain outside the groups.');
    for j=1:6
        assert(any([blocks.group]==j),'groupADC:members','A required physical computation group is empty.');
        assert(~any(strcmp({blocks.name},proposal.groups(j).subsystem)), ...
            'groupADC:existing','Use a clean candidate copy; grouped/partial scopes are not overwritten.');
    end
    edges=struct('src',{},'sp',{},'dst',{},'dp',{});
    for k=1:numel(blocks)
        ph=get_param(blocks(k).path,'PortHandles');
        for port=1:numel(ph.Inport)
            [sp,~]=source_of_input(ph.Inport(port));if sp<=0,continue;end
            sourcePath=get_param(sp,'Parent');index=find(strcmp({blocks.path},sourcePath),1);
            assert(~isempty(index),'groupADC:source','Input source is outside the ADC scope.');
            edges(end+1)=struct('src',index,'sp',get_param(sp,'PortNumber'),'dst',k,'dp',port); %#ok<AGROW>
        end
    end
    % Diagnostics is observational only. No diagnostic output may drive physics,
    % SAR, or any of the three state inputs. It may drive an existing Outport.
    diag=find([blocks.group]==7);
    diagnosticNames={'AzEventId','AzFinalNextDiff','AzFinalNextLog','AzFinalNextMux', ...
        'AzHalfSelect','AzHalfSplit','AzPublicEpoch','AzPublicPol','AzRawCharge', ...
        'AzReturnVoltage','AzRouteLog','AzRouteMux','AzRoutedCommand','AzServiceSelect'};
    assert(numel(diag)==14&&isequal(sort({blocks(diag).name}),sort(diagnosticNames)), ...
        'groupADC:diagnosticInventory','Require the actual current 14 AZ observation blocks.');
    for k=diag
        assert(any(strcmp(blocks(k).type,{'Selector','Sum','Demux','Mux','Constant','ToWorkspace'}))|| ...
            (strcmp(blocks(k).name,'AzPublicPol')&&strcmp(blocks(k).type,'M-S-Function')&& ...
             strcmp(blocks(k).params.FunctionName,'behavior_pol_sfun')), ...
            'groupADC:unknown','Unclassified computation %s is not silently treated as Diagnostics.',blocks(k).name);
    end
    for e=edges
        if blocks(e.src).group==7&&blocks(e.dst).group~=7
            assert(strcmp(blocks(e.dst).type,'Outport'),'groupADC:diagFeedback','Diagnostic output feeds a physical/state path.');
        end
    end
    count=6+~isempty(diag);groups=repmat(struct('name','','inputs',{{}},'outputs',{{}}, ...
        'members',[],'id','','input_ids',{{}},'output_ids',{{}}),count,1);
    for j=1:count
        if j<=6,groups(j).name=proposal.groups(j).subsystem;else,groups(j).name='Diagnostics';end
        groups(j).members=find([blocks.group]==j);
        incoming={};outgoing={};
        for e=edges
            sg=blocks(e.src).group;dg=blocks(e.dst).group;key=endpoint(e.src,e.sp);
            if dg==j&&sg~=j,incoming=append_unique(incoming,key);end
            if sg==j&&dg~=j,outgoing=append_unique(outgoing,key);end
        end
        groups(j).inputs=incoming;groups(j).outputs=outgoing;
    end
    aliases=struct('group',{},'direction',{},'port',{},'short_name',{}, ...
        'source_endpoint',{},'source_path',{},'width',{},'units',{});
    for jj=1:count
        for side=1:2
            direction='input';keys=groups(jj).inputs;
            if side==2,direction='output';keys=groups(jj).outputs;end
            for pp=1:numel(keys)
                [ii,sourcePort]=parse_endpoint(keys{pp});[label,width,units]=behavior_group_boundary(keys{pp},blocks,initialP);
                aliases(end+1)=struct('group',groups(jj).name,'direction',direction, ...
                    'port',pp,'short_name',label,'source_endpoint',sprintf('%s.y%d',blocks(ii).name,sourcePort), ...
                    'source_path',blocks(ii).path,'width',width,'units',units); %#ok<AGROW>
            end
        end
    end
    write_artifact(auditDir,'boundary_aliases.json',jsonencode(aliases));
    save(fullfile(auditDir,'original_graph.mat'),'blocks','edges','groups','initialP','-v7.3');
    report=finish_adc_virtual_groups(model,adcScope,blocks,edges,groups,initialP,auditDir);
end

function key=endpoint(index,port),key=sprintf('b%d_p%d',index,port);end
function [index,port]=parse_endpoint(key),v=sscanf(key,'b%d_p%d');index=v(1);port=v(2);end
function c=append_unique(c,key),if ~any(strcmp(c,key)),c{end+1}=key;end,end
function path=resolve_id(model,id),path=Simulink.ID.getFullName([model ':' extractAfter(id,'blk_')]);end
function id=native_id(path),id=['blk_' char(extractAfter(Simulink.ID.getSID(path),':'))];end
function yes=has_id(view,id),yes=~isempty(regexp(char(view),['(?<![A-Za-z0-9_])' regexptranslate('escape',id) '(?![A-Za-z0-9_])'],'once'));end
function [src,line]=source_of_input(input)
    line=get_param(input,'Line');src=-1;if line<=0,return;end
    src=get_param(line,'SrcPortHandle');while src<=0,line=get_param(line,'LineParent');src=get_param(line,'SrcPortHandle');end
end
function v=read_scope(model,scope,auditDir,label)
    v=char(model_read(model,scope,'0'));write_artifact(auditDir,[label '_read.txt'],v);
    assert(~contains(v,'status: error'),'groupADC:read','model_read failed.');
end
function write_artifact(auditDir,name,value)
    fid=fopen(fullfile(auditDir,name),'w','n','UTF-8');assert(fid>=0);c=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s',char(value));
end

function p=parameters(path,type)
% Bounded parameter snapshots for the current ADC primitives. No formula edit.
    switch type
        case 'M-S-Function',keys={'Parameters','FunctionName'};
        case 'Constant',keys={'Value','OutDataTypeStr','SampleTime','VectorParams1D'};
        case 'Selector'
            % Native setters validate each step. IndexOptions then Indices must
            % precede InputPortWidth (AzEventId width2 cannot keep default3).
            keys={'NumberOfDimensions','IndexMode','IndexOptions','Indices','InputPortWidth','OutputSizes'};
        case 'RelationalOperator',keys={'Operator','OutDataTypeStr','InputSameDT','ZeroCross'};
        case 'DataTypeConversion',keys={'OutDataTypeStr','RndMeth','SaturateOnIntegerOverflow','ConvertRealWorld'};
        case 'Mux',keys={'Inputs'};
        case 'Demux',keys={'Outputs','DisplayOption'};
        case 'Sum',keys={'Inputs','IconShape','CollapseMode','CollapseDim', ...
                'AccumDataTypeStr','OutDataTypeStr','RndMeth','SaturateOnIntegerOverflow'};
        case 'Terminator',keys={};
        case 'ToWorkspace',keys={'VariableName','SaveFormat','MaxDataPoints','Decimation','SampleTime','FixptAsFi','Save2DSignal'};
        otherwise,error('groupADC:type','Unsupported original block type %s; do not silently substitute.',type);
    end
    keys=[keys {'Description','Priority','Orientation','ForegroundColor','BackgroundColor','ShowName'}];
    available=get_param(path,'ObjectParameters');p=struct();
    for k=1:numel(keys),if isfield(available,keys{k}),p.(keys{k})=get_param(path,keys{k});end,end
end
