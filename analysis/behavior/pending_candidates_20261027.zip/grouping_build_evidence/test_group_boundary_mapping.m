function report=test_group_boundary_mapping()
%TEST_GROUP_BOUNDARY_MAPPING Pure four-port regression of the observed pp bug.
% No model loading/mutation or ADC simulation. Helper is a FILE-LEVEL function.
    blocks=struct('name',{'Calendar','RaCtState','SampleCharge','SineCfg'});
    P=struct('xFE0',zeros(317,1),'xBK0',zeros(48,1),'xSC0',zeros(51,1));
    keys={'b1_p1','b2_p1','b3_p1','b4_p1'};ids=cell(1,4);
    for pp=1:4
        before=pp;[label,width,units]=behavior_group_boundary(keys{pp},blocks,P);
        assert(pp==before,'groupADC:testSharedIndex','Helper changed caller loop index.');
        ids{pp}=struct('label',label,'width',width,'units',units);
    end
    assert(numel(ids)==4&&all(~cellfun(@isempty,ids)));
    assert(isequal(cellfun(@(x)x.label,ids,'UniformOutput',false),{'Event','RA_old','FE_old','Source'}));
    report=struct('status','file_level_four_port_index_regression_pass', ...
        'complete_port_map',true,'actual_SLX_simulated',false);
end
