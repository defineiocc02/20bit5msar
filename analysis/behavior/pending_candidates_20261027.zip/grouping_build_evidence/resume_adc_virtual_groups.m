function report=resume_adc_virtual_groups(model,adcScope,originalGraphFile,auditDir)
%RESUME_ADC_VIRTUAL_GROUPS Continue the saved SarView partial, never restart it.
% v1 2026-10-27. originalGraphFile is the ORIGINAL original_graph.mat checkpoint.
% Root should finish the current main run before invoking in the unique MATLAB.
% First retain current partial read/check/save; then rebind actual IDs and add
% only missing groups/blocks/wires. Existing identical wires are not recreated.
    assert(~strcmp(model,'SarAdc')&&bdIsLoaded(model)&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
        'groupADC:resumeCandidate','Use the stopped grouping COPY, never the main model.');
    file=get_param(model,'FileName');assert(~contains(lower(strrep(file,'\','/')),'/current/'), ...
        'groupADC:resumeCurrent','Candidate must remain outside current/.');
    if ~isfolder(auditDir),mkdir(auditDir);end
    assert(~isfile(fullfile(auditDir,'resume_before.slx')),'groupADC:resumeAudit','Use a fresh resume audit folder.');
    % This is a known partial scope: connectivity errors are recorded, not
    % presented as an acceptance pass. Retain every diagnostic exception.
    checkpointError=[];
    try,write_artifact(auditDir,'partial_before_read.txt',model_read(model,adcScope,'0'));
    catch cause,checkpointError=cause;end
    try,write_artifact(auditDir,'partial_before_check.txt',model_check(model,adcScope,'["unconnected_ports","unconnected_lines"]'));
    catch cause
        if isempty(checkpointError),checkpointError=cause;else,checkpointError=addCause(checkpointError,cause);end
    end
    save_system(model,file,'SaveModelWorkspace',true);
    copyfile(file,fullfile(auditDir,'resume_before.slx'));
    if ~isempty(checkpointError),throw(checkpointError);end
    original=load(originalGraphFile,'blocks','edges','groups','initialP');
    assert(all(isfield(original,{'blocks','edges','groups','initialP'})), ...
        'groupADC:resumeCheckpoint','Original graph checkpoint is incomplete.');
    assert(numel(original.blocks)==58&&numel(original.groups)==7, ...
        'groupADC:resumeSize','This resume is bounded to the inspected 58-block ADC.');
    report=finish_adc_virtual_groups(model,adcScope,original.blocks,original.edges, ...
        original.groups,original.initialP,auditDir);
    report.resumed_from=originalGraphFile;report.restart_from_scratch=false;
    save(fullfile(auditDir,'resume_receipt.mat'),'report','-v7.3');
    write_artifact(auditDir,'resume_receipt.json',jsonencode(report));
end
function write_artifact(auditDir,name,value)
    fid=fopen(fullfile(auditDir,name),'w','n','UTF-8');assert(fid>=0);c=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s',char(value));
end
