function report=finish_adc_virtual_groups(model,adcScope,blocks,edges,groups,initialP,auditDir)
%FINISH_ADC_VIRTUAL_GROUPS Only the saved 58-block ADC grouping transaction.
% All helpers are file-level functions with explicit arguments: no nested
% shared workspace can overwrite a caller's port/member loop index.
% Resume is idempotent for existing groups/blocks/identical connections.
    assert(~strcmp(model,'SarAdc')&&bdIsLoaded(model)&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
        'groupADC:finishCandidate','Only a stopped non-main candidate is allowed.');
    modelFile=get_param(model,'FileName');
    assert(~contains(lower(strrep(modelFile,'\','/')),'/current/'), ...
        'groupADC:finishCurrent','Candidate must be outside current/.');
    try
    assert(isequaln(initialP,getVariable(get_param(model,'ModelWorkspace'),'P')), ...
        'groupADC:resumeP','Candidate P differs from the saved original graph checkpoint.');
    count=numel(groups);assert(numel(blocks)==58&&count==7,'groupADC:resumeBound','Require this 58-block/seven-group checkpoint.');
    for gj=1:count
        groups(gj).id='';groups(gj).input_ids={};groups(gj).output_ids={};
    end
    % Keep completed group creation: only create groups absent from live readback.
    view=read_scope(model,adcScope,auditDir,'resume_parent');ops={};
    for originalIndex=find([blocks.group]==0)
        retained=find_child(model,adcScope,blocks(originalIndex).name,view,false);
        assert(strcmp(get_param(resolve_id(model,retained),'BlockType'),blocks(originalIndex).type), ...
            'groupADC:resumeScope','Wrong scope or changed retained parent block.');
        blocks(originalIndex).live_id=retained;
    end
    for gj=1:count
        if isempty(find_child(model,adcScope,groups(gj).name,view,true))
            labelsIn=cellfun(@(key)boundary_name(key,blocks,initialP),groups(gj).inputs,'UniformOutput',false);
            labelsOut=cellfun(@(key)boundary_name(key,blocks,initialP),groups(gj).outputs,'UniformOutput',false);
            ops{end+1}=struct('op','create_subsystem','name',groups(gj).name,'ref',groups(gj).name, ...
                'interface',struct('inputs',{labelsIn},'outputs',{labelsOut})); %#ok<AGROW>
        end
    end
    mutate(model,adcScope,ops,auditDir,'missing_groups');
    for gj=1:count
        view=read_scope(model,adcScope,auditDir,sprintf('g%d_parent',gj));
        groups(gj).id=find_child(model,adcScope,groups(gj).name,view,false);
        if ~strcmp(get_param(resolve_id(model,groups(gj).id),'TreatAsAtomicUnit'),'off')
            mutate(model,adcScope,{struct('op','configure','target',groups(gj).id, ...
                'params',struct('TreatAsAtomicUnit','off'))},auditDir,sprintf('g%d_virtual',gj));
        end
        gv=read_scope(model,groups(gj).id,auditDir,sprintf('g%d_existing',gj));ops={};newSelectors=[];
        % Recreate the complete ID map from actual ports, never old in-memory IDs.
        for side=1:2
            keys=groups(gj).inputs;if side==2,keys=groups(gj).outputs;end
            for portNumber=1:numel(keys)
                [sourceIndex,sourcePort]=parse_endpoint(keys{portNumber});
                [label,width,units]=behavior_group_boundary(keys{portNumber},blocks,initialP);
                pid=find_child(model,groups(gj).id,label,gv,false);
                if side==1,groups(gj).input_ids{portNumber}=pid;else,groups(gj).output_ids{portNumber}=pid;end
                desc=sprintf('Original source %s.y%d; %d words; units %s. Transparent boundary, no math/state.', ...
                    blocks(sourceIndex).name,sourcePort,width,units);
                if ~strcmp(get_param(resolve_id(model,pid),'Description'),desc)
                    ops{end+1}=struct('op','configure','target',pid,'params',struct('Description',desc)); %#ok<AGROW>
                end
            end
        end
        for memberIndex=groups(gj).members
            bid=find_child(model,groups(gj).id,blocks(memberIndex).name,gv,true);
            if isempty(bid)
                seed=blocks(memberIndex).params;
                if strcmp(blocks(memberIndex).type,'Selector')
                    % A narrow target cannot keep default [1 2 3], and a wide
                    % target cannot accept final >3 before its width is set.
                    % Seed safely at index1, then finalize by the actual new ID.
                    seed.Indices='1';
                    newSelectors(end+1)=memberIndex; %#ok<AGROW>
                end
                ops{end+1}=struct('op','add_block','type',blocks(memberIndex).type, ...
                    'name',blocks(memberIndex).name,'ref',blocks(memberIndex).name, ...
                    'params',seed); %#ok<AGROW>
            else
                assert(strcmp(get_param(resolve_id(model,bid),'BlockType'),blocks(memberIndex).type), ...
                    'groupADC:resumeType','Existing copied block type differs from checkpoint.');
                % Group1 primitives already completed are retained, not rebuilt
                % or numerically reconfigured. Wrong PORT descriptions are repaired above.
                fields=fieldnames(blocks(memberIndex).params);
                for fieldIndex=1:numel(fields)
                    assert(isequaln(get_param(resolve_id(model,bid),fields{fieldIndex}), ...
                        blocks(memberIndex).params.(fields{fieldIndex})), ...
                        'groupADC:resumeParameter', ...
                        'Existing copied primitive differs from checkpoint. For the four known failed AZ Selectors run repair_adc_az_selectors first; no physics reconfiguration is inferred.');
                end
            end
        end
        mutate(model,groups(gj).id,ops,auditDir,sprintf('g%d_missing_blocks',gj));
        gv=read_scope(model,groups(gj).id,auditDir,sprintf('g%d_ready',gj));
        for memberIndex=groups(gj).members
            blocks(memberIndex).live_id=find_child(model,groups(gj).id,blocks(memberIndex).name,gv,false);
        end
        finalSelectorOps={};
        for memberIndex=newSelectors
            finalSelectorOps{end+1}=struct('op','configure','target',blocks(memberIndex).live_id, ...
                'params',struct('Indices',blocks(memberIndex).params.Indices)); %#ok<AGROW>
        end
        mutate(model,groups(gj).id,finalSelectorOps,auditDir,sprintf('g%d_final_selector_indices',gj));
        if ~isempty(finalSelectorOps),read_scope(model,groups(gj).id,auditDir,sprintf('g%d_selectors_ready',gj));end
        ops={};
        for e=edges
            if blocks(e.dst).group~=gj,continue;end
            dst=blocks(e.dst).live_id;
            if blocks(e.src).group==gj,src=blocks(e.src).live_id;sp=e.sp;
            else
                inputIndex=find(strcmp(groups(gj).inputs,endpoint(e.src,e.sp)),1);
                src=groups(gj).input_ids{inputIndex};sp=1;
            end
            op=wire_if_missing(model,src,sp,dst,e.dp);
            if ~isempty(op),ops{end+1}=op;end %#ok<AGROW>
        end
        for outputIndex=1:numel(groups(gj).outputs)
            [sourceIndex,sourcePort]=parse_endpoint(groups(gj).outputs{outputIndex});
            op=wire_if_missing(model,blocks(sourceIndex).live_id,sourcePort,groups(gj).output_ids{outputIndex},1);
            if ~isempty(op),ops{end+1}=op;end %#ok<AGROW>
        end
        mutate(model,groups(gj).id,ops,auditDir,sprintf('g%d_missing_edges',gj));
        save(fullfile(auditDir,sprintf('group%d_ids_checkpoint.mat',gj)),'blocks','groups','edges','initialP','-v7.3');
    end
    % Existing parent state/boundary blocks keep their actual IDs. Delete only
    % old computation still present at the ADC parent, after all copies exist.
    view=read_scope(model,adcScope,auditDir,'before_old_removal');ops={};
    for bi=1:numel(blocks)
        old=find_child(model,adcScope,blocks(bi).name,view,blocks(bi).group>0);
        if blocks(bi).group==0,blocks(bi).live_id=old;
        elseif ~isempty(old),ops{end+1}=struct('op','delete','target',old);end %#ok<AGROW>
    end
    mutate(model,adcScope,ops,auditDir,'remove_remaining_old_computation');
    read_scope(model,adcScope,auditDir,'before_boundary_edges');ops={};seen={};
    for e=edges
        sg=blocks(e.src).group;dg=blocks(e.dst).group;
        if sg==dg,continue;end
        if sg>0,src=groups(sg).id;sp=find(strcmp(groups(sg).outputs,endpoint(e.src,e.sp)),1);
        else,src=blocks(e.src).live_id;sp=e.sp;end
        if dg>0,dst=groups(dg).id;dp=find(strcmp(groups(dg).inputs,endpoint(e.src,e.sp)),1);
        else,dst=blocks(e.dst).live_id;dp=e.dp;end
        key=sprintf('%s:%d>%s:%d',src,sp,dst,dp);
        if any(strcmp(seen,key)),continue;end;seen{end+1}=key; %#ok<AGROW>
        op=wire_if_missing(model,src,sp,dst,dp);
        if ~isempty(op),ops{end+1}=op;end %#ok<AGROW>
    end
    mutate(model,adcScope,ops,auditDir,'missing_boundary_edges');
    for e=edges
        ph=get_param(resolve_id(model,blocks(e.dst).live_id),'PortHandles');
        actual=expanded_source(model,ph.Inport(e.dp),groups,blocks);
        assert(strcmp(actual,endpoint(e.src,e.sp)),'groupADC:expandedGraph', ...
            'Expanded source changed at original %s input%d.',blocks(e.dst).name,e.dp);
    end
    for bi=find([blocks.group]>0)
        path=resolve_id(model,blocks(bi).live_id);names=fieldnames(blocks(bi).params);
        for fi=1:numel(names)
            assert(isequaln(get_param(path,names{fi}),blocks(bi).params.(names{fi})), ...
                'groupADC:parameter','Original copied primitive parameter differs.');
        end
    end
    assert(isequaln(initialP,getVariable(get_param(model,'ModelWorkspace'),'P')),'groupADC:P','P changed.');
    read_scope(model,adcScope,auditDir,'completed');
    write_artifact(auditDir,'final_recursive_read.txt',model_read(model,adcScope,'inf'));
    check=model_check(model,adcScope,'["unconnected_ports","unconnected_lines"]');
    write_artifact(auditDir,'connectivity.txt',check);
    assert(~contains(char(check),'status: error')&&isempty(regexp(char(check),'(?m)^\s*severity:\s*error\b','once')), ...
        'groupADC:connectivity','Candidate has connectivity errors.');
    save_system(model,modelFile,'SaveModelWorkspace',true);
    report=struct('status','candidate_grouped_expanded_graph_equal_pending_compile', ...
        'original_blocks',58,'original_edges',numel(edges),'virtual_groups',7, ...
        'original_input_endpoints_equal',true,'parameters_equal',true,'modelP_equal',true, ...
        'trigger_changed',false,'native_simulation_run',false);
    save(fullfile(auditDir,'completed_graph.mat'),'blocks','groups','edges','initialP','report','-v7.3');
    write_artifact(auditDir,'grouping_receipt.json',jsonencode(report));
    catch failure
        if ~strcmp(failure.identifier,'groupADC:partial')
            % Runtime assertions outside model_edit must also leave a checkpoint.
            try,write_artifact(auditDir,'runtime_failure_read.txt',model_read(model,adcScope,'0'));catch cause,failure=addCause(failure,cause);end
            try,write_artifact(auditDir,'runtime_failure_check.txt',model_check(model,adcScope,'["unconnected_ports","unconnected_lines"]'));catch cause,failure=addCause(failure,cause);end
            try,save_system(model,modelFile,'SaveModelWorkspace',true);catch cause,failure=addCause(failure,cause);end
        end
        rethrow(failure);
    end
end

function op=wire_if_missing(model,src,sp,dst,dp)
    op=[];a=get_param(resolve_id(model,src),'PortHandles');b=get_param(resolve_id(model,dst),'PortHandles');
    assert(numel(a.Outport)>=sp&&numel(b.Inport)>=dp,'groupADC:port','Missing actual port.');
    [existing,~]=source_of_input(b.Inport(dp));
    if existing>0
        assert(existing==a.Outport(sp),'groupADC:wireConflict','Existing candidate wire conflicts; not overwritten.');return;
    end
    op=struct('op','connect','target',sprintf('%s.y%d -> %s.u%d',src,sp,dst,dp));
end
function key=expanded_source(model,input,groups,blocks)
    [src,~]=source_of_input(input);assert(src>0,'groupADC:sourceMissing','Missing source.');
    sid=native_id(get_param(src,'Parent'));port=get_param(src,'PortNumber');
    for gi=1:numel(groups)
        if strcmp(sid,groups(gi).id)
            ph=get_param(resolve_id(model,groups(gi).output_ids{port}),'PortHandles');
            key=expanded_source(model,ph.Inport(1),groups,blocks);return;
        end
        for pi=1:numel(groups(gi).input_ids)
            if strcmp(sid,groups(gi).input_ids{pi})
                ph=get_param(resolve_id(model,groups(gi).id),'PortHandles');
                key=expanded_source(model,ph.Inport(pi),groups,blocks);return;
            end
        end
    end
    bi=find(strcmp({blocks.live_id},sid),1);assert(~isempty(bi),'groupADC:unexpectedSource','Unexpected computation.');
    key=endpoint(bi,port);
end
function id=find_child(model,parentID,name,view,optional)
    parent=resolve_id(model,parentID);paths=find_system(parent,'SearchDepth',1,'Type','Block','Name',name);
    paths=paths(~strcmp(paths,parent));
    if isempty(paths)&&optional,id='';return;end
    assert(numel(paths)==1,'groupADC:actualChild','Need one exact-name child %s.',name);
    id=native_id(paths{1});assert(has_id(view,id),'groupADC:actualID','Actual scope readback lacks %s.',id);
end
function path=resolve_id(model,id),path=Simulink.ID.getFullName([model ':' extractAfter(id,'blk_')]);end
function id=native_id(path),id=['blk_' char(extractAfter(Simulink.ID.getSID(path),':'))];end
function yes=has_id(view,id),yes=~isempty(regexp(char(view),['(?<![A-Za-z0-9_])' regexptranslate('escape',id) '(?![A-Za-z0-9_])'],'once'));end
function [src,line]=source_of_input(input)
    line=get_param(input,'Line');src=-1;if line<=0,return;end
    src=get_param(line,'SrcPortHandle');while src<=0,line=get_param(line,'LineParent');src=get_param(line,'SrcPortHandle');end
end
function key=endpoint(index,port),key=sprintf('b%d_p%d',index,port);end
function [index,port]=parse_endpoint(key),v=sscanf(key,'b%d_p%d');index=v(1);port=v(2);end
function v=read_scope(model,scope,auditDir,label)
    v=char(model_read(model,scope,'0'));write_artifact(auditDir,[label '_read.txt'],v);
    assert(~contains(v,'status: error'),'groupADC:read','model_read failed.');
end
function mutate(model,scope,ops,auditDir,label)
    if isempty(ops),return;end
    read_scope(model,scope,auditDir,[label '_pre']);write_artifact(auditDir,[label '_ops.json'],jsonencode(ops));
    v=model_edit(model,scope,jsonencode(ops),'full');write_artifact(auditDir,[label '_result.txt'],v);
    if contains(char(v),'status: error')||contains(char(v),'status: partial')
        failure=MException('groupADC:partial','Candidate partial retained in %s; main model untouched.',auditDir);
        try,write_artifact(auditDir,[label '_partial_read.txt'],model_read(model,scope,'0'));catch cause,failure=addCause(failure,cause);end
        try,write_artifact(auditDir,[label '_partial_check.txt'],model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));catch cause,failure=addCause(failure,cause);end
        try,save_system(model,get_param(model,'FileName'),'SaveModelWorkspace',true);catch cause,failure=addCause(failure,cause);end
        throw(failure);
    end
end
function write_artifact(auditDir,name,value)
    fid=fopen(fullfile(auditDir,name),'w','n','UTF-8');assert(fid>=0);c=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s',char(value));
end

function label=boundary_name(key,blocks,initialP)
    label=behavior_group_boundary(key,blocks,initialP);
end
