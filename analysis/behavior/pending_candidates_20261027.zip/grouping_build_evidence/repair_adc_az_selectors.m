function report=repair_adc_az_selectors(model,diagnosticsScope,originalGraphFile,auditDir)
%REPAIR_ADC_AZ_SELECTORS Repair only four known failed SarView AZ selectors.
% v1 2026-10-27. No block/wire creation, no other scopes or numerical changes.
% Each repair: Indices=1 -> target InputPortWidth -> final Indices -> remaining
% original parameters. Existing correctly configured targets are skipped.
% Original NumberOfDimensions/IndexMode/IndexOptions must already agree (the
% actual failed add_block had applied them before failing at final Indices).
    assert(~strcmp(model,'SarAdc')&&bdIsLoaded(model)&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
        'groupADC:selectorRepairCandidate','Use the stopped candidate copy only.');
    file=get_param(model,'FileName');assert(~contains(lower(strrep(file,'\','/')),'/current/'), ...
        'groupADC:selectorRepairCurrent','Candidate must remain outside current/.');
    if ~isfolder(auditDir),mkdir(auditDir);end
    original=load(originalGraphFile,'blocks','initialP');
    assert(isequaln(original.initialP,getVariable(get_param(model,'ModelWorkspace'),'P')), ...
        'groupADC:selectorRepairP','Candidate P differs from the original checkpoint.');
    names={'AzHalfSelect','AzReturnVoltage','AzRoutedCommand','AzServiceSelect'};
    view=char(model_read(model,diagnosticsScope,'0'));write(auditDir,'before_read.txt',view);
    parent=resolve(model,diagnosticsScope);ops={};rows=struct('name',{},'id',{},'width',{},'indices',{},'repair_needed',{});
    for targetIndex=1:4
        name=names{targetIndex};paths=find_system(parent,'SearchDepth',1,'Type','Block','Name',name);
        paths=paths(~strcmp(paths,parent));assert(numel(paths)==1,'groupADC:selectorRepairName','Need one exact-name target.');
        sid=Simulink.ID.getSID(paths{1});id=['blk_' char(extractAfter(sid,':'))];
        assert(has_id(view,id)&&strcmp(get_param(paths{1},'BlockType'),'Selector'), ...
            'groupADC:selectorRepairID','Target must be a Selector present in actual scope readback.');
        sourceIndex=find(strcmp({original.blocks.name},name),1);assert(~isempty(sourceIndex));
        params=original.blocks(sourceIndex).params;fields=fieldnames(params);same=true;
        for fieldIndex=1:numel(fields)
            same=same&&isequaln(get_param(paths{1},fields{fieldIndex}),params.(fields{fieldIndex}));
        end
        rows(end+1)=struct('name',name,'id',id,'width',params.InputPortWidth, ...
            'indices',params.Indices,'repair_needed',~same); %#ok<AGROW>
        if same,continue;end
        basis={'NumberOfDimensions','IndexMode','IndexOptions'};
        for fieldIndex=1:numel(basis)
            if isfield(params,basis{fieldIndex})
                assert(isequaln(get_param(paths{1},basis{fieldIndex}),params.(basis{fieldIndex})), ...
                    'groupADC:selectorRepairBasis','Unexpected prior selector mode; do not silently reconfigure another interface.');
            end
        end
        ops{end+1}=configure(id,struct('Indices','1')); %#ok<AGROW>
        ops{end+1}=configure(id,struct('InputPortWidth',params.InputPortWidth)); %#ok<AGROW>
        ops{end+1}=configure(id,struct('Indices',params.Indices)); %#ok<AGROW>
        rest=rmfield(params,intersect(fieldnames(params), ...
            {'NumberOfDimensions';'IndexMode';'IndexOptions';'Indices';'InputPortWidth'}));
        if ~isempty(fieldnames(rest)),ops{end+1}=configure(id,rest);end %#ok<AGROW>
    end
    write(auditDir,'repair_ops.json',jsonencode(ops));
    if ~isempty(ops)
        result=model_edit(model,diagnosticsScope,jsonencode(ops),'incremental');write(auditDir,'repair_result.txt',result);
        if contains(char(result),'status: error')||contains(char(result),'status: partial')
            failure=MException('groupADC:selectorRepairPartial','Selector-only repair partial; audit %s.',auditDir);
            try,write(auditDir,'partial_read.txt',model_read(model,diagnosticsScope,'0'));catch cause,failure=addCause(failure,cause);end
            try,write(auditDir,'partial_check.txt',model_check(model,diagnosticsScope,'["unconnected_ports","unconnected_lines"]'));catch cause,failure=addCause(failure,cause);end
            try,save_system(model,file,'SaveModelWorkspace',true);catch cause,failure=addCause(failure,cause);end
            throw(failure);
        end
    end
    write(auditDir,'after_read.txt',model_read(model,diagnosticsScope,'0'));
    for targetIndex=1:4
        sourceIndex=find(strcmp({original.blocks.name},names{targetIndex}),1);params=original.blocks(sourceIndex).params;
        path=resolve(model,rows(targetIndex).id);fields=fieldnames(params);
        for fieldIndex=1:numel(fields)
            assert(isequaln(get_param(path,fields{fieldIndex}),params.(fields{fieldIndex})), ...
                'groupADC:selectorRepairVerify','Selector does not exactly match checkpoint after repair.');
        end
    end
    save_system(model,file,'SaveModelWorkspace',true);
    report=struct('status','four_known_selectors_match_checkpoint','targets',rows, ...
        'blocks_created',0,'wires_changed',0,'other_groups_touched',false,'simulation_run',false);
    write(auditDir,'repair_receipt.json',jsonencode(report));
end
function op=configure(id,params),op=struct('op','configure','target',id,'params',params);end
function path=resolve(model,id),path=Simulink.ID.getFullName([model ':' extractAfter(id,'blk_')]);end
function yes=has_id(view,id),yes=~isempty(regexp(char(view),['(?<![A-Za-z0-9_])' regexptranslate('escape',id) '(?![A-Za-z0-9_])'],'once'));end
function write(auditDir,name,value)
    fid=fopen(fullfile(auditDir,name),'w','n','UTF-8');assert(fid>=0);c=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s',char(value));
end
