function behavior_export_current()
% Export the current saved diagram only; no simulation or model mutation.
    root='D:/Academic/Projects/sar20m1/SAR20';cd(root);addpath(root,'-begin');clear SAR20
    SAR20('open');m='SarAdc';file=get_param(m,'FileName');
    ws=get_param(m,'ModelWorkspace');P=getVariable(ws,'P');
    folder=fullfile(root,'analysis','behavior','current_figures');if ~isfolder(folder),mkdir(folder);end
    tools=fullfile(root,'dependencies','toolkit','tools');
    addpath(fullfile(tools,'common'),fullfile(tools,'model_read'));
    before=hash_file(file);view=model_read(m,'root','0');
    step=lookup(view,'EventStep');stepPath=Simulink.ID.getFullName([m ':' extractAfter(step,'blk_')]);
    inside=model_read(m,step,'0');
    print(['-s' m],'-dpng','-r160',fullfile(folder,'Top.png'));
    print(['-s' stepPath],'-dpng','-r160',fullfile(folder,'System.png'));
    scopes=struct('file',{},'path',{});
    for pair={'Adc','ADC';'Fpga','FPGA'}.'
        id=lookup(inside,pair{1});block=Simulink.ID.getFullName([m ':' extractAfter(id,'blk_')]);
        print(['-s' block],'-dpng','-r160',fullfile(folder,[pair{2} '.png']));
        scopes(end+1)=struct('file',[pair{2} '.png'],'path',block); %#ok<AGROW>
        if strcmp(pair{1},'Adc')
            children=find_system(block,'SearchDepth',1,'BlockType','SubSystem');
            children=children(~strcmp(children,block));
            for k=1:numel(children)
                name=get_param(children{k},'Name');
                print(['-s' children{k}],'-dpng','-r160',fullfile(folder,[name '.png']));
                scopes(end+1)=struct('file',[name '.png'],'path',children{k}); %#ok<AGROW>
            end
        end
    end
    assert(strcmp(before,hash_file(file)),'behavior:exportChangedFile','Export changed the saved model.');
    metadata=struct('model_file',file,'model_sha256',before,'schema',P.schema, ...
        'export_utc',char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z''')), ...
        'saved_records',P.N,'input',P.input,'seed',P.seed,'A0',P.backend.ra.A0, ...
        'UGB_hz',P.backend.ra.UGB_hz,'ni',P.ni,'calibration','off', ...
        'exported_scopes',scopes, ...
        'scope','Actual saved connections and applied configuration. Virtual calculation stages share three state owners. LVDS receiver not present.');
    f=fopen(fullfile(folder,'metadata.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(metadata));fclose(f);
end
function id=lookup(view,name)
    expr=['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'];
    token=regexp(char(view),expr,'tokens','once');assert(~isempty(token),'behavior:readID','Missing %s.',name);id=token{1};
end
function value=hash_file(file)
    f=fopen(file,'rb');c=onCleanup(@()fclose(f)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');md.update(fread(f,inf,'*uint8'));
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
