function group_style_job(root,stage,outdir)
% Presentation only on the task copy: role colours, readable fonts, no thumbnail clutter.
    cd(root);addpath(root,'-begin');SAR20('setup');oldPath=path;
    cleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit','tools');
    for p={'common','common/autolayout','model_read','model_edit','model_check'},addpath(fullfile(toolkit,p{1}));end
    gate=library.settingsLookup();assert(~gate.found||gate.gatePass);
    if gate.found,fileread(gate.kgIndexPath);end
    m='SarView';assert(bdIsLoaded(m)&&strcmp(get_param(m,'SimulationStatus'),'stopped')&&strcmp(get_param(m,'Dirty'),'off'));
    file=get_param(m,'FileName');copyfile(file,fullfile(outdir,'before_style.slx'));
    ws=get_param(m,'ModelWorkspace');P=getVariable(ws,'P');
    rootView=model_read(m,'root','0');step=lookup(rootView,'EventStep');
    adc=lookup(model_read(m,step,'0'),'Adc');view=model_read(m,adc,'0');
    names={'SampleRaAdvance','DacCtFeedback','Sar1TrialRaCt','ResidueCtCompare', ...
        'SarDecisionTracking','ChargeReturnRaReset','Diagnostics','SampleCharge','RaCtState','SarState'};
    colors={'[0.89 0.95 1]','[0.89 0.95 1]','[0.89 0.95 1]','[1 0.94 0.83]', ...
        '[0.89 0.97 0.9]','[0.89 0.95 1]','[0.94 0.94 0.94]','[1 0.98 0.85]','[1 0.98 0.85]','[1 0.98 0.85]'};
    ops={};
    for k=1:numel(names)
        id=lookup(view,names{k});blockPath=Simulink.ID.getFullName([m ':' extractAfter(id,'blk_')]);
        available=get_param(blockPath,'ObjectParameters');params=struct('FontSize','11','ForegroundColor','black','BackgroundColor',colors{k});
        if isfield(available,'ContentPreviewEnabled'),params.ContentPreviewEnabled='off';end
        ops{end+1}=struct('op','configure','target',id,'params',params); %#ok<AGROW>
    end
    result=model_edit(m,adc,jsonencode(ops),'full');write('edit.txt',result);
    write('read.txt',model_read(m,adc,'inf'));write('check.txt',model_check(m,adc,'["unconnected_ports","unconnected_lines"]'));
    save_system(m,file,'SaveModelWorkspace',true);
    assert(~contains(result,'status: partial')&&~contains(result,'status: error'),'group:style','Inspect saved style partial.');
    behavior_applied_note('update',m);save_system(m,file,'SaveModelWorkspace',true);
    assert(isequaln(P,getVariable(ws,'P')),'group:styleP','Style changed configuration.');
    adcPath=Simulink.ID.getFullName([m ':' extractAfter(adc,'blk_')]);
    print(['-s' adcPath],'-dpng','-r160',fullfile(outdir,'ADC.png'));print(['-s' m],'-dpng','-r160',fullfile(outdir,'Top.png'));
    write('receipt.json',jsonencode(struct('status','styled_candidate_ready_for_review','model_file',file,'P_unchanged',true)));
    function write(name,value)
        f=fopen(fullfile(outdir,name),'w','n','UTF-8');c=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s',char(value));
    end
end
function id=lookup(view,name)
    token=regexp(char(view),['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'],'tokens','once');
    assert(~isempty(token),'group:read','Missing %s.',name);id=token{1};
end
