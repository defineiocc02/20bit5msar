function final_sample_job(root,stage,outdir)
% One fresh grouped-model debugging example, then leave the sole entry ready.
    cd(root);addpath(root,'-begin');SAR20('setup');
    reference=fullfile(root,'runs','behavior_16ec06a2-dc6c-457b-8983-ad6746090eb7');
    saved=load(fullfile(reference,'parameters.mat'),'P');SAR20('apply',saved.P);
    run=SAR20('run');a=load(fullfile(reference,'simout.mat'),'simout');b=load(fullfile(run.run_path,'simout.mat'),'simout');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
    for k=1:numel(names)
        x=a.simout.get(names{k});y=b.simout.get(names{k});
        assert(isequal(x.Time,y.Time)&&isequal(size(x.Data),size(y.Data))&& ...
            isequal(typecast(x.Data(:),'uint64'),typecast(y.Data(:),'uint64')),'final:parity','Stress log differs: %s',names{k});
    end
    sample4=SAR20('sample',4,run.run_path);sample5=SAR20('sample',5,run.run_path);
    restored=SAR20('apply');behavior_export_current();audit=audit_behavior_runtime(root,8,'off');
    report=struct('status','current_grouped_debug_example_and_entry_ready','run',run, ...
        'sample4',sample4,'sample5',sample5,'all_12_logs_bit_exact',true,'restored',restored, ...
        'audit',audit,'pid',feature('getpid'),'model_status',get_param('SarAdc','SimulationStatus'), ...
        'candidate_model_loaded',bdIsLoaded('SarView'));
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    f=fopen(fullfile(root,'state','SESSION_READY.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    zip(fullfile(outdir,'current_delivery.zip'),{'SAR20.m','current','config','state/applied_config.json', ...
        'state/SESSION_READY.json','analysis/behavior/current_figures'},root);
end
