function entry_note_job(root,stage,outdir)
% Install the single explicit-config API and live applied-configuration labels.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    model='SarAdc';file=fullfile(root,'current','models','SarAdc.slx');open_system(file);
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped'));
    if strcmp(get_param(model,'Dirty'),'on')
        ws=get_param(model,'ModelWorkspace');currentP=getVariable(ws,'P');
        known=load(fullfile(root,'runs','behavior_e1abeddc-7ddd-4440-ab4c-3a56e1deb55c','parameters.mat'),'P');
        assert(isequaln(currentP,known.P),'entry:dirty','Refuse unrelated unsaved parameter changes.');
        save_system(model,file,'SaveModelWorkspace',true);
    end
    zip(fullfile(outdir,'before_entry.zip'),{'SAR20.m','current','config'},root);
    transfer={'entry/SAR20.m','SAR20.m'; ...
        'entry/behavior_applied_note.m','current/src/model/behavior_applied_note.m'; ...
        'entry/behavior_backend_stage.m','current/src/physics/behavior_backend_stage.m'; ...
        'debug/behavior_sample_plot.m','current/src/analysis/behavior_sample_plot.m'};
    for k=1:size(transfer,1)
        assert(isfile(fullfile(stage,transfer{k,1})),'entry:staging','Missing staged file.');
        copyfile(fullfile(stage,transfer{k,1}),fullfile(root,transfer{k,2}));
        [~,name]=fileparts(transfer{k,2});eval(['clear ' name]);
    end
    % Remove only this project's SDK paths to verify cold apply is self-contained.
    sdk=strrep(lower(fullfile(root,'dependencies','toolkit','tools')),'\','/');
    oldParts=strsplit(path,pathsep);
    for k=1:numel(oldParts)
        item=oldParts{k};n=strrep(lower(item),'\','/');
        if strcmp(n,sdk)||startsWith(n,[sdk '/']),rmpath(item);end
    end
    clear model_read model_edit model_check;
    SAR20('setup');ws=get_param(model,'ModelWorkspace');P=getVariable(ws,'P');
    applied=SAR20('apply',P);assert(strcmp(applied.configuration_source,'explicit'));
    assert(isequaln(P,getVariable(ws,'P')),'entry:parameters','Explicit apply changed the prepared baseline P.');
    baseline=SAR20('run');compare(fullfile(root,'runs','behavior_e1abeddc-7ddd-4440-ab4c-3a56e1deb55c'),baseline.run_path);
    ref=fullfile(root,'runs','behavior_bd6a67ce-47ea-4e4d-94e7-83115f6605b4');
    loaded=load(fullfile(ref,'parameters.mat'),'P');SAR20('apply',loaded.P);
    thermal=SAR20('run');compare(ref,thermal.run_path);
    sample=SAR20('sample',5,fullfile(root,'runs','behavior_16ec06a2-dc6c-457b-8983-ad6746090eb7'));
    restored=SAR20('apply');assert(strcmp(restored.configuration_source,'factory'));
    behavior_export_current();audit=audit_behavior_runtime(root,8,'off');
    report=struct('status','explicit_apply_and_current_labels_actual_bit_exact', ...
        'cold_apply',applied,'off',baseline,'thermal_az',thermal,'sample',sample, ...
        'factory_restored',restored,'runtime_audit',audit,'numerical_changes',false);
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    zip(fullfile(outdir,'current_delivery.zip'),{'SAR20.m','current','config','state/applied_config.json', ...
        'analysis/behavior/current_figures'},root);
end
function compare(a,b)
    a=load(fullfile(a,'simout.mat'),'simout');b=load(fullfile(b,'simout.mat'),'simout');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
    for k=1:numel(names)
        x=a.simout.get(names{k});y=b.simout.get(names{k});
        assert(isequal(x.Time,y.Time)&&isequal(size(x.Data),size(y.Data))&& ...
            isequal(typecast(x.Data(:),'uint64'),typecast(y.Data(:),'uint64')), ...
            'entry:bitEquality','Display/entry change altered %s.',names{k});
    end
end
