function az_close_job(root,stage,outdir)
% Finish only outstanding live binding/profile/native-kTC checks after export.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    audit=audit_behavior_runtime(root,8,'off');
    f=fopen(fullfile(outdir,'runtime_audit.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(audit));fclose(f);
    profileReport=profile_behavior_n8(root,fullfile(outdir,'profile')); %#ok<NASGU>
    addpath(fullfile(stage,'ktc'));SAR20('setup');
    privateOut=fullfile(stage,'ktc',['native_' char(java.util.UUID.randomUUID())]);
    ktc=candidate_native_test(root,privateOut); %#ok<NASGU>
    copyfile(privateOut,fullfile(outdir,'ktc_native'));rmpath(fullfile(stage,'ktc'));
    SAR20('setup');
    zip(fullfile(outdir,'current_az.zip'),{'SAR20.m','current','config','analysis/behavior/current_figures'},root);
end
