"""Submit one owned MATLAB job to the already running COM instance.
Host orchestration only; all ADC calculations run in MATLAB/Simulink.
"""
from pathlib import Path
import ast, base64, datetime, json, re, subprocess, sys, zipfile

stage = Path('/tmp/sar20_az')
remote = 'D:/Temp/SAR20Az'
root = 'D:/Academic/Projects/sar20m1/SAR20'
entry_name = sys.argv[1]
assert re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', entry_name)
host = stage / 'host'
host.mkdir(exist_ok=True)

def ps(code):
    encoded = base64.b64encode(code.encode('utf-16-le')).decode()
    result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',
        'windows-codex','powershell -NoProfile -EncodedCommand '+encoded],
        capture_output=True, timeout=60)
    (host/'ssh_stderr.txt').write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')+'\n'+result.stdout.decode(errors='replace'))
    return result.stdout.decode('utf-8-sig',errors='replace').strip()

def scp(source,dest):
    subprocess.run(['scp','-q','-o','BatchMode=yes',str(source),'windows-codex:'+dest],check=True,timeout=60)

print(ps("$ErrorActionPreference='Stop'; $p=Get-Process MATLAB; if(@($p).Count -ne 1 -or $p.Id -ne 25440){throw 'Unexpected MATLAB'}; $t=Get-ScheduledTask -TaskName SAR20_MatlabControl; if($t.State -eq 'Running'){throw 'Existing task running'}; @{pid=$p.Id;task=$t.State.ToString()}|ConvertTo-Json -Compress"))
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
job = root+'/runs/az_probe_'+stamp
archive = host/('candidate_'+stamp+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(stage.rglob('*')):
        if f.is_file() and f.suffix in ('.m','.json','.mat') and 'host' not in f.relative_to(stage).parts:
            z.write(f,f.relative_to(stage))
print(ps("$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force -Path '"+remote+"'|Out-Null; New-Item -ItemType Directory -Path '"+job+"'|Out-Null"))
scp(archive,job+'/candidate.zip')
print(ps("$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath '"+job+"/candidate.zip' -DestinationPath '"+remote+"' -Force"))
entry = host/'az_job.m'
entry.write_text("addpath('"+remote+"/jobs','-begin');\n"+entry_name+"('"+root+"','"+remote+"','"+job+"');\n")
ns={'re':re,'Path':Path}
parsed=ast.parse(Path('/tmp/sar20_behavior_submit_helper.py').read_text())
for n in parsed.body:
    if isinstance(n,ast.FunctionDef) and n.name in ('ps_quote','make_controller'):
        exec(compile(ast.Module(body=[n],type_ignores=[]),'<controller>','exec'),ns)
controller=host/'controller.ps1'
controller.write_text(ns['make_controller'](job,25440,root,'az_job.m'))
scp(entry,job+'/az_job.m');scp(controller,job+'/controller.ps1')
print(ps("$ErrorActionPreference='Stop'; $name='SAR20_MatlabControl'; if((Get-ScheduledTask -TaskName $name).State -eq 'Running'){throw 'Task became active'}; $a=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \""+job+"/controller.ps1\"' -WorkingDirectory '"+root+"'; $pr=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\\Administrator') -LogonType Interactive -RunLevel Limited; $s=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries; Register-ScheduledTask -TaskName $name -Action $a -Principal $pr -Settings $s -Force|Out-Null; Start-ScheduledTask -TaskName $name; @{job='"+job+"';status='submitted_not_passed'}|ConvertTo-Json -Compress"))
(host/'last_submission.json').write_text(json.dumps({'job':job,'stage':remote,'entry':entry_name},indent=2))
