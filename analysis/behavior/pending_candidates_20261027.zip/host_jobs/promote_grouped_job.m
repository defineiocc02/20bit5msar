function promote_grouped_job(root,stage,outdir)
% Promote the actual bit-verified grouped copy, then run this main SLX again.
    cd(root);addpath(root,'-begin');SAR20('setup');
    assert(bdIsLoaded('SarAdc')&&bdIsLoaded('SarView'));
    for m={'SarAdc','SarView'}
        assert(strcmp(get_param(m{1},'SimulationStatus'),'stopped')&&strcmp(get_param(m{1},'Dirty'),'off'));
    end
    zip(fullfile(outdir,'before_promotion.zip'),{'SAR20.m','current','config'},root);
    mainFile=fullfile(root,'current','models','SarAdc.slx');
    close_system('SarAdc',0);
    save_system('SarView',mainFile,'SaveModelWorkspace',true);
    if bdIsLoaded('SarView'),close_system('SarView',0);end
    % Only reviewed comment lines change in these nine runtime files.
    files=dir(fullfile(stage,'comment_refresh','current','src','**','*.m'));
    prefix=fullfile(stage,'comment_refresh');
    for k=1:numel(files)
        input=fullfile(files(k).folder,files(k).name);
        relative=char(extractAfter(string(input),strlength(string(prefix))+1));
        copyfile(input,fullfile(root,relative));[~,name]=fileparts(input);eval(['clear ' name]);
    end
    rehash;open_system(mainFile);SAR20('apply');SAR20('check');
    short=SAR20('run');
    compare(fullfile(root,'runs','behavior_e1abeddc-7ddd-4440-ab4c-3a56e1deb55c'),short.run_path);
    % Bind the dynamic result to this actual final grouped main SLX/source.
    prior=fullfile(root,'runs','behavior_7832aa94-7571-4b24-beb3-c4afdd032fae');
    p=load(fullfile(prior,'parameters.mat'),'P');SAR20('apply',p.P);
    dynamic=SAR20('run');compare(prior,dynamic.run_path);
    metrics=load(fullfile(dynamic.run_path,'spectrum.mat'),'metrics');m=metrics.metrics;
    fig=figure('Visible','off','Color','white','Position',[100 100 1100 650]);
    closer=onCleanup(@()close(fig)); %#ok<NASGU>
    plot(m.frequency_hz/1e6,10*log10(max(m.power_v2,realmin)/max(m.power_v2)),'LineWidth',1);grid on;
    xlabel('Frequency (MHz)');ylabel('Power (dBc)');ylim([-160 5]);
    title({sprintf('Current grouped SarAdc | actual N256 | SNDR %.3f dB',m.sndr_db), ...
        'Sampling kT/C at 298.15 K + paired AZ/chop; calibration OFF', ...
        sprintf('SLX %s | %s',dynamic.model_sha256(1:12),dynamic.finished_utc)},'Interpreter','none','FontSize',11);
    exportgraphics(fig,fullfile(dynamic.run_path,'Spectrum.png'),'Resolution',160);savefig(fig,fullfile(dynamic.run_path,'Spectrum.fig'));
    sample=SAR20('sample',5,dynamic.run_path);
    restored=SAR20('apply');behavior_export_current();audit=audit_behavior_runtime(root,8,'off');
    report=struct('status','grouped_main_actual_N8_N256_bit_exact', ...
        'short',short,'dynamic',dynamic,'prior_dynamic_reference',prior, ...
        'all_12_logs_bit_exact',true,'sample',sample,'factory_restored',restored,'runtime_audit',audit);
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    zip(fullfile(outdir,'current_delivery.zip'),{'SAR20.m','current','config','state/applied_config.json', ...
        'analysis/behavior/current_figures'},root);
end
function compare(a,b)
    a=load(fullfile(a,'simout.mat'),'simout');b=load(fullfile(b,'simout.mat'),'simout');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
    for k=1:numel(names)
        x=a.simout.get(names{k});y=b.simout.get(names{k});
        assert(isequal(x.Time,y.Time)&&isequal(size(x.Data),size(y.Data))&& ...
            isequal(typecast(x.Data(:),'uint64'),typecast(y.Data(:),'uint64')), ...
            'promotion:bitEquality','Current grouped model changed %s.',names{k});
    end
end
