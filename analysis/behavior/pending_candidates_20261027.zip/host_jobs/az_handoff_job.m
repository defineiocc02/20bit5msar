function az_handoff_job(root,stage,outdir)
% Apply observation-label fixes, export actual diagrams, and profile native N8.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    assert(bdIsLoaded('SarAdc')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off'));
    plotFile=fullfile(root,'current','src','analysis','behavior_sample_plot.m');
    copyfile(plotFile,fullfile(outdir,'before_sample_plot.m'));
    copyfile(fullfile(stage,'debug','behavior_sample_plot.m'),plotFile);clear behavior_sample_plot;
    actual=fullfile(root,'runs','behavior_16ec06a2-dc6c-457b-8983-ad6746090eb7');
    sample4=SAR20('sample',4,actual);sample5=SAR20('sample',5,actual);
    save(fullfile(outdir,'sample_receipts.mat'),'sample4','sample5','-v7');
    f=fopen(fullfile(outdir,'sample_receipts.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(struct('sample4',sample4,'sample5',sample5)));fclose(f);
    behavior_export_current();
    addpath(fullfile(stage,'digital'));SAR20('setup');
    audit=audit_behavior_runtime(root,8,'off');
    f=fopen(fullfile(outdir,'runtime_audit.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(audit));fclose(f);
    profileReport=profile_behavior_n8(root,fullfile(outdir,'profile')); %#ok<NASGU>
    rmpath(fullfile(stage,'digital'));
    addpath(fullfile(stage,'ktc'));SAR20('setup');
    privateOut=fullfile(stage,'ktc',['native_' char(java.util.UUID.randomUUID())]);
    ktc=candidate_native_test(root,privateOut); %#ok<NASGU>
    copyfile(privateOut,fullfile(outdir,'ktc_native'));
    rmpath(fullfile(stage,'ktc'));
    SAR20('setup');
    zip(fullfile(outdir,'current_az.zip'),{'SAR20.m','current','config','analysis/behavior/current_figures'},root);
end
