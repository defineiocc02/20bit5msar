function ktc_integrate_job(root,stage,outdir)
% Integrate physical capture charge noise; keep the sole event-level model.
    cd(root);addpath(root,'-begin');SAR20('setup');model='SarAdc';
    file=fullfile(root,'current','models','SarAdc.slx');open_system(file);
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped')&&strcmp(get_param(model,'Dirty'),'off'));
    items={'ktc/behavior_frontend_init.m','current/src/frontend/behavior_frontend_init.m'; ...
        'ktc/behavior_frontend_step.m','current/src/frontend/behavior_frontend_step.m'; ...
        'ktc_rootfiles/adc_parameters.m','config/adc_parameters.m'; ...
        'ktc_rootfiles/behavior_prepare_configuration.m','current/src/model/behavior_prepare_configuration.m'};
    for k=1:size(items,1),assert(isfile(fullfile(stage,items{k,1})),'ktc:staging','Missing staged source.');end
    zip(fullfile(outdir,'before_ktc.zip'),{'SAR20.m','current','config'},root);
    close_system(model,0);
    for k=1:size(items,1)
        copyfile(fullfile(stage,items{k,1}),fullfile(root,items{k,2}));
        [~,name]=fileparts(items{k,2});eval(['clear ' name]);
    end
    rehash;open_system(file);SAR20('apply');SAR20('check');off=SAR20('run');
    compare(fullfile(root,'runs','behavior_7640c05b-f867-426e-9e5e-e9c3b12043b8'),off.run_path);
    P=adc_parameters();P.front.ktc_enabled=true;P=behavior_prepare_configuration(P);
    assert(P.ni.sample_ktc&&P.front.temperature_K>0);
    ws=get_param(model,'ModelWorkspace');assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
    save_system(model,file,'SaveModelWorkspace',true);
    on=SAR20('run');repeat=SAR20('run');compare(on.run_path,repeat.run_path);
    assert(~isequal(off.code20,on.code20),'ktc:noEffect','Physical kTC did not affect any output code in this actual record.');
    report=struct('status','physical_ktc_integrated_off_and_repeat_bit_exact', ...
        'off',off,'on',on,'repeat',repeat,'temperature_K',P.front.temperature_K, ...
        'ktc_seed',P.front.ktc_seed,'sample_settling_tau_s',P.front.tau_sample_s, ...
        'noise_model','independent differential 2kT/C per physical slice at aperture; same retained charge', ...
        'finite_RC_joint_mode','unsupported_rejected','full_statistics_scan','not_completed');
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    SAR20('apply');
end
function compare(a,b)
    a=load(fullfile(a,'simout.mat'),'simout');b=load(fullfile(b,'simout.mat'),'simout');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
    for k=1:numel(names)
        x=a.simout.get(names{k});y=b.simout.get(names{k});
        assert(isequal(x.Time,y.Time)&&isequal(size(x.Data),size(y.Data))&& ...
            isequal(typecast(x.Data(:),'uint64'),typecast(y.Data(:),'uint64')), ...
            'ktc:bitEquality','Actual %s failed exact repeat/off equivalence.',names{k});
    end
end
