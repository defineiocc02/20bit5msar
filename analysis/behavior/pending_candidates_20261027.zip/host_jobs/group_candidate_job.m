function group_candidate_job(root,stage,outdir)
% Only the task-owned SarView copy is regrouped. Current SarAdc stays intact.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit');
    for part={'common','common/autolayout','model_read','model_edit','model_check'}
        addpath(fullfile(toolkit,'tools',part{1}));
    end
    gate=library.settingsLookup();assert(~gate.found||gate.gatePass,'group:library','Library knowledge is not ready.');
    if gate.found,fileread(gate.kgIndexPath);end
    assert(bdIsLoaded('SarAdc')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off'));
    zip(fullfile(outdir,'current_before_group.zip'),{'SAR20.m','current','config'},root);
    if bdIsLoaded('SarView')
        file=get_param('SarView','FileName');
        assert(contains(strrep(file,'\','/'),'az_probe_20261026T193648Z/SarView.slx')&& ...
            strcmp(get_param('SarView','SimulationStatus'),'stopped')&&strcmp(get_param('SarView','Dirty'),'off'), ...
            'group:name','Only resume the known unmodified task copy.');
    else
        source=fullfile(root,'current','models','SarAdc.slx');file=fullfile(outdir,'SarView.slx');copyfile(source,file);
        open_system(file);
    end
    model='SarView';
    view=model_read(model,'root','0');step=lookup(view,'EventStep');
    inside=model_read(model,step,'0');adc=lookup(inside,'Adc');
    addpath(fullfile(stage,'grouping'));
    structure=rebuild_adc_virtual_groups(model,adc,fullfile(stage,'grouping','adc_grouping.json'),fullfile(outdir,'structure'));
    set_param(model,'SimulationCommand','update');
    ws=get_param(model,'ModelWorkspace');Pdefault=getVariable(ws,'P');
    off=compareCase('off',fullfile(root,'runs','behavior_e1abeddc-7ddd-4440-ab4c-3a56e1deb55c'));
    thermal=compareCase('thermal_az',fullfile(root,'runs','behavior_bd6a67ce-47ea-4e4d-94e7-83115f6605b4'));
    assignin(ws,'P',Pdefault);assignin(ws,'DecodeP',Pdefault.digital);
    save_system(model,file,'SaveModelWorkspace',true);
    figures=fullfile(outdir,'figures');mkdir(figures);
    print(['-s' model],'-dpng',fullfile(figures,'Top.png'));
    adcPath=Simulink.ID.getFullName([model ':' extractAfter(adc,'blk_')]);
    print(['-s' adcPath],'-dpng',fullfile(figures,'ADC.png'));
    children=find_system(adcPath,'SearchDepth',1,'BlockType','SubSystem');
    for k=1:numel(children)
        print(['-s' children{k}],'-dpng',fullfile(figures,[get_param(children{k},'Name') '.png']));
    end
    report=struct('status','grouped_candidate_two_configs_bit_exact_pending_visual_review', ...
        'model_file',file,'structure',structure,'off',off,'thermal_az',thermal, ...
        'current_model_modified',false,'default_P_restored',true);
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    function r=compareCase(label,reference)
        loaded=load(fullfile(reference,'parameters.mat'),'P');P=loaded.P;
        assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);save_system(model,file,'SaveModelWorkspace',true);
        folder=fullfile(outdir,label);mkdir(folder);copyfile(file,fullfile(folder,'SarView.slx'));
        rngBefore=rng;start=tic;simout=sim(model,'ReturnWorkspaceOutputs','on','CaptureErrors','on');elapsed=toc(start);
        save(fullfile(folder,'simout.mat'),'simout','P','-v7.3');
        assert(isempty(simout.ErrorMessage),'group:simulation','%s',simout.ErrorMessage);
        original=load(fullfile(reference,'simout.mat'),'simout');
        names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
            'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
        for j=1:numel(names)
            a=original.simout.get(names{j});b=simout.get(names{j});
            assert(isequal(a.Time,b.Time)&&isequal(size(a.Data),size(b.Data))&& ...
                isequal(typecast(a.Data(:),'uint64'),typecast(b.Data(:),'uint64')), ...
                'group:bitEquality','Grouped candidate differs in %s.',names{j});
        end
        assert(isequal(rngBefore,rng),'group:rng','Grouping advanced global RNG.');
        r=struct('reference',reference,'elapsed_s',elapsed,'all_12_logs_bit_exact',true,'global_rng_unchanged',true);
    end
end
function id=lookup(view,name)
    token=regexp(char(view),['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'],'tokens','once');
    assert(~isempty(token),'group:read','Missing actual block %s.',name);id=token{1};
end
