function az_resume_job(root,stage,outdir)
% Resume the saved AZ interface integration; do not redeploy/rebuild the model.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit');
    for part={'common','common/autolayout','model_read','model_edit','model_check'}
        addpath(fullfile(toolkit,'tools',part{1}));
    end
    gate=library.settingsLookup();assert(~gate.found||gate.gatePass,'az:library','Library knowledge is not ready.');
    if gate.found,fileread(gate.kgIndexPath);end
    file=fullfile(root,'current','models','SarAdc.slx');model='SarAdc';
    open_system(file);
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped'),'az:busy','Model is active.');
    % An actual update evaluates new Level-2 setup interfaces saved in old SLX.
    % Unconnected fourth ports are expected until the bounded SATK patch below.
    try
        set_param(model,'SimulationCommand','update');
        write('interface_update.txt','update returned without error');
    catch cause
        write('interface_update.txt',getReport(cause,'extended','hyperlinks','off'));
    end
    save_system(model,file,'SaveModelWorkspace',true);
    top=model_read(model,'root','0');step=lookup(top,'EventStep');
    inside=model_read(model,step,'0');adc=lookup(inside,'Adc');
    write('interface_read.txt',model_read(model,adc,'0'));
    addpath(fullfile(stage,'routing'),fullfile(stage,'digital'),fullfile(stage,'debug'));
    SAR20('setup');
    adcReceipt=integrate_adc_az(model,adc,fullfile(outdir,'adc'));
    decodeReceipt=integrate_decode_az(file,toolkit,fullfile(outdir,'fpga'));
    debugReceipt=integrate_az_debug(model,adc,fullfile(outdir,'debug'));
    rmpath(fullfile(stage,'routing'),fullfile(stage,'digital'),fullfile(stage,'debug'));
    compile=SAR20('check');baseline=SAR20('run');
    reference=fullfile(root,'runs','behavior_a7b38ecb-7991-4e88-a5ec-3177b799c8c9');
    previous=load(fullfile(reference,'simout.mat'),'simout');
    now=load(fullfile(baseline.run_path,'simout.mat'),'simout');
    logs={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log'};
    for k=1:numel(logs)
        a=previous.simout.get(logs{k});b=now.simout.get(logs{k});
        assert(isequal(a.Time,b.Time)&&isequal(size(a.Data),size(b.Data))&& ...
            isequal(typecast(a.Data(:),'uint64'),typecast(b.Data(:),'uint64')), ...
            'az:offBitEquality','Off baseline differs in actual log %s.',logs{k});
    end
    receipt=struct('status','AZ_integrated_compiled_off_N8_bit_exact', ...
        'adc',adcReceipt,'digital',decodeReceipt,'debug',debugReceipt,'compile',compile, ...
        'baseline',baseline,'baseline_reference',reference,'bit_exact_logs',{logs});
    save(fullfile(outdir,'receipt.mat'),'receipt','-v7.3');write('receipt.json',jsonencode(receipt));
    SAR20('setup');
    function write(name,value)
        f=fopen(fullfile(outdir,name),'w','n','UTF-8');c=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s',char(value));
    end
end
function id=lookup(view,name)
    token=regexp(char(view),['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'],'tokens','once');
    assert(~isempty(token),'az:modelRead','Missing actual block %s.',name);id=token{1};
end
