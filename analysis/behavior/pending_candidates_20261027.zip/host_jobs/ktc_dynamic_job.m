function ktc_dynamic_job(root,stage,outdir)
% Actual coherent N256 with physical sampling noise and paired AZ/chopping.
% Same-event N8 precedes N256. Both results retain exact SLX/source/P/raw codes.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()restore(root,saved)); %#ok<NASGU>
    model='SarAdc';file=fullfile(root,'current','models','SarAdc.slx');open_system(file);
    P=adc_parameters();P.front.ktc_enabled=true;
    P.backend.az.mode='hold_chop';P.backend.ni.az=true;P.digital.az_mode='hold_chop';
    P.backend.ra.vos_input_v=1e-3;
    % Factory write tau=1 ns; no leakage/random AZ noise. Offset is a declared
    % 1 mV input-referred stress, not a fitted target or injected digital code.
    P=behavior_prepare_configuration(P);setcase(P);short=SAR20('run');
    shortSelected=load(fullfile(short.run_path,'selected.mat'),'selected');
    Pshort=P;oldPlan=P.front.plan;oldC=P.front.C_f;
    P.N=256;P.front.plan_rows=max(P.front.plan_rows,P.N+P.first_id+4);P.front.plan=[];
    P=behavior_prepare_configuration(P);
    assert(isequal(P.front.plan(1:size(oldPlan,1),:),oldPlan)&& ...
        isequal(P.front.C_f,oldC)&&isequal(P.input,Pshort.input)&& ...
        P.front.ktc_seed==Pshort.front.ktc_seed&&P.epoch==Pshort.epoch&&P.seed==Pshort.seed, ...
        'ktc:recordExtension','Extending the record changed chip/input/seed/plan prefix.');
    setcase(P);full=SAR20('run');
    selected=load(fullfile(full.run_path,'selected.mat'),'selected');
    assert(isequal(selected.selected.raw(1:8,:),shortSelected.selected.raw)&& ...
        isequal(selected.selected.code20(1:8),shortSelected.selected.code20), ...
        'ktc:prefix','N256 actual raw/code prefix differs from the same-configuration N8.');
    addpath(fullfile(stage,'validation'));loaded=load(fullfile(full.run_path,'simout.mat'),'simout');
    check=test_behavior_az_capture(loaded.simout,P);
    metrics=load(fullfile(full.run_path,'spectrum.mat'),'metrics');m=metrics.metrics;
    fig=figure('Visible','off','Color','white','Position',[100 100 1100 650]);
    closeFigure=onCleanup(@()close(fig)); %#ok<NASGU>
    plot(m.frequency_hz/1e6,10*log10(max(m.power_v2,realmin)/max(m.power_v2)),'LineWidth',1);
    grid on;xlabel('Frequency (MHz)');ylabel('Power (dBc)');ylim([-160 5]);
    title({sprintf('Actual N256 | sampling kT/C + paired AZ/chop | SNDR %.3f dB',m.sndr_db), ...
        sprintf('T=%.2f K; kTC seed %.0f; Vos=1 mV; calibration OFF',P.front.temperature_K,P.front.ktc_seed), ...
        sprintf('Model %s | %s',full.model_sha256(1:12),full.finished_utc)},'Interpreter','none','FontSize',11);
    exportgraphics(fig,fullfile(full.run_path,'Spectrum.png'),'Resolution',160);savefig(fig,fullfile(full.run_path,'Spectrum.fig'));
    sample=SAR20('sample',5,full.run_path);
    report=struct('status','actual_N256_sampling_noise_and_AZ_complete','short',short,'full',full, ...
        'prefix_raw_code_exact',true,'validation',check,'sample',sample, ...
        'scope','One frequency/amplitude/seed; equilibrium sampling kTC and deterministic AZ/RA assumptions; not complete paper reproduction');
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
    SAR20('apply');
    function setcase(P)
        ws=get_param(model,'ModelWorkspace');assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
        save_system(model,file,'SaveModelWorkspace',true);
    end
end
function restore(root,saved)
    path(saved);addpath(root,'-begin');SAR20('setup');
    if bdIsLoaded('SarAdc')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off')
        SAR20('apply');
    end
end
