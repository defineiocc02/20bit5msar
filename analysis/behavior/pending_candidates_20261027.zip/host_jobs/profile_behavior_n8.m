function report=profile_behavior_n8(root,outputDir)
%PROFILE_BEHAVIOR_N8 One actual N8 SAR20 run; existing profiler counters retained.
% Caller runs after the active job finishes and the saved current model is N8/off.
% No factory/apply, parameter assignment, source edit, model save or clock change.
% Saves ONLY top50 inclusive-time/call-count deltas, plus run receipt metadata.
% This instrumented elapsed time is NOT an unprofiled speed benchmark.
    model='SarAdc';assert(bdIsLoaded(model),'behaviorProfile:loaded','Open saved current SarAdc first.');
    assert(strcmpi(canonical(get_param(model,'FileName')), ...
        canonical(fullfile(root,'current','models','SarAdc.slx')))&& ...
        strcmp(get_param(model,'SimulationStatus'),'stopped')&&strcmp(get_param(model,'Dirty'),'off'), ...
        'behaviorProfile:model','Require stopped, clean, unique current model.');
    ws=get_param(model,'ModelWorkspace');P=getVariable(ws,'P');D=getVariable(ws,'DecodeP');
    assert(P.N==8&&strcmp(P.backend.az.mode,'off')&&isequaln(P.digital,D), ...
        'behaviorProfile:parameters','Require saved N8/off and matching DecodeP.');
    assert(strcmpi(canonical(which('SAR20')),canonical(fullfile(root,'SAR20.m'))), ...
        'behaviorProfile:entry','Resolve the real current project entry before profiling.');
    status=profile('status');assert(strcmpi(status.ProfilerStatus,'off'), ...
        'behaviorProfile:busy','Another profiler session is active.');
    if ~isfolder(outputDir),mkdir(outputDir);end
    assert(~isfile(fullfile(outputDir,'profile_top.json')),'behaviorProfile:exists','Choose a fresh profile output folder.');
    before=profile('info');failure=[];runReceipt=struct();
    profile('resume');cleanup=onCleanup(@()profile('off')); %#ok<NASGU>
    try,runReceipt=SAR20('run');catch cause,failure=cause;end
    profile('off');after=profile('info');
    a=before.FunctionTable;b=after.FunctionTable;
    rows=struct('name',{},'complete_name',{},'inclusive_s',{},'calls',{});
    for k=1:numel(b)
        prior=[];if ~isempty(a),prior=find(strcmp({a.CompleteName},b(k).CompleteName),1);end
        oldTime=0;oldCalls=0;
        if ~isempty(prior),oldTime=a(prior).TotalTime;oldCalls=a(prior).NumCalls;end
        calls=b(k).NumCalls-oldCalls;elapsed=b(k).TotalTime-oldTime;
        if calls>0||elapsed>0
            rows(end+1)=struct('name',b(k).FunctionName,'complete_name',b(k).CompleteName, ...
                'inclusive_s',elapsed,'calls',calls); %#ok<AGROW>
        end
    end
    [~,order]=sort([rows.inclusive_s],'descend');top=rows(order(1:min(50,numel(order))));
    unchanged=strcmp(get_param(model,'Dirty'),'off')&& ...
        isequaln(P,getVariable(ws,'P'))&&isequaln(D,getVariable(ws,'DecodeP'));
    report=struct('status','instrumented_n8_complete','run',runReceipt,'top',top, ...
        'prior_counters_preserved',true,'parameters_unchanged',unchanged, ...
        'time_definition','inclusive function times; callers and children overlap; do not add rows', ...
        'timing_scope','profiled diagnostic run, not an unprofiled benchmark');
    if ~isempty(failure)
        report.status='instrumented_n8_failed';report.error=getReport(failure,'extended','hyperlinks','off');
    end
    save(fullfile(outputDir,'profile_top.mat'),'top','report','-v7');
    fid=fopen(fullfile(outputDir,'profile_top.json'),'w','n','UTF-8');assert(fid>=0);
    closeFile=onCleanup(@()fclose(fid));fprintf(fid,'%s\n',jsonencode(report)); %#ok<NASGU>
    if ~isempty(failure),rethrow(failure);end
    assert(unchanged,'behaviorProfile:mutation','P/DecodeP/model dirty state changed during profiling.');
end
function p=canonical(p),p=char(java.io.File(p).getCanonicalPath());end
