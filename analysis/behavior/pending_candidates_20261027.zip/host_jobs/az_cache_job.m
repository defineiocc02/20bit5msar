function az_cache_job(root,stage,outdir)
% Measure only fixed-parameter lookup removal; physics and states are unchanged.
    cd(root);addpath(root,'-begin');SAR20('setup');model='SarAdc';
    file=fullfile(root,'current','models','SarAdc.slx');open_system(file);
    ws=get_param(model,'ModelWorkspace');P=getVariable(ws,'P');
    assert(P.N==8&&strcmp(P.backend.az.mode,'off')&&strcmp(get_param(model,'SimulationStatus'),'stopped'));
    paths={'frontend/behavior_frontend_sfun.m','physics/behavior_backend_sfun.m','model/behavior_wiring_sfun.m'};
    for k=1:numel(paths)
        [~,name,ext]=fileparts(paths{k});
        assert(isfile(fullfile(stage,'cache',[name ext])),'cache:staging','Missing staged wrapper %s.',name);
    end
    % Resume the already completed unprofiled baseline; the prior host staging
    % failure occurred before any runtime source was overwritten.
    prior=fullfile(root,'runs','behavior_ecb150f9-f3d1-42c3-b865-d6df9a452ae0');
    before=jsondecode(fileread(fullfile(prior,'summary.json')));
    priorP=load(fullfile(prior,'parameters.mat'),'P');assert(isequaln(P,priorP.P));
    frozen=fullfile(outdir,'baseline_sources');unzip(fullfile(prior,'source.zip'),frozen);
    for k=1:numel(paths)
        assert(strcmp(fileread(fullfile(root,'current','src',paths{k})), ...
            fileread(fullfile(frozen,'current','src',paths{k}))),'cache:baselineSource','Current wrapper differs from completed baseline.');
    end
    backup=fullfile(outdir,'before_wrappers');mkdir(backup);
    close_system(model,0);
    for k=1:numel(paths)
        [~,name,ext]=fileparts(paths{k});name=[name ext];
        destination=fullfile(root,'current','src',paths{k});
        copyfile(destination,fullfile(backup,name));copyfile(fullfile(stage,'cache',name),destination);
    end
    clear behavior_frontend_sfun behavior_backend_sfun behavior_wiring_sfun;
    rehash;open_system(file);SAR20('check');after=SAR20('run');
    compare(before.run_path,after.run_path);
    % A nonzero AZ/chop/leak case catches accidental stale setup parameters.
    reference=fullfile(root,'runs','behavior_16ec06a2-dc6c-457b-8983-ad6746090eb7');
    loaded=load(fullfile(reference,'parameters.mat'),'P');P=loaded.P;
    ws=get_param(model,'ModelWorkspace');assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
    save_system(model,file,'SaveModelWorkspace',true);stress=SAR20('run');
    compare(reference,stress.run_path);SAR20('apply');
    report=struct('status','parameter_capture_actual_bit_exact', ...
        'before',before,'after',after,'finite_leak_reference',reference,'finite_leak_after',stress, ...
        'timing_scope','one unprofiled pair, not a statistical throughput claim', ...
        'math_state_rng_event_changes',false);
    f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(report));fclose(f);
end
function compare(a,b)
    a=load(fullfile(a,'simout.mat'),'simout');b=load(fullfile(b,'simout.mat'),'simout');
    names={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log','az_route_log','az_commit_log'};
    for k=1:numel(names)
        x=a.simout.get(names{k});y=b.simout.get(names{k});
        assert(isequal(x.Time,y.Time)&&isequal(size(x.Data),size(y.Data))&& ...
            isequal(typecast(x.Data(:),'uint64'),typecast(y.Data(:),'uint64')), ...
            'cache:bitEquality','Actual %s differs after parameter capture.',names{k});
    end
end
