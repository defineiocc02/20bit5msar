function az_native_job(root,stage,outdir)
% Native MATLAB validation only; no model/source mutation or simulation start.
    cd(root);addpath(root,'-begin');SAR20('setup');
    savedPath=path;cleanup=onCleanup(@()path(savedPath)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit','tools');
    addpath(fullfile(toolkit,'common'));
    gate=library.settingsLookup();
    assert(~gate.found||gate.gatePass,'az:library','Custom library gate is not ready.');
    if gate.found,fileread(gate.kgIndexPath);end
    fid=fopen(fullfile(outdir,'library_gate.json'),'w');
    fprintf(fid,'%s',jsonencode(gate));fclose(fid);
    addpath(fullfile(stage,'validation'));
    report=test_behavior_az(root,fullfile(outdir,'native'));
    assert(isstruct(report),'az:native','Expected a native validation receipt.');
end
