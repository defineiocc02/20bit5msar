function group_save_partial_job(root,stage,outdir)
% Preserve the owned partially grouped copy and close only its window.
    cd(root);addpath(root,'-begin');SAR20('setup');oldPath=path;
    cleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit','tools');
    addpath(fullfile(toolkit,'common'),fullfile(toolkit,'model_read'),fullfile(toolkit,'model_check'));
    gate=library.settingsLookup();assert(~gate.found||gate.gatePass);
    if gate.found,fileread(gate.kgIndexPath);end
    m='SarView';assert(bdIsLoaded(m)&&strcmp(get_param(m,'SimulationStatus'),'stopped'));
    file=get_param(m,'FileName');assert(contains(strrep(file,'\','/'),'az_probe_20261026T193648Z/SarView.slx'));
    view=model_read(m,'root','0');step=lookup(view,'EventStep');adc=lookup(model_read(m,step,'0'),'Adc');
    write('partial_read.txt',model_read(m,adc,'inf'));
    write('partial_check.txt',model_check(m,adc,'["unconnected_ports","unconnected_lines"]'));
    save_system(m,file,'SaveModelWorkspace',true);copyfile(file,fullfile(outdir,'SarView_partial.slx'));
    write('partial_identity.json',jsonencode(struct('model_file',file,'adc_scope',adc,'main_untouched',true)));
    close_system(m,0);
    function write(name,value)
        f=fopen(fullfile(outdir,name),'w','n','UTF-8');c=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s',char(value));
    end
end
function id=lookup(view,name)
    token=regexp(char(view),['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'],'tokens','once');
    assert(~isempty(token));id=token{1};
end
