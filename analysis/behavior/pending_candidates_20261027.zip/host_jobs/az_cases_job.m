function az_cases_job(root,stage,outdir)
% Same saved SLX, same input/chip: deterministic AZ A/B/C/D functional records.
% Every case is frozen by SAR20('run'); restore factory N8/off when finished.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()restore(root,saved)); %#ok<NASGU>
    model='SarAdc';file=fullfile(root,'current','models','SarAdc.slx');
    open_system(file);assert(strcmp(get_param(model,'SimulationStatus'),'stopped'));
    assert(strcmp(get_param(model,'Dirty'),'off'));
    Pbase=adc_parameters();
    addpath(fullfile(stage,'backend'),fullfile(stage,'validation'));
    SAR20('setup');suite=mode_cases(Pbase);rmpath(fullfile(stage,'backend'));
    save(fullfile(outdir,'case_definitions.mat'),'suite','-v7.3');
    cases=[struct('name','zero_offset_ordinary','P',suite.references.zero_offset_ordinary); ...
        struct('name','finite_offset_off','P',suite.references.finite_offset_off)];
    for k=1:numel(suite.cases)
        cases(end+1)=struct('name',suite.cases(k).name,'P',suite.cases(k).P); %#ok<AGROW>
    end
    report=struct('status','running','completed',{{}},'cases',{{}});write();
    baseline=load(fullfile(root,'runs','behavior_a7b38ecb-7991-4e88-a5ec-3177b799c8c9','selected.mat'),'selected');
    for k=1:numel(cases)
        P=behavior_prepare_configuration(cases(k).P);
        ws=get_param(model,'ModelWorkspace');assignin(ws,'P',P);assignin(ws,'DecodeP',P.digital);
        save_system(model,file,'SaveModelWorkspace',true);
        run=SAR20('run');loaded=load(fullfile(run.run_path,'simout.mat'),'simout');
        check=test_behavior_az_capture(loaded.simout,P);
        if strcmp(cases(k).name,'zero_offset_ordinary')
            selected=load(fullfile(run.run_path,'selected.mat'),'selected');
            assert(isequal(selected.selected.raw,baseline.selected.raw)&& ...
                isequal(selected.selected.code20,baseline.selected.code20), ...
                'az:zeroOffset','Zero-offset ordinary AZ changed original raw/code.');
        end
        one=struct('name',cases(k).name,'run',run,'validation',check);
        save(fullfile(run.run_path,'az_validation.mat'),'check','-v7.3');
        f=fopen(fullfile(run.run_path,'az_validation.json'),'w','n','UTF-8');fprintf(f,'%s',jsonencode(check));fclose(f);
        report.cases{end+1}=one;report.completed{end+1}=cases(k).name;write();
        fprintf('AZ_CASE %s %.3f s %s\n',cases(k).name,run.elapsed_s,check.status);
        if strcmp(cases(k).name,'D_finite_leak')
            SAR20('sample',4,run.run_path);SAR20('sample',5,run.run_path);
        end
    end
    report.status='actual_AZ_modes_complete';write();SAR20('apply');
    function write()
        f=fopen(fullfile(outdir,'receipt.json'),'w','n','UTF-8');c=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s',jsonencode(report));
    end
end
function restore(root,saved)
    path(saved);addpath(root,'-begin');SAR20('setup');
    if bdIsLoaded('SarAdc')&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off')
        SAR20('apply');
    end
end
