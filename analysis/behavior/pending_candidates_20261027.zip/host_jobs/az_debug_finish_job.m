function az_debug_finish_job(root,stage,outdir)
% Resume only the one failed Selector configuration in the saved work model.
    cd(root);addpath(root,'-begin');SAR20('setup');saved=path;
    cleanup=onCleanup(@()path(saved)); %#ok<NASGU>
    toolkit=fullfile(root,'dependencies','toolkit');
    for part={'common','common/autolayout','model_read','model_edit','model_check'}
        addpath(fullfile(toolkit,'tools',part{1}));
    end
    gate=library.settingsLookup();assert(~gate.found||gate.gatePass,'az:library','Library knowledge is not ready.');
    if gate.found,fileread(gate.kgIndexPath);end
    model='SarAdc';file=fullfile(root,'current','models','SarAdc.slx');open_system(file);
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped')&&strcmp(get_param(model,'Dirty'),'off'));
    top=model_read(model,'root','0');step=lookup(top,'EventStep');
    adc=lookup(model_read(model,step,'0'),'Adc');
    selectId=lookup(model_read(model,adc,'0'),'AzEventId');
    ops={struct('op','configure','target',selectId,'params',struct( ...
        'IndexOptions','Index vector (dialog)','Indices','1','InputPortWidth','2','OutputSizes','1'))};
    answer=model_edit(model,adc,jsonencode(ops),'incremental');write('repair.txt',answer);
    write('read.txt',model_read(model,adc,'0'));
    write('check.txt',model_check(model,adc,'["unconnected_ports","unconnected_lines"]'));
    save_system(model,file,'SaveModelWorkspace',true);
    assert(~contains(answer,'status: partial')&&~contains(answer,'status: error'),'az:repair','Saved repair needs inspection.');
    addpath(fullfile(stage,'debug'));SAR20('setup');
    debug=integrate_az_debug(model,adc,fullfile(outdir,'debug'));
    rmpath(fullfile(stage,'debug'));
    compile=SAR20('check');baseline=SAR20('run');
    reference=fullfile(root,'runs','behavior_a7b38ecb-7991-4e88-a5ec-3177b799c8c9');
    previous=load(fullfile(reference,'simout.mat'),'simout');
    now=load(fullfile(baseline.run_path,'simout.mat'),'simout');
    logs={'event_log','raw_log','ready_log','code_log','front_log','back_log', ...
        'control_log','d1_log','d2_log','dt_log'};
    for k=1:numel(logs)
        a=previous.simout.get(logs{k});b=now.simout.get(logs{k});
        assert(isequal(a.Time,b.Time)&&isequal(size(a.Data),size(b.Data))&& ...
            isequal(typecast(a.Data(:),'uint64'),typecast(b.Data(:),'uint64')), ...
            'az:offBitEquality','Off baseline differs in actual log %s.',logs{k});
    end
    addpath(fullfile(stage,'validation'));
    ws=get_param(model,'ModelWorkspace');P=getVariable(ws,'P');
    diagnostic=test_behavior_az_capture(now.simout,P,previous.simout);
    receipt=struct('status','AZ_integrated_compiled_off_N8_bit_exact','debug',debug, ...
        'compile',compile,'baseline',baseline,'baseline_reference',reference, ...
        'bit_exact_logs',{logs},'diagnostic',diagnostic);
    save(fullfile(outdir,'receipt.mat'),'receipt','-v7.3');write('receipt.json',jsonencode(receipt));
    SAR20('setup');
    function write(name,value)
        f=fopen(fullfile(outdir,name),'w','n','UTF-8');c=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s',char(value));
    end
end
function id=lookup(view,name)
    token=regexp(char(view),['- id: (blk_\d+)\s+Name: ' regexptranslate('escape',name) '(?:\r?\n)'],'tokens','once');
    assert(~isempty(token),'az:modelRead','Missing actual block %s.',name);id=token{1};
end
