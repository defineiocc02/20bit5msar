function report=test_behavior_static_local(projectRoot,outDir,P)
%TEST_BEHAVIOR_STATIC_LOCAL Bounded actual-SLX DC transition experiment.
% Root calls after the public entry supports SAR20('apply',P).
% Uses only that apply/run API, N=1 at fixed ID4 after actual warmup IDs0..3.
% Noise/DEM/dither are explicitly disabled. Other deterministic parameters are
% preserved, including AZ/chop mode, finite RA and frozen nominal decode.
% Two windows: zero +/-8 nominal LSB; real coarse threshold +8*delta1 +/-8LSB.
% 17-point coarse grids, three neighboring thresholds, bracket resolution
% nominalLSB/64, at most96 real run calls TOTAL. No ADC surrogate or FFT.
% Only separated adjacent thresholds with an observed code-k plateau produce
% local DNL bounds. INL is deliberately not measured by this narrow experiment.
    assert(nargin==3&&isstruct(P)&&isscalar(P),'localStatic:arguments','Supply explicit resolved baseline P.');
    assert(~isfolder(outDir)&&~isfile(outDir),'localStatic:overwrite','Use a new evidence folder.');
    mkdir(outDir);oldPath=path;pathCleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(projectRoot,'-begin');clear SAR20
    assert(strcmpi(which('SAR20'),fullfile(projectRoot,'SAR20.m')), ...
        'localStatic:entry','Require the unique actual project entry.');
    original=P;started=tic;restoreNeeded=false;didRestore=false;
    cleanup=onCleanup(@restore_configuration); %#ok<NASGU>
    base=P;base.N=1;base.first_id=4;base.input.amplitude_v=0;
    base.front.ktc_enabled=false;base.front.dem_enabled=false;base.front.dither_enabled=false;
    base.digital.dither_enabled=false;base.control.sar1.coarse_noise_rms_v=0;
    base.backend.ni.ra_noise=false;base.backend.ni.az_noise=false;base.backend.ni.reference_noise=false;
    if isfield(base,'ni')
        for name={'sample_ktc','comparator_noise','jitter'}
            if isfield(base.ni,name{1}),base.ni.(name{1})=false;end
        end
    end
    lsb=base.digital.fsr_diff_v/2^20;resolution=lsb/64;
    coarseOffset=0;
    if isfield(base.control.sar1,'coarse_offset_v'),coarseOffset=base.control.sar1.coarse_offset_v;end
    centers=[0,8*base.control.sar1.delta_v-coarseOffset];
    assert(lsb>0&&isfinite(lsb)&&all(isfinite(centers))&&base.Ts_s==P.Ts_s, ...
        'localStatic:configuration','Invalid declared static measurement settings.');
    observations=struct('voltage_v',{},'code20',{},'D1',{},'D2',{},'DT',{}, ...
        'sample_id',{},'epoch',{},'raw_ready_time_s',{},'run_path',{},'model_sha256',{},'config_sha256',{});
    regions=cell(2,1);runCalls=0;counterexample=[];
    report=struct('schema','sar20-actual-local-static/v1','status','started', ...
        'configuration',base,'original_configuration',original,'nominal_lsb_v',lsb, ...
        'declared_voltage_resolution_v',resolution,'run_call_limit',96,'run_calls',0, ...
        'sample_scope','Fixed sample ID4, epoch preserved, fresh model IC and four actual warmup conversions per voltage; not a phase-averaged steady-state transfer', ...
        'regions',{{}},'INL','not_measured_no_wide_coverage_or_declared_INL_reference', ...
        'DNL_reference','Nominal FSR/2^20; only resolved adjacent actual transition widths', ...
        'monotonicity_scope','Observed input points only; no claim about unobserved intervals/full range', ...
        'source_scope','Actual same main SLX through SAR20 apply/run; no synthetic quantizer, calibration fit or FFT-derived DNL');
    try
        calendar=behavior_calendar(base.control);
        assert(nnz(strcmp({calendar.type},'d2_decide'))==12&& ...
            nnz(strcmp({calendar.type},'ta_compare'))==8&&nnz(strcmp({calendar.type},'ta_feedback'))==7, ...
            'localStatic:calendar','12D2/8TA/7feedback changed.');
        for regionIndex=1:2
            grid=centers(regionIndex)+(-8:8)*lsb;gridCodes=zeros(size(grid));gridD1=zeros(size(grid));
            for j=1:numel(grid)
                gridCodes(j)=measure(grid(j));observation=find([observations.voltage_v]==grid(j),1);
                gridD1(j)=observations(observation).D1;
            end
            centerCode=gridCodes(9);targets=centerCode+(-1:1);
            thresholds=cell(3,1);
            for j=1:3
                k=targets(j);lo=find(gridCodes<k,1,'last');hi=find(gridCodes>=k,1,'first');
                assert(~isempty(lo)&&~isempty(hi)&&lo<hi, ...
                    'localStatic:notBracketed','Requested local transition is not bracketed by actual coarse points.');
                left=grid(lo);right=grid(hi);lc=gridCodes(lo);rc=gridCodes(hi);iterations=0;
                while right-left>resolution
                    mid=(left+right)/2;
                    assert(mid>left&&mid<right,'localStatic:floatResolution','Input bracket cannot be further resolved.');
                    code=measure(mid);iterations=iterations+1;
                    if code<k,left=mid;lc=code;else,right=mid;rc=code;end
                end
                thresholds{j}=struct('transition_to_code',k,'input_low_v',left,'input_high_v',right, ...
                    'observed_code_low',lc,'observed_code_high',rc,'bracket_width_v',right-left, ...
                    'declared_resolution_v',resolution,'bisection_measurements',iterations);
            end
            widths=cell(2,1);
            for j=1:2
                a=thresholds{j};b=thresholds{j+1};k=a.transition_to_code;
                lower=b.input_low_v-a.input_high_v;upper=b.input_high_v-a.input_low_v;
                result=struct('code',k,'status','unresolved_adjacent_width','width_lower_v',lower, ...
                    'width_upper_v',upper,'platform_probe_v',[],'platform_observed_code',[], ...
                    'DNL_lower_lsb',[],'DNL_upper_lsb',[],'DNL_midpoint_estimate_lsb',[]);
                if b.transition_to_code==k+1&&lower>0
                    point=(a.input_high_v+b.input_low_v)/2;observed=measure(point);
                    result.platform_probe_v=point;result.platform_observed_code=observed;
                    if observed==k
                        result.status='actual_adjacent_transition_width_bracketed';
                        result.DNL_lower_lsb=lower/lsb-1;result.DNL_upper_lsb=upper/lsb-1;
                        result.DNL_midpoint_estimate_lsb=(lower+upper)/(2*lsb)-1;
                    else,result.status='missing_code_or_unresolved_plateau_no_DNL';end
                end
                widths{j}=result;
            end
            label='zero neighborhood';if regionIndex==2,label='SAR1 coarse threshold +8*delta1-coarseOffset';end
            regions{regionIndex}=struct('label',label,'center_v',centers(regionIndex), ...
                'measured_input_range_v',[grid(1) grid(end)],'coarse_inputs_v',grid, ...
                'coarse_actual_codes',gridCodes,'actual_D1_words',gridD1, ...
                'actual_SAR1_coarse_fields',floor(gridD1/32), ...
                'observed_SAR1_coarse_field_change',numel(unique(floor(gridD1/32)))>1, ...
                'transitions',vertcat(thresholds{:}), ...
                'local_widths',vertcat(widths{:}));
            checkpoint();
        end
        report.status='actual_local_transition_measurements_complete_not_full_linearity';
    catch cause
        if strcmp(cause.identifier,'localStatic:nonMonotonic')
            report.status='non_monotonic_observed_counterexample_preserved_no_DNL_claim';
        elseif strcmp(cause.identifier,'localStatic:budget')
            report.status='bounded_run_budget_reached_partial_measurements';
        else,report.status='failed';end
        report.identifier=cause.identifier;report.message=cause.message;report.stack=cause.stack;
    end
    restore_configuration();report.configuration_restored=didRestore;report.elapsed_wall_s=toc(started);
    if isfield(report,'restore_error'),report.status='measurements_saved_configuration_restore_failed';end
    checkpoint();

    function code=measure(voltage)
        previous=find([observations.voltage_v]==voltage,1);
        if ~isempty(previous),code=observations(previous).code20;return;end
        assert(runCalls<96,'localStatic:budget','96 actual run-call limit reached.');
        q=base;q.input.offset_v=voltage;q.front.input=q.input;
        restoreNeeded=true;SAR20('apply',q);runCalls=runCalls+1;r=SAR20('run');
        assert(strcmp(r.status,'complete')&&r.simulation_completed&&r.records==1, ...
            'localStatic:run','Actual SLX run did not complete one valid selected record.');
        loaded=load(fullfile(r.run_path,'selected.mat'),'selected');selected=loaded.selected;
        config=load(fullfile(r.run_path,'parameters.mat'),'P');actual=config.P;
        assert(actual.N==1&&actual.first_id==4&&actual.epoch==base.epoch&& ...
            actual.Ts_s==base.Ts_s&&actual.input.offset_v==voltage&&actual.input.amplitude_v==0&& ...
            ~actual.front.ktc_enabled&&~actual.front.dem_enabled&&~actual.front.dither_enabled&& ...
            ~actual.digital.dither_enabled&&~actual.backend.ni.ra_noise&&~actual.backend.ni.az_noise&& ...
            ~actual.backend.ni.reference_noise&&actual.control.sar1.coarse_noise_rms_v==0, ...
            'localStatic:actualConfig','Actual run did not use requested DC/noise-off configuration.');
        raw=selected.raw;code=double(selected.code20);
        assert(isequal(size(raw),[1 6])&&raw(4)==4&&raw(5)==base.epoch&&raw(6)==1&& ...
            isscalar(code)&&isfinite(code)&&code==floor(code)&&code>=0&&code<2^20, ...
            'localStatic:record','Invalid actual public record; do not delete or average it.');
        assert(isequal(actual.control,base.control)&&isequal(actual.backend,base.backend)&& ...
            isequal(actual.digital,base.digital)&&isequal(actual.front,q.front), ...
            'localStatic:deterministicConfig','Deterministic model parameters changed.');
        observations(end+1,1)=struct('voltage_v',voltage,'code20',code,'D1',raw(1),'D2',raw(2), ...
            'DT',raw(3),'sample_id',raw(4),'epoch',raw(5),'raw_ready_time_s',selected.time_s, ...
            'run_path',r.run_path,'model_sha256',r.model_sha256,'config_sha256',r.config_sha256);
        [~,order]=sort([observations.voltage_v]);sorted=observations(order);
        reversal=find(diff([sorted.code20])<0,1);
        if ~isempty(reversal)
            counterexample=sorted(reversal:reversal+1);checkpoint();
            error('localStatic:nonMonotonic','Actual code decreases between measured DC inputs.');
        end
        checkpoint();
    end
    function checkpoint()
        report.run_calls=runCalls;report.regions=regions;report.observations=observations;
        report.first_nonmonotonic_counterexample=counterexample;
        save(fullfile(outDir,'local_static.mat'),'report','-v7.3');
        f=fopen(fullfile(outDir,'local_static.json'),'w','n','UTF-8');assert(f>=0);
        closer=onCleanup(@()fclose(f)); %#ok<NASGU>
        fprintf(f,'%s\n',jsonencode(report));
        if ~isempty(observations),writetable(struct2table(observations),fullfile(outDir,'actual_observations.csv'));end
    end
    function restore_configuration()
        if restoreNeeded
            restoreNeeded=false;
            try,SAR20('apply',original);didRestore=true;
            catch e
                didRestore=false;report.restore_error=struct('identifier',e.identifier,'message',e.message);
            end
        end
    end
end
