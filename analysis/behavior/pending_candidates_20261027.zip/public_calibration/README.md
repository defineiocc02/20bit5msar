# 公开RAW校准特征候选（未接主图）

接口：`F=behavior_public_cal_features(raw,cfg)`；`R=behavior_public_cal_fit(raw,cfg,trainRef,thresholds)`。MATLAB纯显式输入，无persistent/global/RNG/文件写入。归档features/fit v1.1已从records.zip按完整SHA校验，只读必要blob，没有恢复旧运行树；来源和实际fixture SHA见provenance.json。

raw严格只有六个同长数组：raw_D1/raw_D2/raw_DT/sample_id/epoch/valid。拒绝完整P、actualC、held、qres等额外字段。cfg严格17项：schema、vref_v、fs_hz、plan_rows、pool_seed/pool_schedule、dem_enabled/dem_seed/dem_schedule、dither_enabled/dither_seed/dither_input_amplitude_v/dither_schedule、az_mode、backend_weights_ra_v、nominal_ra_gain、tracking_mode。它们均为公开日历/seed/模式或已声明的名义数字尺度；实际C不进入cfg。当前M8/5MS/s、标称RA32，backend14顺序[offset,D2 b11..b0,TA scale]，单位均RA域V。完整字段/版本字符串见函数。

每片38列为MSB16、31个32Cu组、fine16/8/4/2/1、bias17。P矩阵仅1:33采样列为1；B的tail34:37使用实际物理命令`Vref*fine_level + d_n*1024/15`，bias列为−Vref。DEM从公开ID/epoch/slice/seed重放，pool从同seed重放，sample ID≤plan_rows−2。POL只进入响应u=POL*(D2_RA+DT_RA)，绝不翻D1/bias/tail。DT仍是(8..1)的bipolar有限帧和/8。

训练方程Z=xref.*P−B，u=Z*h；h为684个有效C_half/Cf_effective，不是实际F，也不能拆开RA增益和绝对Cf。固定名义backend电压尺度后不擅减维。nominal_h只用于公开方程恒等式诊断，拟合不使用它补零空间。

trainRef严格只有source/provenance/sample_id/epoch/value_v；source='declared_external_reference'，逐帧同ID/epoch配对，来源由调用方取证。本候选完全不接holdout答案。阈值严格只有relative_singular_cutoff/maximum_condition_number/training_rms_limit_v，必须预先声明。N<684在读reference值前硬拒绝（允许trainRef=[]用于实际短batch边界检查）；N256不求系数，rank上界≤256、nullity下界≥428，并单独报告pool membership秩，不能将后者冒称684满秩。

N≥684才接受外部trainRef、构建Z：仅训练列RMS缩放，SVD判据max(relative*s1,max(size(W))*eps(s1))；全684秩、条件数、正h/正分母、训练预算、必要覆盖均通过才返回待独立holdout的h_fit。无正则、无pinv/nominal填补、无holdout挑参。accepted始终false，frozen始终空；独立holdout、主图bank提交、整数回载是后续独立门。

实际fixture：native256.mat来自真实behavior_ce06...N256；actual_chop8.mat来自真实D_finite hold_chop N8。只从selected读取公开raw/code；从参数文件只读公开seed/flag/plan形状及名义digital字段，未读C/held/input/残差/模拟节点/外部参考。未产生假输入或训练参考。`test_behavior_public_calibration()`使用实际raw检查Nx684、当前raw-only decoder恒等式、实际整数码对照（单独报告、不以浮点重新结合公式冒充逐位oracle）、额外模拟字段/holdout字段拒绝、无效帧/越界拒绝和短batch欠秩拒绝。需current/src/digital在path；当前尚未MATLAB执行。

静态电荷基底假设同一采样电压及充分采样/预充，固定h不能无证明吸收有限建立、RA动态、AZ残差、kTC/jitter。当前仅准备公开接口与边界，不声称已辨识参数或完成整图校准。

整数边界：features矩阵乘法与既有nominal decoder的加法结合次序不同，电压可在roundoff内一致而half-count处相差1码。此候选没有引入整数校准输出；不得以该浮点恒等式替代今后的定点/舍入/回载验收，也不为追码改h或theta。
