function report=test_behavior_public_calibration()
%TEST_BEHAVIOR_PUBLIC_CALIBRATION Actual public fixtures, no synthesized signal.
% Requires current digital/ on path for production behavior_decode comparison.
% No train reference exists in these fixtures; N256 row-bound rejection only.
    here=fileparts(mfilename('fullpath'));
    assert(exist('behavior_decode','file')==2,'publicCalTest:decoder','Add current/src/digital to path.');
    files={'native256.mat','actual_chop8.mat'};cases=cell(1,2);
    threshold=struct('relative_singular_cutoff',1e-10,'maximum_condition_number',1e8, ...
        'training_rms_limit_v',1); % Unused no-fit boundary values; NOT an acceptance budget.
    before=rng;
    for q=1:2
        a=load(fullfile(here,files{q}));F=behavior_public_cal_features(a.raw,a.publicCfg);
        n=numel(a.raw.sample_id);
        assert(isequal(size(F.sample_coefficients),[n 684])&&isequal(size(F.code_coefficients_v),[n 684]), ...
            'publicCalTest:shape','Actual public batch did not produce Nx684.');
        assert(all(sum(F.sample_coefficients,2)==8*33),'publicCalTest:sampleMask','Wrong sampled branch count.');
        S=F.sample_coefficients*F.nominal_h;B=F.code_coefficients_v*F.nominal_h;
        v=(F.backend_residual_ra_v+B)./S;voltage=zeros(n,1);codes=zeros(n,1);
        for k=1:n
            names=fieldnames(a.raw);r=struct();for j=1:numel(names),r.(names{j})=a.raw.(names{j})(k);end
            d=behavior_decode(r,a.decodeP);voltage(k)=d.voltage_v;codes(k)=d.code20;
        end
        tol=128*eps(max([abs(v);abs(voltage);a.publicCfg.vref_v]));
        assert(all(abs(v-voltage)<=tol),'publicCalTest:nominalIdentity', ...
            'Nominal public charge identity differs from current raw-only decoder.');
        codeDelta=codes-a.actual_code20(:); % report actual integer comparison separately
        % Nominal voltage identities are checked at roundoff. Do not turn a
        % regrouped float expression at a half-count into a calibrated code oracle.
        R=behavior_public_cal_fit(a.raw,a.publicCfg,[],threshold);
        assert(strcmp(R.status,'rank_deficient_row_bound')&&~R.accepted&&isempty(R.h_fit)&& ...
            isempty(R.frozen)&&~R.reference_values_read&&R.rank_upper_bound==n, ...
            'publicCalTest:rankReject','Short actual RAW batch was fitted/filled/frozen.');
        if n==256,assert(R.nullity_lower_bound>=428,'publicCalTest:N256','N256 missing nullity bound.');end
        cases{q}=struct('fixture',files{q},'actual_rows',n,'mode',a.publicCfg.az_mode, ...
            'feature_shape',size(F.sample_coefficients),'nominal_voltage_max_abs_delta_v',max(abs(v-voltage)), ...
            'actual_integer_decode_match',isequal(codes,a.actual_code20(:)), ...
            'actual_integer_decode_mismatch_count',nnz(codeDelta),'max_abs_integer_decode_delta',max(abs(codeDelta)), ...
            'rank_status',R.status, ...
            'rank_upper_bound',R.rank_upper_bound,'nullity_lower_bound',R.nullity_lower_bound, ...
            'membership_rank',R.membership_rank,'reference_read',R.reference_values_read);
    end
    a=load(fullfile(here,files{1}));
    poison=a.raw;poison.actualC=[];
    rejects(@()behavior_public_cal_features(poison,a.publicCfg),'publicCal:rawBoundary');
    poisonCfg=a.publicCfg;poisonCfg.held=[];
    rejects(@()behavior_public_cal_features(a.raw,poisonCfg),'publicCal:configBoundary');
    badRef=struct('source','declared_external_reference','provenance','boundary_only_no_reference_values', ...
        'sample_id',a.raw.sample_id,'epoch',a.raw.epoch,'value_v',[],'holdout_answers',[]);
    rejects(@()behavior_public_cal_fit(a.raw,a.publicCfg,badRef,threshold),'publicCal:referenceBoundary');
    invalid=a.raw;invalid.valid(1)=0;
    rejects(@()behavior_public_cal_fit(invalid,a.publicCfg,[],threshold),'publicCal:trainingSequence');
    outOfPlan=a.raw;outOfPlan.sample_id(1)=a.publicCfg.plan_rows-1;
    rejects(@()behavior_public_cal_features(outOfPlan,a.publicCfg),'publicCal:rawRange');
    assert(isequal(before,rng),'publicCalTest:RNG','Public feature/fit boundary changed global RNG.');
    report=struct('status','actual_public_shape_boundary_and_short_rank_rejection_passed', ...
        'cases',{cases},'extra_analog_fields_rejected',true,'holdout_field_rejected',true, ...
        'invalid_training_rejected',true,'out_of_plan_rejected',true,'global_rng_unchanged',true, ...
        'external_train_reference_used',false,'coefficient_fit','NOT_RUN', ...
        'full_rank','NOT_ESTABLISHED','holdout','NOT_RUN','main_graph_commit','NOT_RUN');
end
function rejects(f,id)
    ok=false;try,f();catch e,ok=strcmp(e.identifier,id);end
    assert(ok,'publicCalTest:reject','Expected explicit boundary error %s.',id);
end
