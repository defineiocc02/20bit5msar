oldBehaviorPath=path; behaviorCleanup=onCleanup(@()path(oldBehaviorPath));
addpath('D:/Temp/SAR20Behavior/integration');
behavior_native_probe;
clear behaviorCleanup;
