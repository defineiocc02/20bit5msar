function behavior_native_probe()
%BEHAVIOR_NATIVE_PROBE v1.0 — run actual MATLAB kernels and preserve errors.
% Called only by root's existing-MATLAB controller. Does not modify old models.
    here=fileparts(mfilename('fullpath')); stage=fileparts(here);
    project='D:/Academic/Projects/sar20m1/SAR20';
    output=fullfile(pwd,'actual'); if ~isfolder(output),mkdir(output);end
    oldPath=path; cleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(stage));
    addpath(fullfile(project,'current','matlab'));
    report=struct('status','running','stage','load_parameters');
    write_report();
    try
        binding=jsondecode(fileread(fullfile(project,'state','current_binding.json')));
        S=load(binding.workspace_snapshot_file,'SAR20_P');
        P=behavior_parameters(S.SAR20_P,8);
        report.stage='control_test';write_report();
        report.control=test_behavior_control();
        A=struct('A0',P.backend.ra.A0,'UGB_hz',P.backend.ra.UGB_hz, ...
            'Cf_f',P.backend.ra.Cf_f,'tau_reset_s',P.backend.ra.tau_reset_s);
        report.backend=check_behavior_backend(S.SAR20_P,A);
        report.stage='actual_capture';write_report();
        oldRng=rng;
        [capture,elapsed]=behavior_run_capture(P);
        save(fullfile(output,'capture.mat'),'capture','P','elapsed','-v7');
        report.elapsed_s=elapsed;
        report.stage='same_input_repeat';write_report();
        [repeatCapture,repeatElapsed]=behavior_run_capture(P);
        save(fullfile(output,'repeat.mat'),'repeatCapture','repeatElapsed','-v7');
        report.repeat_elapsed_s=repeatElapsed;
        report.rng_unchanged=isequal(oldRng,rng);
        report.validation=behavior_validate_capture(capture,struct('nominal',P.digital),repeatCapture);
        report.codes=[capture.samples.code20];
        report.status='behavior_kernels_actual_n8_complete';
        report.stage='complete';
        report.scope='MATLAB event-kernel integration only; Simulink integration still pending';
        write_report();
    catch cause
        report.status='failed';report.identifier=cause.identifier;
        report.error=getReport(cause,'extended','hyperlinks','off');
        save(fullfile(output,'partial.mat'),'report','-v7');
        write_report();
        rethrow(cause);
    end
    function write_report()
        fid=fopen(fullfile(output,'result.json'),'w','n','UTF-8');
        assert(fid>=0,'behavior:resultWrite','Cannot write result.');
        fprintf(fid,'%s',jsonencode(report));fclose(fid);
    end
end
