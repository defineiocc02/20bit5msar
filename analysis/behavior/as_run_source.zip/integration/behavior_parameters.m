function P=behavior_parameters(saved,N)
%BEHAVIOR_PARAMETERS v1.0 — explicit baseline for the event model, 2026-10-27.
% Call P=behavior_parameters(savedSAR20_P,8). Units: V,F,s,Hz; IDs are integers.
% Only nominal geometry/scales are inherited. No old analog state is imported.
% Baseline intentionally disables noise/mismatch/dither/DEM and assumes settled
% acquisition/DAC. RA uses a finite declared single pole, not the old MNA model.
% This is an implementation baseline; it is not a reproduction-performance claim.
    P=struct('schema','sar20-behavior/v1','Ts_s',200e-9,'N',N, ...
        'first_id',4,'epoch',1,'seed',20261020);
    P.input=struct('offset_v',0,'amplitude_v',3.650563842595822, ...
        'frequency_hz',97656.25,'phase_rad',0.731);
    % 28 pF per half across the eight active 1056Cu arrays is a design assumption.
    unit=28e-12/(8*1056);
    options=struct('plan_rows',max(32,N+P.first_id+4),'unit_cap_f',unit, ...
        'input',P.input,'dem_enabled',false,'dither_enabled',false, ...
        'mismatch_enabled',false,'ktc_enabled',false);
    [~,P.front]=behavior_frontend_init(options);
    Csample=8*1024*unit;
    A=struct('A0',1e4,'UGB_hz',1.2e9,'Cf_f',Csample/32,'tau_reset_s',1e-9);
    P.backend=behavior_backend_parameters(saved,A);
    P.backend.ni.cap_mismatch=false;
    P.backend.ni.cinc_kick=true;
    P.backend.ni.az=false;
    P.control=behavior_control_parameters(saved);
    P.control.sar1.coarse_offset_v=0;
    P.control.sar1.coarse_noise_rms_v=0;
    P.digital=behavior_decode_parameters(saved,P.front.vref_v);
    P.digital.dither_enabled=false;
    P.fs_hz=1/P.Ts_s;P.fsr_diff_v=P.digital.fsr_diff_v;
    P.ni=struct('ra_finite_gain',true,'ra_finite_bandwidth',true, ...
        'sample_ktc',false,'sample_settling',false,'dac_settling',false, ...
        'cap_mismatch',false,'parasitic',false,'jitter',false,'az',false, ...
        'reference_recovery',false,'comparator_noise',false);
    P.assumptions={'RA A0/UGB/closed-loop single pole are design assumptions'; ...
        'Sampling/DAC initially fully settled; their finite-settling tests pending'; ...
        'CINC geometry/scaling inherited from the nominal saved configuration'; ...
        'No calibration and no pin-level LVDS timing claim'};
end
