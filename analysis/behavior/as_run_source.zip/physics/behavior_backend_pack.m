function v=behavior_backend_pack(s)
%BEHAVIOR_BACKEND_PACK Convert named backend state to a fixed UnitDelay vector.
%Version: v1 (2026-10-27). Caller: backend initializer/commit adapter.
%Input s; output v[35,1] finite double, with original mixed units preserved.
%1 time [s]; 2 vx [V]; 3:4 AZ half [V]; 5 reset vx [V]; 6:7 main QB [C];
%8:9 replica QB [C]; 10:11 previous switch charge [C]; 12 cmd Qres [C];
%13 cmd total Ctop [F]; 14:25 D2 signs; 26:32 TA signs; 33:35 on/AZ/reset flags.
%Pure module-specific ABI conversion; no analog advancement, reset or hidden state.
    c=s.command;
    v=[s.time_s;s.vx_v;s.az_input_half_v(:);s.ct_reset_vx_v; ...
        s.main_qb_c(:);s.replica_qb_c(:);s.previous_switch_charge_c(:); ...
        c.qres_c;c.ctop_f;c.d2_signs(:);c.ta_signs(:); ...
        double(c.ra_on);double(c.az_on);double(c.reset)];
    assert(isa(v,'double')&&isequal(size(v),[35 1])&&all(isfinite(v)), ...
        'behavior:pack','Backend retained state must pack to 35 finite doubles.');
end
