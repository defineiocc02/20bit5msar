function behavior_backend_sfun(block)
%BEHAVIOR_BACKEND_SFUN Pure Level-2 backend adapter, v1 2026-10-27.
% Dialog parameters: kind ('advance' or 'commit'), P.backend (named parameters).
% Inputs: state35, event time [s], command24. Outputs: next state35, obs8.
% Numerical definitions and reset behavior: behavior_backend_stage/step.
% Caller: new behavior SLX. No DWork/UserData/persistent/RNG or Update method;
% standard UnitDelay outside these stages is the sole retained state owner.
    setup(block);
end

function setup(block)
    block.NumDialogPrms=2;
    block.DialogPrmsTunable={'Nontunable','Nontunable'};
    kind=block.DialogPrm(1).Data;
    assert((ischar(kind)||isstring(kind))&&any(strcmp(char(kind),{'advance','commit'})), ...
        'behavior:sfunKind','Backend stage must be advance or commit.');
    block.NumInputPorts=3;block.NumOutputPorts=2;
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;
    inputWidths=[35 1 24];outputWidths=[35 8];
    for k=1:3
        block.InputPort(k).Dimensions=inputWidths(k);
        block.InputPort(k).DatatypeID=0;
        block.InputPort(k).Complexity='Real';
        block.InputPort(k).DirectFeedthrough=true;
    end
    for k=1:2
        block.OutputPort(k).Dimensions=outputWidths(k);
        block.OutputPort(k).DatatypeID=0;
        block.OutputPort(k).Complexity='Real';
    end
    block.SampleTimes=[-1 0];
    block.NumContStates=0;block.SimStateCompliance='DefaultSimState';
    block.RegBlockMethod('Outputs',@outputs);
end

function outputs(block)
    [next,obs]=behavior_backend_stage(block.DialogPrm(1).Data, ...
        block.InputPort(1).Data,block.InputPort(2).Data, ...
        block.InputPort(3).Data,block.DialogPrm(2).Data);
    block.OutputPort(1).Data=next;
    block.OutputPort(2).Data=obs;
end
