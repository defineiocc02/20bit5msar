function report=check_behavior_backend(saved,A)
%CHECK_BEHAVIOR_BACKEND Check the isolated analytic backend and fixed state ABI.
%Version: v1 (2026-10-27). Caller: native MATLAB developer check(saved,A).
%Inputs saved SAR20_P and explicit engineering A as in backend_parameters;
%output report contains check status/width/scope, not ADC performance metrics.
%Creates local states and parameter overrides to check pole/AZ/kick/zero-dt/packing
%and unsupported-NI rejection; does not reset or mutate a running model.
%No whole-model run/noise-statistics/PDK claim follows from these isolated checks.
    p=behavior_backend_parameters(saved,A);
    p.ra.A0=1e4;p.ra.UGB_hz=1.2e9;p.ra.slew_v_per_s=Inf;
    p.ni.az=false;p.ni.cinc_kick=false;
    c=struct('qres_c',p.ra.Cf_f*0.1,'ctop_f',31*p.ra.Cf_f, ...
        'd2_signs',zeros(12,1),'ta_signs',zeros(7,1), ...
        'ra_on',true,'az_on',false,'reset',false);
    [s,~]=behavior_backend_step([],c,0,p);
    dt=3e-9;[s1,y]=behavior_backend_step(s,c,dt,p);
    gain=1e4/(1e4+32);tau=32/(2*pi*1.2e9);
    expected=gain*0.1*(-expm1(-dt/tau));
    assert(abs(y.vx_v-expected)<=8*eps(expected),'behavior:testPole','Single-pole endpoint differs.');
    assert(abs(y.noise_gain-32)<=8*eps(32)&&abs(y.target_v-0.1)<=8*eps(0.1), ...
        'behavior:testScaling','Q/Cf or Ctop noise gain differs.');
    [same,~]=behavior_backend_step(s1,c,0,p);
    assert(isequal(typecast(behavior_backend_pack(same),'uint64'), ...
        typecast(behavior_backend_pack(s1),'uint64')),'behavior:testZeroTime','dt=0 changed retained bits.');
    assert(isequaln(behavior_backend_unpack(behavior_backend_pack(s1)),s1), ...
        'behavior:testPacking','Fixed UnitDelay pack/unpack failed.');
    p.ni.az=true;p.az.target_input_half_v=[20e-6;-20e-6];
    p.az.write_tau_s=[2e-9;2e-9];
    c.ra_on=false;c.az_on=true;c.reset=true;
    [az0,~]=behavior_backend_step([],c,0,p);
    [az1,~]=behavior_backend_step(az0,c,2e-9,p);
    expectedAz=p.az.target_input_half_v*(-expm1(-1));
    assert(max(abs(az1.az_input_half_v-expectedAz))<=8*eps(max(abs(expectedAz))), ...
        'behavior:testAZ','AZ RC write endpoint differs.');
    p.ni.az=false;p.ni.cinc_kick=true;p.ni.cap_mismatch=false;
    c.ra_on=true;c.az_on=false;c.reset=false;
    [base,~]=behavior_backend_step([],c,0,p);
    switched=c;switched.d2_signs(1)=1;
    [~,k]=behavior_backend_step(base,switched,0,p);
    assert(all(k.kick_half_v==0),'behavior:testReplica','Matched inverse replica did not cancel.');
    p.ct.replica_enabled=false;
    [~,k]=behavior_backend_step(base,switched,0,p);
    assert(k.kick_diff_v~=0&&k.vx_v==k.predicted.vx_v+k.kick_diff_v, ...
        'behavior:testKick','Main CINC switch did not kick the same RA output.');
    packed=behavior_backend_pack(base);
    command=[switched.qres_c;switched.ctop_f;switched.d2_signs; ...
        switched.ta_signs;double(switched.ra_on);double(switched.az_on);double(switched.reset)];
    [advanced,~]=behavior_backend_stage('advance',packed,dt,command,p);
    retained=behavior_backend_unpack(advanced);
    assert(advanced(1)==dt&&all(retained.command.d2_signs==0), ...
        'behavior:testStageOrder','Advance consumed the new feedback command.');
    [committed,obs]=behavior_backend_stage('commit',advanced,dt,command,p);
    [again,obsAgain]=behavior_backend_stage('commit',advanced,dt,command,p);
    assert(committed(14)==1&&isequal(typecast(committed,'uint64'),typecast(again,'uint64'))&& ...
        isequal(typecast(obs,'uint64'),typecast(obsAgain,'uint64')), ...
        'behavior:testStagePurity','Commit did not retain command or repeat deterministically.');
    p.ni.ra_noise=true;rejected=false;
    try,behavior_backend_step(base,c,0,p);
    catch e,rejected=strcmp(e.identifier,'behavior:unsupportedNI');end
    assert(rejected,'behavior:testNI','Unsupported NI did not fail visibly.');
    report=struct('status','analytic_pole_AZ_kick_layout_checks_passed', ...
        'state_width',35,'whole_model_run',false,'noise_statistics_verified',false);
end
