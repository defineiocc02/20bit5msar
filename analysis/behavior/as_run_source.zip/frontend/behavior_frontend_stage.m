function [xnext,obs,out] = behavior_frontend_stage(kind,x,context,p)
%BEHAVIOR_FRONTEND_STAGE Pure named advance/commit adapter for one UnitDelay.
% Context6=[t_s,id,epoch,event,d1_code,vtop_v], all double.
% advance: 0 observe, 1 CNV(capture/join/open next), 2 startup open, 3 reset.
% commit: 0 observe, 1 registered DAC command, 2 backend return/release, 3 reset.
% Obs7=[coarse_input_v,vres_v,qres_c,cs_f,ctop_f,vtop_equiv_v,dither_input_v].
% All state resides in external x[317]; no scheduler/SAR/backend is embedded.
    kind=char(kind);
    assert(any(strcmp(kind,{'advance','commit'})),'behaviorFE:stageKind','Use advance or commit.');
    assert(isnumeric(context)&&isreal(context)&&numel(context)==6, ...
        'behaviorFE:contextWidth','Expected [time,id,epoch,event,D1,vtop].');
    c=double(context(:));
    assert(all(isfinite(c(1:4)))&&c(4)==floor(c(4))&&c(4)>=0&&c(4)<=3, ...
        'behaviorFE:contextEvent','Context time/tags/event must be finite; event integer 0..3.');
    s=behavior_frontend_unpack(x,p);
    cmd=struct('event','observe','t_s',c(1),'id',c(2),'epoch',c(3));
    % Always analytically advance the old phase before any topology/command event.
    [s,out]=behavior_frontend_step(s,cmd,p);
    if strcmp(kind,'advance')
        switch c(4)
            case 1
                cmd.event='capture';[s,~]=behavior_frontend_step(s,cmd,p);
                cmd.event='convert_join';[s,~]=behavior_frontend_step(s,cmd,p);
                cmd.event='acquire_open';cmd.id=c(2)+1;
                [s,~]=behavior_frontend_step(s,cmd,p);
                cmd.event='observe';cmd.id=c(2);[s,out]=behavior_frontend_step(s,cmd,p);
            case 2
                cmd.event='acquire_open';[s,out]=behavior_frontend_step(s,cmd,p);
            case 3
                cmd.event='reset';[s,out]=behavior_frontend_step(s,cmd,p);
        end
    else
        switch c(4)
            case 1
                cmd.event='dac_commit';cmd.d1_code=c(5);
                [s,out]=behavior_frontend_step(s,cmd,p);
            case 2
                cmd.event='release';cmd.vtop_v=c(6);
                [s,out]=behavior_frontend_step(s,cmd,p);
            case 3
                cmd.event='reset';[s,out]=behavior_frontend_step(s,cmd,p);
        end
    end
    xnext=behavior_frontend_pack(s);
    obs=[out.coarse_input_v;out.vres_v;out.qres_c;out.cs_f;out.ctop_f; ...
        out.vtop_equiv_v;out.dither_input_v];
end
