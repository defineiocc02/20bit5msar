function behavior_event_source(block)
%BEHAVIOR_EVENT_SOURCE Emit one variable-time scheduler hit per exact event group.
%Version: v1 (2026-10-27). Caller: Level-2 MATLAB S-Function block in behavior model.
%Dialog P: sample_period_s [s]=200 ns, n_cycles [integer], groups, optional stop_time_s [s].
%Output double[2]=[zero-based cycle_id; one-based group_index]; no input ports.
%Only DWork is hit_index; Start at t=0 clears it, Outputs reads it/sets NextTimeHit,
%Update alone commits its increment. No analog/SAR reset, RNG or hidden cache.
%Sample time [-2 0]; optional frame_ready +138 ns is routed outside sar_step.
%Model is a declared calendar, not base-rate polling; native Simulink compile/run
%is still required. API: mathworks.com/help/simulink/sfg/mdlgettimeofnextvarhit.html
    block.NumDialogPrms=1;
    block.DialogPrmsTunable={'Nontunable'};
    P=block.DialogPrm(1).Data;
    validate_parameters(P);
    period=double(P.sample_period_s);
    offsets=reshape(double([P.groups.time_s]),[],1);
    groupCount=numel(offsets);totalHits=double(P.n_cycles)*groupCount;
    if isfield(P,'stop_time_s'),stopTime=double(P.stop_time_s);
    else,stopTime=double(P.n_cycles)*period;end
    lastHit=(double(P.n_cycles)-1)*period+offsets(end);
    assert(isscalar(stopTime)&&isfinite(stopTime)&&stopTime>=lastHit, ...
        'behavior:source:stopTime','stop_time_s must include the final scheduled hit.');
    block.NumInputPorts=0;block.NumOutputPorts=1;
    block.SetPreCompPortInfoToDefaults;
    block.OutputPort(1).Dimensions=2;
    block.OutputPort(1).DatatypeID=0;
    block.OutputPort(1).Complexity='Real';
    block.SampleTimes=[-2 0];
    block.NumContStates=0;
    block.SimStateCompliance='DefaultSimState';
    block.RegBlockMethod('PostPropagationSetup',@work);
    block.RegBlockMethod('Start',@start);
    block.RegBlockMethod('Outputs',@outputs);
    block.RegBlockMethod('Update',@update);

    function work(b)
        b.NumDworks=1;
        b.Dwork(1).Name='hit_index';b.Dwork(1).Dimensions=1;
        b.Dwork(1).DatatypeID=0;b.Dwork(1).Complexity='Real';
        b.Dwork(1).UsedAsDiscState=true;
    end
    function start(b)
        assert(b.CurrentTime==0,'behavior:source:start','Event source requires model StartTime=0.');
        b.Dwork(1).Data=0;
    end
    function outputs(b)
        hit=double(b.Dwork(1).Data);
        assert(isscalar(hit)&&hit==floor(hit)&&hit>=0&&hit<=totalHits, ...
            'behavior:source:index','Invalid scheduler hit_index.');
        if hit<totalHits
            cycle=floor(hit/groupCount);group=mod(hit,groupCount)+1;
            b.OutputPort(1).Data=[cycle;group];
            following=hit+1;
            if following<totalHits
                nextCycle=floor(following/groupCount);
                nextGroup=mod(following,groupCount)+1;
                nextHit=nextCycle*period+offsets(nextGroup);
            else,nextHit=stopTime+period;end
        else
            b.OutputPort(1).Data=[-1;0];nextHit=stopTime+period;
        end
        assert(nextHit>b.CurrentTime,'behavior:source:strictFuture', ...
            'NextTimeHit must be strictly future; no epsilon or shifted event is permitted.');
        b.NextTimeHit=nextHit;
    end
    function update(b)
        hit=double(b.Dwork(1).Data);
        if hit<totalHits,b.Dwork(1).Data=hit+1;end
    end
end

function validate_parameters(P)
    assert(isstruct(P)&&isscalar(P)&&all(isfield(P,{'sample_period_s','n_cycles','groups'})), ...
        'behavior:source:parameters','P requires sample_period_s, n_cycles and groups.');
    assert(isscalar(P.sample_period_s)&&isfinite(P.sample_period_s)&& ...
        abs(double(P.sample_period_s)-200e-9)<1e-18, ...
        'behavior:source:period','Require sample_period_s=200 ns.');
    assert(isscalar(P.n_cycles)&&isfinite(P.n_cycles)&&P.n_cycles>=1&& ...
        P.n_cycles==floor(P.n_cycles), ...
        'behavior:source:cycles','n_cycles must be a positive integer including warmup and flush.');
    assert(isstruct(P.groups)&&~isempty(P.groups)&&all(isfield(P.groups,{'time_s','events'})), ...
        'behavior:source:groups','Require ordered grouped event structs.');
    times=double([P.groups.time_s]);
    assert(isreal(times)&&all(isfinite(times))&&times(1)==0&& ...
        all(diff(times)>0)&&times(end)<P.sample_period_s, ...
        'behavior:source:offsets','Group times must start at zero and increase strictly within one CNV period.');
end
