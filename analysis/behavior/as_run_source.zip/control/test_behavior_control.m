function report = test_behavior_control()
%TEST_BEHAVIOR_CONTROL Run bounded synthetic controller/calendar/ABI assertions.
%Version: v1 (2026-10-27). Caller: native MATLAB developer check, no inputs.
%Output report has synthetic status, counts, widths and public RAW integer words.
%Uses local state and artificial comparator bits/voltages [V], event times [s];
%checks fine5/D2-12/TA8/feedback7 plus pack/unpack and explicit-bit precedence.
%No running-model reset, RNG, files, path changes or source replay.
%This does not simulate an actual ADC or validate settling/noise/performance.
    p=struct('sample_period_s',200e-9,'sar1',struct('delta_v',8/1024, ...
        'coarse_offset_v',0,'coarse_noise_rms_v',0),'sar2',struct());
    events=behavior_calendar(p);groups=behavior_event_groups(events);
    assert(numel(events)==73&&numel(groups)==48);
    withFrame=behavior_event_groups(events,true);
    assert(numel(withFrame)==49&&withFrame(end).time_s==138e-9);
    assert(strcmp(withFrame(end).events.type,'frame_ready'));
    assert(sum(strcmp({events.type},'d2_decide'))==12);
    assert(sum(strcmp({events.type},'ta_compare'))==8);
    assert(sum(strcmp({events.type},'ta_feedback'))==7);
    [s,~]=behavior_sar_step([],struct('type','reset'),struct(),p);
    x=behavior_sar_pack(s);assert(isequal(x,behavior_sar_pack(behavior_sar_unpack(x))));
    ready=0;record=struct();
    for k=1:numel(groups)
        for j=1:numel(groups(k).events)
            e=groups(k).events(j);e.sample_id=4;e.epoch=1;e.absolute_time_s=e.time_s;
            c=struct('sample_v',0,'vres_v',0,'vy_v',0,'decision1',mod(e.index+1,2), ...
                'decision2',mod(e.index+1,2),'valid',true,'late',false);
            [s,out]=behavior_sar_step(behavior_sar_unpack(x),e,c,p);
            x=behavior_sar_pack(s);assert(isequal(x,behavior_sar_pack(behavior_sar_unpack(x))));
            if out.record_ready,ready=ready+1;record=out.record;end
        end
    end
    assert(ready==1&&record.valid==1&&record.raw_D1==32*32+21);
    assert(record.raw_D2==hex2dec('AAA')&&record.raw_DT==hex2dec('AA'));
    assert(s.d2_count==12&&s.track_count==8&&s.feedback_count==7&&s.fine_count==5);
    assert(isequal(s.tracking_signs,[1;-1;1;-1;1;-1;1]));
    assert(~s.active&&~s.ra_on);
    % Explicit Relational Operator bits take precedence over the >=0 fallback:
    % all supplied voltages were zero, yet alternating decision=0 remained 0.
    report=struct('status','controller_synthetic_native_test_pass','events',73, ...
        'sample_hits',48,'state_width',51,'record',record,'D2_count',s.d2_count, ...
        'TA_compare_count',s.track_count,'TA_feedback_count',s.feedback_count, ...
        'actual_ADC_simulated',false);
end
