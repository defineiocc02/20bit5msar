function report = test_behavior_control_stages()
%TEST_BEHAVIOR_CONTROL_STAGES v1 (2026-10-27): short synthetic stage parity.
% Compare due/prepare/decide pipeline to directly ordered pure SAR controller.
% No ADC/model/source simulation, RNG or path/file changes. Native MATLAB test.
    q=struct('sample_period_s',200e-9,'sar1',struct('delta_v',8/1024, ...
        'coarse_offset_v',0,'coarse_noise_rms_v',0),'sar2',struct());
    P=struct('control',q,'groups',behavior_event_groups(behavior_calendar(q),true), ...
        'Ts_s',200e-9,'epoch',1);
    [s,~]=behavior_sar_step([],struct('type','reset'),struct(),q);
    x=behavior_sar_pack(s);reference=x;readyCount=0;cnvCount=0;releaseCount=0;
    obs=zeros(7,1);
    for g=1:numel(P.groups)
        events=P.groups(g).events;d1=1;d2=1;
        for j=1:numel(events)
            if strcmp(events(j).type,'fine_decide'),d1=mod(events(j).index+1,2);end
            if any(strcmp(events(j).type,{'d2_decide','ta_compare'})),d2=mod(events(j).index+1,2);end
        end
        cmp=[d1;d2;0];
        [x,~,~]=behavior_control_stage('due',x,[0;g],obs,cmp,P);
        [x,a,~]=behavior_control_stage('prepare',x,[0;g],obs,cmp,P);
        [x,b,z]=behavior_control_stage('decide',x,[0;g],obs,cmp,P);
        cnvCount=cnvCount+a(11);readyCount=readyCount+b(4);releaseCount=releaseCount+b(12);
        c=struct('sample_v',0,'vres_v',0,'vy_v',0,'decision1',d1,'decision2',d2, ...
            'valid',true,'late',false);
        s=behavior_sar_unpack(reference);
        for j=1:numel(events)
            e=events(j);
            if strcmp(e.type,'frame_ready'),continue;end
            e.absolute_time_s=P.groups(g).time_s;e.sample_id=0;e.epoch=1;
            [s,~]=behavior_sar_step(s,e,c,q);
        end
        reference=behavior_sar_pack(s);assert(isequal(x,reference), ...
            'behavior:test:stageParity','Stage/pure controller differ at group %d.',g);
        assert(numel(a)==13&&numel(b)==13&&numel(z)==19);
    end
    assert(cnvCount==1&&readyCount==1&&releaseCount==1);
    assert(s.d1raw==1045&&s.d2raw==hex2dec('AAA')&&s.dtraw==hex2dec('AA'));
    assert(s.feedback_count==7&&s.track_count==8&&s.d2_count==12);
    report=struct('status','synthetic_stage_pipeline_parity_pass', ...
        'groups_including_frame',49,'state_width',51,'signals_width',13, ...
        'signs_width',19,'RAW_ready_events',readyCount,'actual_ADC_simulated',false);
end
