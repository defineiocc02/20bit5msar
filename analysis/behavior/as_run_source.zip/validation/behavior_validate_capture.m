function report=behavior_validate_capture(capture,p,repeatCapture)
%BEHAVIOR_VALIDATE_CAPTURE Check an actual event capture against public contracts.
%Version: v1 (2026-10-27). Caller: behavior run validation; returns report only.
%Inputs capture.samples: sample_id/epoch, integer D1/D2/DT/code20, valid, events;
%events include time_s [s], kind/index/decision/IDs, state versions and RNG words.
%capture.ni_mode/ni/seed declare actual toggles; deterministic NIoff alone may omit seed.
%p.nominal is decode_parameters output; optional decode_reference(publicSamples,p.nominal)
%returns independent integer codes. Only public D1/D2/DT/ID/epoch/valid enter reference.
%Optional repeatCapture requires same settings/seed/input_identity and compares full traces.
%Stateless read-only validation; no model reset, truth/held/residual input or RNG use.
%Independent nominal math is a validation oracle, not an analog/signoff model.
    if nargin<3,repeatCapture=[];end
    assert(isstruct(capture)&&isscalar(capture)&&isfield(capture,'samples'), ...
        'BehaviorValidate:capture','Require an actual event capture.');
    samples=capture.samples;assert(isstruct(samples)&&~isempty(samples), ...
        'BehaviorValidate:samples','No actual samples.');
    assert(all(isfield(samples,{'sample_id','epoch','D1','D2','DT','code20','valid','events'})), ...
        'BehaviorValidate:sampleFields','Missing public sample fields/events.');
    assert(all(isfield(capture,{'ni_mode','ni','seed'}))&& ...
        any(strcmp(capture.ni_mode,{'off','on'}))&&isstruct(capture.ni)&&isscalar(capture.ni), ...
        'BehaviorValidate:ni','Record actual NI mode/toggles and explicit seed.');
    toggles=fieldnames(capture.ni);assert(~isempty(toggles),'BehaviorValidate:ni','Empty NI inventory.');
    enabled=false(size(toggles));
    for k=1:numel(toggles)
        v=capture.ni.(toggles{k});assert(islogical(v)&&isscalar(v), ...
            'BehaviorValidate:ni','NI toggles must be explicit logical scalars.');enabled(k)=v;
    end
    assert((strcmp(capture.ni_mode,'off')&&~any(enabled))|| ...
        (strcmp(capture.ni_mode,'on')&&any(enabled)), ...
        'BehaviorValidate:niLabel','NI mode label disagrees with actual toggles.');
    if isempty(capture.seed)
        assert(strcmp(capture.ni_mode,'off'),'BehaviorValidate:seed','Only deterministic NIoff may omit seed.');
    else
        assert(isnumeric(capture.seed)&&isreal(capture.seed)&&isscalar(capture.seed)&& ...
            isfinite(capture.seed)&&capture.seed>=0&&capture.seed==floor(capture.seed), ...
            'BehaviorValidate:seed','Invalid explicit seed.');
    end
    ids=[samples.sample_id];epochs=[samples.epoch];
    integer_range(ids,0,2^32-1,'sample IDs');integer_range(epochs,0,2^32-1,'epochs');
    assert(all(diff(ids)==1)&&all(epochs==epochs(1)), ...
        'BehaviorValidate:tags','Require contiguous IDs and one epoch.');
    integer_range([samples.D1],0,2^11-1,'D1');
    integer_range([samples.D2],0,2^12-1,'D2');
    integer_range([samples.DT],0,2^8-1,'DT');
    integer_range([samples.code20],0,2^20-1,'code20');
    assert(all([samples.valid]==1),'BehaviorValidate:valid','Invalid actual conversion.');
    required={'time_s','kind','index','decision','decision_id','consumed_decision_id', ...
        'state_version_before','state_version_after','rng_before','rng_after'};
    rows=cell(numel(samples),1);public=repmat(struct('sample_id',0,'epoch',0, ...
        'D1',0,'D2',0,'DT',0,'valid',true),numel(samples),1);
    frames=zeros(numel(samples),1,'uint32');allOutputChecks=0;
    for k=1:numel(samples)
        s=samples(k);events=s.events;
        assert(isstruct(events)&&~isempty(events)&&all(isfield(events,required)), ...
            'BehaviorValidate:events','Incomplete event trace for sample %g.',s.sample_id);
        times=[events.time_s];assert(all(isfinite(times))&&all(diff(times)>=0), ...
            'BehaviorValidate:time','Event time reversed/nonfinite for sample %g.',s.sample_id);
        kinds={events.kind};d2=find(strcmp(kinds,'d2_decide'));d2f=find(strcmp(kinds,'d2_feedback'));
        ta=find(strcmp(kinds,'ta_compare'));taf=find(strcmp(kinds,'ta_feedback'));
        assert(numel(d2)==12&&isequal([events(d2).index],0:11)&& ...
            numel(d2f)==12&&isequal([events(d2f).index],0:11)&& ...
            numel(ta)==8&&isequal([events(ta).index],0:7)&& ...
            numel(taf)==7&&isequal([events(taf).index],0:6), ...
            'BehaviorValidate:eventCounts','Sample %g must have ordered 12D2/12D2-feedback/8TA/7TA-feedback.',s.sample_id);
        assert(d2f(end)<ta(1),'BehaviorValidate:phase','TA starts before D2 feedback completion.');
        comparisons=[d2 ta];decisionIds=[events(comparisons).decision_id];
        assert(numel(decisionIds)==20&&numel(unique(decisionIds))==20&& ...
            all(isfinite(decisionIds)),'BehaviorValidate:decisionIDs','Comparison decision IDs must be unique.');
        integer_range([events(comparisons).decision],0,1,'comparison bits');
        check_feedback(events,d2,d2f,s.sample_id);check_feedback(events,ta(1:7),taf,s.sample_id);
        assert(taf(end)<ta(end),'BehaviorValidate:lastTA','Last TA comparison must see all seven prior updates.');
        % The raw words must contain these actual comparison bits, MSB first.
        expectedD2=sum(double([events(d2).decision]).*2.^(11:-1:0));
        expectedDT=sum(double([events(ta).decision]).*2.^(7:-1:0));
        assert(s.D2==expectedD2&&s.DT==expectedDT, ...
            'BehaviorValidate:rawWords','Actual D2/DT disagree with comparison decisions for sample %g.',s.sample_id);
        outputEvents=find(strcmp(kinds,'outputs'));
        for j=outputEvents
            assert(exact(events(j).state_version_before,events(j).state_version_after)&& ...
                exact(events(j).rng_before,events(j).rng_after), ...
                'BehaviorValidate:outputsMutation','Outputs committed state/RNG for sample %g.',s.sample_id);
        end
        allOutputChecks=allOutputChecks+numel(outputEvents);
        frames(k)=bitor(bitor(bitshift(uint32(s.D1),21),bitshift(uint32(s.D2),9)), ...
            bitor(bitshift(uint32(s.DT),1),uint32(s.valid)));
        frameRecorded=isfield(s,'frame_word');
        if frameRecorded
            assert(isequal(uint32(s.frame_word),frames(k))&&double(s.frame_word)==double(frames(k)), ...
                'BehaviorValidate:frame','Frame packing differs from D1/D2/DT/VALID.');
        end
        for name=fieldnames(public).',public(k).(name{1})=s.(name{1});end
        rows{k}=struct('sample_id',s.sample_id,'epoch',s.epoch,'d2_comparisons',12, ...
            'ta_comparisons',8,'ta_updates',7,'comparison_precedes_feedback',true, ...
            'raw_words_match_decisions',true,'outputs_purity_checks',numel(outputEvents), ...
            'frame_word',double(frames(k)),'captured_frame_checked',frameRecorded);
    end
    reconstruction='not_run_independent_reference_missing';referenceCodes=[];
    if isfield(p,'nominal')
        if isfield(p,'decode_reference')
            assert(isa(p.decode_reference,'function_handle'), ...
            'BehaviorValidate:decodeReference','Supply independent callback and frozen nominal parameters.');
            referenceCodes=p.decode_reference(public,p.nominal);
        else
            referenceCodes=nominal_public_decode(public,p.nominal);
        end
        referenceCodes=double(referenceCodes(:));
        integer_range(referenceCodes,0,2^20-1,'independent reconstructed codes');
        assert(isequal(referenceCodes,double([samples.code20].')), ...
            'BehaviorValidate:decode','Actual code20 differs from independent public-word reconstruction.');
        reconstruction='actual_public_words_independently_reconstructed';
    end
    repeated='not_run';
    if ~isempty(repeatCapture)
        for field={'ni_mode','ni','seed','input_identity'}
            name=field{1};assert(isfield(capture,name)&&isfield(repeatCapture,name)&& ...
                exact(capture.(name),repeatCapture.(name)), ...
                'BehaviorValidate:repeatIdentity','Repeat identity mismatch or missing %s.',name);
        end
        assert(isfield(repeatCapture,'samples')&&exact(samples,repeatCapture.samples), ...
            'BehaviorValidate:repeat','Same-seed actual raw/code/event capture differs.');
        repeated='same_seed_public_words_codes_and_recorded_events_exact';
    end
    report=struct('schema','sar20-behavior-functional-validation/v1','status','event_gate_pass_pending_missing_evidence', ...
        'sample_count',numel(samples),'samples',vertcat(rows{:}),'reconstruction',reconstruction, ...
        'reference_codes',referenceCodes,'outputs_purity_checks',allOutputChecks, ...
        'outputs_purity_status','not_run_missing_outputs_probe_events', ...
        'same_seed_repeat',repeated,'ni_mode',capture.ni_mode,'ni',capture.ni,'seed',capture.seed, ...
        'ni_direction_status','not_run_requires_controlled_off_on_pair', ...
        'scope','Event-level behavior contract only; not old physical-kernel bit equivalence, NI direction, or circuit signoff', ...
        'time_tolerance_used',[],'performance','not_run_use_behavior_spectrum_for_N_ge_256');
    if allOutputChecks>0,report.outputs_purity_status='recorded_outputs_state_rng_unchanged';end
    if all(cellfun(@(x)x.outputs_purity_checks>0&&x.captured_frame_checked,rows))&& ...
            strcmp(reconstruction,'actual_public_words_independently_reconstructed')&&~isempty(repeatCapture)
        report.status='behavior_functional_gate_pass';
    end
end

function codes=nominal_public_decode(records,n)
% Independent arithmetic from declared nominal geometry/public bits only.
% D1: bipolar 1039Cu switch bank minus +17Cu capture bias, input C=1024Cu.
% DT: frame-reset dual integrator, then original scale1/8, not a sum36 average.
    assert(strcmp(n.tracking_mode,'finite_sinc2')&&strcmp(n.calibration_mode,'off')&& ...
        numel(n.d2_weights_ra_v)==12&&n.ra_gain==32, ...
        'BehaviorValidate:nominal','Require reviewed nominal M8/RA32 behavior decode parameters.');
    weights=[512;256;128;64;32;16;16;8;4;2;1];codes=zeros(numel(records),1);
    for k=1:numel(records)
        r=records(k);d1=double(bitget(uint32(r.D1),11:-1:1)).';
        d2=double(bitget(uint32(r.D2),12:-1:1)).';
        dt=double(bitget(uint32(r.DT),8:-1:1)).';
        switchV=sum(weights.*(2*d1-1))*n.vref_v/1024;
        captureBiasV=-17*n.vref_v/1024;coarseFineV=switchV+captureBiasV;
        fineRA=n.d2_offset_ra_v+sum(n.d2_weights_ra_v(:).*d2);
        first=0;second=0;
        for j=1:8,first=first+(2*dt(j)-1);second=second+first;end
        trackRA=n.tracking_step_ra_v*(second/8);
        dith=0;
        if n.dither_enabled
            modulus=2147483647;word=mod(double(n.dither_seed),modulus-1)+1;
            for j=1:(r.sample_id+1),word=mod(16807*word,modulus);end
            dith=(floor(4*word/modulus)-1.5)*n.dither_amplitude_v;
        end
        voltage=((coarseFineV+fineRA/n.ra_gain)+trackRA/n.ra_gain)+dith;
        codes(k)=min(2^20-1,max(0,round(voltage*(2^20/n.fsr_diff_v)+2^19)));
    end
end

function check_feedback(events,comparisons,feedback,sampleId)
    for k=1:numel(feedback)
        a=comparisons(k);b=feedback(k);
        assert(a<b&&events(a).time_s<=events(b).time_s&& ...
            isequal(events(b).consumed_decision_id,events(a).decision_id), ...
            'BehaviorValidate:feedbackOrder','Feedback precedes/misidentifies comparison, sample %g index %g.',sampleId,k-1);
        if k<numel(comparisons)
            assert(b<comparisons(k+1),'BehaviorValidate:feedbackLatency','Next comparison used an uncommitted prior result.');
        end
    end
end

function integer_range(value,lo,hi,label)
    assert(isnumeric(value)&&isreal(value)&&~isempty(value)&&all(isfinite(value(:)))&& ...
        all(value(:)==floor(value(:)))&&all(value(:)>=lo&value(:)<=hi), ...
        'BehaviorValidate:integer','Invalid %s.',label);
end

function yes=exact(a,b)
    yes=strcmp(class(a),class(b))&&isequal(size(a),size(b));if ~yes,return;end
    if isstruct(a)
        f=fieldnames(a);yes=isequal(f,fieldnames(b));if ~yes,return;end
        for j=1:numel(a),for k=1:numel(f)
            if ~exact(a(j).(f{k}),b(j).(f{k})),yes=false;return;end
        end,end
    elseif iscell(a)
        for k=1:numel(a),if ~exact(a{k},b{k}),yes=false;return;end,end
    elseif isnumeric(a)
        assert(isreal(a)&&isreal(b)&&~issparse(a)&&~issparse(b),'BehaviorValidate:storage','Require full real trace arrays.');
        yes=isequal(typecast(a(:),'uint8'),typecast(b(:),'uint8'));
    elseif islogical(a)||ischar(a)||isstring(a),yes=isequal(a,b);
    else,error('BehaviorValidate:type','Unsupported trace class %s.',class(a));end
end
