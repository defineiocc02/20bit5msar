function report=test_backend_unit
% Isolated-process test. Never run in the user's interactive MATLAB session.
% Baseline and candidate are the packaged code, renamed only at declaration.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Speed:interactive', ...
        'Use a disposable isolated MATLAB process, not the known user session.');
    assert(~bdIsLoaded('SarAdc'),'sar20Speed:modelLoaded','Use an empty session.');
    require_uncached({'behavior_backend_step_baseline','behavior_backend_step_candidate', ...
        'sar20_cdac2_network'});
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(pkg,'baseline','current','src')),'-end');
    addpath(fullfile(pkg,'tests','aliases'),'-begin');
    require_location('behavior_backend_step_baseline',fullfile(pkg,'tests','aliases'));
    require_location('behavior_backend_step_candidate',fullfile(pkg,'tests','aliases'));
    require_location('sar20_cdac2_network',fullfile(pkg,'baseline','current','src','physics'));
    q=load(fullfile(pkg,'fixtures','n8_parameters.mat'),'P');P=q.P;p=P.backend;
    assert(~p.ni.ra_noise&&~p.ni.az,'sar20Speed:fixture','Expected baseline RA/AZ OFF.');
    s0=behavior_backend_unpack(P.xBK0);
    patterned=repmat([-1;0;1],7,1);
    patterns=[zeros(19,1),ones(19,1),patterned(1:19)];count=0;
    for mismatch=0:1
      for replica=0:1
       for kick=0:1
        for oldOn=0:1
         for active=0:1
          for reset=0:1
           for floatCase=0:1
            for k=1:3
             pp=p;pp.ni.cap_mismatch=logical(mismatch);
             pp.ct.replica_enabled=logical(replica);pp.ni.cinc_kick=logical(kick);
             s=s0;s.time_s=0;s.vx_v=0.123;s.ct_reset_vx_v=-0.004;
             s.main_qb_c=floatCase*[2e-15;-3e-15];
             s.replica_qb_c=floatCase*[-1e-15;4e-15];
             s.previous_switch_charge_c=[1e-15;-2e-15];
             s.command.ra_on=logical(oldOn);s.command.reset=~logical(oldOn);
             s.command.az_on=false;s.command.sample_id=0;s.command.epoch=double(P.epoch);
             c=s.command;c.ra_on=logical(active);c.reset=logical(reset);
             c.d2_signs=patterns(1:12,k);c.ta_signs=patterns(13:19,k);
             for dt=[0 1.25e-9]
                 pair(s,c,dt,pp);count=count+1;
             end
            end
           end
          end
         end
        end
       end
      end
    end
    % Two observable, opposite-sign engineering mismatch fixtures. These are
    % synthetic stress values, not PDK statistics or measured capacitances.
    mismatchEffects=zeros(2,2);
    for direction=1:2
        [pp,mismatchEffects(direction,:)]=observable_mismatch(p,direction);
        s=s0;s.time_s=0;s.vx_v=0.137;s.ct_reset_vx_v=-0.004;
        s.main_qb_c=[3e-15;-2e-15];s.replica_qb_c=[-1e-15;4e-15];
        s.command.ra_on=true;s.command.reset=false;s.command.az_on=false;
        s.command.sample_id=0;s.command.epoch=double(P.epoch);
        c=s.command;c.d2_signs=repmat([1;-1],6,1);
        c.ta_signs=[1;-1;1;-1;1;-1;1];
        for replica=0:1
            pp.ct.replica_enabled=logical(replica);
            for active=0:1
                for reset=0:1
                    c.ra_on=logical(active);c.reset=logical(reset);
                    for dt=[0 1.25e-9]
                        pair(s,c,dt,pp);count=count+1;
                    end
                end
            end
        end
    end
    assert(mismatchEffects(1,1)*mismatchEffects(2,1)<0&& ...
        mismatchEffects(1,2)*mismatchEffects(2,2)<0, ...
        'sar20Speed:mismatchPolarity','Synthetic perturbations must be observable in both directions.');
    % Explicit finite-DAC forcing. The old state owns the active interval.
    s=s0;s.time_s=0;s.command.ra_on=true;s.command.reset=false;s.command.az_on=false;
    s.command.sample_id=0;s.command.epoch=double(P.epoch);c=s.command;dt=1e-9;
    forcing=struct('dt_s',dt,'source_time_s',0,'sample_id',c.sample_id, ...
        'epoch',c.epoch,'q_endpoint_c',c.qres_c+1e-15, ...
        'delta_q_c',[1e-15;-2e-15],'tau_dac_s',[1e-9;2e-9]);
    pair(s,c,dt,p,forcing);count=count+1;
    % Genuine AZ phase transitions, not a fabricated direct readout state.
    pa=p;pa.ni.az=true;pa.az.mode='ordinary';c=s0.command;
    c.sample_id=0;c.epoch=double(P.epoch);c.ra_on=false;c.az_on=false;c.reset=true;
    [sa,sb]=cold_pair(c,pa);count=count+1;
    c.az_on=true;c.reset=false;[sa,sb]=pair_states(sa,sb,c,0,pa);count=count+1;
    [sa,sb]=pair_states(sa,sb,c,1e-9,pa);count=count+1;
    c.az_on=false;[sa,sb]=pair_states(sa,sb,c,0,pa);count=count+1;
    c.ra_on=true;[~,~]=pair_states(sa,sb,c,0,pa);count=count+1;
    % Same actual OU configuration and explicit exact event time in both calls.
    q=load(fullfile(pkg,'fixtures','ou_on_P.mat'),'P');Pon=q.P;pn=Pon.backend;
    assert(pn.ni.ra_noise&&~pn.ni.az,'sar20Speed:ouFixture','Expected OU ON/AZ OFF.');
    so=behavior_backend_unpack(Pon.xBK0);so.time_s=0;so.command.ra_on=true;
    so.command.reset=false;so.command.az_on=false;so.command.sample_id=0;
    so.command.epoch=double(Pon.epoch);co=so.command;dt=1e-9;
    pair(so,co,dt,pn,[],dt);count=count+1;
    % Errors remain visible with the same identifier and message in both paths.
    c=s0.command;bad=c;bad.d2_signs(1)=2;bad_pair(s0,bad,0,p,'behavior:signs');
    badp=p;badp.ra.Cf_f=-1;bad_pair(s0,c,0,badp,'behavior:parameters');
    badp=p;badp.ni.az_noise=true;bad_pair(s0,c,0,badp,'behavior:unsupportedNI');
    badp=p;badp.ct.reference_v=-1;bad_pair(s0,c,0,badp,'behavior:ctParameters');
    badp=p;badp.ni.cap_mismatch=false;
    badp.ct.net_nominal.main_f=badp.ct.net_nominal.main_f(1,:);
    bad_pair(s0,c,0,badp,'sar20:cdac2Layout');
    report=struct('status','passed','valid_cases',count,'negative_cases',5, ...
        'synthetic_mismatch_vy_deltas',mismatchEffects, ...
        'scope','direct kernel only; exact MATLAB execution required; no timing claim');
end

function require_uncached(names)
    loaded=inmem('-completenames');
    for i=1:numel(loaded)
        [~,stem]=fileparts(loaded{i});
        assert(~any(strcmpi(stem,names)),'sar20Speed:cache', ...
            '%s is already cached; use a fresh process.',stem);
    end
end
function [p,effects]=observable_mismatch(p,direction)
% Verify the stress changes the actual and replica CT networks before testing.
    nominal=p.ct.net_nominal;
    assert(nominal.main_f(1,1)>0&&nominal.main_f(2,1)>0, ...
        'sar20Speed:mismatchFixture','Expected positive main capacitor on each side.');
    actual=nominal;replica=nominal;
    if direction==1
        actual.main_f(1,1)=actual.main_f(1,1)*1.03;
        replica.main_f(2,1)=replica.main_f(2,1)*0.98;
    else
        actual.main_f(2,1)=actual.main_f(2,1)*0.97;
        replica.main_f(1,1)=replica.main_f(1,1)*1.02;
    end
    assert(~isequaln(actual,nominal)&&~isequaln(replica,nominal), ...
        'sar20Speed:mismatchFixture','Both physical netlists must differ from nominal.');
    d=repmat([1;-1],6,1);t=[1;-1;1;-1;1;-1;1];q=[3e-15;-2e-15];
    ref=sar20_cdac2_network(nominal,0.137,d,t,p.ct.reference_v,zeros(2,1),q);
    aa=sar20_cdac2_network(actual,0.137,d,t,p.ct.reference_v,zeros(2,1),q);
    rr=sar20_cdac2_network(replica,0.137,d,t,p.ct.reference_v,zeros(2,1),q);
    effects=[aa.vy-ref.vy,rr.vy-ref.vy];
    assert(all(isfinite(effects))&&all(abs(effects)>1e-8), ...
        'sar20Speed:mismatchInvisible','The actual/replica perturbations are not observable.');
    p.ni.cap_mismatch=true;p.ct.net_actual=actual;p.ct.net_replica=replica;
end

function require_location(name,folder)
    actual=which(name);expected=fullfile(folder,[name '.m']);
    assert(strcmpi(strrep(actual,'\','/'),strrep(expected,'\','/')), ...
        'sar20Speed:path','Unexpected resolution for %s.',name);
end
function pair(s,c,dt,p,varargin)
    before=rng;
    [a,ya]=behavior_backend_step_baseline(s,c,dt,p,varargin{:});
    [b,yb]=behavior_backend_step_candidate(s,c,dt,p,varargin{:});
    same_bits(a,b,'state');same_bits(ya,yb,'observation');
    assert(isequaln(before,rng),'sar20Speed:rng','Global RNG changed.');
end
function [a,b]=cold_pair(c,p)
    [a,ya]=behavior_backend_step_baseline([],c,0,p);
    [b,yb]=behavior_backend_step_candidate([],c,0,p);
    same_bits(a,b,'cold_state');same_bits(ya,yb,'cold_observation');
end
function [a,b]=pair_states(a,b,c,dt,p)
    [a,ya]=behavior_backend_step_baseline(a,c,dt,p);
    [b,yb]=behavior_backend_step_candidate(b,c,dt,p);
    same_bits(a,b,'AZ_state');same_bits(ya,yb,'AZ_observation');
end
function bad_pair(s,c,dt,p,id)
    [ida,ma]=caught(@()behavior_backend_step_baseline(s,c,dt,p));
    [idb,mb]=caught(@()behavior_backend_step_candidate(s,c,dt,p));
    assert(strcmp(ida,id)&&strcmp(ida,idb)&&strcmp(ma,mb), ...
        'sar20Speed:error','Expected matching %s, got %s and %s.',id,ida,idb);
end
function [id,message]=caught(fun)
    try,fun();catch ex,id=ex.identifier;message=ex.message;return;end
    error('sar20Speed:noError','The negative case unexpectedly succeeded.');
end
function same_bits(a,b,where)
    assert(strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'sar20Speed:type','Class or shape differs at %s.',where);
    if isstruct(a)
        fa=fieldnames(a);fb=fieldnames(b);
        assert(isequal(fa,fb),'sar20Speed:fields','Fields differ at %s.',where);
        for i=1:numel(a)
            for j=1:numel(fa),same_bits(a(i).(fa{j}),b(i).(fa{j}),[where '.' fa{j}]);end
        end
    elseif isnumeric(a)
        assert(isreal(a)&&isreal(b)&&isequal(typecast(a(:),'uint8'),typecast(b(:),'uint8')), ...
            'sar20Speed:bits','Numeric bits differ at %s.',where);
    elseif iscell(a)
        for i=1:numel(a),same_bits(a{i},b{i},where);end
    else
        assert(isequaln(a,b),'sar20Speed:value','Value differs at %s.',where);
    end
end
