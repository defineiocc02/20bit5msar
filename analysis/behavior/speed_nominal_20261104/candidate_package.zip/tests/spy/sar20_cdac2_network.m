function varargout=sar20_cdac2_network(varargin)
% Test-only counter wrapper. The renamed reference keeps its original arithmetic.
    sar20_speed_counter('increment');
    [varargout{1:nargout}]=sar20_cdac2_network_reference(varargin{:});
end
