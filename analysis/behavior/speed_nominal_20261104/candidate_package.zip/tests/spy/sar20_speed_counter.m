function count=sar20_speed_counter(action)
% Instrumentation is confined to this disposable test process.
    persistent n
    if isempty(n),n=0;end
    switch action
        case 'reset',n=0;
        case 'increment',n=n+1;
        case 'read'
        otherwise,error('sar20Speed:counter','Unknown counter action.');
    end
    count=n;
end
