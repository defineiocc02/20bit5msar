#!/usr/bin/env python3
"""Audit frozen scratch bytes; never execute MATLAB or touch production."""
import hashlib
import json
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
LIMIT = 300_000_000
BACKEND = 'current/src/physics/behavior_backend_step.m'


def sha(path):
    assert path.is_file() and path.stat().st_size <= LIMIT, f'absent/oversize: {path}'
    return hashlib.sha256(path.read_bytes()).hexdigest()


index = json.loads((PKG / 'RUNTIME_INDEX.json').read_text(encoding='utf-8'))
for variant in ('baseline', 'candidate'):
    base = PKG / variant
    rows = index[variant]
    expected = {r['path']: r['sha256'] for r in rows}
    assert len(expected) == len(rows), f'duplicate runtime path: {variant}'
    actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    assert actual == expected.keys(), f'runtime set differs: {variant}'
    for name, digest in expected.items():
        assert sha(base / name) == digest, f'runtime SHA mismatch: {variant}/{name}'

source_lock = json.loads((PKG / 'SOURCE_LOCK.json').read_text(encoding='utf-8'))
source = {r['path']: r['sha256'] for r in source_lock['source_files']}
assert len(source) == len(source_lock['source_files']) == 109
canonical = ''.join(f'{name}\0{source[name]}\n' for name in sorted(source)).encode()
assert hashlib.sha256(canonical).hexdigest() == source_lock['source_tree_sha256'] == '84a4bb860f0ecd0989a0e6671510bef15587fe92608187edde22057bcc7dc2c3'
for name, digest in source.items():
    assert sha(PKG / 'baseline' / name) == digest, f'baseline source mismatch: {name}'
    if name != BACKEND:
        assert sha(PKG / 'candidate' / name) == digest, f'candidate source mismatch: {name}'
pins = {
    'config/adc_parameters.m': 'f91372be10dbb453e488e71f911566a55ed004275b99b060bddea73ae95f6df1',
    'current/src/calibration/public_calibration_config.m': '4e5b8617860b61f2d595d67bba5cd5f489d6e8bd639e9416fd808773a0cc60c9',
    'current/src/calibration/behavior_cal_collector_step.m': 'd98a0005fe43fb15a8881ba3b85faff3b350d1f79bfb8726f361d9ba4629a6cd',
    'current/src/model/behavior_prepare_configuration.m': '3513898f825776fa0fd16567c9631ff2b2c1bb6a242d8b1787b756230eb77ccd',
    'current/src/model/behavior_ra_noise_guard.m': 'f34f5c0ef9283729729bdaf444af5d724b50422ee92bd29b0ea7952caa019d1b',
    'current/src/model/behavior_training_configuration.m': 'cd6a4fe8f5247e3ca95a3b477892898b2e920e85fbab1dcec32aa0a48ebf81dc',
    'current/src/analysis/behavior_spectrum.m': 'f567aab44fc37579c00812b673264afa464ec99d074f07ad0fa6d6955fcd4f3e',
}
for name, digest in pins.items():
    assert source.get(name) == digest, f'NI/spectrum pin mismatch: {name}'

original = (PKG / 'baseline' / BACKEND).read_text(encoding='utf-8')
candidate = (PKG / 'candidate' / BACKEND).read_text(encoding='utf-8')
assert sha(PKG / 'baseline' / BACKEND) == 'b6fd6bcd73b8673542a93537a34f5a65d81a49d1a58ef6914230638fb26f4d75'
assert sha(PKG / 'candidate' / BACKEND) == '2e97bfbbf6a78bbdd352679f5a95330e5ac1e89bb7cdc8476888a6b786672d6a'
model = 'current/models/SarAdc.slx'
assert sha(PKG / 'baseline' / model) == sha(PKG / 'candidate' / model) == 'd4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0'
diff = [p for p in index['baseline'] if sha(PKG / 'baseline' / p['path']) != sha(PKG / 'candidate' / p['path'])]
assert [p['path'] for p in diff] == [BACKEND], f'unexpected runtime changes: {diff}'

before = '    actual=observe(s,cmd,p);\n'
after = '''    % With mismatch OFF, switch_networks already solved this exact nominal
    % network at vx=0 using the same post-command signs and zero qB/noise.
    % The physical actual network in observe is still evaluated separately.
    if ~p.ni.cap_mismatch
        actual=observe(s,cmd,p,main);
    else
        actual=observe(s,cmd,p);
    end
'''
sig_before = 'function y=observe(s,c,p)\n'
sig_after = 'function y=observe(s,c,p,reusedNominal)\n'
nom_before = '    nominal=sar20_cdac2_network(p.ct.net_nominal,0,d,t,p.ct.reference_v);\n'
nom_after = '''    if nargin<4
        nominal=sar20_cdac2_network(p.ct.net_nominal,0,d,t,p.ct.reference_v);
    else
        nominal=reusedNominal;
    end
'''
for piece in (before, sig_before, nom_before):
    assert original.count(piece) == 1, f'baseline pattern mismatch: {piece!r}'
assert candidate == original.replace(before, after).replace(sig_before, sig_after).replace(nom_before, nom_after)
assert "sar20_cdac2_network(net,s.vx_v-s.ct_reset_vx_v,d,t," in candidate
assert "p.ct.reference_v,zeros(2,1),s.main_qb_c)" in candidate
assert "replica=sar20_cdac2_network(replicaNet,0,-factor*d,-factor*t,p.ct.reference_v);" in candidate
assert "exist('sar20_cdac2_network','file')==2" in candidate

for variant, source in (('baseline', original), ('candidate', candidate)):
    alias = (PKG / 'tests/aliases' / f'behavior_backend_step_{variant}.m').read_text(encoding='utf-8')
    renamed = source.replace('function [s,y] = behavior_backend_step(',
                             f'function [s,y] = behavior_backend_step_{variant}(', 1)
    assert alias == renamed, f'test alias differs: {variant}'

network = (PKG / 'baseline/current/src/physics/sar20_cdac2_network.m').read_text(encoding='utf-8')
spy_reference = (PKG / 'tests/spy/sar20_cdac2_network_reference.m').read_text(encoding='utf-8')
assert spy_reference == network.replace('function r = sar20_cdac2_network(',
                                        'function r = sar20_cdac2_network_reference(', 1)

manifest = json.loads((PKG / 'MANIFEST.json').read_text(encoding='utf-8'))
files = {x['path']: x['sha256'] for x in manifest['files']}
actual = {str(p.relative_to(PKG)) for p in PKG.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
assert set(files) == actual, 'bundle membership differs'
for name, digest in files.items():
    assert sha(PKG / name) == digest, f'bundle SHA mismatch: {name}'
print(json.dumps({'status': 'static_pass', 'runtime_files_each': len(index['baseline']),
                  'runtime_changed': [BACKEND], 'bundle_files': len(files),
                  'current_source_tree_sha256': source_lock['source_tree_sha256'],
                  'ni_pins': len(pins)-1, 'spectrum_pin': 'f567aab4',
                  'matlab_executed': False, 'runtime_bit_equivalence': 'NOT_RUN',
                  'performance': 'NOT_MEASURED'}, indent=2))
