function report=test_call_count
% Test-only call counter in a fresh isolated process, never in production.
    pkg=fileparts(fileparts(mfilename('fullpath')));
    assert(feature('getpid')~=27628,'sar20Speed:interactive','Refuse the known user session.');
    assert(~bdIsLoaded('SarAdc'),'sar20Speed:modelLoaded','Use an empty session.');
    loaded=inmem('-completenames');
    for i=1:numel(loaded)
        [~,name]=fileparts(loaded{i});
        assert(~any(strcmpi(name,{'sar20_cdac2_network','sar20_cdac2_network_reference', ...
            'behavior_backend_step_baseline','behavior_backend_step_candidate','sar20_speed_counter'})), ...
            'sar20Speed:cache','%s is already cached; use a fresh process.',name);
    end
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(genpath(fullfile(pkg,'baseline','current','src')),'-end');
    addpath(fullfile(pkg,'tests','aliases'),'-begin');
    addpath(fullfile(pkg,'tests','spy'),'-begin');
    assert(strcmpi(strrep(which('sar20_cdac2_network'),'\','/'), ...
        strrep(fullfile(pkg,'tests','spy','sar20_cdac2_network.m'),'\','/')), ...
        'sar20Speed:spy','Test counter did not resolve.');
    q=load(fullfile(pkg,'fixtures','n8_parameters.mat'),'P');P=q.P;p=P.backend;
    s=behavior_backend_unpack(P.xBK0);c=s.command;
    rows=zeros(2,3);
    for mismatch=0:1
        pp=p;pp.ni.cap_mismatch=logical(mismatch);
        sar20_speed_counter('reset');
        [a,ya]=behavior_backend_step_baseline(s,c,0,pp);na=sar20_speed_counter('read');
        sar20_speed_counter('reset');
        [b,yb]=behavior_backend_step_candidate(s,c,0,pp);nb=sar20_speed_counter('read');
        assert(na==6&&nb==5+double(mismatch),'sar20Speed:calls','Unexpected CT invocation count.');
        assert(isequaln(a,b)&&isequaln(ya,yb),'sar20Speed:values','Test-only wrapper changed results.');
        rows(mismatch+1,:)=[mismatch na nb];
    end
    report=struct('status','passed','columns',{{'cap_mismatch','baseline_calls','candidate_calls'}}, ...
        'rows',rows,'scope','instrumented direct kernel; not a timing result');
end
