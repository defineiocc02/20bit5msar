# SAR20 后端性能候选：同事件 nominal CT 复用

本目录是**未运行 MATLAB 的隔离候选**，从 `sar20_speed_candidate_20261104.XLkaYe` 另建，旧包未覆盖。`baseline/` 和 `candidate/` 均使用本机当前 109 项工作源码快照：它在原 N8 源 ZIP 上包含已安装的六项 NI 代码与 `f567…` 频谱代码；两者均配同一份 N8 运行时 SLX。唯一运行时代码差异为 `current/src/physics/behavior_backend_step.m`。NI 新源码的 smoke/行为验证不由本包静态重基证明。两个 runtime 位于项目库外，不得直接覆盖 current。

## 依据与限制

2026-10-28 一次 profiler 对旧模型记录：`sar20_cdac2_network` 301,824 次，函数累计含子 20.146 s；后端输入验证 50,304 次，`exist` 所在行累计 14.404 s。此为带插桩的历史热点，并非当前模型的无插桩自耗时。旧校验前移候选的 N256 单次顺序 old/new 为 129.078/101.510 s，30 路位门已独立回读，但独立 missing-dependency 负例未运行、候选未晋升，不能外推为本候选收益。

本候选保留 `behavior_backend_step` 的公共参数校验、`exist` 依赖检查、所有数字/物理状态、模型图和日志配置。只在 `p.ni.cap_mismatch=false` 时，将同一次 `switch_networks(cmd,p)` 的 `main` 交给后续 `observe(s,cmd,p)`，作为其**nominal** 结果。两处原调用都是：

```matlab
sar20_cdac2_network(p.ct.net_nominal, 0, d, t, p.ct.reference_v)
```

两处均省略 `reset_noise_v`、`floating_qb_c`，在网络内部按相同代码置零；`switch_networks` 的 `~ra_on || reset` 与 `observe` 的 `~(ra_on && ~reset)` 对已规范化布尔命令等价。两处传入的都是同一 `cmd`；`p`、`cmd` 和 `main` 不被中间操作修改。网络无 persistent/global/RNG。**实际 CT** 仍使用 `s.vx_v-s.ct_reset_vx_v` 与 `s.main_qb_c` 独立计算；replica、switch charge、输出负载与 AZ 状态仍走原路径。失配开启时保留原来的全部调用。网络内部计算次序与模型日志配置未改，也未新增隐藏状态。缺依赖检测仍在原每次调用位置。

异常日志仍有未关闭的边界：奇异或近奇异 nominal 网络可能在每次矩阵求解时产生警告；删除一次重复求解可能改变警告次数。现有校验不保证网络始终非奇异，因此不能宣称所有异常警告日志一致；部署前必须验证或为可复用分支设置能证明安全的资格门。

`sar20_cdac2_network` 少调用的次数和墙钟收益均尚未知；相同输入重复调用的位级等价也必须由目标 MATLAB/Simulink 实测。该候选不能直接承接旧 141949 的验证结论。

## 工程位置与固定输入

- 两份 `current/models/SarAdc.slx`：沿用 N8 实际运行时 SHA `d4e7fc99ab040857e535df07d73447e71c65e7d51dcadf7b17f4bad88594a6a0`；本机现有 `current` SLX 是另一身份 `f358…`。本包不凭本机文件推断 Windows 此刻模型身份。
- baseline 后端 SHA `b6fd6bcd73b8673542a93537a34f5a65d81a49d1a58ef6914230638fb26f4d75`；candidate SHA `2e97bfbbf6a78bbdd352679f5a95330e5ac1e89bb7cdc8476888a6b786672d6a`。
- 源码祖先是 N8 源 ZIP `5e28ead4…fee6af37e`；重基后有六项 NI 文件不同，因此**不再声称本包等于该 ZIP**。重基时 109 项本机工作源码集合相等、逐项双读 SHA 稳定；其相对路径/哈希在 `SOURCE_LOCK.json`，规范化树 SHA `84a4bb860f0ecd0989a0e6671510bef15587fe92608187edde22057bcc7dc2c3`。`RUNTIME_INDEX.json` 分别锁定两套 110 项（含 SLX）。
- `fixtures/` 含 N8 P 及已归档 RA OU ON/OFF 的 P；N256 测试要求调用方明确提供完整 N256 P MAT，不能把 N8 改个 `N` 当作已准备的 N256。

## 验证顺序（本轮没有运行）

1. 运行 `python3 tests/verify_static.py` 核对候选精确差异、整套 runtime 哈希和测试别名与正式候选一致。这只证明文件结构，不能证明 MATLAB 语义。
2. `tests/check_mismatch_fixture.py` 使用归档 P 的电容和独立节点方程，只检查两组合成失配刺激是否可见；本机输出保存在 `tests/mismatch_proxy.json`。这不是 MATLAB 比较或 PDK 证据。在**不附着用户会话的独立 MATLAB 进程**调用 `test_backend_unit`。它逐字段、逐数值字节比较独立基线/候选的完整 state 与 y，覆盖失配、replica、kick、活动/reset、旧状态、非零 qB/vx、符号、有限 DAC forcing、合法 AZ 写/读序列、真实 OU ON 配置，以及五类负例的异常 ID 和消息。失配 ON 增加两组相反方向的合成网表，分别改变 actual 与 replica 电容；先要求二者相对 nominal 的 VY 差均可见，再逐状态比较。这些比例只用于构造敏感刺激，不是 PDK 统计。不测到的物理配置仍不构成覆盖。
3. 在新的隔离进程调用 `test_call_count`，通过只存在于 `tests/spy` 的计数包装确认：正常一次 step 由 6 次 CT 调用降为 5 次，失配开启仍为 6 次。包装调用逐字节保留算术的重命名原网络，只用于证明实际走到省略分支，不能作为无插桩计时。
4. 在另一个干净进程、仅加入 `tests/` 与 `tests/aliases/` 且找不到 `sar20_cdac2_network` 时调用 `test_missing_dependency`，两版必须都抛 `behavior:dependency`。若目标环境自带其他同名文件或缓存，该测试拒绝执行。
5. 用 `run_one_variant('baseline',pFile,runId)` 和 `run_one_variant('candidate',pFile,runId)` 分别在独立新 MATLAB 进程跑同一 N8 P；调用 `compare_runs(baseId,candidateId,comparisonId)` 比较所有 `SimulationOutput.who` 变量及 root `yout`：类/形状、timeseries 的 Time/Data 原始字节；遇到未支持的数据类型直接失败而非跳过。保持模型原日志/solver，不改生产 SLX。日志类和容器在目标版本上若与测试假设不同，应保留失败原件并补验证器，不放宽比较。
6. N8、setup/事件/缺依赖边界通过后，再对**同一完整 N256 P** 重复上述两个进程；每对仅判该次位等价。计时须 profiler OFF，至少三组交替 AB/BA 顺序配对，报告各次 `sim_s`、中位数和范围；仿真输出身份和 log 位门失败的组不能计为成功提速。

示例（仅供未来获准后在隔离进程运行，不要在 PID 27628 中执行）：

```matlab
addpath(fullfile(pkg,'tests'));
test_backend_unit
run_one_variant('baseline',fullfile(pkg,'fixtures','n8_parameters.mat'),'n8_base_01')
% 另一个新进程：同一 pkg / P，variant='candidate'，runId='n8_cand_01'
% 独立进程或干净会话：compare_runs('n8_base_01','n8_cand_01','n8_cmp_01')
```

`run_one_variant` 在包内新建唯一 `runs/<runId>`、隔离 cache/codegen，保留失败回执与实际 simout；不覆盖旧结果，也不调用 `SAR20('apply')`。输入 P 先复制并与源文件双向核哈希，再只从本次副本加载；模型加载前、加载后及仿真后检查 backend/CT 两个函数的解析与缓存路径。路径检查不证明缓存内存字节与磁盘相同。输入和输出读取设 300 MB 上限。源码/fixture 内存缓存路径、模型 workspace 和 file-generation 是 MATLAB 进程级状态：务必使用独立进程并在各次执行前核验，不在用户会话中用清缓存或改路径换取通过。
