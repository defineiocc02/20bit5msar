# SAR20-5 current checkpoint

Updated 2026-10-26. Full reproduction goal remains ACTIVE and incomplete.

## Live Windows job: do not interrupt or submit another MATLAB action

- Sole MATLAB PID 25440, started 2026-10-26T12:17:03.972Z, R2024a Update 6.
- Own controller: SAR20_MatlabControl; control folder: runs/control.
- N256 apply/run submitted 2026-10-26T13:27:40Z.
- Native producer confirmed status=running, stage=actual_simulation; live CPU increased at the 13:55:51Z check. Observation timeout is not termination.
- Run: runs/run_tp4fb8520b_6c12_4e37_8581_7883ebe2064e.
- Native status/result: that run's direct_run/result.json.
- Host receipt: runs/control/dynamic_256_result.json.
- Applied snapshot: runs/apply_tp22070235_8288_4d00_a507_d9f93acb5972/apply/F2_KTC_DITHER_MODEL_WORKSPACE.mat. Keep it while current_binding references it.
- Configuration: N256, M8, compact, Fs5MHz, UGB1.2GHz, A0=1e4, internal BE cap62.5ps, owner1.25ns/global250ps; only record_length changed from the accepted N8 capture.
- Retained input: 97656.25Hz (bin5 of256), differential peak3.650563842595822V, phase0.731rad, offset0, masterseed20261020; calibration off.
- No N256 result/FFT completion claim yet. Do not rerun this job just because a poll is delayed.

## One public engineering entry and current identity

Windows root D:/Academic/Projects/sar20m1/SAR20. Mac root is this directory.
Use SAR20; change config/parameters.json then SAR20('apply'); SAR20('run') uses saved configuration. Direct Simulink Run does not apply JSON.
Only development SLX: current/runtime_work/pool_pole_precision_trial_r1/models/PoolCt.slx.
Current SLX SHA: 473438e7affa9f467ce00e19585bb63ca95d543446cbe7da602f3c2bff391e67.
Current workspace SHA: cb7edc989b9bc386b7e863ba32cdf4d734b0629fdc4cd421bb2c11b753c720c5.
Mac mirror now matches these bytes; exactly three binding paths were remapped. See analysis/performance/CURRENT_SYNC.json. No native Mac MATLAB/MEX validation.
Binding status applied_to_private_work_current_not_run is a fixed apply-schema value required by SAR20; do not change it to describe the running job. Use native run receipts for execution status.

## Accepted cache milestone

See analysis/performance/REPORT.md and actual receipts/results there.
Local sys reuse was deployed in pool_cached_predict; no analog/RNG state is cached across calls, no BE/timing/solver-budget change. pool_cached_matrix only lost an unused duplicate helper. run_pool_ct pins were rebased.
- predict SHA bfcd7285b54ebc556af819f48a6688ba5c0e636065a0356512933e103ba400e0
- matrix SHA a57df83d05d99f42dfe53a7dc7c30b15d24ea379728e6aab9f23514d6c1177b9
- runner SHA 9ebcc22ea6210ffcd5763fe623a467f0db438258cff6d2513291821c1fbedfd2
- contract SHA 71da7eb9190fe57788a58d1665bc2eb0ea658dfac4b809ffe2e465fee94002b5; source closure remains270 files.
Original source_file_pins/lineage were preserved. feature_source_pins plus candidate_overrides and runner pins were updated; release/MIGRATION bind the new contract.
Old/new physics N8 runs: run_tpbd8d0822_70d8_4956_9aa1_7bf0a971b706 / run_tp6204420c_7b4f_426b_9c32_bbfcf8f17d10.
Same SLX15acb3f2b8ec6767bb8e9a6004ba1a97dd6101e438a2ae5783eeed1b1104f5c6; all59 Data/Time, tout, entire selected, complete hi/lo state/ledger and RNG5179/charge5180:5181 matched bitwise, with no tolerance.
Physics elapsed192.4924693 ->170.1690159s, 1.131x /11.60% less time, one pair only.
Accepted compact run run_tp8d3ea108_5620_44f6_b4bb_bfd421d82725: 162.5648095s, all54 compact observations matched old62.5ps, global RNG unchanged. N8 codes: 963377 979639 989055 991472 986860 975304 956956 932107.
Do not use the older208s run in another MATLAB process as a controlled timing pair. Profile283s is diagnostic only.

## Next action after the existing N256 job completes

1. Preserve native failed/partial output if present; inspect exact error before choosing a repair. Do not repeat completed captures.
2. If completed, collect direct_run raw/selected/result plus host receipt and hashes. Verify first8 codes against accepted short capture, records256, source/seed/coherence, native metrics and true NI flags.
3. analysis/performance/analyze_dynamic_256.py is prepared for independent NumPy FFT of actual files; it rejects N8. Inputs --capture-dir --identity --receipt --output-dir. Identity has artifacts[file,sha256,bytes] for raw.mat/selected.mat/result.json. No fabricated codes or DNL/INL. adc-analyzer skill applies; existing analysis_env only, no installs.
4. Bind spectrum/code CSV/node plots and report to this SLX/source/capture. SNR excludes H2-H10; ENOB is the actual approximately-1dBFS input value, without silent full-scale normalization.
5. Only after MATLAB is idle consider the bounded residual-mode2 build/arithmetic task. Use independent pool_sparse_mode2_mex basename, fixed XML/strict FP flags, capture verbose build via evalc (not diary). Actual owner-array arithmetic test is not a BE-substep replay or a substitute for the full59 gate.

## Outstanding physical and feature limits

Cache bitwise parity proves preservation of the recorded short trajectory, not correctness of shared physics. Independent full tail/kTC charge verification remains pending. BE step sensitivity is not signed off; 125->62.5ps still changed codes. Do not relax budgets or label them converged.
Current active NI: sample-kTC298.15K, finite switch/RA/CT dynamics, saved DAC1 IID mismatch/Cp, DEM and physical/public tail dither, digital rounding. Rsource=Rref=0; finite reference recovery is off. P/N C/Cp copied equal. CT/replica mismatch, jitter/skew, many additional noise/offset/slew effects are off; scans are not complete. A0/UGB and paper28pF-per-side interpretation remain design assumptions.
No current static INL/DNL, no complete ADI on/off matrix, no integrated ping-pong training/freeze/holdout. Old NativeCt101.91dB and old R91 SNDR99.608385dB are historical, not this N256.
NONDEPLOYED_NEXT.zip holds only drafts, not current functionality. Public-context guard draft must cover dither on/off and training still needs explicit train_accept; Assertion alone is not a write gate.
Potential future exact algebraic elimination/exponential propagation is a new integrator, not a bitwise refactor; it requires explicit impact reporting and unchanged independent KCL/charge budgets. Do not implement it during this run.

## Evidence protection / cleanup

Windows evidence/performance_sources.zip SHA690cb395d79d8294eaf9ee3d0099df190f60a0e00ff86a9c78b2a8f135774e60 contains1162 closed source/control/model snapshot files, each read-back SHA verified before loose removal. Raw/selected and the active workspace MAT were retained. There was exactly one loose SLX before the new live N256 run created its own as-run snapshots; never remove active job snapshots.
The running MATLAB owns runs/control/matlab_startup.log. Keep that file and its directory; archive scripts must exclude it. The first archive attempt hit this active log; resume verified the partial archive and completed it without rerunning simulation.
Older evidence/records.zip, windows_records.zip, time_step_sources.zip and relocation_source_snapshot.zip remain protected. Current source preimages are preserved. No new runtime version trees.

## Agents

Latest user choice: gpt-6.1-sol / medium. Six bounded roles: engineering_sol_cache, readability_sol_cache, physics_sol_cache, validation_sol_fullstate, calibration_sol_next, performance_sol_profile. Root alone owns SSH/MATLAB scheduling. Reassign real critical-path work; do not manufacture parallel documents or reactivate old Luna agents.

## Additional verified preparation while N256 is running

- Public N256 input/plan check: analysis/performance/n256_input_prefix_check.json. Both old N8 and current N256 retain the same276x8 plan bitwise; Fs, period, seed, firstID and four stimulus scalars match exactly.
- Independent postprocessor now includes selected-sample actual held/RA/CT/control plots and change events. Its nominal time check uses the exact producer formula ids*saved sample_period_s, with Fs*period==1; no added time tolerance. A closed N8 ID8 read gave12D2/8TA/7 feedback updates plus one separate clear event. No N8 FFT.
- Real API defect found: prepare_f2_ktc_dither_candidate pre-capture equality currently compares p_source capture8 against saved p_f0 capture256, so the next apply is expected to fail. It also rejects canonically extended plans on reentry. A minimal one-file draft is being prepared only in /tmp/sar20_factory_reentry_candidate. After the current run closes, review/rebase this guard-preserving fix before blindly changing parameters. Preserve C/seed/p_source; normalize only allowed capture/time/plan metadata and require full canonical plan plus original prefix.
- sample-kTC is not yet a public on/off API: F2 factory/entry/capture guards force v4/on. The existing kernel and MEX support v3/off, but exposing an explicit sample_kTC_enabled flag requires coordinated guards/profile/selector widths. Do not use T=0 as off. Independent tail-dither gate is not a kTC-off comparison gate.
- Public calibration context draft now covers dither on/off. Production CalOwner must NEVER read Reference watermark or retirement feedback. Future activation uses public Core RX IDs plus a proved protocol/consumer lead bound; Reference is read-only validation.
- Old684 features are ratios C/Cf_eff, not absolute F. Current public incidence is exactly rank18 (mod-prime check too), so no ring/gcd null in the18 bias columns. Actual684 rank still requires sufficiently rich public training; N256 cannot prove it. Tail feature amplitude is physical input_dither*1024/15, not RX's input-equivalent d_n.
- Compact logger audit: four256-word decoder state/next logs dominate54.70% of N8 Data. N256 expected dense data about600.44MiB (not measured raw size). Change-only logging could preserve exact observations but is not implemented; do not change current capture during this run.

## Process scheduling correction

At 2026-10-26T15:05:56.6947363Z, only MATLAB PID25440 priority was restored from BelowNormal to Normal after PID/start-time verification. No MATLAB command, model/source change or simulation interrupt was sent. The current N256 wall time spans this change and is not a controlled algorithm-speed benchmark. Future timing pairs must share the same priority. The prior physics cache pair was measured before this change. The SSH-session window enumeration returned no windows but is not proof that the interactive desktop has no dialog.
