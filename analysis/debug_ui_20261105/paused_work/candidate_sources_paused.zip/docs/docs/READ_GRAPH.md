# 按论文物理模块定位，再进入真实执行阶段

## 证据状态

本页按当前成电两步 SAR、DAC1 残差、RA/AZ、CINC 连续时间二级与 tracking 架构组织。物理模块是调试导航；它们不代表新增或复制了一套计算核。执行阶段的实际名称仍保留在 `SarAdc/EventStep/Adc`。当前 N256 回执包含 `event_log`、`front_log`、`back_log`、`control_log`、`raw_log`、`ready_log`、`record_log`、`record_ready_log`、`code_log` 等旧日志；它没有证明完整 FE353/RA48/SAR51 向量的 `old / advanced / after_command / next` 逐事件快照。

root 正在接入的 observer bundle 候选为 6329 宽、18 段，只围绕选定 sample 5 与其后 next-CNV 记录共 49 行全量观测；其余默认日志维持原 32 通道。该结构尚待 root 实际 UI、新 SLX 与回执核对。取得回执前，候选新增字段及四阶段快照仍标“未记录”，不得按设计说明推断已保存。[实际回执](../analysis/behavior/public_normal_20261105/release_actual/behavior_12d08121-d679-40cd-9ee2-bc334ff42955/summary.json)

## 物理模块导航

| 论文物理模块 | 在行为模型中追踪什么 | 实际执行块 / 状态 owner | 调试入口与边界 |
|---|---|---|---|
| 输入采样与 DAC1 | 差分输入、采样电荷、分组电容和本次采集身份；八条前端数值段合起来是一只物理阵列 | `SampleCharge`，FE353；入口 `SampleRaAdvance` | 从实际采集/held 开始。八段不是八只独立阵列或八路前端。源码：[frontend stage](../current/src/frontend/behavior_frontend_stage.m)、[frontend state step](../current/src/frontend/behavior_frontend_step.m) |
| DAC1 电荷残差 | SAR1 粗/细试探切换真实采样电荷，形成 `Qres` 并作为 RA 驱动；不以理想输入减理想码替代 | `Sar1TrialRaCt`、`DacCtFeedback`；SAR 控制状态在 `SarState`/SAR51 | 先看粗/细判决与残差的同一 ID/epoch。信号定义缺少来源时标“待确认”。源码：[SAR control](../current/src/control/behavior_sar_step.m)、[DAC forcing](../current/src/physics/behavior_dac_forcing_from_frontend.m) |
| 唯一 RA 与 ordinary AZ 存储 | `Qres` 到 RA 输出、AZ 写/保持/泄漏；多次 RA 调用推进同一个状态 | `RaCtState`/RA48；`SampleRaAdvance`、`Sar1TrialRaCt`、`DacCtFeedback`、`ChargeReturnRaReset` 内阶段共用 | VX 是 RA 输出参考面；不得当成已折算到 ADC 输入的电压。多阶段调用不等于多只 RA。源码：[backend stage](../current/src/physics/behavior_backend_stage.m)、[backend state step](../current/src/physics/behavior_backend_step.m) |
| CINC / CT 二级 | CT 电荷状态、CINC 反馈与 `VY`；连接 RA 输出和比较器输入的实际阶段值 | `DacCtFeedback/CtFeedback`、`Sar1TrialRaCt/RaAzCt`、`ResidueCtCompare/Compare2`；CT 状态归 RA48 | RA 后没有新增采样保持。VX 与 VY 所在位置及事件阶段不同，不能直接把它们的差命名为建立误差。源码：[CT/backend step](../current/src/physics/behavior_backend_step.m) |
| SAR2 与 tracking 判决/反馈 | 12 次 D2 判决、8 次 tracking 比较、7 次物理反馈更新；第 8 次比较不冒充第 8 次更新 | `SarDecisionTracking`、`SarState`/SAR51、`DacCtFeedback/DueFeedback` | 逐项保留比较和反馈先后，异常按首次不同的事件/阶段/字段定位。源码：[SAR control](../current/src/control/behavior_sar_step.m)、[calendar](../current/src/control/behavior_calendar.m) |
| 数字重构与输出 | 同一 RAW 上的名义 D1/D2/DT 重构、公共 Code20、记录资格和输出对应关系 | `EventStep/Fpga` 与外部 `Record`；源码 [decode](../current/src/digital/behavior_decode.m) | `CodeValid` 标成“Bank 输出资格〔旧 CodeValid〕”。有效 ADC 记录按 `RecordReady && RAW.valid`，输出对齐须核同一 ID/epoch；不能把旧 CodeValid 用作通用记录有效位。 |

当前默认 ordinary AZ。CAAZ 是独立 N8 试验身份；FrameAvg partial-712 与 ADI v2 是未完成候选，不是这条默认物理路径的一部分。

## 实际执行视图

物理模块之下按模型原执行块查看，不按论文框图重排计算：

1. `SampleRaAdvance`：捕获本轮输入/采样电荷并推进旧 RA 命令。
2. `DacCtFeedback`：先处理到期反馈，再执行 DAC1 与 CT 反馈。
3. `Sar1TrialRaCt`：预转换、SAR1 trial、RA 命令与 AZ/CT 阶段计算。
4. `ResidueCtCompare`：比较 DAC1 实际残差与 CT 实际 VY。
5. `SarDecisionTracking`：D2 与 tracking 判决，形成 RAW 字。
6. `ChargeReturnRaReset`：实际电荷返还与信号 reset；AZ 状态依其真实保存规则处理。

这些阶段的同一时刻记录按日志原顺序查看，不按名称排序或合并。`Frontend` 观察点在返还计算阶段，`Backend` 观察点是比较前阶段值；它们不能直接当作 UnitDelay 最终提交态。

## 状态所有者与快照语义

| owner | 持久状态 | 边界 |
|---|---|---|
| FE353 | `SampleCharge` | 采样电荷及采集相关信息；一个阵列的八个数值段 |
| RA48 | `RaCtState` | 唯一共享 RA、AZ 与 CT 状态；RA 各阶段调用复用此 owner |
| SAR51 | `SarState` | SAR trial、判决和待提交反馈 |
| ADC 外 | Bank、Transport、参考队列等各自数字状态 | 单独标识，不把它们塞进 ADC 三个主要状态 owner |

`commit` 表示应用当前事件命令；持久状态由对应 UnitDelay 的 `next` 更新。此处 `z⁻¹` 是离散执行序列中前一次有效更新/输出到本次的状态交接，未执行或禁用时按模型保持规则处理；它不是固定模拟延迟，也不等于一个完整采样周期。

目标快照定义及取值位置：`old`=该 owner 的 UnitDelay 输出端；`advanced`=对应状态演化阶段输出、当前事件命令尚未应用；`after_command`=命令应用阶段输出；`next`=送入该 owner UnitDelay 输入端的向量。它们分别绑定 FE353、RA48、SAR51 的实际端口/阶段输出，不以截图读数或重复复制代替。当前归档没有提供这些 owner 的逐事件四阶段完整向量，因此这些值仍是“未记录”，不能用现有 `front_log/back_log/control_log` 推补。相邻有效执行以同一 owner 的 `next → old` 和 sample ID/epoch 对齐；初始化、复位、不执行分别标出。

当前模型把打包向量作为内部接口；本候选不把旧图的 `c(13)`、`f(3)`、`bk(3)` 等位置固化成新字段定义。新日志需将名称、原向量索引、单位、物理参考面、owner、有效条件、更新阶段与源码定义位置绑定到同一字段字典；未从真实源码/回执确认的项显示“待确认”，未写入日志的值显示“未记录”。

## 有效性和观测边界

- 旧 `CodeValid` 仅是 Bank 输出资格；Bank OFF 时为零并不取消有效 ADC RAW。
- 记录资格使用同条记录的 `RecordReady && RAW.valid`。最终公共输出还要按实际传输关系核对 ID、epoch；不跨日志套行号或有效掩码。
- 新增观测只读已计算结果；不为绘图再次调用状态推进函数、不新增随机抽样、不改触发/使能、计算顺序或状态更新。
- 新入口约定为 `SAR20()` / `SAR20('home')`，主页由内部 `sar20_dashboard` 实现；操作包括 `open/apply/check/run/sample/results/compare/focus`。工作树入口与 observer bundle 均待 root 实际验证。旧基线 9 路日志名不等于全量状态历史；未记录的电压参考面、向量索引和更新阶段要留空并标“待确认/未记录”。

模型入口：[SarAdc.slx](../current/models/SarAdc.slx) · 当前源码导航：[event wiring](../current/src/model/behavior_wiring_sfun.m) · [SAR20 entry](../SAR20.m)。
