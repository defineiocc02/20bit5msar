# 参数状态、修改和恢复

## 三层参数真值

| 层级 | 位置 | 表示什么 | 判断规则 |
|---|---|---|---|
| 1. 工厂待应用 | [config/adc_parameters.m](../config/adc_parameters.m)、[config/normal_parameters.m](../config/normal_parameters.m) | 下次 apply 将生成的参数；前者集中 N/输入设置，后者集中 normal 物理估计与开关 | 编辑文件不会改变已打开模型。用 `apply` 后才进入模型工作区 |
| 2. 模型已应用 | 保存模型的 `ModelWorkspace.P`；公开 apply 回执在 [state/applied_config.json](../state/applied_config.json) | 最近一次 public apply 写入并保存的 P | GUI 内手改后，内存 P 可能与文件回执不一致；此时必须标成 GUI 未保存/待确认，不能说仍等于工厂或回执 |
| 3. 历史运行实际使用 | 每次 run 的 `parameters.mat`/`parameters.json` 与 `summary.json` | 该 run 实际保存的配置、模型 SHA、输出身份 | 查历史结果一律明确 run ID/目录；不能用当前工厂或 ModelWorkspace P 代替历史 P |

当前基线运行身份与度量见 [N256 release receipt](../analysis/behavior/public_normal_20261105/release_actual/release_receipt.json) 和 [该 run 的参数快照](../analysis/behavior/public_normal_20261105/release_actual/behavior_12d08121-d679-40cd-9ee2-bc334ff42955/parameters.json)。该 run 为 N256、5 MS/s、ordinary AZ、差分 FSR 10 V；`transport/training/frozen/bank` 均关闭，`calibration_mode=off`。精确噪声和非理想状态读 P 快照，不从旧文档或模型图推断。

## 一页受控改参与恢复

保存当前完整的模型参数，再对一个明确字段做实验。下面是现有 API。约定的唯一公开入口仍为 `SAR20.m`：无参 `SAR20()` 或 `SAR20('home')` 打开主页；它由内部 `sar20_dashboard` 实现，不是第二个公开函数。该界面尚待 root 实际验收：

```matlab
SAR20('open')
ws = get_param('SarAdc','ModelWorkspace');
P0 = getVariable(ws,'P');
P1 = P0;
P1.input.phase_rad = P1.input.phase_rad + 0.001;  % 示例：只改一个字段

try
    SAR20('apply',P1);
    SAR20('check');
    r = SAR20('run');
    SAR20('sample',5,r.run_path);
catch err
    SAR20('apply',P0);       % 恢复实验前的完整已应用 P
    SAR20('check');
    rethrow(err)
end
SAR20('apply',P0);
SAR20('check');
```

`apply(P1)` 保存显式完整 P；`check` 只做模型更新，不仿真；公开 `run` 使用已保存 P 并建立新 run；`sample` 读取明确的历史 run。恢复 `P0` 与恢复工厂默认不是一回事：无参 `SAR20('apply')` 会重建工厂配置。若改了工厂文件，先在库外保存原件/hash；恢复原文件后再无参 apply、check。不要覆盖既有 run 或 raw。

GUI 直接 Run 读取当前内存 `ModelWorkspace.P`，不会重新读取工厂文件，也不生成公开 run 的完整身份回执；手动 Workspace 改动必须显式记录。新 UI 所需的待 apply 标志、已应用摘要、当前 run ID 与三层对照尚待 root 的真实界面验收。

## A0、UGB 与噪声派生量

`normal_parameters.m` 的工厂构建流程读取顶部 `raA0`、`raUGB_hz`，并从当前电容和温度推导其他项。改变这两个工厂字段后，无参 apply 会重建 P，并重新计算：

- RA 闭环噪声增益 `NG = 1 + Ctop/Cf`、有限增益系数 `A0/(A0+NG)` 与单极点 `tauRA = NG/(2π·UGB)`；
- `P.backend.ra_noise.sigma_vx_rms`：该 OU 代理在 RA 输出端的 RMS 电压幅值；工厂用器件噪声密度估计和新极点推导它。

这里保存/保持的是**输出 RMS**，不是固定输入 PSD。底层 `en` 是一侧噪声密度假设；改变 A0/UGB 会重新导出 RMS 目标值。温度与比较器等效电容决定 SAR2/tracking comparator RMS，单改 A0/UGB 时这些参数保持原工厂设定；`dacTau_s` 也是独立工厂值，不会随 RA 极点变化。若只对已有完整 P 手工赋值 `P.backend.ra.A0` 或 `UGB_hz`，不能假定 `behavior_prepare_configuration` 会替你重算所有派生噪声字段；应走工厂重建，或明确计算并审查相关字段后再 apply。

## 当前、结果、历史

- **current**：`current/models/SarAdc.slx`、`current/src/` 与 `config/`。当前默认以 9197 原始 SHA 和已归档 N256 回执识别；root 完成新版图后，新的 SHA 应与原 SHA 并列保存。
- **results**：`SAR20('run')` 为每次执行创建独立身份。run 目录中的参数快照、summary 与原始数据互相绑定；sample/compare 必须显式指定 run。
- **history**：旧 N8/校准/CAAZ/FrameAvg/ADI 实验仍按各自模型、参数和完成状态保留。FrameAvg partial-712 未完成；CAAZ 63283 是独立 N8；ADI v2 是尚未完成整图集成的候选。不要用历史校准 `working` 或旧 1056 Cu 数值描述当前默认。

`SAR20('calibration',...)` 当前公开入口会拒绝，报错是有意保护：不得 freeze 或应用旧 pool 系数。有效记录看 `RecordReady && RAW.valid`，旧 `CodeValid` 只显示为“Bank 输出资格”。CAAZ/ADI 详细来源见[独立证据边界](CAAZ_ADI.md)。

主页中的 `results / compare / focus` 与 observer bundle（6329 宽、18 段，仅 sample 5 与后续 next-CNV 共 49 行；其他默认日志仍为原 32 通道）仍待 root 的实际运行回执验证。这些说明需等新 SLX、真实 UI 操作及 root 回执后再收口。
