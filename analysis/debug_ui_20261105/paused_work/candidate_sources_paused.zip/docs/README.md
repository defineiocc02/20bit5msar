# SAR20-5 Simulink 行为模型

> 文档候选状态：截至 2026-11-05，9197 普通 AZ 的 N256 默认运行有真实 MATLAB 回执；新的 `SAR20()` / `SAR20('home')` 调试界面、全量单样本 observer 与 Compare/Focus 尚待本轮 root 的新 SLX、UI 与回执验证。本页不把待验证功能写成通过。

## 当前基线

- 唯一模型：[current/models/SarAdc.slx](current/models/SarAdc.slx)；唯一已实现的公开 MATLAB 入口：[SAR20.m](SAR20.m)。Windows MATLAB R2024a Update 6。
- 本轮运行的模型身份：`91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e`。它是**旧基线身份**；重排图后的模型 SHA 尚待 root 绑定到最终 SLX 回执。
- 默认运行：N=256、Fs=5 MS/s、单物理前端、ordinary AZ、差分 FSR 10 V。八个前端条目是一个物理阵列的数值分段。
- 真实默认运行 [release receipt](analysis/behavior/public_normal_20261105/release_actual/release_receipt.json) 与 [run summary](analysis/behavior/public_normal_20261105/release_actual/behavior_12d08121-d679-40cd-9ee2-bc334ff42955/summary.json)：SNDR 99.1327659 dB，256 条有效输出记录。ID 5 为 RAW `1924/2473/19`、Code20 `979623`。这是已归档运行的输出证据；不代表新版调试 UI 已验收。
- 本配置开启有限采样 RC/kTC、固定电容失配、有限 DAC 建立、有限 RA/AZ、RA OU 与 SAR2/tracking 比较器噪声；关闭 DEM/dither、transport、jitter、reference recovery、训练、冻结校准和 Bank。校准公开命令会明确拒绝，不可复用旧 working/holdout 描述。

| 功能 | 当前默认 | 本轮证据 |
|---|---|---|
| 单阵列、N256、ordinary AZ | ON | 上述 N256 实际运行；不等于全部样本状态快照已验收 |
| 采样 RC/kTC、固定失配、有限 DAC/RA、RA OU、SAR2/tracking 噪声 | ON | 随同一真实默认 run 使用；未据此宣称全 PVT 或统计认证 |
| DEM/dither、transport、训练/冻结/Bank、jitter、reference recovery | OFF | 此默认 run 不验证这些开关路径 |
| 输入侧 CAAZ | 默认 OFF、独立 N8 | 独立试验回执，见下方链接 |
| FrameAvg partial-712、ADI v2 | 未完成 | partial / 候选，不进入默认模型 |

CAAZ 的两组 N8 试验、FrameAvg partial-712 与 ADI v2 候选各自独立；均不进入以上默认配置。详见[CAAZ/ADI 证据边界](docs/CAAZ_ADI.md)。

## 一页操作卡

### 已存在的 MATLAB 调用

```matlab
SAR20('open')
SAR20('check')                    % 仅模型更新检查，不仿真
r = SAR20('run');                 % 使用已保存的 ModelWorkspace.P，创建新运行目录
SAR20('sample',5,r.run_path)      % 指定真实归档目录；sample ID 不是数组行号
```

若更改参数工厂文件，先 `SAR20('apply')` 再 `SAR20('check')` 和 `SAR20('run')`。`apply` 会重建并保存模型工作区参数；直接 GUI Run 使用当前内存中的 `ModelWorkspace.P`，不重新读取工厂文件，也不产生公开 run 的完整归档。改完恢复时应用改动前保存的完整 P；不要把无参 `apply` 当作恢复任意实验前状态。

### 新调试入口状态

约定的唯一公开入口是 `SAR20.m`：无参 `SAR20()` 或 `SAR20('home')` 打开主页；界面操作为 `open / apply / check / run / sample / results / compare / focus`。内部 GUI 实现名为 `sar20_dashboard`，不是独立公开函数。本候选只列目标：主页状态、结果选取、同 ID/epoch 对照与事件/字段聚焦仍为 **PENDING**，需 root 的真实 UI 操作、新 SLX 与回执后才能改为已实现。当前工作树中的 `SAR20.m` 仍仅实现 `setup/open/apply/check/run/sample`；`home/results/compare/focus` 尚未集成，`SAR20('calibration',...)` 会直接报不可用。

有效 ADC 记录按 `RecordReady && RAW.valid` 判断，并以同一条记录的 ID/epoch 对齐公共输出。顶层 `CodeValid` 是旧 Bank 输出资格标志；Bank 关闭时它为零不表示 ADC 的 RAW 记录无效。新版主页的三层参数状态、功能开启/验证状态及具体事件聚焦仍待验收。

## 工程与结果归类

- **current**：唯一可运行模型、源码与参数工厂；README 链接只指向当前实际存在文件。
- **results**：每次 `SAR20('run')` 的独立 run ID、运行参数和输出。分析时传入明确 run 路径，不以“最近修改”代替身份绑定。
- **history**：已归档旧实验、私有 CAAZ、partial-712 和 ADI v2 候选；保留原始数据，不混入默认配置，也不覆盖历史 raw。

源码文件数只是库存，不是性能成绩或验证结果。当前已验证的是所引用回执中的 N256 normal 行为运行；全量 observer bundle（6329 宽、18 段；限定 sample 5 与其后 next-CNV 共 49 行）、比较/聚焦、参数受控改动后恢复、重开与新版模型回归均待 root 实际验证。其他默认运行日志维持原 32 通道。

进一步阅读：[按论文物理模块定位](docs/READ_GRAPH.md) · [参数、应用与恢复](docs/PARAMETERS.md)。
