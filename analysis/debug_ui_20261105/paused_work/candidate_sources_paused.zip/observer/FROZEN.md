# Observer candidate freeze

Date: 2026-11-05

The source-only observer candidate is frozen for root's native old-two-dialog N8 comparison. No further changes should be made to files under `candidate/` without notifying the root coordinator first.

## Finalized correction

`behavior_backend_stage.m` no longer overwrites `advancedState.time_s` in the diagnostic copy. The `advanced_RA48` trace preserves the state returned by `behavior_backend_step`, including its internally accumulated `t0+dt` time word. The trace header still records the exact scheduled `eventTime_s`, and the existing final `stateNext` still receives the stage's original exact-event-time alignment.

The same review also clarified stage-local handoff documentation: only the final FE `ChargeReturn`, backend `RaReset`, and SAR chain outputs are external UnitDelay inputs; intermediate `stateNext` and event-local SC snapshots remain labeled as such.

## Frozen source artifact hashes

- `candidate/behavior_backend_stage.m`: `ad202c0d994a30a25b5104f514755c5d616d74cf126baf1e7272adb5032234f3`
- `observer.patch`: `e605997a47d08bec9dc41f7d023d5dad6eb3ca24bee97205eeb6bc71edba33df`
- `observer_delta_backend_time.patch`: `77d248a9cfdc7838eddb80dca23211ed721392189929faf62b93ef5b2b25c4b0`

Native compilation, dynamic-port refresh, and behavior comparison remain unrun.
