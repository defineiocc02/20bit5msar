# Native off / same-P observer comparison (run on the designated Windows MATLAB host)

Status: prepared, not executed. This source-only candidate has not been compiled or simulated.

## 1. Keep a reviewable model candidate

1. Start from the original `SarAdc.slx` SHA256 `91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e` and apply the candidate source files in the `candidate/` folder to a separate model copy.
2. Load/update the old two-dialog model with the candidate S-functions. The expected pre-conversion output-port counts are FE=2, BE=2, controller=3; original input ports and direct-feedthrough settings remain unchanged. Confirm these before changing the dialogs.
3. Set all 11 S-functions' third dialog expression to `P.debug.observer`, force a model update, and verify the appended ports appear: FE=3 with port 3 width 1079, BE=3 with port 3 width 164, controller=4 with port 4 width 150.
4. Keep the observer's `Ts_s` equal to the current run's `P.Ts_s`; the config entry applies this invariant. Do not change any physical parameter or random seed between paired runs.

## 2. Paired runs

Use the current default N=256 model configuration and one identical seed/configuration for both runs. Capture the existing outputs/state handoff signals and the exact `[cycle,groupIndex,eventTime_s]` event/time tuple.

| Run | Observer spec | Expected observer result |
|---|---|---|
| A | `P.debug.observer.enabled=false`, `sample_id=5`, `Ts_s=P.Ts_s` | The added trace outputs are all NaN and the model's existing output ports/states follow the original candidate calculation. |
| B | Same P and seed; change only `enabled=true` | Trace records appear only in inclusive window `[5*P.Ts_s,6*P.Ts_s]`; event time `6*Ts_s` includes the next CNV. |

Compare A and B bit-for-bit for the event/time tuple, legacy S-function outputs, FE/RA/SAR UnitDelay `old` and `next` signals, effective RAW sequence/validity, and public output sequence. No tolerance should be introduced unless a specific logged representation changes the comparison format; report that limitation explicitly.

## 3. Trace acceptance checks

1. The 11 trace ports occur in the outer observer bundle in this order: FE blocks 322/328/332/347; backend blocks 321/327/334/348; controller blocks 331/333/346; then actual UnitDelay `FEold,FEnext,RAold,RAnext,SARold,SARnext`; then `[cycle,groupIndex,eventTime_s]`.
2. The planned output variable is `observer_log` (double timeseries, width 6329), enabled by `FEAdvanceTrace.valid` and capped at 64 points. With transport disabled, the calendar has 48 groups plus the inclusive next CNV; default sample 5 must produce exactly 49 rows, ending at cycle/sample 6's CNV. Treat fewer or more than 49 rows as an incomplete or mismatched trace; 64 is only a resource cap and must not hide extra rows. Out-of-window trace values are NaN; logger enable logic must avoid retaining other rows.
3. In the selected window, inspect FE/RA `old -> advanced -> after_command/stateNext` phases and retain NaN for a phase that did not execute. Verify final `stateNext` taps against actual UnitDelay D inputs and the following execution's old output; identify initialization/reset/no-execution cases rather than copying a value into a missing phase. Intermediate stage `stateNext` remains stage-local.
4. At cycle 5's first D2 compare (45 ns after CNV, absolute `5*Ts+45 ns`), the controller event slot must retain its original `group.events` ordinal, physical `vy_v`, effective comparator voltage, comparator offset/noise, decision, and event-local state51. Confirm no CAAZ/ADI trace is included.
5. At relative 12.5 ns, controller Prepare trace must contain two slots in original order (`coarse_latch`, `fine_prepare`). At 76.25 ns, Due and Decide traces must show ordinals 1 and 2 for `ta_feedback` and `ta_compare` respectively, with both records sharing the exact event time.
6. Count comparator helper/RNG-path invocations through existing model instrumentation if available; observer trace must not add any call. Check run receipts for elapsed time and artifact size instead of assuming zero overhead.

## 4. Result wording

Only mark the paired comparison as passed after the native R2024a Update 6 run receipts and all paired signal arrays are independently checked. Until then, report the source patch and static schema only; do not claim N256 equivalence, comparator-noise equivalence, or successful model opening.
