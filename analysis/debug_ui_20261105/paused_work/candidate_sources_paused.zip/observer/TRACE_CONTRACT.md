# SAR20-5 passive observer trace contract

## Candidate boundary

This is an isolated source patch under `/tmp`; it does not modify the published `current/` tree or the model file. The locked model baseline is SHA256 `91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e`.

The three affected S-functions accept the original two dialog parameters and retain their original output-port count and stage call when loaded against the old model. With exactly three dialog parameters, the third is `P.debug.observer={enabled,sample_id,Ts_s}` and a diagnostic output is appended after every legacy output. The setup code reads the block's `Parameters` text and counts only top-level commas; it does not evaluate the text. It accepts only two or three parameters.

For the current two-parameter source/model combination, the old output-port counts remain FE=2, BE=2, controller=3. After adding the third dialog parameter and updating the model, the counts become FE=3, BE=3, controller=4. Input widths, direct-feedthrough properties and legacy output order remain unchanged.

The selection window is inclusive:

```text
sample_id * Ts_s <= existing Context.time / eventTime <= (sample_id + 1) * Ts_s
```

The default configuration is `P.debug.observer=struct('enabled',true,'sample_id',5,'Ts_s',P.Ts_s)`. Outside the selected window, diagnostic output vectors are all NaN. The control trace also leaves unused event slots NaN.

## S-function ports

| Module | Dialog parameters | Legacy inputs | Legacy outputs | New final output |
|---|---|---|---|---|
| Frontend | `kind`, `P.front`, `P.debug.observer` | `[353,6,4]` | `[stateNext353,obs7]` | `trace1079` |
| Backend | `kind`, backend parameters, `P.debug.observer` | advance `[48,1,26,353]`; commit `[48,1,26]` | `[stateNext48,obs8]` | `trace164` |
| Controller | `kind`, `P`, `P.debug.observer` | `[51,2,7,3]` | `[stateNext51,signals13,signs19]` | `trace150` |

The backend advance code does not read the new-command port. On the original two-dialog path it retains the exact old call expression; on the three-dialog path it passes an empty unused command value. The port metadata is unchanged.

## Frontend trace, output port 3, 1079 doubles

| Indices | Fields | Source and meaning |
|---|---|---|
| 1:6 | `[valid,time_s,context_id,epoch,kind_code,context_event]` | `Context` values; `kind_code`: advance=1, commit=2; `context_event` is the original unmodified Context(4), decoded jointly with `kind`. |
| 7:359 | `old_FE353` | S-function state input, before the first `behavior_frontend_step('observe',...)`. |
| 360:712 | `advanced_FE353` | State returned by that existing first observe call, before input-change or event commands. |
| 713:1065 | `after_command_FE353` | Final state returned by the existing stage call sequence; all NaN when no command and no source input change occurred. This is the same value as legacy `stateNext` Output 1 when present. |
| 1066:1072 | `advanced_obs7` | The existing first observe call's returned fields. |
| 1073:1079 | `after_command_obs7` | Existing final stage output fields; all NaN when the after-command state is absent. |

Context(4) meanings depend on `kind`. For advance: 0 observe, 1 capture+convert_join (and, in multi-bank mode, next acquire), 2 startup acquire_open, 3 reset. For commit: 0 observe, 1 dac_commit, 2 release (and, in single-bank mode, next acquire), 3 reset. No internal FE operation is replayed to create these snapshots.

## Backend trace, output port 3, 164 doubles

| Indices | Fields | Source and meaning |
|---|---|---|
| 1:4 | `[valid,eventTime_s,kind_code,advanced_valid]` | Existing event time; advance=1, commit=2. |
| 5:52 | `old_RA48` | Existing state input before the stage call. |
| 53:100 | `advanced_RA48` | Packed from `behavior_backend_step`'s already-computed interval endpoint before its endpoint command/CINC switch, with every state word preserved as returned. Its state-time word remains the kernel's own `s.time_s+dt` result; header `eventTime_s` separately retains the exact scheduled event-time word. On `dt=0` or commit this phase is absent and these indices are NaN. |
| 101:148 | `after_command_RA48` | Existing stage-local `stateNext` after its exact event-time alignment; same value as that S-function's legacy Output 1. Only the final `RaReset` stage output feeds the external RA UnitDelay input. |
| 149:156 | `predicted_obs8` | Existing `y.predicted` from the already-computed observe call before endpoint network switching. With finite DAC coupling, the kernel first writes the FE `q_endpoint_c` into its local `old.qres_c` and `cmd.qres_c`, so `predicted.target_v` uses that interval-endpoint charge. The packed `advanced_RA48` still contains the interval-start `s.command.qres_c`. Preserve both actual local results; do not recalculate `predictedObs8` from the packed advanced vector. The reset baseline comes from the old retained state. |
| 157:164 | `actual_obs8` | Existing stage `obs8` from `y.actual`; on commit this is the new-command endpoint. `stateNext` remains stage-local here; only the final `RaReset` stage output feeds the external RA UnitDelay input. |

No backend kernel is called a second time. The extra `advancedState` return is populated only when the selected-window observer requests it.

## Controller trace, output port 4, 150 doubles

Two original-group event slots are flattened as `[slot1(1:75),slot2(1:75)]`; `record_valid` indices are 1 and 76. A slot is written only after the corresponding accepted `group.events` entry has been processed, in the original array order. The current calendar's maximum same-group event count is two, including coarse_latch+fine_prepare at 12.5 ns. At 76.25 ns, due feedback and TA comparison remain separate stage outputs carrying original ordinals 1 and 2.

| Slot-relative indices | Fields | Meaning |
|---|---|---|
| 1:10 | `[record_valid,time_s,sample_id,epoch,group_ordinal,stage_code,event_code,event_index,event_bit,comparison_used]` | `group_ordinal` is the original 1-based index in `group.events`; `stage_code`: due=1, prepare=2, decide=3. |
| 11:20 | `[sample_v,vres_v,vy_v,decision1,decision2,compare_valid,compare_late,cmp_effective_v,cmp_offset_v,cmp_noise_v]` | Present for fine_decide/d2_decide/ta_compare only. The effective voltage/offset/noise come from the same existing comparator helper call; no comparator/noise helper is called twice. Other events keep these fields NaN. |
| 21:24 | `[decision,record_ready,feedback_changed,trial_changed]` | Existing event-local `behavior_sar_step` result. |
| 25:75 | `state_after_event51` | Actual packed controller state immediately after this original event. |

Event code mapping: 1 cnv, 2 coarse_latch, 3 fine_prepare, 4 fine_decide, 5 fine_feedback, 6 ra_start, 7 d2_prepare, 8 d2_decide, 9 d2_feedback, 10 d2_end, 11 ta_compare, 12 ta_feedback, 13 tracking_end, 14 raw_latch, 15 release, 16 reset, 17 frame_ready. The current accepted stage sets do not emit reset/frame_ready slots.

## State handoff and evidence status

The diagnostic `after_command` and each legacy S-function `stateNext` are stage-local outputs. Intermediate FE/RA stage outputs continue into the next real stage; only the final `ChargeReturn` FE output and `RaReset` backend output feed their respective external UnitDelay inputs. Controller `state_after_event51` is event-local, and controller stage `stateNext` is likewise local until the final SAR chain output reaches the `SarState` UnitDelay input. The outer observer must tap each UnitDelay Q as `old` and its actual D input as `next`; do not relabel an intermediate stage output as a committed or final next state. A UnitDelay output becomes the next execution's `old` value only after the delay update.

## Outer logger contract

The 11 stable S-function trace signal names are:

```text
FEAdvanceTrace, FEDacFeedbackTrace, FEDacTrialTrace, FEChargeReturnTrace
BackendAdvanceTrace, BackendCtFeedbackTrace, BackendRaAzCtTrace, BackendRaResetTrace
ControlDueTrace, ControlPrepareTrace, ControlDecideTrace
```

The planned outer Observer bundle concatenates them in that order, then the actual state-owner taps `[FEold353,FEnext353,RAold48,RAnext48,SARold51,SARnext51]` (904 doubles), then `[cycle,groupIndex,eventTime_s]` (3 doubles). Total width is 6329 doubles. The S-function trace headers/slots carry their own time and sample/epoch/event tags; the final tuple preserves source scheduler context.

The planned workspace variable is `observer_log`, a double `timeseries` with inherited sample time and `MaxDataPoints=64`. Its enable signal is `FEAdvanceTrace.valid` (column 1), finite/1 only in the inclusive window selected by `P.debug.observer.sample_id` and `Ts_s` (default sample ID 5). With transport disabled, the event calendar has 48 unique groups per cycle; the inclusive next-CNV endpoint adds the 49th row. The default sample 5 run is expected to contain exactly 49 rows, tagged with cycle/sample IDs 5 and the next-CNV cycle 6; fewer or more than 49 is an incomplete/mismatched trace and must be reported by the reader. The 64-point cap is only a resource ceiling so excess rows remain detectable instead of being truncated at 49. Static payload is 2,480,968 bytes at 49 expected rows and 3,240,448 bytes at the 64-point cap, before MATLAB timeseries metadata. These are size calculations, not measured run overhead. Model wiring, logger settings, and row count are not yet native-verified.

No MATLAB/Windows run was performed for this source patch. It is not evidence of compiled ports, native execution, simulation equivalence, or an N256 pass.
