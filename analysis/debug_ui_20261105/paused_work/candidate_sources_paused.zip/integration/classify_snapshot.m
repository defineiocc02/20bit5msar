% CLASSIFY_SNAPSHOT v1: resume saved stage1 checkpoint; actual model navigation view.
job='D:/Temp/SAR20DEBUG_CLASSIFY_20261105';
restoredefaultpath;addpath(job,'-begin');run_classify(job);
function run_classify(job)
    root='D:/Academic/Projects/sar20m1/SAR20';tool=fullfile(root,'dependencies','toolkit','tools');
    r=struct('status','starting','pid',feature('getpid'),'simulation_run',false, ...
        'baseline_sha256','91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e', ...
        'resumed_sha256','80a2bd30c13d213e12dc6fd131f9361c50bba3483a15571cfa05c9df8f657c45');
    model=fullfile(job,'model','SarAdc.slx');assert(strcmp(sha(model),r.resumed_sha256));
    addpath(fullfile(tool,'common'),fullfile(tool,'common','autolayout'), ...
        fullfile(tool,'model_read'),fullfile(tool,'model_edit'),fullfile(tool,'model_check'),'-begin');
    addpath(genpath(fullfile(root,'current','src')),fullfile(root,'config'),'-begin');
    cd(job);gate=library.settingsLookup();assert(~gate.found||gate.gatePass);r.library_gate=gate;
    assert(~bdIsLoaded('SarAdc'));open_system(model);
    ws=get_param('SarAdc','ModelWorkspace');P=getVariable(ws,'P');D=getVariable(ws,'DecodeP');rng0=rng;
    try
        % SATK refuses this hidden display-only parameter although native R2024a
        % supports it. Use native API only for this explicitly requested style.
        ids=[105 112 123 232 244 261 279 285 297];r.preview_api='native display-only ContentPreviewEnabled; SDK PARAM_VALUE_INVALID retained';
        for sid=ids
            path=Simulink.ID.getFullName(['SarAdc:' num2str(sid)]);
            set_param(path,'ContentPreviewEnabled','off');assert(strcmp(get_param(path,'ContentPreviewEnabled'),'off'));
        end
        read=char(model_read('SarAdc','blk_105','0'));write_text(fullfile(job,'eventstep_before.txt'),read);
        assert(~contains(read,'Name: PhysicalView'),'classify:exists','PhysicalView already exists; do not duplicate.');
        ops={struct('op','create_subsystem','name','PhysicalView','ref','pv', ...
            'interface',struct('inputs',{{}},'outputs',{{}}))};
        edit_scope('blk_105',ops,job,'parent');
        view=char(model_read('SarAdc','blk_105','0'));sid=find_id(view,'PhysicalView');
        labels={ ...
          'Sample_DAC1','片内ADC | 输入采集与DAC1','FE353：一个物理阵列的8个数值分段'; ...
          'Coarse_SAR1','片内ADC | 6位预转换 / SAR1','阈值预转换与5次细SAR；控制状态SAR51'; ...
          'Residue','片内ADC | 真实电荷残差','FE353生成Qres；RA48仅锁存区间命令'; ...
          'Shared_RA_AZ','片内ADC | 唯一共享RA / AZ','同一个RaCtState[48]；多阶段调用非多台RA'; ...
          'CINC_CT','片内ADC | CINC / 连续时间CT','同一VX与CT电荷；RA后无新增采样保持'; ...
          'SAR2_Tracking','片内ADC | SAR2 / Tracking','12次D2；8次比较、7次物理反馈'; ...
          'Digital_Code','片外FPGA | 数字重构与输出','D1+D2后加DT；舍入/饱和；名义码旁路'; ...
          'LVDS','跨芯片协议 | LVDS TX / RX','片内TX + 片外FPGA RX；当前关闭，非电气/CDC模型'};
        ops=cell(1,size(labels,1));
        for k=1:size(labels,1),ops{k}=struct('op','create_subsystem','name',labels{k,1},'ref',['c' num2str(k)],'interface',struct('inputs',{{}},'outputs',{{}}));end
        edit_scope(sid,ops,job,'cards');view=char(model_read('SarAdc',sid,'0'));
        ops=cell(1,size(labels,1));
        for k=1:size(labels,1)
            id=find_id(view,labels{k,1});path=Simulink.ID.getFullName(['SarAdc:' extractAfter(id,'blk_')]);
            assert(all(get_param(path,'Ports')==0));set_param(path,'ContentPreviewEnabled','off');
            col=mod(k-1,4);row=floor((k-1)/4);position=[80+col*355 110+row*230 365+col*355 235+row*230];
            text=sprintf('%s\n%s\n功能导航块：不执行计算',labels{k,2},labels{k,3});
            ops{k}=struct('op','configure','target',id,'params',struct('AttributesFormatString',text,'Position',position,'FontSize','14'));
        end
        edit_scope(sid,ops,job,'labels');
        p=Simulink.ID.getFullName(['SarAdc:' extractAfter(sid,'blk_')]);
        set_param(p,'ContentPreviewEnabled','off');
        r.scope_sid=sid;r.cards=labels;r.navigation_callbacks='pending entry integration; view not an independently executable architecture';
        assert(isequaln(P,getVariable(ws,'P'))&&isequaln(D,getVariable(ws,'DecodeP'))&&isequaln(rng0,rng));
        save_system('SarAdc',model);r.model_sha256=sha(model);r.status='CLASSIFICATION_VIEW_SAVED';
        r.export_utc=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
        write_json(fullfile(job,'view_receipt.json'),r);
        print(['-s' p],'-dpng','-r150',fullfile(job,'physical_view.png'));
        print('-sSarAdc/EventStep/Adc','-dpng','-r120',fullfile(job,'execution_before_layout.png'));
        close_system('SarAdc',0);
    catch ex
        r.status='failed';r.error=getReport(ex,'extended','hyperlinks','off');
        if bdIsLoaded('SarAdc'),save_system('SarAdc',model);r.partial_sha256=sha(model);close_system('SarAdc',0);end
        write_json(fullfile(job,'view_receipt.json'),r);rethrow(ex);
    end
end
function edit_scope(scope,ops,job,name)
    before=char(model_read('SarAdc',scope,'0'));reply=char(model_edit('SarAdc',scope,jsonencode(ops),'incremental'));
    after=char(model_read('SarAdc',scope,'0'));check=char(model_check('SarAdc',scope,'["unconnected_ports","unconnected_lines"]'));
    write_json(fullfile(job,[name '_scope.json']),struct('scope',scope,'before',before,'reply',reply,'after',after,'check',check));
    assert(startsWith(reply,'status: ok')||startsWith(reply,'status: success'),'classify:edit','%s',reply);
    assert(startsWith(check,'status: healthy'),'classify:check','%s',check);
end
function id=find_id(view,name)
    ids=unique(regexp(view,'blk_[0-9]+','match'),'stable');hits={};
    for k=1:numel(ids),p=Simulink.ID.getFullName(['SarAdc:' extractAfter(ids{k},'blk_')]);if strcmp(get_param(p,'Name'),name),hits{end+1}=ids{k};end,end %#ok<AGROW>
    assert(numel(hits)==1,'classify:id','Expected unique actual block %s.',name);id=hits{1};
end
function h=sha(file)
    f=fopen(file,'rb');assert(f>=0);c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8'); %#ok<NASGU>
    m=java.security.MessageDigest.getInstance('SHA-256');m.update(b);h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
function write_json(file,r),write_text(file,jsonencode(r));end
function write_text(file,t),f=fopen(file,'w','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'%s\n',t);end %#ok<NASGU>
