# Cleanup only exact terminal tasks and regenerable caches created in this work.
$ErrorActionPreference='Stop'
$job='D:\Temp\SAR20DEBUG_UI_20261105';$out=Join-Path $job 'pause_cleanup'
if(Test-Path $out){throw 'Cleanup archive already exists.'}
$gui=Get-Content (Join-Path $job 'pause_gui_receipt.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($gui.status -ne 'PAUSE_CLEANUP_COMPLETE'){throw 'GUI cleanup did not finish.'}
$p=@(Get-Process MATLAB)
if($p.Count -ne 1 -or $p[0].Id -ne 27628){throw 'Unexpected MATLAB worker; leave tasks/caches untouched.'}
$names=@('SAR20_CAAZ_AZVX_20261105','SAR20_CAAZ_UNIT_20261105',
 'SAR20_DEBUG_CLASSIFY_20261105','SAR20_DEBUG_DISPLAYPROP_20261105',
 'SAR20_DEBUG_GRAPH1_20261105','SAR20_DEBUG_QUERY_20261105',
 'SAR20_DEBUG_SOURCE_SMOKE_20261105','SAR20_FRAME_BUILD_20261105',
 'SAR20_PKU_CAAZ_N8_20261105','SAR20_PKU_CICC_N8_20261105',
 'SAR20_PKU_DEMOD_20261105','SAR20_PKU_PROBE_20261105',
 'SAR20_DEBUG_PAUSE_CLEANUP_20261105')
$original=@{}
foreach($n in @('SAR20_MatlabControl','SAR20_ReadDesktop')){$original[$n]=[string](Export-ScheduledTask -TaskName $n)}
foreach($n in $names){if([string](Get-ScheduledTask -TaskName $n).State -ne 'Ready'){throw ('Task not terminal: '+$n)}}
[void](New-Item -ItemType Directory -Path $out)
$rows=@()
foreach($n in $names){
 $file=Join-Path $out ($n+'.xml');$xml=[string](Export-ScheduledTask -TaskName $n)
 [IO.File]::WriteAllText($file,$xml,[Text.UTF8Encoding]::new($false))
 $info=Get-ScheduledTaskInfo -TaskName $n
 $rows += [pscustomobject]@{task=$n;last_result=$info.LastTaskResult;definition_sha256=(Get-FileHash $file -Algorithm SHA256).Hash.ToLowerInvariant()}
 Unregister-ScheduledTask -TaskName $n -Confirm:$false
}
foreach($n in $original.Keys){if([string](Export-ScheduledTask -TaskName $n) -ne $original[$n]){throw 'Original task definition changed.'}}
$cachePaths=@('D:\Temp\SAR20DEBUG_SOURCE_SMOKE_20261105\worker_prefs',
 'D:\Temp\SAR20DEBUG_GRAPH1_20261105\worker_prefs','D:\Temp\SAR20DEBUG_CLASSIFY_20261105\worker_prefs',
 'D:\Temp\SAR20_WORKER_TMP\DEBUG_SOURCE_SMOKE_20261105','D:\Temp\SAR20_WORKER_TMP\DEBUG_GRAPH1_20261105',
 'D:\Temp\SAR20_WORKER_TMP\DEBUG_CLASSIFY_20261105',
 'D:\Temp\SAR20DEBUG_SOURCE_SMOKE_20261105\slprj','D:\Temp\SAR20DEBUG_GRAPH1_20261105\slprj',
 'D:\Temp\SAR20DEBUG_CLASSIFY_20261105\slprj')
$caches=@();[long]$freed=0
foreach($path in $cachePaths){
 if(-not (Test-Path -LiteralPath $path)){continue}
 $items=@(Get-ChildItem -LiteralPath $path -Recurse -Force)
 $unsafe=@($items|Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -or (-not $_.PSIsContainer -and $_.Length -gt 300000000)})
 if($unsafe.Count -gt 0){$caches += [pscustomobject]@{path=$path;status='skipped_large_or_reparse';bytes=0};continue}
 [long]$bytes=0;foreach($f in @($items|Where-Object {-not $_.PSIsContainer})){$bytes+=$f.Length}
 Remove-Item -LiteralPath $path -Recurse -Force
 if(Test-Path -LiteralPath $path){throw ('Cache removal failed: '+$path)}
 $freed+=$bytes;$caches += [pscustomobject]@{path=$path;status='deleted_regenerable';bytes=$bytes}
}
$r=[pscustomobject]@{status='PAUSED_TASKS_RETIRED';tasks=$rows;cache_cleanup=$caches;cache_logical_bytes_removed=$freed;original_tasks_unchanged=$true;raw_and_as_run_preserved=$true}
[IO.File]::WriteAllText((Join-Path $out 'receipt.json'),($r|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{status=$r.status;retired_tasks=$rows.Count;cache_bytes_removed=$freed;original_tasks_unchanged=$true}|ConvertTo-Json -Compress
