$ErrorActionPreference='Stop'
$p=@(Get-Process MATLAB)
if($p.Count -ne 1 -or $p[0].Id -ne 27628){throw 'Original GUI only expected.'}
$app=[Runtime.InteropServices.Marshal]::GetActiveObject('Matlab.Application')
$out=[string]$app.Execute("disp(get_param(Simulink.ID.getFullName('SarAdc:105'),'ContentPreviewEnabled')); disp(exist('exportapp','file'));")
[IO.File]::WriteAllText('D:/Temp/SAR20DEBUG_UI_20261105/display_prop_console.txt',$out,[Text.UTF8Encoding]::new($false))
