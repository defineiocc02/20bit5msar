function report=SAR20(action,varargin)
%SAR20 v3 — sole public entry for the editable behavioral Simulink project.
% SAR20 / SAR20('home') displays the debug dashboard; SAR20('open') opens the real model.
% SAR20('results'[,runPath]) lists saved local results; compare/run/sample remain read-only at their boundaries.
% SAR20('compare',runPathA,runPathB[,sampleID]) compares two saved runs.
% SAR20('focus',semanticKey[,owner]) navigates through the verified SID manifest.
% SAR20('apply',P) explicitly prepares/applies P; no-P apply uses the normal factory.
% Edit config/adc_parameters.m (N/input) or config/normal_parameters.m (NI), then apply.
% Factory edits do not change saved P; GUI Run uses the loaded ModelWorkspace.P.
% SAR20('sample',id,runPath) reads a saved run and writes a derived view beside it, never into it.
% SAR20('calibration',...) is unavailable until single-bank calibration is validated.
% Root-relative current/models/SarAdc.slx, current/src and config/adc_parameters.m.
% apply derives parameters; run ALWAYS uses the saved model workspace P.
% Apply binds the resolved ModelWorkspace P/DecodeP and factory-source identities.
    if nargin==0||isempty(action),action='home';end
    action=lower(char(action));
    assert(ismember(action,{'setup','home','open','apply','check','run','sample', ...
        'calibration','results','compare','focus'}), ...
        'SAR20:action','Unknown action.');
    validate_action_arguments(action,varargin);
    root=fileparts(mfilename('fullpath'));src=fullfile(root,'current','src');
    config=fullfile(root,'config');model='SarAdc';modelFile=fullfile(root,'current','models',[model '.slx']);
    assert(isfolder(src)&&isfolder(config),'SAR20:layout','Missing current/src or config.');
    % Remove only this project's retired runtime paths; preserve other work.
    oldPaths=strsplit(path,pathsep);
    for k=1:numel(oldPaths)
        item=oldPaths{k};
        if isempty(item),continue;end
        retired=under(item,fullfile(root,'current')) && ~under(item,src) && ~strcmpi(canon(item),canon(src));
        staging=startsWith(strrep(lower(item),'\','/'),'d:/temp/sar20behavior/') && ...
            ~startsWith(strrep(lower(root),'\','/'),'d:/temp/sar20behavior/');
        if retired||staging,rmpath(item);end
    end
    addpath(genpath(src),config,'-begin');
    verify_project_resolution(root,src,config);
    report=struct('action',action,'status','setup_complete','project_root',root);
    if strcmp(action,'setup'),return;end
    if strcmp(action,'home')
        report=home_report(root,model,modelFile);
        runtime_entry('sar20_dashboard',fullfile(src,'analysis'));
        sar20_dashboard('home',report);return;
    end
    if strcmp(action,'results')
        selectedPath='';if ~isempty(varargin),selectedPath=varargin{1};end
        if isempty(selectedPath),selectedPath='';end
        report=sar20_debug_result_registry(root,selectedPath);
        runtime_entry('sar20_dashboard',fullfile(src,'analysis'));
        sar20_dashboard('results',report);return;
    end
    if strcmp(action,'compare')
        runA=path_argument(varargin{1},'first run');runB=path_argument(varargin{2},'second run');
        sampleID=[];if numel(varargin)>=3,sampleID=varargin{3};end
        if isempty(sampleID),sampleID=common_sample_id(runA,runB);end
        assert(isnumeric(sampleID)&&isreal(sampleID)&&isscalar(sampleID)&& ...
            isfinite(sampleID)&&sampleID>=0&&sampleID==floor(sampleID), ...
            'SAR20:compareSampleID','sampleID must be a nonnegative integer ID.');
        runtime_entry('sar20_debug_compare',fullfile(src,'analysis'));
        report=sar20_debug_compare(runA,runB,sampleID);
        assert(isstruct(report)&&isscalar(report),'SAR20:compareView', ...
            'Compare helper must return one saved-run comparison view.');
        report.action='compare';report.sample_id=sampleID;
        runtime_entry('sar20_dashboard',fullfile(src,'analysis'));
        sar20_dashboard('compare',report);return;
    end
    if strcmp(action,'focus')
        target=varargin{1};owner='';if numel(varargin)>=2,owner=varargin{2};end
        report=focus_report(root,model,modelFile,target,owner);
        runtime_entry('sar20_dashboard',fullfile(src,'analysis'));
        sar20_dashboard('focus',report);return;
    end
    if strcmp(action,'calibration')
        error('singleBank:calibrationUnavailable', ...
            'Single-bank calibration is not validated; do not freeze or apply legacy pool coefficients.');
    end
    if strcmp(action,'sample')
        assert(numel(varargin)==2,'SAR20:samplePathRequired', ...
            'Use SAR20(''sample'',id,runPath) with an explicit saved single-bank run.');
        id=varargin{1};assert(isnumeric(id)&&isreal(id)&&isscalar(id)&&isfinite(id)&& ...
            id>=0&&id==floor(id),'SAR20:sampleID','ID must be nonnegative integer.');
        inputPath=varargin{2};
        assert((ischar(inputPath)&&isrow(inputPath)&&~isempty(inputPath))|| ...
            (isstring(inputPath)&&isscalar(inputPath)&&strlength(inputPath)>0), ...
            'SAR20:samplePath','runPath must be a nonempty text scalar.');
        runPath=canon(char(inputPath));
        assert(isfolder(runPath),'SAR20:samplePath','The specified run directory does not exist.');
        inputFiles={'parameters.mat','simout.mat','summary.json'};
        for k=1:numel(inputFiles)
            f=dir(fullfile(runPath,inputFiles{k}));
            assert(isscalar(f)&&~f.isdir&&f.bytes<=300e6,'SAR20:sampleInput', ...
                'Missing or oversized saved run file: %s.',inputFiles{k});
        end
        % Historical sample viewing is archive-only: the data helper validates
        % saved files and classifies baseline family without current PDK guards.
        runtime_entry('sar20_debug_sample',fullfile(src,'analysis'));
        D=sar20_debug_sample(runPath,id);
        assert(isstruct(D)&&isscalar(D)&&isfield(D,'events')&&isfield(D,'waveforms')&& ...
            isfield(D,'snapshots')&&isfield(D,'validity')&&isfield(D,'firstD2'), ...
            'SAR20:sampleView','Sample helper must return the registered interactive view schema.');
        reportRoot=fullfile(root,'runs');
        assert(~strcmpi(canon(reportRoot),runPath)&&~under(reportRoot,runPath), ...
            'SAR20:sampleOutput','Sample view output must be outside the selected source run.');
        if ~isfolder(reportRoot)
            [ok,msg]=mkdir(reportRoot);assert(ok,'SAR20:sampleOutput','%s',msg);
        end
        outputDir=fullfile(reportRoot,['sample_' char(java.util.UUID.randomUUID())]);
        assert(~isfolder(outputDir)&&~isfile(outputDir),'SAR20:sampleOutput','Report directory already exists.');
        [ok,msg,msgid]=mkdir(outputDir);
        assert(ok&&isempty(msgid),'SAR20:sampleOutput','%s',msg);
        runID=sample_run_id(D,runPath);
        D.run_path=runPath;D.run_id=runID;D.sample_id=id;D.output_dir=outputDir;
        viewFile=fullfile(outputDir,'sample_view.mat');
        identity=struct('schema','sar20-sample-view/v1','source_run_path',runPath, ...
            'run_id',runID,'sample_id',id,'events_count',height(D.events), ...
            'waveforms_count',numel(D.waveforms),'snapshot_count',numel(D.snapshots), ...
            'source_summary_sha256',sha(fullfile(runPath,'summary.json')), ...
            'source_parameters_sha256',sha(fullfile(runPath,'parameters.mat')), ...
            'source_simout_sha256',sha(fullfile(runPath,'simout.mat')), ...
            'read_only_source_run',true,'view_file','sample_view.mat');
        save(viewFile,'D','identity','-v7.3');identity.view_sha256=sha(viewFile);
        write_json(fullfile(outputDir,'sample_manifest.json'),identity);
        report=struct('action','sample','status','sample_view_ready','run_path',runPath, ...
            'run_id',runID,'output_dir',outputDir,'sample_id',id, ...
            'events_count',height(D.events),'view_sha256',identity.view_sha256, ...
            'view_file',viewFile,'manifest_file',fullfile(outputDir,'sample_manifest.json'));
        runtime_entry('sar20_dashboard',fullfile(src,'analysis'));
        sar20_dashboard('sample',D);return;
    end
    if strcmp(action,'apply'),require_toolkit(root);end
    assert(isfile(modelFile),'SAR20:model','Missing unique current/models/SarAdc.slx.');
    wasLoaded=bdIsLoaded(model);
    resumeDirtyPending=false;
    if wasLoaded&&strcmp(get_param(model,'Dirty'),'on')&&strcmp(action,'apply')
        resumeDirtyPending=safe_pending_apply_resume(root,model,modelFile);
    end
    if ~resumeDirtyPending,guard_model(model,modelFile);end
    if strcmp(action,'open')
        open_system(modelFile);report.status='model_opened';
        report.configuration='saved ModelWorkspace.P';
        report.factory_edits_require='SAR20(''apply'')';
        if ~isfile(fullfile(root,'state','applied_config.json'))
            warning('SAR20:applyRequired', ...
                'No public apply record; open uses saved P. Run SAR20(''apply'') to save the factory configuration.');
        end
        return;
    end
    if strcmp(action,'run'),require_applied_model(root,modelFile);end
    if ~wasLoaded,load_system(modelFile);end
    cleanup=onCleanup(@()close_owned(model,wasLoaded)); %#ok<NASGU>
    ws=get_param(model,'ModelWorkspace');
    switch action
        case 'apply'
            assert(numel(varargin)<=1,'SAR20:arguments','Use apply or apply with one scalar P.');
            runtime_entry('sar20_navigation_manifest',fullfile(src,'analysis'));
            state=fullfile(root,'state');if ~isfolder(state),mkdir(state);end
            transaction=read_apply_transaction(root);
            currentModelSha=sha(modelFile);
            recoverNavigation=false;
            if isfield(transaction,'pending')&&isequal(transaction.pending,true)&& ...
                    ~strcmp(text_local(transaction,'model_sha_before'),'unknown')
                afterSha=text_local(transaction,'model_sha_after');
                recoverNavigation=strcmp(afterSha,currentModelSha);
                if ~recoverNavigation&&strcmp(afterSha,'unknown')&& ...
                        ~strcmp(text_local(transaction,'model_sha_before'),currentModelSha)
                    currentWs=get_param(model,'ModelWorkspace');
                    if hasVariable(currentWs,'P')&&hasVariable(currentWs,'DecodeP')
                        currentP=getVariable(currentWs,'P');currentDecodeP=getVariable(currentWs,'DecodeP');
                        pHash=sar20_parameter_fingerprint(currentP);
                        dHash=sar20_parameter_fingerprint(currentDecodeP);
                        recoverNavigation=strcmp(pHash.sha256,text_local(transaction,'prepared_P_sha256'))&& ...
                            strcmp(dHash.sha256,text_local(transaction,'prepared_DecodeP_sha256'))&& ...
                            isstruct(currentP)&&isfield(currentP,'digital')&&isequaln(currentDecodeP,currentP.digital);
                    end
                end
            end
            if recoverNavigation
                recovered=sar20_navigation_manifest('recover',root,model,modelFile, ...
                    transaction.model_sha_before);
                transaction.navigation_recovery_status=recovered.status;
                transaction.navigation_manifest_sha256=recovered.manifest_sha256;
                transaction.last_recovery_utc=utc_now();
                write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            end
            navigationBefore=sar20_navigation_manifest('verify',root,model,modelFile);
            factorySource=sar20_factory_source_identity(root);
            previousP=load_applied_parameters(root);
            runtime_entry('behavior_prepare_configuration',src);
            runtime_entry('behavior_applied_note',src);
            if isempty(varargin)
                assert(strcmp(factorySource.status,'complete'),'SAR20:factoryIdentityUnknown', ...
                    'Factory input hashes are incomplete/oversized; no factory apply was performed.');
                runtime_entry('adc_parameters',config);P=adc_parameters();source='factory';
                configurationName=sprintf('factory_%gMS_%sAZ_N%d', ...
                    1e-6/P.Ts_s,char(P.backend.az.mode),P.N);
                factorySourceAfter=sar20_factory_source_identity(root);
                assert(strcmp(factorySource.source_sha256,factorySourceAfter.source_sha256), ...
                    'SAR20:factorySourceChanged','Factory files changed while P was being constructed; no apply was saved.');
                factorySource=factorySourceAfter;
            else
                P=varargin{1};source='explicit';
                configurationName='explicit_P';
                assert(isstruct(P)&&isscalar(P),'SAR20:parameters','Explicit P must be a scalar struct.');
            end
            P=configure_debug_observer(P);
            inputChanges=sar20_parameter_diff(previousP,P);
            P=behavior_prepare_configuration(P);
            assert(isstruct(P)&&isscalar(P)&&isfield(P,'digital'),'SAR20:parameters','Prepared P must contain digital settings.');
            DecodeP=P.digital;
            preparedFingerprint=sar20_parameter_fingerprint(P);
            preparedDecodeFingerprint=sar20_parameter_fingerprint(DecodeP);
            transaction=struct('schema','sar20-apply-transaction/v1','pending',true, ...
                'status','prepared_before_model_save','started_utc',utc_now(), ...
                'model_sha_before',navigationBefore.model_sha256,'model_sha_after','unknown', ...
                'configuration_source',source,'configuration_name',configurationName, ...
                'factory_source_sha256',factorySource.source_sha256, ...
                'factory_source_status',factorySource.status, ...
                'prepared_P_sha256',preparedFingerprint.sha256, ...
                'prepared_DecodeP_sha256',preparedDecodeFingerprint.sha256, ...
                'recovery','Inspect SAR20(''home''). Resume is allowed only when prepared P/DecodeP, saved-model path/SHA and verified SID manifest match; other dirty edits require explicit resolution.');
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            transaction.status='model_workspace_assignment_started';
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            assignin(ws,'P',P);assignin(ws,'DecodeP',DecodeP);
            assignin(ws,'TrainCaptureFile',''); % independent model default, never stored in P
            transaction.status='model_workspace_assigned';
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);

            noteReport=behavior_applied_note('update',model);
            transaction.status='model_note_updated';
            transaction.display_note=noteReport.text;
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            save_system(model,modelFile,'SaveModelWorkspace',true);
            modelSha=sha(modelFile);
            transaction.status='model_saved_navigation_pending';
            transaction.model_sha_after=modelSha;transaction.model_saved_utc=utc_now();
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            savedP=getVariable(ws,'P');savedDecodeP=getVariable(ws,'DecodeP');
            assert(isequaln(savedP,P)&&isequaln(savedDecodeP,DecodeP)&& ...
                isequaln(savedDecodeP,savedP.digital),'SAR20:applyWorkspaceBinding', ...
                'Saved ModelWorkspace P/DecodeP do not match the parameters prepared for this apply.');
            P=savedP;DecodeP=savedDecodeP;
            pFingerprint=sar20_parameter_fingerprint(savedP);
            dFingerprint=sar20_parameter_fingerprint(savedDecodeP);
            noiseConvention=parameter_noise_convention(P,source);
            derived=parameter_prepare_report(P,source,inputChanges);
            parameterMatName=sprintf('applied_parameters_%s_%s_%s.mat', ...
                modelSha(1:12),pFingerprint.sha256(1:12),char(java.util.UUID.randomUUID()));
            parameterMat=fullfile(state,parameterMatName);
            assert(~isfile(parameterMat)&&~isfolder(parameterMat), ...
                'SAR20:applyParameterSnapshotExists','Refuse to overwrite an existing applied P snapshot.');
            identity=struct('schema','sar20-applied-parameters/v1', ...
                'model_sha256',modelSha,'baseline_model_sha256', ...
                '91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e', ...
                'P_sha256',pFingerprint.sha256,'DecodeP_sha256',dFingerprint.sha256, ...
                'factory_source_sha256',factorySource.source_sha256, ...
                'factory_source_files',factorySource.source_files, ...
                'factory_source_file_list',factorySource.files, ...
                'configuration_source',source,'configuration_name',configurationName, ...
                'noise_convention',noiseConvention,'derived_report',derived, ...
                'observer_identity',P.debug.observer, ...
                'display_note',noteReport.text,'detailed_text',noteReport.detailed_text);
            save(parameterMat,'P','DecodeP','identity','-v7.3');
            parameterMatSha=sha(parameterMat);
            transaction.status='parameters_mat_saved';
            transaction.parameters_mat=relative(parameterMat,root);
            transaction.parameters_mat_sha256=parameterMatSha;
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            navigation=sar20_navigation_manifest('refresh',root,model,modelFile, ...
                navigationBefore.model_sha256,modelSha);
            transaction.status='navigation_refreshed';
            transaction.navigation_manifest_sha256=navigation.manifest_sha256;
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            applied=struct('schema','sar20-applied-config/v2','utc',utc_now(), ...
                'model_sha256',modelSha,'baseline_model_sha256',identity.baseline_model_sha256, ...
                'configuration_source',source,'configuration_name',configurationName, ...
                'source_sha256',factorySource.source_sha256, ...
                'source_files',factorySource.source_files,'source_file_list',factorySource.files, ...
                'factory_source_status',factorySource.status, ...
                'P_sha256',pFingerprint.sha256,'DecodeP_sha256',dFingerprint.sha256, ...
                'parameters_mat',relative(parameterMat,root), ...
                'parameters_mat_sha256',parameterMatSha,'noise_convention',noiseConvention, ...
                'derived_report',derived,'observer_identity',P.debug.observer, ...
                'display_note',noteReport.text,'detailed_text',noteReport.detailed_text, ...
                'navigation_manifest_sha256',navigation.manifest_sha256, ...
                'navigation_status',navigation.status, ...
                'config_identity','Referenced applied P/DecodeP MAT is exact; config is a lossy JSON display projection', ...
                'config',P);
            write_json_atomic(fullfile(state,'applied_config.json'),applied);
            transaction.status='applied_config_saved';transaction.pending=false;
            transaction.finished_utc=utc_now();transaction.parameters_mat_sha256=parameterMatSha;
            write_json_atomic(fullfile(state,'apply_transaction.json'),transaction);
            report=struct('action','apply','status','parameters_applied', ...
                'model_sha256',applied.model_sha256,'configuration_source',source, ...
                'configuration_name',configurationName,'source_sha256',factorySource.source_sha256, ...
                'P_sha256',pFingerprint.sha256,'DecodeP_sha256',dFingerprint.sha256, ...
                'parameters_mat_sha256',parameterMatSha,'noise_convention',noiseConvention, ...
                'derived_report',derived,'observer_identity',P.debug.observer, ...
                'display_note',noteReport.text,'detailed_text',noteReport.detailed_text, ...
                'navigation_manifest_sha256',navigation.manifest_sha256);
        case 'check'
            P=getVariable(ws,'P'); %#ok<NASGU>
            set_param(model,'SimulationCommand','update');
            report=struct('action','check','status','actual_model_update_pass','model_sha256',sha(modelFile),'simulation_run',false);
        case 'run'
            P=getVariable(ws,'P');
            behavior_single_guard(P,true);
            DecodeP=getVariable(ws,'DecodeP');
            assert(isequaln(DecodeP,P.digital)&& ...
                strcmp(P.backend.az.mode,P.digital.az_mode)&& ...
                P.backend.ni.az==~strcmp(P.backend.az.mode,'off')&& ...
                P.ni.az==P.backend.ni.az,'SAR20:modeJoin', ...
                'Saved analog, digital and coverage configurations differ; apply consistent parameters before running.');
            runtime_entry('behavior_applied_note',src);
            behavior_applied_note('check',model);
            runtime_entry('behavior_spectrum',src);
            runtime_entry('behavior_spectrum_eligibility',src);
            spectrumEligibility=behavior_spectrum_eligibility(P.N,P.fs_hz, ...
                P.input.frequency_hz,P.input.amplitude_v);
            runIdentity=run_identity(root,modelFile,P,DecodeP);
            report=run_saved(model,modelFile,P,DecodeP,root,src,config, ...
                spectrumEligibility,runIdentity);
    end
end

function validate_action_arguments(action,args)
    n=numel(args);
    switch action
        case {'setup','home','open','check','run'}
            valid=n==0;
        case 'apply'
            valid=n<=1;
        case 'sample'
            valid=n==2;
        case 'results'
            valid=n<=1;
        case 'compare'
            valid=n==2||n==3;
        case 'focus'
            valid=n==1||n==2;
        case 'calibration'
            valid=true;
        otherwise
            valid=false;
    end
    assert(valid,'SAR20:arguments','Invalid argument count for SAR20(''%s'',...).',action);
end

function report=home_report(root,model,modelFile)
    state=sar20_parameter_state(root,model,modelFile);
    modelSha=sha(modelFile);
    configurationSummary=state.workspace.configuration_summary;
    if isempty(fieldnames(configurationSummary))&&isfield(state.applied,'configuration_summary')
        configurationSummary=state.applied.configuration_summary;
    end
    modelVersion='unknown';
    if isstruct(configurationSummary)&&isfield(configurationSummary,'schema')
        modelVersion=configurationSummary.schema;
    end
    report=struct('action','home','status','dashboard_ready','project_root',root, ...
        'model_path',modelFile,'model_name',model,'model_sha256',modelSha, ...
        'model_dirty_status',model_dirty_status(model,modelFile), ...
        'model_version',modelVersion, ...
        'baseline_model_sha256','91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e', ...
        'baseline_model_sha_prefix','91973cf76507', ...
        'physical_baseline','5 MS/s, single physical frontend, ordinary AZ, N=256 default', ...
        'parameter_state',state,'factory_source',state.factory_source, ...
        'source_pending_status',state.source_pending_status, ...
        'applied_configuration',state.applied, ...
        'parameter_derivation',field_local(state.applied,'derived_report',struct()), ...
        'noise_convention',field_local(state.applied,'noise_convention',struct()), ...
        'apply_transaction',read_apply_transaction(root), ...
        'configuration_summary',configurationSummary, ...
        'workspace_status',state.workspace, ...
        'selected_run',state.selected_run, ...
        'operation_semantics',struct('apply', ...
        'SAR20(''apply'') resolves factory P or supplied explicit P, prepares it and saves ModelWorkspace.P/DecodeP.', ...
        'SAR20_run','SAR20(''run'') uses the currently loaded/saved ModelWorkspace.P and records exact P/DecodeP.', ...
        'GUI_Run','GUI Run uses the loaded ModelWorkspace values and bypasses SAR20 public run checks.', ...
        'factory_status','Dashboard hashing never executes adc_parameters or normal_parameters.'), ...
        'actions',{{'open','apply','check','run','sample','results','compare','focus','calibration'}});
end

function transaction=read_apply_transaction(root)
    file=fullfile(root,'state','apply_transaction.json');
    d=dir(file);
    if isempty(d)
        transaction=struct('status','no_apply_transaction','pending',false);return;
    end
    assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6,'SAR20:applyTransaction', ...
        'Missing or oversized apply transaction marker.');
    transaction=jsondecode(fileread(file));
end

function status=model_dirty_status(model,modelFile)
    if ~bdIsLoaded(model),status='model_not_loaded';return;end
    actual=get_param(model,'FileName');
    if isempty(actual)||~strcmpi(canon(actual),canon(modelFile))
        status='different_same_name_model_loaded';return;
    end
    status=char(get_param(model,'Dirty'));
end

function tf=safe_pending_apply_resume(root,model,modelFile)
    tf=false;transaction=read_apply_transaction(root);
    if ~isfield(transaction,'pending')||~isequal(transaction.pending,true),return;end
    safeStages={'prepared_before_model_save','model_workspace_assignment_started', ...
        'model_workspace_assigned','model_note_updated'};
    stage=text_local(transaction,'status');
    assert(any(strcmp(stage,safeStages)),'SAR20:pendingApplyDirty', ...
        'Pending Apply is dirty at an unrecognized stage; inspect SAR20(''home'') and resolve model edits explicitly.');
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped')&& ...
        strcmpi(canon(get_param(model,'FileName')),canon(modelFile))&& ...
        strcmp(sha(modelFile),text_local(transaction,'model_sha_before')), ...
        'SAR20:pendingApplyDirty','Pending Apply no longer matches the saved model identity/path; do not save dirty contents automatically.');
    ws=get_param(model,'ModelWorkspace');
    assert(hasVariable(ws,'P')&&hasVariable(ws,'DecodeP'), ...
        'SAR20:pendingApplyDirty','Pending Apply workspace lacks P or DecodeP.');
    P=getVariable(ws,'P');DecodeP=getVariable(ws,'DecodeP');
    p=sar20_parameter_fingerprint(P);d=sar20_parameter_fingerprint(DecodeP);
    assert(strcmp(p.sha256,text_local(transaction,'prepared_P_sha256'))&& ...
        strcmp(d.sha256,text_local(transaction,'prepared_DecodeP_sha256'))&& ...
        isstruct(P)&&isfield(P,'digital')&&isequaln(DecodeP,P.digital), ...
        'SAR20:pendingApplyDirty','Pending workspace P/DecodeP do not match the exact prepared transaction.');
    sar20_navigation_manifest('verify',root,model,modelFile);
    if strcmp(stage,'model_note_updated')
        try
            behavior_applied_note('check',model);
        catch cause
            error('SAR20:pendingApplyDirty', ...
                'Pending model annotation failed its read-only check; inspect SAR20(''home'') before saving: %s', ...
                cause.message);
        end
    end
    tf=true;
end

function P=configure_debug_observer(P)
% Add only passive observer controls; physical fields and RNG seeds are untouched.
    assert(isstruct(P)&&isscalar(P)&&isfield(P,'Ts_s')&&isnumeric(P.Ts_s)&& ...
        isreal(P.Ts_s)&&isscalar(P.Ts_s)&&isfinite(P.Ts_s)&&P.Ts_s>0, ...
        'SAR20:observerPeriod','Prepared P needs a finite positive Ts_s.');
    if ~isfield(P,'debug'),P.debug=struct();end
    assert(isstruct(P.debug)&&isscalar(P.debug),'SAR20:observer','P.debug must be a scalar struct.');
    if ~isfield(P.debug,'observer'),P.debug.observer=struct();end
    observer=P.debug.observer;
    assert(isstruct(observer)&&isscalar(observer),'SAR20:observer','P.debug.observer must be a scalar struct.');
    if ~isfield(observer,'enabled'),observer.enabled=true;end
    if ~isfield(observer,'sample_id'),observer.sample_id=5;end
    if ~isfield(observer,'Ts_s'),observer.Ts_s=P.Ts_s;end
    assert((islogical(observer.enabled)||isnumeric(observer.enabled))&& ...
        isreal(observer.enabled)&&isscalar(observer.enabled)&& ...
        any(double(observer.enabled)==[0 1]),'SAR20:observer','observer.enabled must be binary.');
    assert(isnumeric(observer.sample_id)&&isreal(observer.sample_id)&& ...
        isscalar(observer.sample_id)&&isfinite(observer.sample_id)&& ...
        observer.sample_id>=0&&observer.sample_id==floor(observer.sample_id), ...
        'SAR20:observer','observer.sample_id must be a nonnegative integer ID.');
    assert(isnumeric(observer.Ts_s)&&isreal(observer.Ts_s)&&isscalar(observer.Ts_s)&& ...
        isfinite(observer.Ts_s)&&observer.Ts_s==P.Ts_s, ...
        'SAR20:observerPeriod','observer.Ts_s must equal P.Ts_s; edit the observer window deliberately.');
    observer.enabled=logical(observer.enabled);
    P.debug.observer=observer;
end

function convention=parameter_noise_convention(P,source)
    convention=struct('status','not_configured','kind','unknown', ...
        'field','unknown','value',NaN,'unit','V_rms at RA output differential VX','rule','');
    if ~isfield(P,'backend')||~isstruct(P.backend)||~isfield(P.backend,'ra_noise')|| ...
            ~isstruct(P.backend.ra_noise)||~isfield(P.backend.ra_noise,'sigma_vx_rms')
        return;
    end
    value=P.backend.ra_noise.sigma_vx_rms;
    if strcmp(source,'factory')
        kind='factory_A1_PSD_to_sigma_vx_rms';
        rule=['No-argument factory apply constructs the normal profile; normal_parameters ' ...
            'maps its A1 channel PSD assumptions to this output RMS before prepare.'];
        recalculated=true;
    elseif strcmp(source,'explicit')
        kind='explicit_fixed_sigma_vx_rms';
        rule=['SAR20(''apply'',P) only runs behavior_prepare_configuration; it preserves ' ...
            'the supplied sigma_vx_rms and does not call normal_parameters.'];
        recalculated=false;
    else
        convention=struct('status','unknown_source','kind','unknown_source', ...
            'field','P.backend.ra_noise.sigma_vx_rms','value',value, ...
            'unit','V_rms at RA output differential VX', ...
            'rule','Configuration source is unknown; no recalculation or preservation claim.', ...
            'value_recalculated_by_apply','unknown', ...
            'value_recalculated_by_factory','unknown', ...
            'value_recalculated_by_prepare','unknown');
        return;
    end
    convention=struct('status','recorded','kind',kind, ...
        'field','P.backend.ra_noise.sigma_vx_rms','value',value, ...
        'unit','V_rms at RA output differential VX','rule',rule, ...
        'value_recalculated_by_apply',recalculated, ...
        'value_recalculated_by_factory',recalculated, ...
        'value_recalculated_by_prepare',false);
end

function D=parameter_prepare_report(P,source,inputChanges)
    Psummary=sar20_parameter_summary(P);
    prepareFields={'P.calendar','P.adc_groups','P.groups','P.n_cycles', ...
        'P.stop_time_s','P.schedule','normalized P.front metadata', ...
        'P.xFE0','P.xBK0','P.xSC0','P.transport derived schedule/IC', ...
        'P.reference derived settings','P.training derived settings','P.ni coverage flags', ...
        'DecodeP = P.digital'};
    factoryFields={};
    preservedFields={'physical values established before prepare (except listed derived fields)', ...
        'A0/UGB and other supplied analog settings','all supplied random seeds', ...
        'P.backend.ra_noise.seed_u64','comparator-noise and input values'};
    if strcmp(source,'factory')
        factoryFields={'P.backend.ra_noise.sigma_vx_rms (normal_parameters maps A1 PSD to output RMS)', ...
            'P.front.C_f mismatch realization and finite-RC parameters', ...
            'P.backend.ct.net_actual/net_replica CINC mismatch values', ...
            'P.control.comparator.sar2_noise_rms_v from factory Ceff/K temperature assumptions'};
        preservedFields{end+1}='factory-computed sigmaVX is unchanged by behavior_prepare_configuration';
    elseif strcmp(source,'explicit')
        preservedFields{end+1}='P.backend.ra_noise.sigma_vx_rms supplied in explicit P';
    end
    allRecomputed=[factoryFields prepareFields];
    D=struct('configuration_source',source, ...
        'input_change_status',inputChanges.status, ...
        'changed_fields',{inputChanges.changed_fields}, ...
        'factory_recomputed_fields',{factoryFields}, ...
        'prepare_recomputed_fields',{prepareFields}, ...
        'recomputed_fields',{allRecomputed}, ...
        'preserved_by_prepare_fields',{preservedFields}, ...
        'preserved_fields',{preservedFields}, ...
        'noise_convention',parameter_noise_convention(P,source), ...
        'derived_values',Psummary.derived, ...
        'normal_parameters_called_by_explicit_apply',false, ...
        'physical_parameters_changed_by_debug_observer',false);
end

function P=load_applied_parameters(root)
    P=[];record=read_json_optional_local(fullfile(root,'state','applied_config.json'));
    relative=text_local(record,'parameters_mat');expected=text_local(record,'parameters_mat_sha256');
    if strcmp(relative,'unknown')||strcmp(expected,'unknown'),return;end
    relative=strrep(relative,'\',filesep);
    if startsWith(relative,['state' filesep]),file=fullfile(root,relative);
    else,file=fullfile(root,'state',relative);end
    state=fullfile(root,'state');
    if ~under(file,state),return;end
    d=dir(file);if isempty(d)||~isscalar(d)||d.isdir||d.bytes>300e6,return;end
    if ~strcmp(sha(file),expected),return;end
    previous=load(file,'P','DecodeP','identity');
    if ~all(isfield(previous,{'P','DecodeP','identity'})),return;end
    p=sar20_parameter_fingerprint(previous.P);decode=sar20_parameter_fingerprint(previous.DecodeP);
    identity=previous.identity;
    if ~strcmp(text_local(identity,'model_sha256'),text_local(record,'model_sha256'))|| ...
            ~strcmp(text_local(identity,'P_sha256'),text_local(record,'P_sha256'))|| ...
            ~strcmp(text_local(identity,'DecodeP_sha256'),text_local(record,'DecodeP_sha256'))|| ...
            ~strcmp(p.sha256,text_local(record,'P_sha256'))|| ...
            ~strcmp(decode.sha256,text_local(record,'DecodeP_sha256'))
        return;
    end
    P=previous.P;
end

function R=run_identity(root,modelFile,P,DecodeP)
    applied=read_json_local(fullfile(root,'state','applied_config.json'));
    currentSource=sar20_factory_source_identity(root);
    pFingerprint=sar20_parameter_fingerprint(P);
    dFingerprint=sar20_parameter_fingerprint(DecodeP);
    workspaceChanges=sar20_parameter_diff(load_applied_parameters(root),P);
    appliedP=text_local(applied,'P_sha256');appliedD=text_local(applied,'DecodeP_sha256');
    if strcmp(appliedP,'unknown'),modifiedP='unknown_legacy_apply';
    else,modifiedP=yn_local(~strcmp(pFingerprint.sha256,appliedP));end
    if strcmp(appliedD,'unknown'),modifiedD='unknown_legacy_apply';
    else,modifiedD=yn_local(~strcmp(dFingerprint.sha256,appliedD));end
    appliedSource=text_local(applied,'source_sha256');
    if strcmp(appliedSource,'unknown')||strcmp(currentSource.source_sha256,'unknown'),sourceStatus='unknown_source_identity';
    elseif strcmp(appliedSource,currentSource.source_sha256),sourceStatus='unchanged_since_apply';
    else,sourceStatus='changed_since_apply';end
    observer=struct('status','not_configured','enabled',false);
    if isfield(P,'debug')&&isstruct(P.debug)&&isfield(P.debug,'observer')
        observer=P.debug.observer;observer.status='configured';
    end
    runtime_entry('sar20_debug_fields',fullfile(fileparts(mfilename('fullpath')),'current','src','analysis'));
    fieldRegistry=sar20_debug_fields();
    semanticMap=fieldRegistry.fields;
    semanticBundle=fieldRegistry.bundle;
    registryIdentity=sar20_parameter_fingerprint(fieldRegistry);
    navFile=fullfile(root,'state','model_navigation.json');
    navStatus='unknown_missing';navSha='unknown';
    if isfile(navFile)
        navDir=dir(navFile);assert(isscalar(navDir)&&~navDir.isdir&&navDir.bytes<=300e6, ...
            'SAR20:navigationManifest','Missing or oversized model_navigation.json.');
        nav=jsondecode(fileread(navFile));navSha=sha(navFile);
        if isfield(nav,'model')&&isstruct(nav.model)&&isfield(nav.model,'model_sha256')&& ...
                strcmp(char(nav.model.model_sha256),sha(modelFile))
            navStatus='current_model_match';
        else
            navStatus='stale_model_identity';
        end
    end
    R=struct('schema','sar20-run-identity/v1', ...
        'configuration_source',text_local(applied,'configuration_source'), ...
        'configuration_name',text_local(applied,'configuration_name'), ...
        'configuration_summary',sar20_parameter_summary(P), ...
        'factory_source_sha256',appliedSource, ...
        'factory_source_files',field_local(applied,'source_files',struct()), ...
        'current_factory_source_sha256',currentSource.source_sha256, ...
        'factory_source_status',sourceStatus, ...
        'workspace_P_modified_since_apply',modifiedP, ...
        'workspace_DecodeP_modified_since_apply',modifiedD, ...
        'workspace_change_status',workspaceChanges.status, ...
        'workspace_changed_fields',workspaceChanges.changed_fields, ...
        'P_sha256',pFingerprint.sha256,'DecodeP_sha256',dFingerprint.sha256, ...
        'baseline_lineage',struct('baseline_model_sha256', ...
        '91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e', ...
        'source_model_sha256',sha(modelFile),'configuration', ...
        '5 MS/s single frontend ordinary AZ N256 default','status','model_identity_recorded'), ...
        'observer_identity',observer, ...
        'observer_logging',struct('incremental_overhead_status', ...
        'not_measured_without_matched_observer_off_run','scope', ...
        'single-run elapsed and simout bytes will be recorded; no zero-overhead claim'), ...
        'semantic_signal_mapping',semanticMap, ...
        'semantic_observer_bundle',semanticBundle, ...
        'semantic_bundle_width',fieldRegistry.bundle_width, ...
        'semantic_signal_mapping_sha256',registryIdentity.sha256, ...
        'semantic_signal_mapping_schema','sar20-debug-fields/v1', ...
        'navigation_manifest_status',navStatus,'navigation_manifest_sha256',navSha);
end

function id=sample_run_id(D,runPath)
    id=folder_name_local(runPath);
    if isfield(D,'run_id')&&is_text_local(D.run_id),id=char(D.run_id);
    elseif isfield(D,'run')&&isstruct(D.run)
        if isfield(D.run,'run_id')&&is_text_local(D.run.run_id),id=char(D.run.run_id);
        elseif isfield(D.run,'run_path')&&is_text_local(D.run.run_path),id=folder_name_local(char(D.run.run_path));end
    end
end

function id=common_sample_id(runA,runB)
    a=read_json_local(fullfile(canon(runA),'summary.json'));
    b=read_json_local(fullfile(canon(runB),'summary.json'));
    idsA=number_vector_local(a,'sample_ids');idsB=number_vector_local(b,'sample_ids');
    common=intersect(idsA,idsB,'stable');
    assert(~isempty(common),'SAR20:compareNoCommonID','Runs have no shared recorded sample IDs.');
    if any(common==5),id=5;else,id=common(1);end
end

function path=path_argument(value,label)
    assert((ischar(value)&&isrow(value)&&~isempty(strtrim(value)))|| ...
        (isstring(value)&&isscalar(value)&&strlength(strtrim(value))>0), ...
        'SAR20:pathArgument','%s path must be a nonempty text scalar.',label);
    path=char(value);
end

function x=number_vector_local(S,name)
    x=[];if isstruct(S)&&isfield(S,name)&&isnumeric(S.(name))&&isvector(S.(name))
        x=double(S.(name)(:).');
    end
end

function S=read_json_local(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:jsonInput','Missing or oversized JSON: %s.',file);
    S=jsondecode(fileread(file));if isempty(S),S=struct();end
end

function S=read_json_optional_local(file)
    d=dir(file);
    if isempty(d),S=struct();return;end
    assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:jsonInput','Missing or oversized JSON: %s.',file);
    S=jsondecode(fileread(file));if isempty(S),S=struct();end
end

function value=text_local(S,name)
    value='unknown';if isstruct(S)&&isfield(S,name)
        v=S.(name);if ischar(v)&&isrow(v),value=v;elseif isstring(v)&&isscalar(v),value=char(v);end
    end
end

function value=string_value_local(value)
    if ischar(value)&&isrow(value),return;end
    if isstring(value)&&isscalar(value),value=char(value);return;end
    value='unknown';
end

function value=field_local(S,name,fallback)
    value=fallback;if isstruct(S)&&isfield(S,name),value=S.(name);end
end

function tf=is_text_local(value)
    tf=(ischar(value)&&isrow(value))||(isstring(value)&&isscalar(value));
end

function value=yn_local(tf)
    if tf,value='yes';else,value='no';end
end

function value=folder_name_local(path)
    [~,value]=fileparts(path);
end

function path=canon_path_local(path)
    path=char(java.io.File(path).getCanonicalPath());
end

function store_selected_run(root,runPath,summaryPath)
    d=dir(summaryPath);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:selectionSummary','Missing or oversized completed summary.');
    summary=read_json_local(summaryPath);
    value=struct('schema','sar20-debug-selection/v1', ...
        'run_id',folder_name_local(runPath),'run_path',runPath, ...
        'summary_sha256',sha(summaryPath),'selected_utc',utc_now(), ...
        'status',text_local(summary,'status'));
    state=fullfile(root,'state');if ~isfolder(state),mkdir(state);end
    write_json_atomic(fullfile(state,'debug_selection.json'),value);
end

function file=write_observer_contract(root,runPath,simout,P,src)
% Archive only the registry contract and logger shape; sample values stay in simout.mat.
    file=fullfile(runPath,'observer_contract.json');
    observer=struct('status','not_configured','enabled',false,'sample_id','unknown','Ts_s','unknown');
    if isfield(P,'debug')&&isstruct(P.debug)&&isfield(P.debug,'observer')&& ...
            isstruct(P.debug.observer)
        observer=P.debug.observer;observer.status='configured';
    end
    contract=struct('schema_version','sar20-observer-contract/v1', ...
        'log_status','not_recorded','reason','observer disabled or not configured', ...
        'observer_identity',observer,'logger_variable','unknown', ...
        'registry_source','sar20_debug_fields','registry_source_path','unknown', ...
        'registry_source_sha','unknown','registry_schema_version','unknown', ...
        'bundle',struct(),'bundle_width',NaN,'observed_rows',NaN, ...
        'expected_rows',NaN,'max_data_points',NaN, ...
        'observed_width',NaN,'logger_class','not_present');
    enabled=isfield(observer,'enabled')&&(islogical(observer.enabled)||isnumeric(observer.enabled))&& ...
        isscalar(observer.enabled)&&isfinite(double(observer.enabled))&&double(observer.enabled)==1;
    if ~enabled
        contract.reason='P.debug.observer.enabled is not true';
        write_json(file,contract);return;
    end
    runtime_entry('sar20_debug_fields',fullfile(src,'analysis'));
    R=sar20_debug_fields();registryFile=which('sar20_debug_fields');
    assert(~isempty(registryFile),'SAR20:observerRegistry','sar20_debug_fields did not resolve to a source file.');
    [~,~,registryExt]=fileparts(registryFile);
    assert(strcmpi(registryExt,'.m'),'SAR20:observerRegistry', ...
        'observer_contract requires the deployed sar20_debug_fields.m source bytes.');
    contract.registry_source_path=relative(registryFile,root);
    contract.registry_source_sha=sha(registryFile);
    if isfield(R,'schema_version')
        contract.registry_schema_version=string_value_local(R.schema_version);
    elseif isfield(R,'schema')
        contract.registry_schema_version=string_value_local(R.schema);
    end
    if ~isfield(R,'bundle')
        contract.log_status='unsupported_registry_bundle_missing';
        contract.reason='sar20_debug_fields does not provide R.bundle';
        write_json(file,contract);return;
    end
    contract.bundle=R.bundle;
    if isfield(R.bundle,'logger_name')
        logVariable=string_value_local(R.bundle.logger_name);
    else
        logVariable='unknown';
    end
    contract.logger_variable=logVariable;
    if isfield(R.bundle,'width')&&isnumeric(R.bundle.width)&&isscalar(R.bundle.width)
        registeredWidth=R.bundle.width;
    else
        registeredWidth=NaN;
    end
    if isfield(R.bundle,'expected_selected_sample_rows')&& ...
            isnumeric(R.bundle.expected_selected_sample_rows)&&isscalar(R.bundle.expected_selected_sample_rows)
        contract.expected_rows=double(R.bundle.expected_selected_sample_rows);
    end
    if isfield(R.bundle,'max_data_points')&&isnumeric(R.bundle.max_data_points)&&isscalar(R.bundle.max_data_points)
        contract.max_data_points=double(R.bundle.max_data_points);
    end
    if ~isfinite(contract.expected_rows)||contract.expected_rows<1|| ...
            contract.expected_rows~=floor(contract.expected_rows)|| ...
            ~isfinite(contract.max_data_points)||contract.max_data_points~=floor(contract.max_data_points)|| ...
            contract.max_data_points<contract.expected_rows
        contract.log_status='unsupported_registry_row_contract';
        contract.reason='R.bundle must define a positive expected row count and compatible MaxDataPoints';
        write_json(file,contract);return;
    end
    if isempty(logVariable)||strcmp(logVariable,'unknown')
        contract.log_status='unsupported_registry_logger_missing';
        contract.reason='R.bundle.logger_name is missing or invalid';
        write_json(file,contract);return;
    end
    if ~isnumeric(registeredWidth)||~isscalar(registeredWidth)||~isfinite(registeredWidth)|| ...
            registeredWidth<1||registeredWidth~=floor(registeredWidth)
        contract.log_status='unsupported_registry_width_missing';
        contract.reason='R.bundle.width and R.bundle_width are missing or invalid';
        write_json(file,contract);return;
    end
    if isfield(R,'bundle_width')&&(~isnumeric(R.bundle_width)||~isscalar(R.bundle_width)|| ...
            ~isfinite(R.bundle_width)||double(R.bundle_width)~=double(registeredWidth))
        contract.log_status='unsupported_registry_width_disagreement';
        contract.reason='R.bundle.width and R.bundle_width are inconsistent or invalid';
        write_json(file,contract);return;
    end
    contract.bundle_width=double(registeredWidth);
    loggedNames=simout.who;
    if isstring(loggedNames),loggedNames=cellstr(loggedNames);end
    if ischar(loggedNames),loggedNames=cellstr(loggedNames);end
    assert(iscell(loggedNames),'SAR20:observerLogNames','SimulationOutput.who must return logged variable names.');
    if ~any(strcmp(loggedNames,logVariable))
        contract.reason=[logVariable ' is absent from this saved SimulationOutput'];
        write_json(file,contract);return;
    end
    logged=simout.get(logVariable);contract.logger_class=class(logged);
    if ~isa(logged,'timeseries')
        contract.log_status='unsupported_logger_type';
        contract.reason=[logVariable ' is present but is not a timeseries'];
        write_json(file,contract);return;
    end
    times=double(logged.Time(:));data=double(logged.Data);
    if isempty(times)
        rows=zeros(0,0);
    elseif logged.IsTimeFirst
        rows=reshape(data,numel(times),[]);
    else
        order=[ndims(data) 1:ndims(data)-1];
        rows=reshape(permute(data,order),numel(times),[]);
    end
    contract.observed_rows=size(rows,1);contract.observed_width=size(rows,2);
    if contract.observed_width~=contract.bundle_width
        contract.log_status='unsupported_width_mismatch';
        contract.reason=sprintf('observed width %d differs from registered bundle width %d', ...
            contract.observed_width,contract.bundle_width);
    elseif isfinite(contract.expected_rows)&&contract.observed_rows~=contract.expected_rows
        contract.log_status='incomplete_row_count';
        contract.reason=sprintf('observed row count %d differs from registered expected count %d', ...
            contract.observed_rows,contract.expected_rows);
    elseif isfinite(contract.max_data_points)&&contract.observed_rows>contract.max_data_points
        contract.log_status='incomplete_row_limit_exceeded';
        contract.reason=sprintf('observed row count %d exceeds registered MaxDataPoints %d', ...
            contract.observed_rows,contract.max_data_points);
    else
        contract.log_status='logged';contract.reason='observer_log shape agrees with sar20_debug_fields bundle';
    end
    write_json(file,contract);
end

function report=focus_report(root,model,modelFile,target,owner)
    runtime_entry('sar20_navigation_manifest',fullfile(fileparts(mfilename('fullpath')),'current','src','analysis'));
    report=sar20_navigation_manifest('focus',root,model,modelFile,target,owner);
end

function report=run_saved(model,modelFile,P,DecodeP,root,src,config,spectrumEligibility,runIdentity)
    runPath=fullfile(root,'runs',['behavior_' char(java.util.UUID.randomUUID())]);mkdir(runPath);
    report=struct('action','run','status','started','utc',utc_now(),'run_path',runPath, ...
        'model_kind','behavioral','simulation_completed',false,'model_sha256',sha(modelFile), ...
        'capture_boundary','direct_raw','spectrum_eligibility',spectrumEligibility, ...
        'baseline_lineage',runIdentity.baseline_lineage, ...
        'configuration_source',runIdentity.configuration_source, ...
        'configuration_name',runIdentity.configuration_name, ...
        'configuration_summary',runIdentity.configuration_summary, ...
        'factory_source_sha256',runIdentity.factory_source_sha256, ...
        'factory_source_files',runIdentity.factory_source_files, ...
        'factory_source_status',runIdentity.factory_source_status, ...
        'workspace_P_modified_since_apply',runIdentity.workspace_P_modified_since_apply, ...
        'workspace_DecodeP_modified_since_apply',runIdentity.workspace_DecodeP_modified_since_apply, ...
        'workspace_change_status',runIdentity.workspace_change_status, ...
        'workspace_changed_fields',runIdentity.workspace_changed_fields, ...
        'P_sha256',runIdentity.P_sha256,'DecodeP_sha256',runIdentity.DecodeP_sha256, ...
        'observer_identity',runIdentity.observer_identity, ...
        'observer_logging',runIdentity.observer_logging, ...
        'semantic_signal_mapping',runIdentity.semantic_signal_mapping, ...
        'semantic_observer_bundle',runIdentity.semantic_observer_bundle, ...
        'semantic_bundle_width',runIdentity.semantic_bundle_width, ...
        'semantic_signal_mapping_sha256',runIdentity.semantic_signal_mapping_sha256, ...
        'navigation_manifest_status',runIdentity.navigation_manifest_status, ...
        'navigation_manifest_sha256',runIdentity.navigation_manifest_sha256);
    if isfield(P,'transport')&&isfield(P.transport,'enabled')&&P.transport.enabled
        report.capture_boundary='serial_rx';
    end
    report.decode_mode='nominal';
    if isfield(P,'frozen')&&P.frozen.enabled
        report.decode_mode='immutable_candidate_for_holdout';
        report.coefficient_sha256=P.frozen.cache.coefficient_sha256;
        report.calibration_accepted=false;
    elseif isfield(P,'bank')&&isstruct(P.bank)&&isfield(P.bank,'enabled')&&P.bank.enabled
        report.decode_mode='prequalified_dual_version_behavior_only';
        report.calibration_accepted=false;
        report.bank_scope='same-h prequalified behavior simulation; not product acceptance';
        report.bank_versions=double([P.bank.slots.version]);
        report.bank_coefficient_sha256=P.bank.slots(1).cache.coefficient_sha256;
    end
    file=fullfile(runPath,'summary.json');write_json(file,report);
    try
        save(fullfile(runPath,'parameters.mat'),'P','DecodeP','runIdentity','-v7.3');
        write_json(fullfile(runPath,'parameters.json'),P);
        report.config_sha256=sha(fullfile(runPath,'parameters.mat'));
        report.config_identity='parameters.mat preserves exact P and DecodeP; parameters.json is a lossy display projection';
        report.parameters_mat_sha256=report.config_sha256;
        copyfile(modelFile,fullfile(runPath,'SarAdc.slx'));
        assert(strcmp(sha(fullfile(runPath,'SarAdc.slx')),report.model_sha256), ...
            'SAR20:snapshot','Copied model differs from the actual source.');
        report.source_files=snapshot_source(root,src,config,runPath);
        report.source_zip_sha256=sha(fullfile(runPath,'source.zip'));
        navigationFile=fullfile(root,'state','model_navigation.json');
        if isfile(navigationFile)
            report.navigation_manifest_status='copied_for_run';
            assert(copyfile(navigationFile,fullfile(runPath,'model_navigation.json')), ...
                'SAR20:navigationSnapshot','Cannot preserve model navigation identity in this run.');
            report.navigation_manifest_sha256=sha(fullfile(runPath,'model_navigation.json'));
        end
        if isfield(P,'bank')&&isstruct(P.bank)&&isfield(P.bank,'enabled')&&P.bank.enabled
            bankQ=char(P.bank.qualification_file);bankQCopy=fullfile(runPath,'bank_qualification.json');
            assert(isfile(bankQ)&&copyfile(bankQ,bankQCopy),'SAR20:bankQualification','Cannot snapshot the applied Bank qualification.');
            report.bank_qualification_sha256=sha(bankQCopy);
            assert(strcmp(report.bank_qualification_sha256,'a9cfaaefed217e5f6d6e7e1a2faa5586e78dbf8f6808523a9c5185c19ab9778f'), ...
                'SAR20:bankQualification','Applied qualification differs from the fixed reviewed bytes.');
        end
        report.status='running';write_json(file,report);
        trainingRun=isfield(P,'cal_cfg')&&P.cal_cfg.enabled;
        committed=[];
        if trainingRun
            trainPath=actual_train_state_path(model);
            trainParams=get_param(trainPath,'Parameters');
            assert(strcmp(regexprep(trainParams,'\s',''),'P.cal_cfg,TrainCaptureFile'), ...
                'SAR20:trainCaptureParameters','Actual Train must use P.cal_cfg,TrainCaptureFile dialogs.');
            captureDefault=getVariable(get_param(model,'ModelWorkspace'),'TrainCaptureFile');
            assert(ischar(captureDefault)&&isempty(captureDefault), ...
                'SAR20:trainCaptureDefault','Saved ModelWorkspace TrainCaptureFile must be empty.');
            captureFile=fullfile(runPath,'training_committed.mat');
            assert(~isfile(captureFile)&&~isfolder(captureFile),'SAR20:trainCaptureExists','Refuse existing run capture path.');
            simInput=Simulink.SimulationInput(model);
            simInput=simInput.setVariable('TrainCaptureFile',captureFile,'Workspace',model);
            simInput=simInput.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on');
            report.training_capture_variable='TrainCaptureFile';
            report.training_capture_workspace=model;
            report.training_capture_file='training_committed.mat';
            report.training_capture_saved_default='';
            report.training_capture_override_only=true;
            report.training_capture_parameters=trainParams;
            report.training_capture_verified=false;
            write_json(file,report);
        end
        rngBefore=rng;
        started=tic;
        if trainingRun
            simout=sim(simInput);
        else
            simout=sim(model,'ReturnWorkspaceOutputs','on','CaptureErrors','on');
        end
        report.elapsed_s=toc(started);
        report.global_rng_unchanged=isequal(rngBefore,rng);
        % Preserve actual simout before any capture read/validation, including
        % failed/stopped simulations. A Terminate file alone is not success.
        save(fullfile(runPath,'simout.mat'),'simout','-v7.3');
        simoutFile=dir(fullfile(runPath,'simout.mat'));
        report.simout_file_bytes=simoutFile.bytes;
        report.simulation_elapsed_s=report.elapsed_s;
        observerContractFile=write_observer_contract(root,runPath,simout,P,src);
        report.observer_contract_path=relative(observerContractFile,runPath);
        report.observer_contract_sha256=sha(observerContractFile);
        contractMeta=jsondecode(fileread(observerContractFile));
        report.observer_contract_status=contractMeta.log_status;
        report.observer_logging.elapsed_includes_observer=logical( ...
            isfield(runIdentity.observer_identity,'enabled')&&runIdentity.observer_identity.enabled);
        report.observer_logging.simout_file_bytes=simoutFile.bytes;
        report.observer_logging.incremental_overhead_status= ...
            'not_measured_without_matched_observer_off_run';
        report.observer_logging.scope='single-run elapsed and simout size are recorded; no zero-overhead claim';
        if trainingRun
            report.training_capture_present=isfile(captureFile);
            if report.training_capture_present,report.training_capture_sha256=sha(captureFile);end
            report.training_capture_default_unchanged=isequal(captureDefault, ...
                getVariable(get_param(model,'ModelWorkspace'),'TrainCaptureFile'));
            report.training_capture_P_unchanged=isequaln(P,getVariable(get_param(model,'ModelWorkspace'),'P'));
            report.training_capture_SLX_unchanged=strcmp(report.model_sha256,sha(modelFile));
        end
        if isprop(simout,'ErrorMessage')&&~isempty(simout.ErrorMessage)
            error('SAR20:simulation','%s',simout.ErrorMessage);
        end
        if trainingRun
            assert(report.training_capture_default_unchanged&&report.training_capture_P_unchanged&& ...
                report.training_capture_SLX_unchanged,'SAR20:trainCaptureMutation','Capture override changed saved defaults/P/SLX.');
            assert(report.training_capture_present,'SAR20:trainCaptureMissing', ...
                'Training Terminate capture missing; Outputs/finalOP are not post-Update substitutes.');
            captured=load(captureFile,'committed');
            assert(isfield(captured,'committed'),'SAR20:trainCaptureVariable','Actual capture must contain committed.');
            committed=captured.committed;
            validate_train_capture(committed,simout,P,trainPath);
            report.training_capture_verified=true;
            report.training_capture_source=committed.source;
            report.training_capture_block=committed.block_path;
            report.training_capture_time_s=committed.time_s;
            report.training_capture_status7=committed.status7;
        end
        report.simulation_completed=true;
        if isfield(P,'bank')&&isstruct(P.bank)&&isfield(P.bank,'enabled')&&P.bank.enabled
            assert(strcmp(sha(bankQ),report.bank_qualification_sha256)&& ...
                strcmp(sha(bankQCopy),report.bank_qualification_sha256), ...
                'SAR20:bankQualification','Qualification changed during the actual run.');
        end
        runtime_entry('behavior_record_view',src);
        V=behavior_record_view(simout,P);
        runtime_entry('behavior_record_ready_summary',src);
        report.record_ready_summary=behavior_record_ready_summary(struct( ...
            'observed_raw',V.observed_raw,'raw',V.raw,'readiness_boundary',V.readiness_boundary));
        write_json(file,report); % retained even when selected validity later rejects
        [selected,metadata]=select_actual(simout,P,V);
        save(fullfile(runPath,'selected.mat'),'selected','metadata','-v7.3');
        report.records=numel(selected.code20);report.sample_ids=selected.raw(:,4).';
        report.raw_words=selected.raw;report.code20=selected.code20.';
        report.selected_sha256=sha(fullfile(runPath,'selected.mat'));
        if isfield(P,'cal_cfg')&&P.cal_cfg.enabled
            [training,public_training_data]=behavior_training_result(simout,P.cal_cfg,P.training.reference,committed,P);
            save(fullfile(runPath,'training.mat'),'training','public_training_data','-v7.3');
            write_json(fullfile(runPath,'training.json'),training);
            report.training=training;
        end
        if strcmp(spectrumEligibility,'eligible')
            try
                metrics=behavior_spectrum(selected.code20,metadata);
            catch spectrumError
                if ~strcmp(spectrumError.identifier,'BehaviorSpectrum:power'),rethrow(spectrumError);end
                metrics=struct('schema','sar20-behavior-spectrum/v1', ...
                    'status','not_run_degenerate_power','record_length',P.N, ...
                    'diagnostic',spectrumError.message);
            end
            save(fullfile(runPath,'spectrum.mat'),'metrics','-v7.3');
            report.spectrum_status=metrics.status;
            for field={'snr_db','sndr_db','sfdr_db','thd_db','enob'}
                if isfield(metrics,field{1}),report.(field{1})=metrics.(field{1});end
            end
        elseif P.N>=256
            % A real capture can be useful when the existing coherent FFT
            % does not apply. Save a status only; never fabricate metrics.
            metrics=struct('schema','sar20-behavior-spectrum/v1', ...
                'status',spectrumEligibility,'record_length',P.N);
            save(fullfile(runPath,'spectrum.mat'),'metrics','-v7.3');
            report.spectrum_status=metrics.status;
        else
            report.spectrum_status=spectrumEligibility;
        end
        report.status='complete';report.finished_utc=utc_now();write_json(file,report);
        write_json(fullfile(root,'runs','latest_behavior_run.json'),struct('run_path',runPath,'summary_sha256',sha(file)));
        store_selected_run(root,runPath,file);
    catch cause
        if exist('started','var'),report.elapsed_s=toc(started);end
        report.partial_output_saved=isfile(fullfile(runPath,'simout.mat'));
        report.status='failed';report.error_identifier=cause.identifier;
        report.error=getReport(cause,'extended','hyperlinks','off');write_json(file,report);rethrow(cause);
    end
end

function [selected,metadata]=select_actual(simout,P,V)
% Actual public record boundary: bypass direct RAW or pin-only received RAW.
% V is the same public record view already summarized before selection. 
    r=V.raw;c=V.code20;t=V.time_s;
    assert(size(r,1)==P.N&&isequal(r(:,4),(P.first_id:P.first_id+P.N-1).')&& ...
        all(r(:,5)==P.epoch),'SAR20:records','Expected exactly N consecutive ready IDs with matching epoch.');
    assert(all(r(:,6)==1),'SAR20:invalid','Selected capture contains invalid RAW; keep simout and diagnose.');
    assert(all(isfinite(c)&c==floor(c)&c>=0&c<2^20),'SAR20:code','Code20 outside unsigned20 range.');
    selected=struct('raw',r,'code20',c,'time_s',t,'raw_fields',{{'D1','D2','DT','ID','epoch','valid'}});
    metadata=struct('fs_hz',P.fs_hz,'fsr_diff_v',P.fsr_diff_v,'stimulus',P.input);
    if isfield(P,'bank')&&isstruct(P.bank)&&isfield(P.bank,'enabled')&&P.bank.enabled
        runtime_entry('behavior_bank_record_gate',fullfile(fileparts(mfilename('fullpath')),'current','src'));
        runtime_entry('behavior_bank_validate_rows',fullfile(fileparts(mfilename('fullpath')),'current','src'));
        versions=double([P.bank.slots.version]);
        bank=behavior_bank_record_gate(simout,versions,struct('raw',r,'time_s',t));
        selected.bank_valid=bank.valid;selected.bank_slot=bank.slot;selected.bank_version=bank.version;
        metadata.bank_scope=bank.scope;
    end
end
function [x,t]=series(ts,width)
    assert(isa(ts,'timeseries'),'SAR20:logger','Expected native timeseries logger.');
    t=double(ts.Time(:));d=double(ts.Data);
    if ts.IsTimeFirst,x=reshape(d,numel(t),[]);else
        order=[ndims(d) 1:ndims(d)-1];x=reshape(permute(d,order),numel(t),[]);
    end
    assert(isequal(size(x),[numel(t) width]),'SAR20:loggerWidth','Unexpected logger width.');
end
function rows=snapshot_source(root,src,config,runPath)
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(config,'*.mat'))];
    names=cell(numel(files)+1,1);rows=struct('path',{},'sha256',{});
    for k=1:numel(files)
        path=fullfile(files(k).folder,files(k).name);names{k}=relative(path,root);
        rows(end+1)=struct('path',names{k},'sha256',sha(path)); %#ok<AGROW>
    end
    names{end}='SAR20.m';rows(end+1)=struct('path','SAR20.m','sha256',sha(fullfile(root,'SAR20.m')));
    zip(fullfile(runPath,'source.zip'),names,root);
    write_json(fullfile(runPath,'source_manifest.json'),struct('files',rows));
end
function guard_model(model,file)
    if ~bdIsLoaded(model),return;end
    assert(strcmpi(canon(get_param(model,'FileName')),canon(file)),'SAR20:sameName','A different same-name model is loaded.');
    assert(strcmp(get_param(model,'SimulationStatus'),'stopped'),'SAR20:busy','Target model is busy; finish its run first.');
    assert(strcmp(get_param(model,'Dirty'),'off'),'SAR20:dirty','Save or discard target model edits explicitly first.');
end
function close_owned(model,wasLoaded)
    if ~wasLoaded&&bdIsLoaded(model)&&strcmp(get_param(model,'SimulationStatus'),'stopped')
        close_system(model,0);
    end
end
function verify_project_resolution(root,src,config)
% Once per public entry, reject a same-name source or stale cached function.
% This does not clear MATLAB state or prove cached bytes from the same path.
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(root,'SAR20.m'))];
    names=cell(numel(files),1);expected=cell(numel(files),1);
    for k=1:numel(files)
        [~,names{k}]=fileparts(files(k).name);
        expected{k}=canon(fullfile(files(k).folder,files(k).name));
        resolved=which(names{k});
        assert(~isempty(resolved)&&strcmpi(canon(resolved),expected{k}), ...
            'SAR20:runtimePath','%s resolves outside the current source: %s.',names{k},resolved);
    end
    assert(numel(unique(lower(string(names))))==numel(names), ...
        'SAR20:duplicateSource','Duplicate project function names are unsupported.');
    loaded=inmem('-completenames');
    for k=1:numel(loaded)
        [~,name]=fileparts(loaded{k});
        j=find(strcmpi(name,names));
        if ~isempty(j)
            assert(isscalar(j)&&strcmpi(canon(loaded{k}),expected{j}), ...
                'SAR20:cachedPath','%s remains cached from another source: %s.',name,loaded{k});
        end
    end
end
function require_toolkit(root)
% Check essential installed SATK files before loading or assigning the model.
    tools=fullfile(root,'dependencies','toolkit','tools');
    dirs={'common',fullfile('common','autolayout'),'model_read','model_edit','model_check'};
    for k=1:numel(dirs)
        assert(isfolder(fullfile(tools,dirs{k})),'SAR20:toolkitMissing','Missing SATK directory: %s.',dirs{k});
    end
    required={fullfile('model_read','model_read'),fullfile('model_edit','model_edit'), ...
        fullfile('model_edit','+library','settingsLookup')};
    for k=1:numel(required)
        stem=fullfile(tools,required{k});
        assert(isfile([stem '.p'])||isfile([stem '.m']),'SAR20:toolkitMissing','Missing SATK function: %s.',required{k});
    end
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    addpath(fullfile(tools,'common'),fullfile(tools,'common','autolayout'), ...
        fullfile(tools,'model_read'),fullfile(tools,'model_edit'),fullfile(tools,'model_check'));
    functions={'model_read','model_edit','library.settingsLookup'};
    locations={fullfile(tools,'model_read'),fullfile(tools,'model_edit'), ...
        fullfile(tools,'model_edit','+library')};
    for k=1:numel(functions)
        resolved=which(functions{k});
        assert(~isempty(resolved)&&under(resolved,locations{k}), ...
            'SAR20:toolkitPath','%s resolves outside this project toolkit: %s.',functions{k},resolved);
    end
    loaded=inmem('-completenames');
    for k=1:numel(loaded)
        [~,name]=fileparts(loaded{k});
        j=find(strcmpi(name,{'model_read','model_edit','settingsLookup'}));
        if ~isempty(j)
            assert(isscalar(j)&&under(loaded{k},locations{j}), ...
                'SAR20:toolkitCache','%s remains cached from another toolkit: %s.',name,loaded{k});
        end
    end
end
function runtime_entry(name,folder)
    path=which(name);assert(~isempty(path)&&under(path,folder),'SAR20:runtimePath','%s resolves outside the current runtime.',name);
end
function tf=under(path,folder)
    path=canon(path);folder=canon(folder);tf=startsWith(lower(path),[lower(folder) filesep]);
end
function p=relative(path,root),p=char(extractAfter(string(path),strlength(string(root))+1));end
function p=canon(p),p=char(java.io.File(p).getCanonicalPath());end
function require_applied_model(root,modelFile)
% The original 485 graph saves an earlier P; require a successful public apply.
% A subsequent graph save changes the file identity and needs a fresh apply.
    transaction=read_apply_transaction(root);
    assert(~isfield(transaction,'pending')||~isequal(transaction.pending,true), ...
        'SAR20:applyIncomplete', ...
        'Last apply did not complete. Inspect SAR20(''home'') and retry SAR20(''apply'') before running.');
    record=fullfile(root,'state','applied_config.json');d=dir(record);
    assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6,'SAR20:applyRequired', ...
        'Run SAR20(''apply'') to save the selected configuration before running.');
    saved=jsondecode(fileread(record));
    assert(isstruct(saved)&&isscalar(saved)&&isfield(saved,'model_sha256')&& ...
        strcmp(saved.model_sha256,sha(modelFile)),'SAR20:applyRequired', ...
        'Saved model changed since apply; run SAR20(''apply'') again.');
end
function s=sha(path)
    d=dir(path);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:fileSize','Missing or oversized file: %s.',path);
    fid=fopen(path,'rb');assert(fid>=0,'SAR20:read','Cannot read %s.',path);cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid),bytes=fread(fid,1024*1024,'*uint8');md.update(typecast(bytes(:),'int8'));end
    s=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
function write_json(path,value)
    fid=fopen(path,'w','n','UTF-8');assert(fid>=0,'SAR20:write','Cannot write %s.',path);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));
end
function write_json_atomic(path,value)
    temp=[path '.tmp.' char(java.util.UUID.randomUUID())];
    fid=fopen(temp,'w','n','UTF-8');assert(fid>=0,'SAR20:write','Cannot write %s.',temp);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));clear cleanup;
    [ok,msg]=movefile(temp,path,'f');assert(ok,'SAR20:write','Atomic JSON replace failed: %s',msg);
end
function s=utc_now(),s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));end

function path=actual_train_state_path(model)
% SID resolved by Simulink to the real current name/path, never concatenated hierarchy.
    path=Simulink.ID.getFullName([model ':383']);
    assert(strcmp(bdroot(path),model)&&strcmp(get_param(path,'Name'),'Train')&& ...
        strcmp(get_param(path,'FunctionName'),'behavior_cal_train_sfun'), ...
        'SAR20:trainStateIdentity','SID383 must resolve to actual Train behavior_cal_train_sfun; inspect actual model_read after structural edits.');
end

function validate_train_capture(committed,simout,P,trainPath)
% Read-only postprocess: no fitting/commit/state mutation. Partial files remain.
    keys={'extracted';'status7';'snapshot2624';'raw_buffer';'reference_buffer';'time_s';'block_path';'source'};
    assert(isstruct(committed)&&isscalar(committed)&&isequal(sort(fieldnames(committed)),sort(keys))&& ...
        isequal(committed.extracted,true)&&strcmp(committed.source,'actual Terminate post-Update DWorks'), ...
        'SAR20:trainCaptureSchema','Require actual eight-field Terminate DWork capture.');
    assert(strcmp(committed.block_path,trainPath),'SAR20:trainCapturePath','Capture is not from actual Train block.');
    actualTout=simout.get('tout');
    assert(isnumeric(actualTout)&&isreal(actualTout)&&~isempty(actualTout)&& ...
        actualTout(end)==P.stop_time_s&&isscalar(committed.time_s)&& ...
        committed.time_s==actualTout(end),'SAR20:trainCaptureTime', ...
        'Actual simulation/capture did not reach the unchanged declared StopTime; a stopped/partial file is not success.');
    n=P.cal_cfg.N_train;
    assert(isa(committed.raw_buffer,'double')&&isequal(size(committed.raw_buffer),[n 6])&& ...
        isa(committed.reference_buffer,'double')&&isequal(size(committed.reference_buffer),[n 4])&& ...
        isa(committed.status7,'double')&&isequal(size(committed.status7),[7 1])&& ...
        isa(committed.snapshot2624,'double')&&isequal(size(committed.snapshot2624),[2624 1]), ...
        'SAR20:trainCaptureDimensions','Actual capture buffer/status/snapshot dimensions differ from saved N.');
    st=committed.status7;fit=committed.snapshot2624;
    assert(st(1)==1&&st(2)==n&&st(3)==1&&st(7)==0&& ...
        isequaln(st(1:5),fit(1:5))&&st(6)==fit(8)&&st(7)==fit(9), ...
        'SAR20:trainCaptureIncomplete','Actual Terminate capture must show N rows and exactly one fit; no acceptance claim.');
end
