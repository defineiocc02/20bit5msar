function S=sar20_parameter_state(root,model,modelFile)
%SAR20_PARAMETER_STATE Read the pending, applied and selected-run identities.
% Never executes configuration factories. Exact applied parameters come from
% the MAT path committed by applied_config.json; unreferenced pending snapshots are ignored.
    source=sar20_factory_source_identity(root);
    stateDir=fullfile(root,'state');appliedFile=fullfile(stateDir,'applied_config.json');
    currentModelSha='unknown';
    if isfile(modelFile),currentModelSha=file_sha256(modelFile);end
    applied=read_json_if_present(appliedFile);
    if isfield(applied,'source_sha256')&&is_text_scalar(applied.source_sha256)
        appliedSourceSha=char(applied.source_sha256);
        if strcmp(appliedSourceSha,'unknown')||strcmp(source.source_sha256,'unknown')
            sourceStatus='unknown_incomplete_source_identity';
        elseif strcmp(appliedSourceSha,source.source_sha256)
            sourceStatus='unchanged_since_apply';
        else
            sourceStatus='changed_since_apply';
        end
    else
        appliedSourceSha='unknown';sourceStatus='unknown_legacy_apply';
    end
    S=struct('schema','sar20-parameter-state/v1', ...
        'factory_source',source,'source_pending_status',sourceStatus, ...
        'applied_source_sha256',appliedSourceSha,'applied',struct(), ...
        'selected_run',struct(),'workspace',struct());

    [appliedSnapshot,parameterMatStatus]=load_committed_parameters(root,applied);
    S.applied=applied_summary(applied,appliedSnapshot,currentModelSha,parameterMatStatus);

    loadedP=[];loadedDecodeP=[];workspaceSource='model_not_loaded';
    if bdIsLoaded(model)&&strcmpi(canonical(get_param(model,'FileName')),canonical(modelFile))
        ws=get_param(model,'ModelWorkspace');
        if hasVariable(ws,'P'),loadedP=getVariable(ws,'P');end
        if hasVariable(ws,'DecodeP'),loadedDecodeP=getVariable(ws,'DecodeP');end
        workspaceSource='loaded_model_workspace';
    elseif bdIsLoaded(model)
        workspaceSource='different_same_name_model_loaded';
    elseif strcmp(currentModelSha,field_text(applied,'model_sha256'))&& ...
            isfield(appliedSnapshot,'P')&&isfield(appliedSnapshot,'DecodeP')
        loadedP=appliedSnapshot.P;loadedDecodeP=appliedSnapshot.DecodeP;
        workspaceSource='saved_apply_snapshot_model_hash_match';
    end
    if isempty(loadedP)
        S.workspace=struct('status',workspaceSource,'P_fingerprint','unknown', ...
            'DecodeP_fingerprint','unknown','modified_since_apply','unknown', ...
            'DecodeP_matches_P_digital','unknown', ...
            'changed_fields_status','unknown','changed_fields',{{}}, ...
            'configuration_summary',struct());
    else
        pfp=sar20_parameter_fingerprint(loadedP);
        dfp=sar20_parameter_fingerprint(loadedDecodeP);
        expectedP=field_text(applied,'P_sha256');
        expectedD=field_text(applied,'DecodeP_sha256');
        if strcmp(expectedP,'unknown')||strcmp(expectedD,'unknown')
            modified='unknown_legacy_apply';
        elseif strcmp(pfp.sha256,expectedP)&&strcmp(dfp.sha256,expectedD)
            modified='no';
        else
            modified='yes';
        end
        decodeMatches='unknown';
        if isstruct(loadedP)&&isscalar(loadedP)&&isfield(loadedP,'digital')
            decodeMatches=yn(isequaln(loadedDecodeP,loadedP.digital));
        end
        if isfield(appliedSnapshot,'P')
            changed=sar20_parameter_diff(appliedSnapshot.P,loadedP);
        else
            changed=struct('status','no_previous_exact_P','changed_fields',{{}});
        end
        S.workspace=struct('status',workspaceSource, ...
            'P_fingerprint',pfp.sha256,'DecodeP_fingerprint',dfp.sha256, ...
            'modified_since_apply',modified, ...
            'DecodeP_matches_P_digital',decodeMatches, ...
            'changed_fields_status',changed.status,'changed_fields',{changed.changed_fields}, ...
            'configuration_summary',sar20_parameter_summary(loadedP));
    end
    S.selected_run=selected_run(root);
end

function out=applied_summary(record,snapshot,currentModelSha,parameterMatStatus)
    out=struct('status','no_apply_record','configuration_source','unknown', ...
        'configuration_name','unknown','model_sha256','unknown', ...
        'P_sha256','unknown','DecodeP_sha256','unknown', ...
        'parameters_mat_sha256','unknown','model_matches_apply','unknown', ...
        'noise_convention','unknown','observer_identity',struct(), ...
        'display_note','','detailed_text','','configuration_summary',struct(), ...
        'configuration_summary_source','unknown','parameters_mat_status',parameterMatStatus);
    if isempty(fieldnames(record)),return;end
    out.status='legacy_or_recorded_apply';
    for key={'configuration_source','configuration_name','model_sha256', ...
            'P_sha256','DecodeP_sha256','parameters_mat_sha256','noise_convention'}
        name=key{1};if isfield(record,name),out.(name)=record.(name);end
    end
    for key={'display_note','detailed_text','derived_report'}
        name=key{1};if isfield(record,name),out.(name)=record.(name);end
    end
    recordedModel=field_text(record,'model_sha256');
    if strcmp(currentModelSha,'unknown')||strcmp(recordedModel,'unknown')
        out.model_matches_apply='unknown';
    else
        out.model_matches_apply=yn(strcmp(currentModelSha,recordedModel));
    end
    if isfield(record,'observer_identity'),out.observer_identity=record.observer_identity;end
    if ~isempty(fieldnames(snapshot))
        out.parameters_mat_available=true;
        if isfield(snapshot,'identity'),out.identity=snapshot.identity;end
        if isfield(snapshot,'P')
            out.configuration_summary=sar20_parameter_summary(snapshot.P);
            out.configuration_summary_source='exact_applied_parameters_mat';
        end
    else
        out.parameters_mat_available=false;
        if isfield(record,'config')&&isstruct(record.config)&&isscalar(record.config)
            out.configuration_summary=sar20_parameter_summary(record.config);
            out.configuration_summary_source='lossy_json_projection_non_authoritative';
        end
    end
end

function [snapshot,status]=load_committed_parameters(root,record)
    snapshot=struct();status='no_committed_exact_parameter_mat';
    relative=field_text(record,'parameters_mat');
    expectedMatSha=field_text(record,'parameters_mat_sha256');
    if strcmp(relative,'unknown')
        return;
    end
    relative=strrep(relative,'\',filesep);
    if startsWith(relative,['state' filesep])
        file=fullfile(root,relative);
    else
        file=fullfile(root,'state',relative);
    end
    stateDir=fullfile(root,'state');
    try
        inside=under_path(file,stateDir);
    catch
        inside=false;
    end
    if ~inside,status='referenced_parameter_mat_outside_state';return;end
    d=dir(file);
    if isempty(d),status='referenced_parameter_mat_missing';return;end
    if ~isscalar(d)||d.isdir,status='referenced_parameter_mat_invalid_path';return;end
    if d.bytes>300e6,status='oversized_not_read';return;end
    if strcmp(expectedMatSha,'unknown'),status='parameter_mat_hash_not_recorded';return;end
    actualMatSha=file_sha256(file);
    if ~strcmp(actualMatSha,expectedMatSha),status='parameter_mat_hash_mismatch';return;end
    loaded=load(file,'P','DecodeP','identity');
    if ~all(isfield(loaded,{'P','DecodeP','identity'}))|| ...
            ~isstruct(loaded.identity)||~isscalar(loaded.identity)
        status='parameter_mat_schema_incomplete';return;
    end
    p=sar20_parameter_fingerprint(loaded.P);decode=sar20_parameter_fingerprint(loaded.DecodeP);
    identity=loaded.identity;
    modelSha=field_text(record,'model_sha256');Psha=field_text(record,'P_sha256');Dsha=field_text(record,'DecodeP_sha256');
    if any(strcmp({modelSha,Psha,Dsha},'unknown'))
        status='parameter_identity_not_recorded';return;
    end
    bound=strcmp(field_text(identity,'model_sha256'),modelSha)&& ...
        strcmp(field_text(identity,'P_sha256'),Psha)&& ...
        strcmp(field_text(identity,'DecodeP_sha256'),Dsha)&& ...
        strcmp(p.sha256,Psha)&&strcmp(decode.sha256,Dsha);
    if ~bound,status='parameter_mat_identity_mismatch';return;end
    snapshot=loaded;status='verified_committed_parameter_mat';
end

function R=selected_run(root)
    stateFile=fullfile(root,'state','debug_selection.json');
    selected=read_json_if_present(stateFile);runPath=field_text(selected,'run_path');
    selectionSource='saved_ui_selection';
    if strcmp(runPath,'unknown')
        latest=read_json_if_present(fullfile(root,'runs','latest_behavior_run.json'));
        runPath=field_text(latest,'run_path');selectionSource='latest_run_pointer';
    end
    if strcmp(runPath,'unknown')||~isfolder(runPath)
        R=struct('status','no_selected_run','run_path','unknown','run_id','unknown', ...
            'selection_source',selectionSource);return;
    end
    runsRoot=canonical(fullfile(root,'runs'));
    if ~under_path(runPath,runsRoot)
        R=struct('status','selection_outside_project_runs','run_path','unknown','run_id','unknown', ...
            'selection_source',selectionSource);return;
    end
    summary=read_json_if_present(fullfile(runPath,'summary.json'));
    if isempty(fieldnames(summary))
        R=struct('status','selected_run_summary_missing','run_path',runPath,'run_id','unknown', ...
            'selection_source',selectionSource);return;
    end
    parameterFile=fullfile(runPath,'parameters.mat');d=dir(parameterFile);
    Psha='unknown';DecodePsha='unknown';pSummary=struct();identityStatus='parameters_mat_missing';
    parameterFileSha='unknown';
    if ~isempty(d)
        assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
            'SAR20:selectedRunParameter','Missing or oversized selected-run parameters.mat.');
        loaded=load(parameterFile,'P','DecodeP','runIdentity');
        parameterFileSha=file_sha256(parameterFile);
        if isfield(loaded,'P')
            pf=sar20_parameter_fingerprint(loaded.P);Psha=pf.sha256;
            pSummary=sar20_parameter_summary(loaded.P);
            identityStatus='P_loaded_decode_unknown';
            if isfield(loaded,'DecodeP')
                df=sar20_parameter_fingerprint(loaded.DecodeP);DecodePsha=df.sha256;
                identityStatus='exact_P_and_DecodeP_loaded';
            end
        end
    end
    expectedRunP=field_text(summary,'P_sha256');
    expectedRunDecode=field_text(summary,'DecodeP_sha256');
    expectedRunMat=field_text(summary,'config_sha256');
    if ~strcmp(expectedRunP,'unknown')&&~strcmp(Psha,'unknown')&& ...
            ~strcmp(expectedRunP,Psha)
        identityStatus='summary_P_fingerprint_mismatch';
    elseif ~strcmp(expectedRunDecode,'unknown')&&~strcmp(DecodePsha,'unknown')&& ...
            ~strcmp(expectedRunDecode,DecodePsha)
        identityStatus='summary_DecodeP_fingerprint_mismatch';
    elseif ~strcmp(expectedRunMat,'unknown')&&~strcmp(parameterFileSha,'unknown')&& ...
            ~strcmp(expectedRunMat,parameterFileSha)
        identityStatus='summary_parameters_mat_hash_mismatch';
    elseif strcmp(Psha,'unknown')||strcmp(DecodePsha,'unknown')|| ...
            strcmp(expectedRunP,'unknown')||strcmp(expectedRunDecode,'unknown')|| ...
            strcmp(expectedRunMat,'unknown')||strcmp(parameterFileSha,'unknown')
        identityStatus='mat_loaded_summary_identity_unknown';
    else
        identityStatus='exact_P_DecodeP_and_parameters_mat_identity';
    end
    R=struct('status','selected','run_path',runPath, ...
        'run_id',folder_name(runPath),'summary',summary, ...
        'selection_source',selectionSource, ...
        'model_sha256',field_text(summary,'model_sha256'), ...
        'config_sha256',field_text(summary,'config_sha256'), ...
        'configuration_source',field_text(summary,'configuration_source'), ...
        'P_sha256',Psha,'DecodeP_sha256',DecodePsha, ...
        'parameters_mat_sha256',parameterFileSha, ...
        'configuration_summary',pSummary,'parameter_identity_status',identityStatus);
end

function value=read_json_if_present(file)
    value=struct();d=dir(file);if isempty(d),return;end
    assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6,'SAR20:stateFile','Missing or oversized JSON: %s.',file);
    value=jsondecode(fileread(file));
    if isempty(value),value=struct();end
end

function value=field_text(S,name)
    value='unknown';
    if isstruct(S)&&isscalar(S)&&isfield(S,name)
        candidate=S.(name);
        if ischar(candidate)&&isrow(candidate),value=candidate;
        elseif isstring(candidate)&&isscalar(candidate),value=char(candidate);end
    end
end

function tf=is_text_scalar(value)
    tf=(ischar(value)&&isrow(value))||(isstring(value)&&isscalar(value));
end

function value=yn(tf)
    if tf,value='yes';else,value='no';end
end

function value=folder_name(path)
    [~,value]=fileparts(path);
end

function value=canonical(path)
    value=char(java.io.File(path).getCanonicalPath());
end

function tf=under_path(path,root)
    path=canonical(path);root=canonical(root);
    tf=startsWith(lower(path),[lower(root) filesep]);
end

function value=file_sha256(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:fileSize','Missing or oversized file: %s.',file);
    fid=fopen(file,'rb');assert(fid>=0,'SAR20:read','Cannot read %s.',file);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid),bytes=fread(fid,1024*1024,'*uint8');md.update(typecast(bytes(:),'int8'));end
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
