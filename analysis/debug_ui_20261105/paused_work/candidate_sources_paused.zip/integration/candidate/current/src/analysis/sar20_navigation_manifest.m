function R=sar20_navigation_manifest(action,root,model,modelFile,varargin)
%SAR20_NAVIGATION_MANIFEST Verify, safely refresh, or resolve real Simulink SIDs.
% Manifest strings are data only. Focus uses validated decimal SIDs and the
% current SarAdc model; no eval or visible-name-to-path construction occurs.
    action=lower(char(action));manifestFile=fullfile(root,'state','model_navigation.json');
    switch action
        case 'verify'
            assert(isempty(varargin),'SAR20:navigationArgs','verify accepts no extra arguments.');
            M=read_manifest(manifestFile);currentSha=file_sha256(modelFile);
            assert(strcmp(M.model.model_sha256,currentSha),'SAR20:navigationStale', ...
                'Navigation manifest is not bound to the current model SHA.');
            assert_model_loaded(model,modelFile,true);
            validate_targets(M,model);
            R=struct('status','verified_current_model','manifest_path',manifestFile, ...
                'manifest_sha256',file_sha256(manifestFile),'model_sha256',currentSha, ...
                'target_count',numel(M.targets),'validated_sid_count',count_sids(M));
        case 'refresh'
            assert(numel(varargin)==2,'SAR20:navigationArgs', ...
                'refresh requires the verified old SHA and the saved new SHA.');
            expectedOld=char(string(varargin{1}));newSha=char(string(varargin{2}));
            M=read_manifest(manifestFile);
            assert(strcmp(M.model.model_sha256,expectedOld),'SAR20:navigationLineage', ...
                'Navigation manifest changed after preflight; refusing to refresh from an unverified SID map.');
            assert(strcmp(file_sha256(modelFile),newSha),'SAR20:navigationModelSha', ...
                'Provided model SHA does not match the saved model bytes.');
            assert_model_loaded(model,modelFile,true);
            validate_targets(M,model);
            M.model.model_sha256=newSha;
            M.model.updated_utc=char(datetime('now','TimeZone','UTC', ...
                'Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
            M.model.update_reason='workspace apply; all registered SIDs and block identities revalidated';
            write_manifest(manifestFile,M);
            R=struct('status','refreshed_after_apply','manifest_path',manifestFile, ...
                'manifest_sha256',file_sha256(manifestFile),'model_sha256',newSha, ...
                'target_count',numel(M.targets),'validated_sid_count',count_sids(M));
        case 'recover'
            assert(numel(varargin)==1,'SAR20:navigationArgs', ...
                'recover requires the manifest SHA recorded before the interrupted apply.');
            expectedOld=char(string(varargin{1}));M=read_manifest(manifestFile);
            currentSha=file_sha256(modelFile);
            assert_model_loaded(model,modelFile,true);validate_targets(M,model);
            if strcmp(M.model.model_sha256,currentSha)
                status='already_current_after_interrupted_apply';
            else
                assert(strcmp(M.model.model_sha256,expectedOld),'SAR20:navigationRecoveryLineage', ...
                    'Current navigation map does not match the interrupted apply lineage.');
                M.model.model_sha256=currentSha;
                M.model.updated_utc=char(datetime('now','TimeZone','UTC', ...
                    'Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
                M.model.update_reason='recovery of interrupted workspace apply; all registered SIDs revalidated';
                write_manifest(manifestFile,M);status='recovered_interrupted_apply';
            end
            R=struct('status',status,'manifest_path',manifestFile, ...
                'manifest_sha256',file_sha256(manifestFile),'model_sha256',currentSha, ...
                'target_count',numel(M.targets),'validated_sid_count',count_sids(M));
        case 'focus'
            assert(numel(varargin)==2,'SAR20:navigationArgs','focus requires target and owner.');
            target=varargin{1};owner=varargin{2};
            assert(isfile(modelFile),'SAR20:model','Missing unique current model file.');
            if bdIsLoaded(model)
                assert_model_loaded(model,modelFile,true);
            else
                load_system(modelFile);
                assert_model_loaded(model,modelFile,true);
            end
            M=read_manifest(manifestFile);currentSha=file_sha256(modelFile);
            assert(strcmp(M.model.model_sha256,currentSha),'SAR20:navigationStale', ...
                'Navigation manifest is not bound to this saved model SHA.');
            validate_targets(M,model);
            R=resolve_focus(M,model,target,owner,currentSha,file_sha256(manifestFile));
        otherwise
            error('SAR20:navigationAction','Unknown navigation action.');
    end
end

function M=read_manifest(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:navigationManifest','Missing or oversized model_navigation.json.');
    M=jsondecode(fileread(file));
    assert(isstruct(M)&&isscalar(M)&&isfield(M,'schema_version')&& ...
        isfield(M,'model')&&isstruct(M.model)&&isfield(M,'targets')&& ...
        isstruct(M.targets)&&isfield(M.model,'name')&&isfield(M.model,'model_sha256')&& ...
        isfield(M.model,'baseline_sha256')&&strcmp(char(M.model.name),'SarAdc'), ...
        'SAR20:navigationSchema','Unsupported model navigation manifest schema.');
    assert(strcmp(char(M.schema_version),'sar20-model-navigation/v1'), ...
        'SAR20:navigationSchema','Unsupported model navigation version.');
    assert(strcmp(char(M.model.baseline_sha256), ...
        '91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e'), ...
        'SAR20:navigationBaseline','Navigation manifest baseline is not the locked 91973 baseline.');
    assert(strcmp(char(M.model.relative_path),'current/models/SarAdc.slx'), ...
        'SAR20:navigationPath','Navigation manifest points to a different model path.');
end

function assert_model_loaded(model,modelFile,requireFile)
    assert(bdIsLoaded(model),'SAR20:navigationModel','SarAdc must be loaded for SID verification.');
    actual=get_param(model,'FileName');
    assert(~isempty(actual)&&strcmpi(canonical(actual),canonical(modelFile)), ...
        'SAR20:navigationModel','A different same-name model is loaded.');
    if requireFile
        assert(isfile(modelFile),'SAR20:model','Missing unique current model file.');
    end
end

function validate_targets(M,model)
    for k=1:numel(M.targets)
        target=M.targets(k);
        assert(isfield(target,'key')&&is_text(target.key)&&isfield(target,'focus_sid'), ...
            'SAR20:navigationTarget','Each target needs a semantic key and focus_sid.');
        ids={};
        if ~isempty_sid(target.focus_sid),ids{end+1}=sid_text(target.focus_sid);end %#ok<AGROW>
        if isfield(target,'sids')
            list=target.sids;
            if isnumeric(list),list=num2cell(list(:));elseif ischar(list)||isstring(list),list=cellstr(list);end
            if iscell(list)
                for j=1:numel(list),if ~isempty_sid(list{j}),ids{end+1}=sid_text(list{j});end,end %#ok<AGROW>
            end
        end
        if isfield(target,'owner')&&isstruct(target.owner)&&isscalar(target.owner)&& ...
                isfield(target.owner,'sid')&&~isempty_sid(target.owner.sid)
            ownerSid=sid_text(target.owner.sid);ids{end+1}=ownerSid; %#ok<AGROW>
            verify_block(model,ownerSid,target.owner);
        end
        implementations=struct([]);
        if isfield(target,'implementations')&&isstruct(target.implementations)
            implementations=target.implementations;
            for j=1:numel(implementations)
                if isfield(implementations(j),'sid')&&~isempty_sid(implementations(j).sid)
                    sid=sid_text(implementations(j).sid);ids{end+1}=sid; %#ok<AGROW>
                    verify_block(model,sid,implementations(j));
                end
            end
        end
        ids=unique(ids,'stable');
        for j=1:numel(ids)
            if isempty(implementations)||~any(arrayfun(@(q)has_sid(q,ids{j}),implementations))
                verify_block(model,ids{j},struct());
            end
        end
    end
end

function verify_block(model,sid,metadata)
    path=resolve_sid(model,sid);
    expected=metadata_text(metadata,'block_type');
    if ~isempty(expected)
        actual=char(get_param(path,'BlockType'));
        assert(strcmp(actual,expected),'SAR20:navigationBlockType', ...
            'Registered SID %s changed BlockType.',sid);
    end
    expected=metadata_text(metadata,'function_name');
    if ~isempty(expected)
        actual=optional_param(path,'FunctionName');
        assert(strcmp(actual,expected),'SAR20:navigationFunction', ...
            'Registered SID %s changed FunctionName.',sid);
    end
    expected=metadata_text(metadata,'name');
    if ~isempty(expected)
        actual=char(get_param(path,'Name'));
        assert(strcmp(actual,expected),'SAR20:navigationName', ...
            'Registered SID %s changed block identity.',sid);
    end
end

function path=resolve_sid(model,sid)
    assert(~isempty(regexp(sid,'^[0-9]+$','once')),'SAR20:navigationSID', ...
        'Only decimal SID values from the verified manifest can be resolved.');
    path=Simulink.ID.getFullName([model ':' sid]);
    assert(ischar(path)&&isrow(path)&&~isempty(path)&&strcmpi(bdroot(path),model), ...
        'SAR20:navigationSID','SID %s does not resolve inside this SarAdc model.',sid);
end

function R=resolve_focus(M,model,target,owner,modelSha,manifestSha)
    ownerText=text_value(owner);key='';sid='';
    if isnumeric(target)||islogical(target)
        sid=sid_text(target);
    elseif ischar(target)||(isstring(target)&&isscalar(target))
        value=strtrim(char(target));lowerValue=lower(value);
        if startsWith(lowerValue,'physical:'),key=value(10:end);
        elseif startsWith(lowerValue,'exec:'),key=value(6:end);
        elseif startsWith(lowerValue,'state:'),key=state_key(value(7:end));
        elseif startsWith(lowerValue,'sid:'),sid=value(5:end);
        elseif any(strcmpi(value,{'FE353','RA48','SAR51','SampleCharge','RaCtState','SarState'})),key=state_key(value);
        elseif ~isempty(regexp(value,'^[0-9]+$','once')),sid=value;
        else,key=value;end
        key=lower(strtrim(key));
    else
        error('SAR20:navigationTarget','Target must be a semantic key or decimal SID.');
    end
    if ~isempty(sid),sid=sid_text(sid);end
    hits=struct('key',{},'target',{},'entry',{});
    if ~isempty(sid)
        for k=1:numel(M.targets)
            targetRow=M.targets(k);candidateEntries=target_entries(targetRow,model);
            for j=1:numel(candidateEntries)
                if strcmp(candidateEntries(j).sid,sid)
                    hits(end+1)=struct('key',char(targetRow.key),'target',targetRow, ...
                        'entry',candidateEntries(j)); %#ok<AGROW>
                end
            end
        end
    else
        ix=find(strcmp({M.targets.key},key));
        assert(isscalar(ix),'SAR20:navigationKey','Unknown or ambiguous semantic navigation key: %s.',key);
        row=M.targets(ix);allEntries=target_entries(row,model);
        if ~isempty(ownerText)
            take=arrayfun(@(e)owner_matches(e.owner,ownerText),allEntries);
            allEntries=allEntries(take);
        end
        for j=1:numel(allEntries)
            hits(end+1)=struct('key',key,'target',row,'entry',allEntries(j)); %#ok<AGROW>
        end
    end
    if ~isempty(ownerText)&&~isempty(hits)
        keep=arrayfun(@(h)owner_matches(h.entry.owner,ownerText),hits);hits=hits(keep);
    end
    assert(~isempty(hits),'SAR20:navigationNotFound','No registered SID matches the requested target/owner.');
    if numel(hits)>1
        keys=unique({hits.key},'stable');if isempty(key),key=strjoin(keys,',');end
        R=struct('schema','sar20-focus-target/v1','status','ambiguous_multiple_stage_or_owner', ...
            'semantic_key',key,'requested_owner',ownerText,'model_name',model, ...
            'model_sha256',modelSha,'navigation_manifest_sha256',manifestSha, ...
            'resolved_targets',reshape([hits.entry],[],1), ...
            'navigation_only',false,'calculates','unknown');
        return;
    end
    hit=hits(1);primarySid=sid;
    if isempty(primarySid)&&~isempty(ownerText)
        primarySid=hit.entry.sid;
    end
    if isempty(primarySid)&&isfield(hit.target,'focus_sid')&&~isempty_sid(hit.target.focus_sid)
        primarySid=sid_text(hit.target.focus_sid);
    end
    if isempty(primarySid),primarySid=hit.entry.sid;end
    path=resolve_sid(model,primarySid);
    title=metadata_text(hit.target,'title');
    if isempty(title),title=hit.key;end
    navigationOnly=logical_value(hit.target,'navigation_only',false);
    calculates=field_value(hit.target,'calculates','unknown');
    R=struct('schema','sar20-focus-target/v1','status','resolved', ...
        'semantic_key',hit.key,'title',title,'model_name',model, ...
        'model_file',get_param(model,'FileName'),'model_sha256',modelSha, ...
        'navigation_manifest_sha256',manifestSha,'focus_sid',primarySid, ...
        'full_name',path,'owner',hit.entry.owner, ...
        'resolved_targets',target_entries(hit.target,model), ...
        'navigation_only',navigationOnly,'calculates',calculates, ...
        'sourcepoints',field_value(hit.target,'sourcepoints',{}));
end

function entries=target_entries(target,model)
    prototype=struct('semantic_key',char(target.key),'sid','','name','','block_type','','function_name','', ...
        'sourcepoint','','owner','unknown','full_name','');
    entries=repmat(prototype,0,1);
    if isfield(target,'implementations')&&isstruct(target.implementations)
        for k=1:numel(target.implementations)
            item=target.implementations(k);if ~isfield(item,'sid')||isempty_sid(item.sid),continue;end
            sid=sid_text(item.sid);path=resolve_sid(model,sid);
            entries(end+1)=struct('semantic_key',char(target.key),'sid',sid,'name',metadata_text(item,'name'), ...
                'block_type',metadata_text(item,'block_type'), ...
                'function_name',metadata_text(item,'function_name'), ...
                'sourcepoint',metadata_text(item,'sourcepoint'), ...
                'owner',owner_text(item,target),'full_name',path); %#ok<AGROW>
        end
    end
    if isfield(target,'owner')&&isstruct(target.owner)&&isscalar(target.owner)&& ...
            isfield(target.owner,'sid')&&~isempty_sid(target.owner.sid)
        item=target.owner;sid=sid_text(item.sid);path=resolve_sid(model,sid);
        entries(end+1)=struct('semantic_key',char(target.key),'sid',sid, ...
            'name',metadata_text(item,'name'),'block_type',metadata_text(item,'block_type'), ...
            'function_name',metadata_text(item,'function_name'), ...
            'sourcepoint',metadata_text(item,'sourcepoint'), ...
            'owner',owner_text(item,target),'full_name',path); %#ok<AGROW>
    end
    if isfield(target,'sids')
        list=target.sids;
        if isnumeric(list),list=num2cell(list(:));elseif ischar(list)||isstring(list),list=cellstr(list);end
        if iscell(list)
            for k=1:numel(list)
                if isempty_sid(list{k}),continue;end
                sid=sid_text(list{k});if any(strcmp({entries.sid},sid)),continue;end
                path=resolve_sid(model,sid);
                entries(end+1)=struct('semantic_key',char(target.key),'sid',sid, ...
                    'name','','block_type','','function_name','','sourcepoint','', ...
                    'owner',owner_text(target,target),'full_name',path); %#ok<AGROW>
            end
        end
    end
    if isfield(target,'focus_sid')&&~isempty_sid(target.focus_sid)
        sid=sid_text(target.focus_sid);
        if ~any(strcmp({entries.sid},sid))
            path=resolve_sid(model,sid);
            entries(end+1)=struct('semantic_key',char(target.key),'sid',sid, ...
                'name',metadata_text(target,'name'),'block_type',metadata_text(target,'block_type'), ...
                'function_name',metadata_text(target,'function_name'), ...
                'sourcepoint',metadata_text(target,'sourcepoint'), ...
                'owner',owner_text(target,target),'full_name',path); %#ok<AGROW>
        end
    end
    if ~isempty(entries)
        [~,keep]=unique({entries.sid},'stable');entries=entries(keep);
    end
end

function tf=has_sid(item,sid)
    tf=isfield(item,'sid')&&~isempty_sid(item.sid)&&strcmp(sid_text(item.sid),sid);
end

function tf=owner_matches(value,requested)
    a=lower(owner_text_value(value));b=lower(requested);
    aliases=struct('fe353','samplecharge','ra48','ractstate','sar51','sarstate');
    if isfield(aliases,matlab.lang.makeValidName(b)),b=lower(aliases.(matlab.lang.makeValidName(b)));end
    if isfield(aliases,matlab.lang.makeValidName(a)),a=lower(aliases.(matlab.lang.makeValidName(a)));end
    tf=strcmp(a,b);
end

function value=owner_text(item,target)
    if isfield(item,'owner')&&~isempty(item.owner),value=owner_text_value(item.owner);
    elseif isfield(target,'owner')&&~isempty(target.owner),value=owner_text_value(target.owner);
    else,value='unknown';end
end

function value=owner_text_value(value)
    if isstruct(value)&&isscalar(value)
        if isfield(value,'name'),value=text_value(value.name);
        elseif isfield(value,'owner'),value=text_value(value.owner);
        else,value='unknown';end
    else,value=text_value(value);end
end

function key=state_key(value)
    switch lower(strtrim(value))
        case {'fe353','samplecharge'},key='fe_state';
        case {'ra48','ractstate'},key='ra_state';
        case {'sar51','sarstate'},key='sar_state';
        otherwise,error('SAR20:navigationOwner','Unknown state owner key.');
    end
end

function value=metadata_text(S,name)
    value='';if isstruct(S)&&isscalar(S)&&isfield(S,name),value=text_value(S.(name));end
end

function value=field_value(S,name,fallback)
    value=fallback;if isstruct(S)&&isfield(S,name),value=S.(name);end
end

function value=text_value(value)
    if ischar(value)&&isrow(value),return;end
    if isstring(value)&&isscalar(value),value=char(value);return;end
    if isnumeric(value)&&isscalar(value),value=num2str(value);return;end
    if islogical(value)&&isscalar(value),value=char(string(value));return;end
    value='';
end

function value=sid_text(value)
    if isnumeric(value)||islogical(value)
        assert(isscalar(value)&&isfinite(double(value))&&double(value)>0&&double(value)==floor(double(value)), ...
            'SAR20:navigationSID','SID must be a positive integer.');
        value=sprintf('%.0f',double(value));
    else
        value=text_value(value);
    end
    number=str2double(value);
    assert(~isempty(regexp(value,'^[0-9]+$','once'))&&isfinite(number)&&number>0&& ...
        number==floor(number)&&number<=flintmax,'SAR20:navigationSID', ...
        'Only positive decimal SIDs are accepted.');
end

function tf=isempty_sid(value)
    tf=isempty(value)||(ischar(value)&&isempty(strtrim(value)))|| ...
        (isstring(value)&&isscalar(value)&&strlength(strtrim(value))==0);
end

function value=optional_param(path,name)
    value='';try,value=char(get_param(path,name));catch,end
end

function value=logical_value(S,name,fallback)
    value=fallback;if isstruct(S)&&isfield(S,name)&&(islogical(S.(name))||isnumeric(S.(name)))&& ...
        isscalar(S.(name)),value=logical(S.(name));end
end

function n=count_sids(M)
    n=0;for k=1:numel(M.targets),n=n+numel(target_entries(M.targets(k),'SarAdc'));end
end

function tf=is_text(value)
    tf=(ischar(value)&&isrow(value))||(isstring(value)&&isscalar(value));
end

function p=canonical(p),p=char(java.io.File(p).getCanonicalPath());end

function value=file_sha256(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:fileSize','Missing or oversized file: %s.',file);
    fid=fopen(file,'rb');assert(fid>=0,'SAR20:read','Cannot read %s.',file);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid),bytes=fread(fid,1024*1024,'*uint8');md.update(typecast(bytes(:),'int8'));end
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function write_manifest(file,M)
    temp=[file '.tmp'];fid=fopen(temp,'w','n','UTF-8');
    assert(fid>=0,'SAR20:navigationWrite','Cannot write navigation manifest.');
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(M));clear cleanup;
    [ok,msg]=movefile(temp,file,'f');assert(ok,'SAR20:navigationWrite','%s',msg);
end
