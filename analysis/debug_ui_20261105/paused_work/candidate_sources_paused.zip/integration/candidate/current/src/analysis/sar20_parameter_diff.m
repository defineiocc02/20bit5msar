function D=sar20_parameter_diff(before,after)
%SAR20_PARAMETER_DIFF Report changed resolved-P leaf paths without reshaping data.
% Large vectors/matrices are compared as whole fields and are never expanded.
    if isempty(before)
        D=struct('status','no_previous_exact_P','changed_fields',{{}});return;
    end
    assert(isstruct(before)&&isscalar(before)&&isstruct(after)&&isscalar(after), ...
        'SAR20:parameterDiff','Parameter diff requires two scalar struct P values.');
    fields=collect(before,after,'P',{});
    D=struct('status','compared_exact_MAT_values','changed_fields',{fields});
end

function fields=collect(a,b,prefix,fields)
    if isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)
        names=unique([fieldnames(a);fieldnames(b)],'stable');
        for k=1:numel(names)
            name=names{k};next=[prefix '.' name];
            hasa=isfield(a,name);hasb=isfield(b,name);
            if hasa&&hasb
                x=a.(name);y=b.(name);
                if isstruct(x)&&isscalar(x)&&isstruct(y)&&isscalar(y)
                    fields=collect(x,y,next,fields);
                elseif ~isequaln(x,y)
                    fields{end+1}=next; %#ok<AGROW>
                end
            else
                fields{end+1}=next; %#ok<AGROW>
            end
        end
    elseif ~isequaln(a,b)
        fields{end+1}=prefix; %#ok<AGROW>
    end
end
