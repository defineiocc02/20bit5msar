function S=sar20_parameter_summary(P)
%SAR20_PARAMETER_SUMMARY Compact, non-authoritative dashboard projection of P.
% Exact values remain bound in P/DecodeP MAT files; no factory is executed.
    S=struct('schema',text_value(P,'schema','unknown'), ...
        'N',number_value(P,'N',NaN),'sample_rate_hz',number_value(P,'fs_hz',NaN), ...
        'sample_period_s',number_value(P,'Ts_s',NaN), ...
        'first_id',number_value(P,'first_id',NaN),'epoch',number_value(P,'epoch',NaN), ...
        'seed',number_value(P,'seed',NaN),'input',struct(), ...
        'az_mode','unknown','A0',NaN,'UGB_hz',NaN, ...
        'transport_enabled','unknown','observer_identity',struct(), ...
        'nonideality_flags',struct(), ...
        'nonideality_flag_scope','P.ni coverage labels from saved parameters; not feature-level verification', ...
        'feature_switches',struct(), ...
        'derived',struct('status','not_available','Ctop_half_f',NaN,'Cf_f',NaN, ...
        'noise_gain',NaN,'finite_gain_factor',NaN,'tau_ra_s',NaN, ...
        'tau_ra_status','unknown','sigma_vx_rms',NaN, ...
        'sigma_vx_reference','RA output differential VX; value copied from P.backend.ra_noise.sigma_vx_rms'), ...
        'random_seeds',struct(),'seed_scope', ...
        'P.seed is a run label; explicit feature seeds determine their own streams.');
    if isfield(P,'input')&&isstruct(P.input)
        S.input=struct('offset_v',number_value(P.input,'offset_v',NaN), ...
            'amplitude_v',number_value(P.input,'amplitude_v',NaN), ...
            'frequency_hz',number_value(P.input,'frequency_hz',NaN), ...
            'phase_rad',number_value(P.input,'phase_rad',NaN));
    end
    if isfield(P,'backend')&&isstruct(P.backend)
        if isfield(P.backend,'az')&&isstruct(P.backend.az)
            S.az_mode=text_value(P.backend.az,'mode','unknown');
        end
        if isfield(P.backend,'ra')&&isstruct(P.backend.ra)
            S.A0=number_value(P.backend.ra,'A0',NaN);
            S.UGB_hz=number_value(P.backend.ra,'UGB_hz',NaN);
        end
    end
    if isfield(P,'transport')&&isstruct(P.transport)
        S.transport_enabled=logical_value(P.transport,'enabled','unknown');
    end
    if isfield(P,'debug')&&isstruct(P.debug)&&isfield(P.debug,'observer')
        S.observer_identity=P.debug.observer;
    end
    if isfield(P,'ni')&&isstruct(P.ni)
        flags=fieldnames(P.ni);
        for k=1:numel(flags)
            value=P.ni.(flags{k});
            S.nonideality_flags.(flags{k})=flag_value(value);
        end
    end
    seeds=struct('run_label',number_value(P,'seed',NaN), ...
        'frontend_plan','not_recorded','dem','not_recorded','dither','not_recorded', ...
        'ktc','not_recorded','aperture','not_recorded','ra_ou','not_recorded', ...
        'comparator','not_recorded','chip_mismatch','not_recorded_in_resolved_P', ...
        'ct_mismatch','deterministic_values_saved_in_P');
    if isfield(P,'front')&&isstruct(P.front)
        for pair={'pool_seed','frontend_plan';'dem_seed','dem'; ...
                'dither_seed','dither';'ktc_seed','ktc'}'
            source=pair{1};destination=pair{2};
            if isfield(P.front,source),seeds.(destination)=P.front.(source);end
        end
        if isfield(P.front,'jitter')&&isstruct(P.front.jitter)&&isfield(P.front.jitter,'seed')
            seeds.aperture=P.front.jitter.seed;
        end
    end
    if isfield(P,'backend')&&isstruct(P.backend)&&isfield(P.backend,'ra_noise')&& ...
            isstruct(P.backend.ra_noise)&&isfield(P.backend.ra_noise,'seed_u64')
        seeds.ra_ou=P.backend.ra_noise.seed_u64;
    end
    if isfield(P,'control')&&isstruct(P.control)&&isfield(P.control,'comparator')&& ...
            isstruct(P.control.comparator)&&isfield(P.control.comparator,'seed_u64')
        seeds.comparator=P.control.comparator.seed_u64;
    end
    S.random_seeds=seeds;
    switches=struct();
    if isfield(P,'front')&&isstruct(P.front)
        for key={'dem_enabled','dither_enabled','mismatch_enabled','ktc_enabled'}
            name=key{1};if isfield(P.front,name),switches.(['frontend_' name])=flag_value(P.front.(name));end
        end
        if isfield(P.front,'jitter')&&isstruct(P.front.jitter)
            switches.frontend_jitter_enabled=logical_value(P.front.jitter,'enabled','invalid_or_unknown');
        end
    end
    if isfield(P,'backend')&&isstruct(P.backend)&&isfield(P.backend,'ni')&&isstruct(P.backend.ni)
        for key={'ra_noise','az','cap_mismatch','cinc_kick'}
            name=key{1};if isfield(P.backend.ni,name),switches.(name)=flag_value(P.backend.ni.(name));end
        end
    end
    if isfield(P,'control')&&isstruct(P.control)&&isfield(P.control,'comparator')&& ...
            isstruct(P.control.comparator)&&isfield(P.control.comparator,'enabled')
        switches.comparator_noise_enabled=flag_value(P.control.comparator.enabled);
    else
        switches.comparator_noise_enabled='unknown_not_configured';
    end
    if isfield(P,'backend')&&isstruct(P.backend)&&isfield(P.backend,'ra')&&isstruct(P.backend.ra)
        if isfield(P.backend.ra,'A0')&&isnumeric(P.backend.ra.A0)&&isscalar(P.backend.ra.A0)
            switches.ra_finite_gain_effect=isfinite(P.backend.ra.A0);
        end
        if isfield(P.backend.ra,'UGB_hz')&&isnumeric(P.backend.ra.UGB_hz)&&isscalar(P.backend.ra.UGB_hz)
            switches.ra_finite_bandwidth_effect=isfinite(P.backend.ra.UGB_hz);
        end
    end
    if isfield(P,'backend')&&isstruct(P.backend)&&isfield(P.backend,'dac_coupling')&& ...
            isstruct(P.backend.dac_coupling)&&isfield(P.backend.dac_coupling,'enabled')
        switches.dac_coupling_enabled=flag_value(P.backend.dac_coupling.enabled);
        switches.dac_finite_settling_enabled=false;
        if isfield(P.backend.dac_coupling,'tau_dac_s')&&isnumeric(P.backend.dac_coupling.tau_dac_s)
            switches.dac_finite_settling_enabled=any(isfinite(P.backend.dac_coupling.tau_dac_s(:))& ...
                P.backend.dac_coupling.tau_dac_s(:)>0);
        end
    else
        switches.dac_coupling_enabled='unknown_not_configured';
        switches.dac_finite_settling_enabled='unknown_not_configured';
    end
    for key={'training','cal_cfg','frozen','bank'}
        name=key{1};if isfield(P,name)&&isstruct(P.(name))&&isfield(P.(name),'enabled')
            switches.([name '_enabled'])=flag_value(P.(name).enabled);
        end
    end
    S.feature_switches=switches;
    S.derived=derived_values(P);
end

function D=derived_values(P)
    D=struct('status','not_available','Ctop_half_f',NaN,'Cf_f',NaN, ...
        'noise_gain',NaN,'finite_gain_factor',NaN,'tau_ra_s',NaN, ...
        'tau_ra_status','unknown','sigma_vx_rms',NaN, ...
        'sigma_vx_reference','RA output differential VX; value copied from P.backend.ra_noise.sigma_vx_rms', ...
        'sigma_vx_recomputed_for_display',false);
    if ~isfield(P,'front')||~isstruct(P.front)||~all(isfield(P.front,{'group_C_f','Cp_f'}))|| ...
            ~isfield(P,'backend')||~isstruct(P.backend)||~isfield(P.backend,'ra')|| ...
            ~isstruct(P.backend.ra)||~all(isfield(P.backend.ra,{'Cf_f','A0','UGB_hz'}))
        return;
    end
    if ~isnumeric(P.front.group_C_f)||~isreal(P.front.group_C_f)||size(P.front.group_C_f,1)<8|| ...
            ~isnumeric(P.front.Cp_f)||~isreal(P.front.Cp_f)||numel(P.front.Cp_f)<8|| ...
            ~isnumeric(P.backend.ra.Cf_f)||~isreal(P.backend.ra.Cf_f)||~isscalar(P.backend.ra.Cf_f)|| ...
            ~isnumeric(P.backend.ra.A0)||~isreal(P.backend.ra.A0)||~isscalar(P.backend.ra.A0)|| ...
            ~isnumeric(P.backend.ra.UGB_hz)||~isreal(P.backend.ra.UGB_hz)||~isscalar(P.backend.ra.UGB_hz)
        return;
    end
    Ctop=sum(P.front.group_C_f(1:8,:),'all')+sum(P.front.Cp_f(1:8));
    Cf=double(P.backend.ra.Cf_f);A0=double(P.backend.ra.A0);UGB=double(P.backend.ra.UGB_hz);
    if ~(isfinite(Ctop)&&Ctop>=0&&isfinite(Cf)&&Cf>0),return;end
    NG=1+Ctop/Cf;
    gain=NaN;
    if isinf(A0)&&A0>0,gain=1;
    elseif isfinite(A0)&&A0>0,gain=A0/(A0+NG);end
    tau=NaN;tauStatus='unknown';
    if isinf(UGB)&&UGB>0,tau=0;tauStatus='ideal_infinite_UGB_limit';
    elseif isfinite(UGB)&&UGB>0,tau=NG/(2*pi*UGB);tauStatus='derived_from_saved_UGB';end
    sigma=NaN;
    if isfield(P.backend,'ra_noise')&&isstruct(P.backend.ra_noise)&& ...
            isfield(P.backend.ra_noise,'sigma_vx_rms')
        sigma=P.backend.ra_noise.sigma_vx_rms;
    end
    D=struct('status','derived_from_saved_P','Ctop_half_f',Ctop,'Cf_f',Cf, ...
        'noise_gain',NG,'finite_gain_factor',gain,'tau_ra_s',tau, ...
        'tau_ra_status',tauStatus,'sigma_vx_rms',sigma, ...
        'sigma_vx_reference','RA output differential VX; value copied from P.backend.ra_noise.sigma_vx_rms', ...
        'sigma_vx_recomputed_for_display',false);
end

function value=number_value(S,name,fallback)
    value=fallback;
    if isstruct(S)&&isfield(S,name)&&isnumeric(S.(name))&&isreal(S.(name))&&isscalar(S.(name))
        value=double(S.(name));
    end
end

function value=text_value(S,name,fallback)
    value=fallback;
    if isstruct(S)&&isfield(S,name)
        v=S.(name);
        if ischar(v)&&isrow(v),value=v;elseif isstring(v)&&isscalar(v),value=char(v);end
    end
end

function value=logical_value(S,name,fallback)
    value=fallback;
    if isstruct(S)&&isfield(S,name)&&(islogical(S.(name))||isnumeric(S.(name)))&&isscalar(S.(name))
        value=flag_value(S.(name));
    end
end

function value=flag_value(value)
    if (islogical(value)||isnumeric(value))&&isreal(value)&&isscalar(value)&& ...
            isfinite(double(value))&&any(double(value)==[0 1])
        value=logical(value);
    else
        value='invalid_or_unknown';
    end
end
