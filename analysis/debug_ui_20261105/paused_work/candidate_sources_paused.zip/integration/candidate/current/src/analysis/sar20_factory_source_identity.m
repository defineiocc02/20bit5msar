function identity=sar20_factory_source_identity(root)
%SAR20_FACTORY_SOURCE_IDENTITY Hash factory inputs without executing them.
% Reading this identity never calls adc_parameters/normal_parameters and
% therefore never constructs local RandStreams or changes a random stream.
    names={'config/adc_parameters.m';'config/normal_parameters.m'; ...
        'config/normal_10v_configuration.m';'config/nominal.mat'};
    rows=repmat(struct('path','','sha256','','bytes',0),numel(names),1);
    bundle=uint8([]);sourceFiles=struct();complete=true;
    for k=1:numel(names)
        relative=names{k};file=fullfile(root,strrep(relative,'/',filesep));
        d=dir(file);
        if isempty(d)||~isscalar(d)||d.isdir||d.bytes>300e6
            complete=false;
            rows(k)=struct('path',relative,'sha256','unknown','bytes',0);
        else
            rows(k)=struct('path',relative,'sha256',file_sha256(file),'bytes',d.bytes);
        end
        [~,stem,ext]=fileparts(relative);
        field=matlab.lang.makeValidName([stem ext]);
        sourceFiles.(field)=rows(k).sha256;
        record=unicode2native([relative char(0) rows(k).sha256 char(10)],'UTF-8');
        bundle=[bundle;uint8(record(:))]; %#ok<AGROW>
    end
    if complete,status='complete';sourceHash=bytes_sha256(bundle);
    else,status='unknown_incomplete_or_oversized';sourceHash='unknown';end
    identity=struct('schema','sar20-factory-source/v1','status',status, ...
        'source_sha256',sourceHash,'source_files',sourceFiles, ...
        'files',rows, ...
        'read_only_hashing',true,'factory_executed',false);
end

function value=file_sha256(file)
    fid=fopen(file,'rb');assert(fid>=0,'SAR20:factorySourceRead','Cannot read %s.',file);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid)
        bytes=fread(fid,1024*1024,'*uint8');md.update(typecast(bytes(:),'int8'));
    end
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function value=bytes_sha256(bytes)
    md=java.security.MessageDigest.getInstance('SHA-256');
    if ~isempty(bytes),md.update(typecast(bytes(:),'int8'));end
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
