function R=sar20_debug_result_registry(root,selectedRunPath)
%SAR20_DEBUG_RESULT_REGISTRY Index local result summaries without loading MATs.
% Only immediate run directories with a bounded summary.json are inspected.
    if nargin<2,selectedRunPath='';end
    assert(ischar(selectedRunPath)||(isstring(selectedRunPath)&&isscalar(selectedRunPath)), ...
        'SAR20:resultsPath','Selected result path must be text.');
    runsRoot=canonical(fullfile(root,'runs'));
    entries=struct('run_id',{},'run_path',{},'status',{},'utc',{}, ...
        'model_sha256',{},'config_sha256',{},'configuration_source',{}, ...
        'P_sha256',{},'DecodeP_sha256',{},'observer_identity',{},'baseline_lineage',{}, ...
        'configuration_summary',{},'N',{},'sample_ids',{},'summary_sha256',{});
    folders=dir(runsRoot);
    for k=1:numel(folders)
        if ~folders(k).isdir||ismember(folders(k).name,{'.','..'}),continue;end
        folder=fullfile(runsRoot,folders(k).name);summaryFile=fullfile(folder,'summary.json');
        d=dir(summaryFile);if isempty(d),continue;end
        assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
            'SAR20:resultSummary','Missing or oversized result summary: %s.',summaryFile);
        summary=jsondecode(fileread(summaryFile));
        recordN=field_number(summary,'N',NaN);
        if isnan(recordN)&&isstruct(summary)&&isfield(summary,'configuration_summary')&& ...
                isstruct(summary.configuration_summary)
            recordN=field_number(summary.configuration_summary,'N',NaN);
        end
        entries(end+1)=struct('run_id',field_text(summary,'run_id',folders(k).name), ...
            'run_path',canonical(folder),'status',field_text(summary,'status','unknown'), ...
            'utc',field_text(summary,'utc','unknown'), ...
            'model_sha256',field_text(summary,'model_sha256','unknown'), ...
            'config_sha256',field_text(summary,'config_sha256','unknown'), ...
            'configuration_source',field_text(summary,'configuration_source','unknown'), ...
            'P_sha256',field_text(summary,'P_sha256','unknown'), ...
            'DecodeP_sha256',field_text(summary,'DecodeP_sha256','unknown'), ...
            'observer_identity',field_struct(summary,'observer_identity'), ...
            'baseline_lineage',field_struct(summary,'baseline_lineage'), ...
            'configuration_summary',field_struct(summary,'configuration_summary'), ...
            'N',recordN, ...
            'sample_ids',field_vector(summary,'sample_ids'), ...
            'summary_sha256',file_sha256(summaryFile)); %#ok<AGROW>
    end
    if ~isempty(entries)
        [~,order]=sort({entries.utc});entries=entries(fliplr(order));
    end
    selectedPath='';requested=char(selectedRunPath);
    if ~isempty(requested)
        selectedPath=canonical(requested);
        assert(under(selectedPath,runsRoot),'SAR20:resultsOutsideRoot', ...
            'Results selection must be a run directory under this project runs/ folder.');
        selectedRecord=match_path(entries,selectedPath);
        write_selection(root,selectedRecord);
    else
        selection=read_json(fullfile(root,'state','debug_selection.json'));
        candidate=field_text(selection,'run_path','');
        if ~isempty(candidate)&&isfolder(candidate)
            candidate=canonical(candidate);
            if under(candidate,runsRoot),selectedPath=candidate;end
        end
        if isempty(selectedPath)
            latest=read_json(fullfile(runsRoot,'latest_behavior_run.json'));
            candidate=field_text(latest,'run_path','');
            if ~isempty(candidate)&&isfolder(candidate)
                candidate=canonical(candidate);
                if under(candidate,runsRoot),selectedPath=candidate;end
            end
        end
    end
    selected=[];
    if ~isempty(selectedPath),selected=match_path(entries,selectedPath);end
    R=struct('schema','sar20-result-registry/v1','runs_root',runsRoot, ...
        'runs',entries,'selected_run',selected,'selected_run_path',selectedPath, ...
        'run_count',numel(entries),'scope','local run summaries; source MATs not loaded');
end

function selected=match_path(entries,path)
    idx=find(strcmp({entries.run_path},path));
    assert(isscalar(idx),'SAR20:resultNotRegistered', ...
        'Selected run has no registered summary.json under runs/.');
    selected=entries(idx);
end

function write_selection(root,entry)
    file=fullfile(root,'state','debug_selection.json');
    if ~isfolder(fileparts(file)),mkdir(fileparts(file));end
    value=struct('schema','sar20-debug-selection/v1','run_id',entry.run_id, ...
        'run_path',entry.run_path,'summary_sha256',entry.summary_sha256, ...
        'selected_utc',char(datetime('now','TimeZone','UTC', ...
        'Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z''')));
    temp=[file '.tmp'];fid=fopen(temp,'w','n','UTF-8');
    assert(fid>=0,'SAR20:selectionWrite','Cannot write selected result record.');
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));clear cleanup;
    [ok,msg]=movefile(temp,file,'f');assert(ok,'SAR20:selectionWrite','%s',msg);
end

function value=read_json(file)
    value=struct();d=dir(file);if isempty(d),return;end
    assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6,'SAR20:stateFile','Missing or oversized JSON: %s.',file);
    value=jsondecode(fileread(file));if isempty(value),value=struct();end
end

function value=field_text(S,name,fallback)
    value=fallback;
    if isstruct(S)&&isscalar(S)&&isfield(S,name)
        item=S.(name);
        if ischar(item)&&isrow(item),value=item;
        elseif isstring(item)&&isscalar(item),value=char(item);end
    end
end

function value=field_number(S,name,fallback)
    value=fallback;
    if isstruct(S)&&isscalar(S)&&isfield(S,name)&&isnumeric(S.(name))&&isscalar(S.(name))
        value=double(S.(name));
    end
end

function value=field_struct(S,name)
    value=struct();if isstruct(S)&&isscalar(S)&&isfield(S,name)&&isstruct(S.(name))
        value=S.(name);
    end
end

function value=field_vector(S,name)
    value=[];
    if isstruct(S)&&isscalar(S)&&isfield(S,name)&&isnumeric(S.(name))&&isvector(S.(name))
        value=double(S.(name)(:).');
    end
end

function p=canonical(p),p=char(java.io.File(p).getCanonicalPath());end

function tf=under(p,root)
    p=canonical(p);root=canonical(root);tf=startsWith(lower(p),[lower(root) filesep]);
end

function value=file_sha256(file)
    d=dir(file);assert(isscalar(d)&&~d.isdir&&d.bytes<=300e6, ...
        'SAR20:fileSize','Missing or oversized file: %s.',file);
    fid=fopen(file,'rb');assert(fid>=0,'SAR20:read','Cannot read %s.',file);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid),bytes=fread(fid,1024*1024,'*uint8');md.update(typecast(bytes(:),'int8'));end
    value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
