function identity=sar20_parameter_fingerprint(value)
%SAR20_PARAMETER_FINGERPRINT Fingerprint exact MATLAB values, including Inf/NaN.
% The byte stream is kept in memory; no lossy JSON projection is used.
    bytes=getByteStreamFromArray(value);
    md=java.security.MessageDigest.getInstance('SHA-256');
    if ~isempty(bytes),md.update(typecast(bytes(:),'int8'));end
    digest=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
    identity=struct('schema','matlab-byte-stream-sha256/v1', ...
        'sha256',digest,'byte_count',numel(bytes));
end
