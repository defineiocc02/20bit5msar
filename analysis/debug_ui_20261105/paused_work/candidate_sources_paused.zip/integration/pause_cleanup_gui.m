% PAUSE_CLEANUP_GUI v1: close only clean stopped views owned by this SAR20 task.
disp(jsonencode(pause_cleanup()));
function r=pause_cleanup()
    assert(feature('getpid')==27628&&usejava('desktop'));
    root='D:/Academic/Projects/sar20m1/SAR20';
    out='D:/Temp/SAR20DEBUG_UI_20261105/pause_gui_receipt.json';assert(~isfile(out));
    r=struct('status','PAUSE_CLEANUP_COMPLETE','pid',feature('getpid'), ...
        'closed_model',false,'closed_figures',0,'original_matlab_retained',true,'notes',{{}});
    if bdIsLoaded('SarAdc')
        actual=canon(get_param('SarAdc','FileName'));
        expected=canon(fullfile(root,'current','models','SarAdc.slx'));
        owned=strcmpi(actual,expected)||startsWith(lower(actual),'d:/temp/sar20debug_');
        if owned&&strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&&strcmp(get_param('SarAdc','Dirty'),'off')
            close_system('SarAdc',0);r.closed_model=true;
        else
            r.notes{end+1}='Loaded model left untouched: not owned, dirty, or running.';
        end
    end
    figures=findall(groot,'Type','figure');
    for k=1:numel(figures)
        tag=get(figures(k),'Tag');
        if ischar(tag)&&(startsWith(tag,'SAR20Dashboard')||startsWith(tag,'SAR20Debug'))
            close(figures(k));r.closed_figures=r.closed_figures+1;
        end
    end
    f=fopen(out,'w','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(r));
end
function p=canon(p),p=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
