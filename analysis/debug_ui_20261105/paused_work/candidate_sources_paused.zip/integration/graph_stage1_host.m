% GRAPH_STAGE1_HOST v1: actual SATK visual/navigation/wrapper stage on private 9197.
job='D:/Temp/SAR20DEBUG_GRAPH1_20261105';
restoredefaultpath;addpath(job,fullfile(job,'scripts'),'-begin');run_graph_stage1(job);
function run_graph_stage1(job)
    file=fullfile(job,'host_receipt.json');assert(~isfile(file));
    r=struct('status','starting','pid',feature('getpid'),'simulation_run',false,'keep_worker_alive',false);
    try
        manifest=fullfile(job,'FILES.json');assert(strcmp(sha(manifest),lower(getenv('SAR20_GRAPH_MANIFEST'))));
        m=jsondecode(fileread(manifest));verify(job,m.files);
        r.stage=run_modelgraph_stage1('D:/Academic/Projects/sar20m1/SAR20', ...
            fullfile(job,'model_work'),'ColdOpenCompile',true,'KeepModelOpen',false);
        verify(job,m.files);assert(strcmp(r.stage.status,'candidate_prepared'));
        r.status='passed';r.model_sha256=r.stage.final_model_sha256;
    catch ex
        r.status='failed';r.error=getReport(ex,'extended','hyperlinks','off');
        % Never exit with an owned modified graph that has no recoverable save.
        owned=false;
        if bdIsLoaded('SarAdc')
            f=get_param('SarAdc','FileName');owned=startsWith(lower(canon(f)),[lower(canon(job)) '/']);
        end
        if owned
            saved=false;attempt=0;
            while ~saved
                attempt=attempt+1;
                try
                    recover=fullfile(job,['owned_recovery_' num2str(attempt) '.slx']);
                    save_system('SarAdc',recover);r.recovery_path=recover;r.recovery_sha256=sha(recover);
                    saved=true;r.keep_worker_alive=false;
                catch se
                    r.keep_worker_alive=true;r.recovery_error=getReport(se,'extended','hyperlinks','off');
                    write_json(file,r);
                    marker=fullfile(job,['REQUEST_SAVE_' sprintf('%02d',attempt)]);
                    while ~isfile(marker),pause(2);end
                end
            end
            close_system('SarAdc',0);
        end
    end
    write_json(file,r);
    assert(strcmp(r.status,'passed'),'graphHost:failed','Inspect host and scope receipts; no whole-stage retry.');
end
function verify(root,rows)
    for k=1:numel(rows),p=fullfile(root,rows(k).path);d=dir(p);assert(isscalar(d)&&~d.isdir&&d.bytes==rows(k).bytes&&d.bytes<=300e6&&strcmp(sha(p),rows(k).sha256));end
end
function p=canon(p),p=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function h=sha(p)
    f=fopen(p,'rb');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    b=fread(f,Inf,'*uint8');m=java.security.MessageDigest.getInstance('SHA-256');m.update(b);
    h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
function write_json(file,r)
    f=fopen(file,'w','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',jsonencode(r));
end
