$ErrorActionPreference='Stop'
$job='D:\Temp\SAR20DEBUG_UI_20261105'
$p=@(Get-Process MATLAB)
if($p.Count -ne 1 -or $p[0].Id -ne 27628 -or -not $p[0].Responding){throw 'Only original responsive GUI expected.'}
$model='D:\Academic\Projects\sar20m1\SAR20\current\models\SarAdc.slx'
$sha=(Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash
if($sha.ToLowerInvariant() -ne '91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e'){throw 'Baseline changed.'}
$app=[Runtime.InteropServices.Marshal]::GetActiveObject('Matlab.Application')
$console=[string]$app.Execute("run('D:/Temp/SAR20DEBUG_UI_20261105/scope_query.m');")
[IO.File]::WriteAllText((Join-Path $job 'query_console.txt'),$console,[Text.UTF8Encoding]::new($false))
if((Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash -ne $sha){throw 'Read-only query changed file.'}
