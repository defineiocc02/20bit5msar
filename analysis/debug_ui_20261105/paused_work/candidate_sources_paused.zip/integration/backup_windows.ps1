# v1: preserve actual working source/model/state before this debug-only stage.
$ErrorActionPreference='Stop'
$root='D:\Academic\Projects\sar20m1\SAR20'
$dest='D:\Academic\Projects\sar20m1\SAR20_preserved\before_debug_ui_20261105'
$active='D:\Temp\SAR20DEBUG_UI_20261105\BASELINE_ACTIVE.json'
if(Test-Path -LiteralPath $dest){throw 'Backup already exists; inspect its receipt.'}
$manifest=Get-Content -LiteralPath $active -Raw -Encoding UTF8|ConvertFrom-Json
foreach($row in $manifest.files){
 $f=Join-Path $root ([string]$row.path).Replace('/','\');$d=Get-Item -LiteralPath $f
 if($d.Length -gt 300000000 -or (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Current identity differs: '+$row.path)}
}
[void](New-Item -ItemType Directory -Path $dest)
$copy=Join-Path $dest 'working_files';[void](New-Item -ItemType Directory -Path $copy)
$selected=@()
foreach($dir in @('current','config','state')){
 foreach($item in @(Get-ChildItem -LiteralPath (Join-Path $root $dir) -File -Recurse -Force)){
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw ('Reparse input: '+$item.FullName)}
  if($item.Length -gt 300000000){throw ('Oversized input: '+$item.FullName)}
  $selected += $item
 }
}
foreach($rel in @('SAR20.m','README.md','release.json','docs/READ_GRAPH.md','docs/PARAMETERS.md','docs/SPEC.md')){
 if(Test-Path -LiteralPath (Join-Path $root $rel)){$selected += Get-Item -LiteralPath (Join-Path $root $rel)}
}
$rows=@()
foreach($item in $selected){
 if($item.Length -gt 300000000){throw 'Oversized input.'}
 $rel=$item.FullName.Substring($root.Length+1);$to=Join-Path $copy $rel
 [void](New-Item -ItemType Directory -Path (Split-Path $to) -Force)
 Copy-Item -LiteralPath $item.FullName -Destination $to
 $h=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
 if((Get-FileHash -LiteralPath $to -Algorithm SHA256).Hash.ToLowerInvariant() -ne $h){throw ('Copy mismatch: '+$rel)}
 $rows += [pscustomobject]@{path=$rel.Replace('\','/');bytes=$item.Length;sha256=$h}
}
$m=Join-Path $dest 'MANIFEST.json'
[IO.File]::WriteAllText($m,(@{schema='sar20-debug-baseline-backup/v1';files=$rows}|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=Join-Path $dest 'working_files.zip'
[IO.Compression.ZipFile]::CreateFromDirectory($copy,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
$r=[pscustomobject]@{status='BACKUP_VERIFIED';files=$rows.Count;manifest_sha256=(Get-FileHash $m -Algorithm SHA256).Hash.ToLowerInvariant();zip_sha256=(Get-FileHash $zip -Algorithm SHA256).Hash.ToLowerInvariant();original_modified=$false}
[IO.File]::WriteAllText((Join-Path $dest 'receipt.json'),($r|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
$r|ConvertTo-Json -Compress
