#!/usr/bin/env python3
"""Generate the small source diff and hash manifest for entry_config_luna."""

from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

CANDIDATE = Path(
    "/Users/zhaoyi/Obsidan/项目库临时文件夹/"
    "sar20_debug_ui_20261105.88odpncj/candidate"
)
PATCH_DIR = Path(
    "/Users/zhaoyi/Obsidan/项目库临时文件夹/"
    "sar20_debug_ui_20261105.88odpncj/agent_patches/entry_config_luna"
)
CHANGED = [
    ("SAR20.baseline.m", "SAR20.m"),
    ("behavior_applied_note.baseline.m", "current/src/model/behavior_applied_note.m"),
]
ADDED = [
    "current/src/analysis/sar20_factory_source_identity.m",
    "current/src/analysis/sar20_parameter_fingerprint.m",
    "current/src/analysis/sar20_parameter_state.m",
    "current/src/analysis/sar20_parameter_summary.m",
    "current/src/analysis/sar20_parameter_diff.m",
    "current/src/analysis/sar20_debug_result_registry.m",
    "current/src/analysis/sar20_navigation_manifest.m",
]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines(keepends=True)


patch_lines: list[str] = []
for baseline_name, candidate_name in CHANGED:
    baseline = PATCH_DIR / baseline_name
    candidate = CANDIDATE / candidate_name
    patch_lines.extend(difflib.unified_diff(
        lines(baseline),
        lines(candidate),
        fromfile=f"a/{candidate_name}",
        tofile=f"b/{candidate_name}",
    ))
for relative in ADDED:
    candidate = CANDIDATE / relative
    patch_lines.extend(difflib.unified_diff(
        [],
        lines(candidate),
        fromfile="/dev/null",
        tofile=f"b/{relative}",
    ))

patch_path = PATCH_DIR / "ENTRY_CONFIG.patch"
patch_path.write_text("".join(patch_lines), encoding="utf-8")
files = []
for _, candidate_name in CHANGED:
    files.append({
        "path": candidate_name,
        "sha256": sha(CANDIDATE / candidate_name),
        "baseline_sha256": sha(PATCH_DIR / CHANGED[[c[1] for c in CHANGED].index(candidate_name)][0]),
        "kind": "modified",
    })
for relative in ADDED:
    files.append({"path": relative, "sha256": sha(CANDIDATE / relative), "kind": "added"})

manifest = {
    "schema": "sar20-entry-config-patch/v1",
    "candidate_root": str(CANDIDATE),
    "patch_file": str(patch_path),
    "patch_sha256": sha(patch_path),
    "production_tree_modified": False,
    "windows_or_matlab_run": False,
    "base_model_sha256": "91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e",
    "files": files,
    "verification_script": str(PATCH_DIR / "verify_entry_candidate.py"),
    "integration_dependencies": [
        "sar20_dashboard.m",
        "sar20_debug_sample.m",
        "sar20_debug_compare.m",
        "sar20_debug_fields.m",
        "state/model_navigation.json",
    ],
    "status": "entry_and_identity_patch_ready; runtime dependency merge pending",
}
manifest_path = PATCH_DIR / "ENTRY_CONFIG_MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"patch": str(patch_path), "manifest": str(manifest_path), "files": len(files)}, ensure_ascii=False))
