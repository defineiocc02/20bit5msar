#!/usr/bin/env python3
"""Static acceptance checks for the isolated SAR20 entry/config candidate.

This does not start MATLAB, Simulink, a model run, or any factory function.
It checks source wiring and identity guards only.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


CANDIDATE = Path(
    "/Users/zhaoyi/Obsidan/项目库临时文件夹/"
    "sar20_debug_ui_20261105.88odpncj/candidate"
)
PRODUCTION = Path("/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020")
PATCH_DIR = Path(
    "/Users/zhaoyi/Obsidan/项目库临时文件夹/"
    "sar20_debug_ui_20261105.88odpncj/agent_patches/entry_config_luna"
)
BASELINE_MODEL_SHA256 = "91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e"
BASELINE_ENTRY_SHA256 = "50df7279305af7e2be5ce9f2f1c563bb7f7e25f62150dbc274a1d29c81934469"
BASELINE_NOTE_SHA256 = "a511fe00f336d2ff3130cb5c445e0913973a5834d4c0c6f69b4b274d7aaed960"

ENTRY_HELPERS = [
    "current/src/analysis/sar20_factory_source_identity.m",
    "current/src/analysis/sar20_parameter_fingerprint.m",
    "current/src/analysis/sar20_parameter_state.m",
    "current/src/analysis/sar20_parameter_summary.m",
    "current/src/analysis/sar20_parameter_diff.m",
    "current/src/analysis/sar20_debug_result_registry.m",
    "current/src/analysis/sar20_navigation_manifest.m",
]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read(rel: str) -> str:
    return (CANDIDATE / rel).read_text(encoding="utf-8")


def check(condition: bool, label: str, evidence: str = "") -> dict[str, str]:
    if not condition:
        raise AssertionError(f"FAILED {label}: {evidence}")
    return {"check": label, "status": "pass", "evidence": evidence}


def main() -> None:
    sar20 = read("SAR20.m")
    note = read("current/src/model/behavior_applied_note.m")
    factory_hash = read("current/src/analysis/sar20_factory_source_identity.m")
    navigation = read("current/src/analysis/sar20_navigation_manifest.m")
    state = read("current/src/analysis/sar20_parameter_state.m")
    results = read("current/src/analysis/sar20_debug_result_registry.m")

    checks: list[dict[str, str]] = []
    checks.append(check(
        sha(CANDIDATE / "current/models/SarAdc.slx") == BASELINE_MODEL_SHA256,
        "candidate_model_identity",
        sha(CANDIDATE / "current/models/SarAdc.slx"),
    ))
    checks.append(check(
        sha(PRODUCTION / "SAR20.m") == BASELINE_ENTRY_SHA256,
        "production_entry_unchanged",
        sha(PRODUCTION / "SAR20.m"),
    ))
    checks.append(check(
        sha(PRODUCTION / "current/src/model/behavior_applied_note.m") == BASELINE_NOTE_SHA256,
        "production_note_unchanged",
        sha(PRODUCTION / "current/src/model/behavior_applied_note.m"),
    ))
    checks.append(check(
        "action='home'" in sar20 and "strcmp(action,'open')" in sar20 and "open_system(modelFile)" in sar20,
        "home_default_and_real_model_open",
        "home is no-argument default; open_system receives current/models/SarAdc.slx",
    ))
    checks.append(check(
        "SAR20('home')" in sar20 and "sar20_parameter_state" in sar20,
        "home_parameter_state_route",
        "home calls source-hash/state helper and dashboard; no factory construction is on this route",
    ))
    checks.append(check(
        all(name in factory_hash for name in [
            "config/adc_parameters.m",
            "config/normal_parameters.m",
            "config/normal_10v_configuration.m",
            "config/nominal.mat",
        ]) and not re.search(r"\b(adc_parameters|normal_parameters)\s*\(", factory_hash),
        "factory_sources_hashed_without_execution",
        "four files are hashed as bytes; no factory call expression exists in the helper",
    ))
    checks.append(check(
        "applied_parameters_%s_%s_%s.mat" in sar20 and "save(parameterMat,'P','DecodeP','identity'" in sar20
        and "P_sha256" in sar20 and "DecodeP_sha256" in sar20,
        "exact_applied_P_DecodeP_binding",
        "P and DecodeP are saved in MAT with model/source fingerprints",
    ))
    checks.append(check(
        "applied_parameters_%s_%s_%s.mat" in sar20
        and "write_json_atomic(fullfile(state,'applied_config.json'),applied)" in sar20
        and "load_committed_parameters" in read("current/src/analysis/sar20_parameter_state.m"),
        "versioned_snapshot_and_atomic_commit",
        "pending MAT snapshots do not replace the last committed P; applied_config atomically selects the committed snapshot",
    ))
    checks.append(check(
        "source_sha256" in sar20 and "source_files" in sar20
        and "unknown_legacy_apply" in state,
        "pending_source_identity_and_legacy_unknown",
        "per-file and bundle hashes are recorded; missing old hashes remain unknown",
    ))
    checks.append(check(
        "sar20_parameter_diff" in sar20 and "changed_fields" in sar20
        and "recomputed_fields" in sar20 and "preserved_fields" in sar20
        and "factory_A1_PSD_to_sigma_vx_rms" in sar20
        and "explicit_fixed_sigma_vx_rms" in sar20 and "unknown_source" in sar20,
        "parameter_change_and_derivation_report",
        "apply reports exact changed fields, recomputed derived fields, and preserved noise inputs",
    ))
    checks.append(check(
        "P.debug.observer" in sar20 and "sample_id=5" in sar20
        and "observer.Ts_s=P.Ts_s" in sar20,
        "passive_observer_identity",
        "default observer window is explicitly tied to sample ID 5 and saved Ts_s",
    ))
    checks.append(check(
        "observer_contract.json" in sar20 and "sar20_debug_fields()" in sar20
        and "R.bundle" in sar20 and "which('sar20_debug_fields')" in sar20
        and "R.bundle.logger_name" in sar20 and "simout.who" in sar20
        and "registry_source_sha" in sar20 and "expected_selected_sample_rows" in sar20
        and "observer_schema.json" not in sar20,
        "archived_observer_contract_from_registry_source",
        "saved observer_log uses deployed registry bundle/source SHA; no graph-generated schema is consumed",
    ))
    sample_start = sar20.index("if strcmp(action,'sample')")
    sample_end = sar20.index("if strcmp(action,'apply')", sample_start)
    sample_branch = sar20[sample_start:sample_end]
    checks.append(check(
        "sar20_debug_sample(runPath,id)" in sample_branch
        and "sar20_dashboard('sample',D)" in sample_branch
        and "behavior_single_guard" not in sample_branch
        and "sample_view.mat" in sample_branch,
        "archive_only_sample_view",
        "sample reads saved data, writes derived view outside source run, and does not invoke live physical guard",
    ))
    checks.append(check(
        "sar20_debug_compare(runA,runB,sampleID)" in sar20
        and "sar20_dashboard('compare',report)" in sar20,
        "saved_run_compare_route",
        "compare delegates to the read-only saved-run helper and dashboard",
    ))
    checks.append(check(
        "sar20_debug_result_registry" in sar20 and "run_path" in results
        and "configuration_summary" in results,
        "registered_local_results",
        "results indexes bounded summary.json records and exposes run identity/config summaries",
    ))
    checks.append(check(
        "Simulink.ID.getFullName([model ':' sid])" in navigation
        and "eval(" not in navigation
        and "M.model.model_sha256" in navigation
        and "refresh" in sar20,
        "verified_sid_focus_and_apply_rebind",
        "only numeric SIDs from a baseline-bound manifest resolve inside SarAdc; no eval",
    ))
    checks.append(check(
        "'pending',true" in sar20 and "model_saved_navigation_pending" in sar20
        and "apply_transaction.json" in sar20,
        "interrupted_apply_recovery_marker",
        "apply persists atomic stages; home exposes pending/dirty state and resume checks model P/DecodeP plus SID identity",
    ))
    checks.append(check(
        "detailedText=note" in note and "note=compact_text(P)" in note
        and "SAR20(''home'')" in note,
        "short_model_note_with_full_detail",
        "existing note validations remain; final block annotation is compact and report retains detailed text",
    ))
    for rel in ENTRY_HELPERS:
        checks.append(check((CANDIDATE / rel).is_file(), "helper_present", rel))

    result = {
        "schema": "sar20-entry-static-check/v1",
        "candidate_root": str(CANDIDATE),
        "production_root": str(PRODUCTION),
        "matlab_or_simulink_started": False,
        "candidate_model_sha256": sha(CANDIDATE / "current/models/SarAdc.slx"),
        "production_entry_sha256": sha(PRODUCTION / "SAR20.m"),
        "candidate_entry_sha256": sha(CANDIDATE / "SAR20.m"),
        "candidate_note_sha256": sha(CANDIDATE / "current/src/model/behavior_applied_note.m"),
        "checks": checks,
        "status": "pass",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
