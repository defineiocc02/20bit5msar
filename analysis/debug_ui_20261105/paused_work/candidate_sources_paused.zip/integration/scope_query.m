% SCOPE_QUERY v1: original GUI, current baseline, read-only SATK scope/parameter query.
disp(jsonencode(query_scopes()));
function r=query_scopes()
    job='D:/Temp/SAR20DEBUG_UI_20261105';
    root='D:/Academic/Projects/sar20m1/SAR20';
    tools=fullfile(root,'dependencies','toolkit','tools');
    out=fullfile(job,'scope_query');assert(~isfolder(out));mkdir(out);
    assert(feature('getpid')==27628&&usejava('desktop'),'debugQuery:pid','Original GUI required.');
    oldPath=path;oldCwd=pwd;beforeRng=rng;
    restore=onCleanup(@()restore_environment(oldPath,oldCwd)); %#ok<NASGU>
    addpath(fullfile(tools,'common'),fullfile(tools,'common','autolayout'), ...
        fullfile(tools,'model_edit'),fullfile(tools,'model_read'),'-begin');
    cd(root);gate=library.settingsLookup();write_json(fullfile(out,'library_gate.json'),gate);
    assert(~gate.found,'debugQuery:library','Review custom library policy before proceeding.');
    model=fullfile(root,'current','models','SarAdc.slx');opened=false;
    if ~bdIsLoaded('SarAdc'),open_system(model);opened=true;end
    assert(strcmpi(canon(get_param('SarAdc','FileName')),canon(model))&& ...
        strcmp(get_param('SarAdc','SimulationStatus'),'stopped')&& ...
        strcmp(get_param('SarAdc','Dirty'),'off'),'debugQuery:owner','Require clean stopped current graph.');
    ws=get_param('SarAdc','ModelWorkspace');P=getVariable(ws,'P');D=getVariable(ws,'DecodeP');
    assert(P.N==256&&P.front.single_bank&&strcmp(P.backend.az.mode,'ordinary'));
    scopes={'root','blk_105','blk_112','blk_123'};names={'root','eventstep','adc','fpga'};
    for k=1:numel(scopes)
        value=char(model_read('SarAdc',scopes{k},'1'));
        write_text(fullfile(out,[names{k} '_read.txt']),value);
    end
    properties=struct('sid',{},'name',{},'property',{},'value',{});
    for sid=[105 112 123]
        target=Simulink.ID.getFullName(['SarAdc:' num2str(sid)]);
        params=get_param(target,'ObjectParameters');keys=fieldnames(params);
        for k=1:numel(keys)
            key=keys{k};
            if ~isempty(regexpi(key,'Preview|Content|AttributesFormat|OpenFcn|ShowPort','once'))
                try,v=get_param(target,key);catch ex,v=ex.message;end
                if ischar(v)||isnumeric(v)||islogical(v)
                    properties(end+1)=struct('sid',sid,'name',get_param(target,'Name'), ...
                        'property',key,'value',v); %#ok<AGROW>
                end
            end
        end
    end
    write_json(fullfile(out,'display_properties.json'),properties);
    assert(isequaln(P,getVariable(ws,'P'))&&isequaln(D,getVariable(ws,'DecodeP'))&& ...
        strcmp(get_param('SarAdc','Dirty'),'off')&&isequaln(beforeRng,rng), ...
        'debugQuery:unchanged','Query changed model/configuration/RNG.');
    r=struct('status','READ_ONLY_QUERY_PASS','pid',feature('getpid'),'opened_model',opened, ...
        'N',P.N,'output',out,'model_unchanged',true,'global_rng_unchanged',true);
    write_json(fullfile(out,'receipt.json'),r);
end
function restore_environment(p,c),path(p);cd(c);end
function p=canon(p),p=strrep(char(java.io.File(p).getCanonicalPath()),'\','/');end
function write_json(file,v),write_text(file,jsonencode(v));end
function write_text(file,t)
    f=fopen(file,'w','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    fprintf(f,'%s\n',t);
end
