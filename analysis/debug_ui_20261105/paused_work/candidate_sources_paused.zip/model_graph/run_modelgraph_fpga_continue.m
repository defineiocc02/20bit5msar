function receipt = run_modelgraph_fpga_continue(projectRoot, privateCheckpointPath, expectedCheckpointSha, varargin)
%RUN_MODELGRAPH_FPGA_CONTINUE Resume only FPGA D1/D2/DT wrapping from a private checkpoint.
% This is intentionally NOT a full-stage restart. It requires the actual private
% checkpoint path and its exact SHA from the root-owned classification job. It
% preserves the already-created PhysicalView/preview state and edits only Fpga.
%
% Usage on Windows MATLAB R2024a (root-owned execution):
%   r = run_modelgraph_fpga_continue(projectRoot, checkpointPath, checkpointSha)
%
% This runner never configures ContentPreviewEnabled, never recreates the PhysicalView,
% never deletes/reorders classification cards, and never simulates. The sole writes
% are ModelEdit D1/D2/DT virtual wrappers/wires/deletion of original FPGA arithmetic
% nodes, then a cold-open model update compile. All other stage data remain intact.

p=inputParser;
addParameter(p,'ColdOpenCompile',true,@(x)islogical(x)&&isscalar(x));
addParameter(p,'KeepModelOpen',true,@(x)islogical(x)&&isscalar(x));
parse(p,varargin{:}); opt=p.Results;
projectRoot=char(projectRoot); privateCheckpointPath=char(privateCheckpointPath);
expectedCheckpointSha=char(expectedCheckpointSha);
lockedBaseline='91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e';
if ~isfile(privateCheckpointPath),error('sar20:fpgaContinue:CheckpointMissing','Missing private checkpoint: %s',privateCheckpointPath);end
if startsWith(lower(canonical(privateCheckpointPath)),lower(canonical(projectRoot)))
    error('sar20:fpgaContinue:ProductionBoundary','Checkpoint path must remain outside the SAR20 project root.');
end

oldPath=path; pathCleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
toolRoot=fullfile(projectRoot,'dependencies','toolkit','tools');
paths={fullfile(toolRoot,'common'),fullfile(toolRoot,'common','autolayout'), ...
    fullfile(toolRoot,'model_read'),fullfile(toolRoot,'model_edit'),fullfile(toolRoot,'model_check')};
for k=1:numel(paths),if ~isfolder(paths{k}),error('sar20:fpgaContinue:Toolkit','Missing SATK directory %s.',paths{k});end,end
addpath(paths{:}); addpath(genpath(fullfile(projectRoot,'current','src')));
% Library/policy gate is the first SATK action.
gate=library.settingsLookup();
if gate.found&&~gate.gatePass,error('sar20:fpgaContinue:Gate','settingsLookup gatePass=false.');end
if gate.found&&gate.gatePass, kgIndexText=fileread(gate.kgIndexPath); %#ok<NASGU>
end

inputSha=sha256(privateCheckpointPath);
if isempty(expectedCheckpointSha)||~strcmpi(inputSha,expectedCheckpointSha)
    error('sar20:fpgaContinue:CheckpointSha','Expected checkpoint SHA %s, got %s.',expectedCheckpointSha,inputSha);
end
sourceModel=fullfile(projectRoot,'current','models','SarAdc.slx');
if ~isfile(sourceModel)||~strcmpi(sha256(sourceModel),lockedBaseline)
    error('sar20:fpgaContinue:SourceBaseline','Project source is not the locked 9197 baseline.');
end
scriptRoot=fileparts(mfilename('fullpath')); generatedRoot=fullfile(scriptRoot,'generated');
sourceInventory=jsondecode(fileread(fullfile(generatedRoot,'source_inventory.json')));
fpgaSpec=jsondecode(fileread(fullfile(generatedRoot,'fpga_stage1_spec.json')));
if ~strcmpi(sourceInventory.baseline_sha256,lockedBaseline)||~strcmpi(fpgaSpec.baseline_sha256,lockedBaseline)
    error('sar20:fpgaContinue:SpecBaseline','Generated source spec does not match 9197.');
end
groups=load_fpga_stage1_groups(fpgaSpec);

workDir=fileparts(privateCheckpointPath); receiptDir=fullfile(workDir,'receipts');
if ~isfolder(receiptDir),mkdir(receiptDir);end
backupPath=fullfile(receiptDir,['before_fpga_' inputSha '.slx']);
if ~isfile(backupPath),[ok,msg]=copyfile(privateCheckpointPath,backupPath);if ~ok,error('sar20:fpgaContinue:Backup','%s',msg);end,end
if ~strcmpi(sha256(backupPath),inputSha),error('sar20:fpgaContinue:BackupSha','Private backup hash mismatch.');end

model='SarAdc'; loaded=find_system('Type','block_diagram','Name',model);
if isempty(loaded),open_system(privateCheckpointPath);
elseif ~strcmpi(canonical(get_param(model,'FileName')),canonical(privateCheckpointPath))
    error('sar20:fpgaContinue:LoadedElsewhere','SarAdc is loaded from a different file; do not close it automatically.');
end
if ~bdIsLoaded(model)||~strcmpi(canonical(get_param(model,'FileName')),canonical(privateCheckpointPath))
    error('sar20:fpgaContinue:OpenCheckpoint','Active model is not the supplied private checkpoint.');
end
receipt=struct('schema_version','sar20-fpga-continuation-receipt/v1', ...
    'status','running','baseline_sha256',lockedBaseline,'input_checkpoint_sha256',inputSha, ...
    'private_checkpoint_path',privateCheckpointPath,'backup_path',backupPath, ...
    'backup_sha256',inputSha,'settings_lookup',gate,'content_preview_modified',false, ...
    'physical_view_modified',false,'simulation_run',false,'scope_receipts',{{}});
writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);

try
    rootBefore=readScope(model,'root');
    eventId=findId(rootBefore,'EventStep');
    eventBefore=readScope(model,eventId);
    fpgaId=findId(eventBefore,'Fpga');
    physicalId=findId(eventBefore,'PhysicalView');
    cardRead=readScope(model,physicalId);
    cardRows=parseRows(cardRead);
    cardRows=cardRows(strcmp({cardRows.block_type},'SubSystem'));
    if numel(cardRows)~=8
        error('sar20:fpgaContinue:PhysicalViewCardCount','Expected 8 existing portless classification cards; found %d. Nothing changed.',numel(cardRows));
    end
    for k=1:numel(cardRows)
        cardPath=pathById(model,cardRows(k).id);
        cardPorts=get_param(cardPath,'Ports');
        if any(cardPorts(:)~=0)
            error('sar20:fpgaContinue:PhysicalViewPorts','Existing card %s is not portless. Nothing changed.',cardRows(k).name);
        end
        cardRead=readScope(model,cardRows(k).id);
        if ~isempty(parseRows(cardRead))
            error('sar20:fpgaContinue:PhysicalViewComputes','Existing card %s contains internal blocks; refusing to claim it is navigation-only.',cardRows(k).name);
        end
    end
    % Read and preserve preview state; this continuation never writes the
    % display-only ContentPreviewEnabled property or the classification cards.
    eventPath=pathById(model,eventId);
    previewState=struct('EventStep',get_param(eventPath,'ContentPreviewEnabled'));
    adcId=findId(eventBefore,'Adc'); fpgaPath=pathById(model,fpgaId); adcPath=pathById(model,adcId);
    previewState.Adc=get_param(adcPath,'ContentPreviewEnabled');
    previewState.Fpga=get_param(fpgaPath,'ContentPreviewEnabled');
    if ~strcmp(char(previewState.EventStep),'off')
        error('sar20:fpgaContinue:ClassificationPreview','Checkpoint EventStep preview is not off; do not change classification here.');
    end

    fpgaBefore=readScope(model,fpgaId);
    required={'Raw','RawReady','TrainRef','code20','d1_v','d2_v','dt_v','RawFields','PublicPol', ...
        'D1PlusD2','PlusTracking','PlusDither','Counts','UnsignedMidpoint','RoundCode','SaturateCode','Calibration'};
    for k=1:numel(required), assertName(fpgaBefore,required{k}); end
    for k=1:numel(groups)
        if hasName(fpgaBefore,groups(k).wrapper)
            error('sar20:fpgaContinue:WrapperExists','%s already exists in checkpoint. Stop; inspect this exact hash instead of creating duplicates.',groups(k).wrapper);
        end
    end
    oldNative=verifyOriginalFpgaParams(model,fpgaBefore,sourceInventory,groups);

    % Create the three wrappers in one parent-scope SATK call. No input/output
    % path is rewired until all child networks have been populated and checked.
    createOps=cell(1,numel(groups));
    for k=1:numel(groups)
        createOps{k}=struct('op','create_subsystem','name',groups(k).wrapper, ...
            'ref',groups(k).ref,'interface',struct('inputs',{groups(k).inputs},'outputs',{groups(k).outputs}));
    end
    runEditScope(model,fpgaId,'fpga_create_three_wrappers',createOps,'incremental', ...
        privateCheckpointPath,receiptDir,receipt);
    fpgaAfterCreate=readScope(model,fpgaId); wrapperIds=struct();
    for k=1:numel(groups), wrapperIds.(groups(k).key_field)=findId(fpgaAfterCreate,groups(k).wrapper); end

    for k=1:numel(groups)
        g=groups(k); childId=wrapperIds.(g.key_field); childBefore=readScope(model,childId);
        inputs=cell(1,numel(g.inputs)); outputs=cell(1,numel(g.outputs));
        for q=1:numel(g.inputs),inputs{q}=findId(childBefore,g.inputs{q});end
        for q=1:numel(g.outputs),outputs{q}=findId(childBefore,g.outputs{q});end
        ops=makePopulateOps(g,oldNative.(g.key_field),inputs,outputs);
        runEditScope(model,childId,['fpga_populate_' g.key_field],ops,'full', ...
            privateCheckpointPath,receiptDir,receipt);
        childAfter=readScope(model,childId);
        verifyChildParams(model,childAfter,oldNative.(g.key_field),g);
        receipt.scope_receipts{end+1}=struct('name',['fpga_populate_' g.key_field], ...
            'scope_id',childId,'internal_wires',verify_modelgraph_child_topology(model,childAfter,g,inputs,outputs)); %#ok<AGROW>
        save_system(model); writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
    end

    % Connect each wrapper to the exact original source/output pins, then remove
    % those original blocks. All operations remain within the Fpga parent scope.
    fpgaBeforeReplace=readScope(model,fpgaId); parentOps={};
    for k=1:numel(groups)
        g=groups(k); wrapper=findId(fpgaBeforeReplace,g.wrapper);
        for q=1:numel(g.parent_inputs)
            src=findId(fpgaBeforeReplace,g.parent_inputs{q});
            parentOps{end+1}=struct('op','connect','target',[src '.y' num2str(g.parent_input_ports(q)) ' -> ' wrapper '.u' num2str(q)]); %#ok<AGROW>
        end
        for q=1:numel(g.parent_outputs)
            dst=findId(fpgaBeforeReplace,g.parent_outputs{q});
            parentOps{end+1}=struct('op','connect','target',[wrapper '.y1 -> ' dst '.u' num2str(g.parent_output_ports(q))]); %#ok<AGROW>
        end
        for q=1:numel(g.nodes)
            oldId=findId(fpgaBeforeReplace,g.nodes{q});
            parentOps{end+1}=struct('op','delete','target',oldId); %#ok<AGROW>
        end
        parentOps{end+1}=struct('op','configure','target',wrapper, ...
            'params',struct('AttributesFormatString',g.display_text)); %#ok<AGROW>
    end
    runEditScope(model,fpgaId,'fpga_wire_replacements_delete_original_nodes', ...
        parentOps,'incremental',privateCheckpointPath,receiptDir,receipt);
    fpgaFinal=readScope(model,fpgaId);
    for k=1:numel(groups)
        assertName(fpgaFinal,groups(k).wrapper);
        for q=1:numel(groups(k).nodes)
            if hasName(fpgaFinal,groups(k).nodes{q})
                error('sar20:fpgaContinue:OldNodeRemains','Old D1/D2/DT node remains: %s.',groups(k).nodes{q});
            end
        end
    end
    parentEdges=verify_modelgraph_parent_topology(model,fpgaFinal,groups);
    receipt.parent_edges=parentEdges; receipt.final_fpga_model_read=fpgaFinal;
    receipt.preview_state_before=previewState;
    receipt.wrapper_old_to_new=oldToNewMap(model,fpgaBefore,fpgaFinal,groups);
    wrapperPreviewIds=cell(1,numel(groups));
    for k=1:numel(groups),wrapperPreviewIds{k}=findId(fpgaFinal,groups(k).wrapper);end
    setNewWrapperPreviewsOff(model,privateCheckpointPath,fpgaId,wrapperPreviewIds,receiptDir,receipt);
    save_system(model);

    if opt.ColdOpenCompile
        shaBefore=sha256(privateCheckpointPath); close_system(model,0); open_system(privateCheckpointPath);
        set_param(model,'SimulationCommand','update');
        if ~strcmp(get_param(model,'SimulationStatus'),'stopped')
            error('sar20:fpgaContinue:SimulationUnexpected','Model update started a simulation.');
        end
        save_system(model); receipt.cold_open_compile=struct('method','save/close/open/SimulationCommand=update/save', ...
            'sha_before',shaBefore,'sha_after',sha256(privateCheckpointPath),'simulation_started',false);
    end
    receipt.status='fpga_wrappers_saved'; receipt.output_sha256=sha256(privateCheckpointPath);
    writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
    if ~opt.KeepModelOpen&&bdIsLoaded(model),close_system(model,0);end
catch cause
    try
        save_system(model);
        partial=savePrivateSnapshot(privateCheckpointPath,receiptDir,'fpga_continue_failure');
        receipt.status='partial_private_saved'; receipt.partial_snapshot=partial;
    catch saveCause
        receipt.status='partial_not_persisted'; receipt.save_error=getReport(saveCause,'extended','hyperlinks','off');
    end
    receipt.error=getReport(cause,'extended','hyperlinks','off');
    writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
    rethrow(cause);
end
end

function oldNative=verifyOriginalFpgaParams(model,fpgaRead,sourceInventory,groups)
oldNative=struct(); xmlBlocks=sourceInventory.systems.fpga.blocks;
for g=1:numel(groups)
    bundle=struct();
    for k=1:numel(groups(g).nodes)
        nm=groups(g).nodes{k}; spec=xmlBlocks(strcmp({xmlBlocks.name},nm));
        id=findId(fpgaRead,nm); pth=pathById(model,id); type=get_param(pth,'BlockType');
        if ~strcmp(type,spec.block_type),error('sar20:fpgaContinue:BlockType','%s type differs from 9197.',nm);end
        expected=spec.parameters; keys=fieldnames(expected); dialog=get_param(pth,'DialogParameters'); dialogNames=fieldnames(dialog); vals=struct();
        for q=1:numel(keys)
            key=keys{q}; if ~any(strcmp(dialogNames,key)),error('sar20:fpgaContinue:ParamUnavailable','Dialog lacks %s.%s.',nm,key);end
            actual=get_param(pth,key);
            if ~strcmp(canonicalParam(actual),canonicalParam(expected.(key)))
                error('sar20:fpgaContinue:ParamMismatch','%s.%s differs from baseline.',nm,key);
            end
            vals.(key)=editParamValue(actual);
        end
        bundle.(matlab.lang.makeValidName(nm))=struct('name',nm,'block_type',type, ...
            'source_id',id,'source_path',pth,'dialog_parameters',dialog,'explicit_params',vals);
    end
    oldNative.(groups(g).key_field)=bundle;
end
end

function ops=makePopulateOps(g,native,inputIds,outputIds)
ops={}; refs=struct();
for k=1:numel(g.nodes)
    nm=g.nodes{k}; src=native.(matlab.lang.makeValidName(nm)); ref=['r_' regexprep(nm,'[^A-Za-z0-9]','_')];
    refs.(matlab.lang.makeValidName(nm))=ref;
    op=struct('op','add_block','type',src.block_type,'name',nm,'ref',ref);
    if ~isempty(fieldnames(src.explicit_params)),op.params=src.explicit_params;end
    ops{end+1}=op; %#ok<AGROW>
end
for k=1:numel(g.edges)
    parts=split(string(g.edges{k}),'>'); s=char(parts(1)); d=char(parts(2));
    ops{end+1}=struct('op','connect','target',[endpoint(s,'source') ' -> ' endpoint(d,'destination')]); %#ok<AGROW>
end
    function e=endpoint(label,role)
        if any(strcmp(g.inputs,label)), i=find(strcmp(g.inputs,label),1);e=[inputIds{i} '.y1'];return;end
        if any(strcmp(g.outputs,label)), i=find(strcmp(g.outputs,label),1);e=[outputIds{i} '.u1'];return;end
        p=split(string(label),'.');name=char(p(1));port=char(p(2));e=['#' refs.(matlab.lang.makeValidName(name)) '.' port];
    end
end

function verifyChildParams(model,readText,native,g)
ignore={'Position','Orientation','FontSize','FontName','ForegroundColor','BackgroundColor','ShowName','ShowPortLabels','DropShadow','ZOrder'};
for k=1:numel(g.nodes)
    nm=g.nodes{k}; old=native.(matlab.lang.makeValidName(nm)); newId=findId(readText,nm); newPath=pathById(model,newId);
    if ~strcmp(get_param(newPath,'BlockType'),old.block_type),error('sar20:fpgaContinue:NewType','New block type mismatch %s.',nm);end
    newDlg=get_param(newPath,'DialogParameters'); newNames=fieldnames(newDlg); oldNames=fieldnames(old.dialog_parameters);
    for q=1:numel(oldNames)
        key=oldNames{q}; if any(strcmp(ignore,key)),continue;end
        if ~any(strcmp(newNames,key)),error('sar20:fpgaContinue:NewParam','New %s missing dialog field %s.',nm,key);end
        a=get_param(old.source_path,key); b=get_param(newPath,key);
        if ~strcmp(canonicalParam(a),canonicalParam(b)),error('sar20:fpgaContinue:ParamReadback','New %s.%s differs from source.',nm,key);end
    end
end
end

function setNewWrapperPreviewsOff(model,checkpointPath,fpgaScope,wrapperIds,receiptDir,receipt)
% SDK exception whitelist: display-only ContentPreviewEnabled on private wrappers.
if ~strcmpi(canonical(get_param(model,'FileName')),canonical(checkpointPath))
    error('sar20:fpgaContinue:PreviewBoundary','Preview style must stay on the private checkpoint.');
end
before=readScope(model,fpgaScope);
for k=1:numel(wrapperIds)
    pth=pathById(model,wrapperIds{k});
    current=char(get_param(pth,'ContentPreviewEnabled'));
    if ~strcmp(current,'off')
        try
            set_param(pth,'ContentPreviewEnabled','off');
        catch cause
            partialStop(model,checkpointPath,fpgaScope,'wrapper_preview_display_only', ...
                getReport(cause,'extended','hyperlinks','off'),before,receiptDir,receipt);
        end
    end
    if ~strcmp(char(get_param(pth,'ContentPreviewEnabled')),'off')
        partialStop(model,checkpointPath,fpgaScope,'wrapper_preview_native_readback', ...
            'New wrapper ContentPreviewEnabled did not read back off.',before,receiptDir,receipt);
    end
end
after=readScope(model,fpgaScope);
check=char(model_check(model,fpgaScope,'["unconnected_ports","unconnected_lines"]'));
if contains(check,'status: has_errors')||contains(check,'severity: error')
    partialStop(model,checkpointPath,fpgaScope,'wrapper_preview_check', ...
        'Display-only preview update changed model_check status.',before,receiptDir,receipt,after,check);
end
receipt.wrapper_preview_display_only=struct('property','ContentPreviewEnabled','value','off', ...
    'scope',fpgaScope,'model_read_after',after,'model_check',check);
writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
end

function m=oldToNewMap(model,before,after,groups)
m={};
for g=1:numel(groups)
    wrapperId=findId(after,groups(g).wrapper);
    wrapperRead=readScope(model,wrapperId);
    for k=1:numel(groups(g).nodes)
        name=groups(g).nodes{k}; oldId=findId(before,name); newId=findId(wrapperRead,name);
        m{end+1}=struct('old_name',name,'old_sid',sid(oldId),'replacement_wrapper',groups(g).wrapper, ...
            'wrapper_sid',sid(wrapperId),'replacement_sid',sid(newId)); %#ok<AGROW>
    end
end
end

function runEditScope(model,scope,label,ops,layout,pathName,receiptDir,receipt)
before=readScope(model,scope); response=char(model_edit(model,scope,jsonencode(ops),layout));
first=strtrim(extractBefore(string(response)+newline,newline));
if startsWith(first,'status: partial')||startsWith(first,'status: error')||startsWith(first,'status: failed')
    partialStop(model,pathName,scope,label,response,before,receiptDir,receipt);
end
after=readScope(model,scope); check=char(model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));
if contains(check,'status: has_errors')||contains(check,'severity: error')
    partialStop(model,pathName,scope,[label '_model_check'],response,before,receiptDir,receipt,after,check);
end
receipt.scope_receipts{end+1}=struct('name',label,'scope',scope,'model_read_before',before, ...
    'model_edit',response,'model_read_after',after,'model_check',check); %#ok<AGROW>
writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
end

function partialStop(model,pathName,scope,label,response,before,receiptDir,receipt,varargin)
saveError='';try,save_system(model);catch e,saveError=getReport(e,'extended','hyperlinks','off');end
if isempty(saveError), snap=savePrivateSnapshot(pathName,receiptDir,[label '_partial']);
else, snap=struct('status','not_saved','path','','sha256','','save_error',saveError);end
try,after=readScope(model,scope);catch e,after=getReport(e,'extended','hyperlinks','off');end
try,check=char(model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));catch e,check=getReport(e,'extended','hyperlinks','off');end
receipt.status=ternary(isempty(saveError),'partial_private_saved','partial_not_persisted');
receipt.partial_snapshot=snap; receipt.partial_scope=struct('label',label,'scope',scope, ...
    'before',before,'model_edit',response,'after',after,'check',check);
writeJson(fullfile(receiptDir,'fpga_continue_receipt.json'),receipt);
if isempty(saveError),error('sar20:fpgaContinue:Partial','%s stopped; private SHA %s.',label,snap.sha256);
else,error('sar20:fpgaContinue:NotPersisted','%s stopped and could not save private partial: %s',label,saveError);end
end

function pathName=pathById(model,id)
pathName=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
function id=findId(report,name)
lines=splitlines(string(report)); cur=''; hits={};
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t),cur=t{1};continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(cur),hits{end+1}=cur;cur='';end %#ok<AGROW>
end
hits=unique(hits,'stable');if numel(hits)~=1,error('sar20:fpgaContinue:Resolve','Expected one fresh ID for %s, got %d.',name,numel(hits));end
id=hits{1};
end
function rows=parseRows(report)
lines=splitlines(string(report));rows=struct('id',{},'name',{},'block_type',{});cur=[];
for k=1:numel(lines)
    line=char(lines(k));t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t)
        if ~isempty(cur)&&isfield(cur,'id')&&isfield(cur,'name'),rows(end+1)=cur;end %#ok<AGROW>
        cur=struct('id',t{1},'name','','block_type','');continue
    end
    if isempty(cur),continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');if ~isempty(t),cur.name=strtrim(t{1});continue;end
    t=regexp(line,'^\s*BlockType:\s*(.*?)\s*$','tokens','once');if ~isempty(t),cur.block_type=strtrim(t{1});end
end
if ~isempty(cur)&&isfield(cur,'id')&&isfield(cur,'name'),rows(end+1)=cur;end
end
function r=readScope(model,scope)
r=char(model_read(model,scope,'0'));
if ~startsWith(strtrim(r),'status: ok')&&~startsWith(strtrim(r),'status: success'),error('sar20:fpgaContinue:Read','model_read failed: %s',r);end
end
function assertName(report,name)
if ~hasName(report,name),error('sar20:fpgaContinue:MissingName','Required block %s is missing.',name);end
end
function tf=hasName(report,name)
pat=['(?m)^\s*Name:\s*' regexptranslate('escape',name) '\s*$'];tf=~isempty(regexp(char(report),pat,'once'));
end
function s=sid(id),s=char(extractAfter(string(id),'blk_'));end
function v=canonicalParam(x)
if ischar(x),v=strtrim(x);elseif isstring(x),v=strtrim(char(x));elseif isnumeric(x)||islogical(x),v=mat2str(x,17);else,try,v=jsonencode(x);catch,v=char(string(x));end,end
v=regexprep(v,'\s+','');
end
function v=editParamValue(x)
if ischar(x),v=x;elseif isstring(x),v=char(x);elseif isnumeric(x)||islogical(x),v=mat2str(x,17);else,try,v=char(jsonencode(x));catch,v=char(string(x));end,end
end
function v=ternary(test,a,b),if test,v=a;else,v=b;end,end
function p=canonical(p)
try,p=char(java.io.File(char(p)).getCanonicalPath());catch,p=char(p);end
end
function h=sha256(p)
f=fopen(p,'rb');if f<0,error('sar20:fpgaContinue:Hash','Cannot read %s.',p);end
cl=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');while true,x=fread(f,1024*1024,'*uint8');if isempty(x),break;end;md.update(x);end
b=typecast(md.digest(),'uint8');h=lower(reshape(dec2hex(b,2).',1,[]));
end
function s=savePrivateSnapshot(pathName,receiptDir,label)
p=fullfile(receiptDir,[regexprep(label,'[^A-Za-z0-9]','_') '_' datestr(now,'yyyymmddTHHMMSS') '.slx']);
[ok,msg]=copyfile(pathName,p,'f');if ~ok,error('sar20:fpgaContinue:Snapshot','%s',msg);end
s=struct('path',p,'sha256',sha256(p),'candidate_sha256',sha256(pathName));
if ~strcmpi(s.sha256,s.candidate_sha256),error('sar20:fpgaContinue:SnapshotHash','Partial snapshot SHA mismatch.');end
end
function writeJson(pathName,v)
f=fopen(pathName,'w','n','UTF-8');if f<0,error('sar20:fpgaContinue:Receipt','Cannot write %s.',pathName);end
cl=onCleanup(@()fclose(f)); %#ok<NASGU>
fwrite(f,jsonencode(v,'PrettyPrint',true),'char');fwrite(f,newline,'char');
end
