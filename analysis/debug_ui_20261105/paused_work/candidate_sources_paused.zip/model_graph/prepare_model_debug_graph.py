#!/usr/bin/env python3
"""Read-only SAR20 9197 SLX inventory and temp driver-manifest generator.

This script reads the current baseline SLX ZIP/XML only. It never invokes MATLAB,
never writes to the project/artifact tree, and writes generated manifests only to
--out (default /tmp/sar20_model_debug_graph_luna/generated).
"""
from __future__ import annotations
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

BASELINE_SHA256 = "91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e"
DEFAULT_SLX = Path("/Users/zhaoyi/Obsidan/项目库产物文件夹/sar20_5_simulink_20261020/current/models/SarAdc.slx")
DEFAULT_OUT = Path("/tmp/sar20_model_debug_graph_luna/generated")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def props(elem):
    return {p.attrib.get("Name"): (p.text or "").strip() for p in elem.findall("P") if p.attrib.get("Name")}


def flatten_line(line):
    p = props(line)
    src = p.get("Src")
    name = p.get("Name", "")
    out = []
    if p.get("Dst"):
        out.append({"src": src, "dst": p["Dst"], "signal_name": name})
    def descend(branch):
        bp = props(branch)
        if bp.get("Dst"):
            out.append({"src": src, "dst": bp["Dst"], "signal_name": name})
        for child in branch.findall("Branch"):
            descend(child)
    for branch in line.findall("Branch"):
        descend(branch)
    return out


def system_inventory(zf, entry, parent_path):
    root = ET.fromstring(zf.read(entry))
    records = []
    edges = []
    for b in root.findall("Block"):
        p = props(b)
        ref = b.find("System")
        pc = b.find("PortCounts")
        records.append({
            "sid": b.attrib.get("SID"),
            "model_edit_id": "blk_" + b.attrib.get("SID", ""),
            "name": b.attrib.get("Name"),
            "path_from_model": parent_path + "/" + b.attrib.get("Name", ""),
            "block_type": b.attrib.get("BlockType"),
            "system_ref": ref.attrib.get("Ref") if ref is not None else None,
            "ports": dict(pc.attrib) if pc is not None else {},
            "parameters": {k: v for k, v in p.items() if k not in {"Position", "ZOrder"}},
        })
    for line in root.findall("Line"):
        edges.extend(flatten_line(line))
    return {"entry": entry, "system_parameters": props(root), "blocks": records, "connections": edges}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slx", type=Path, default=DEFAULT_SLX)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    slx = args.slx.expanduser().resolve()
    out = args.out.expanduser().resolve()
    actual = sha256(slx)
    if actual != BASELINE_SHA256:
        raise SystemExit(f"拒绝生成：输入SHA256不等于锁定9197基线：{actual}")
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(slx, "r") as zf:
        root = system_inventory(zf, "simulink/systems/system_root.xml", "SarAdc")
        event = system_inventory(zf, "simulink/systems/system_105.xml", "SarAdc/EventStep")
        adc = system_inventory(zf, "simulink/systems/system_112.xml", "SarAdc/EventStep/Adc")
        fpga = system_inventory(zf, "simulink/systems/system_123.xml", "SarAdc/EventStep/Fpga")
        # The SLX relationship map records the child system IDs; this confirms the
        # hierarchy without using native MATLAB/model_read or modifying the model.
        blockdiagram = ET.fromstring(zf.read("simulink/blockdiagram.xml"))
        blockdiagram_props = props(blockdiagram)

    source = {
        "evidence_type": "read_only_embedded_slx_xml_inventory",
        "slx_path": str(slx),
        "baseline_sha256": actual,
        "model_name": "SarAdc",
        "systems": {"root": root, "event_step": event, "adc": adc, "fpga": fpga},
        "blockdiagram_parameters": blockdiagram_props,
        "limits": [
            "Static XML inventory only; no MATLAB settingsLookup/model_read/model_check was run.",
            "Block and line identities must be re-confirmed by root's fresh model_read before model_edit.",
            "No behavioral equivalence, solver behavior, simulation, or signoff claim is made."
        ],
    }
    (out / "source_inventory.json").write_text(json.dumps(source, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    fpga_nodes = {
        "d1": ["D1TwiceRaw", "D1CoarseDivide", "D1CoarseFloor", "D1CoarseSubtract", "D1Units", "D1DacOffset", "D1DacVoltage", "D1CaptureBias"],
        "d2": ["D2Divide", "D2Floor", "D2UpperDivide", "D2UpperFloor", "D2UpperTwice", "D2Bits", "D2Weighted", "D2Offset", "D2InputReference", "D2Demod"],
        "dt": ["DTDivide", "DTFloor", "DTUpperDivide", "DTUpperFloor", "DTUpperTwice", "DTBits", "DTWeighted", "DTBipolarTwice", "DTBipolarOffset", "DTInputReference", "DTDemod"],
    }
    by_name = {b["name"]: b for b in fpga["blocks"]}
    names_by_sid = {b["sid"]: b["name"] for b in fpga["blocks"]}
    for group, names in fpga_nodes.items():
        missing = [n for n in names if n not in by_name]
        if missing:
            raise SystemExit(f"9197 FPGA XML missing required {group} nodes: {missing}")
    def node_records(names):
        return [by_name[n] for n in names]
    def edges_for_nodes(names):
        sids = {by_name[n]["sid"] for n in names}
        return [e for e in fpga["connections"] if e["src"].split("#", 1)[0] in sids or e["dst"].split("#", 1)[0] in sids]

    fpga_plan = {
        "evidence": {"baseline_sha256": actual, "source_entry": "simulink/systems/system_123.xml", "scope_sid": "123", "scope_model_edit_id": "blk_123"},
        "model_edit_capability": {
            "operations_from_installed_registry": ["add_block", "connect", "disconnect", "configure", "delete", "replace_block", "create_subsystem"],
            "move_or_encapsulate_supported": False,
            "plan": "Create three new virtual subsystems, reconstruct only the existing standard arithmetic nodes with copied original params and explicit wiring, replace each old node group's outgoing links, verify readback, then delete old nodes. Never use native Simulink structure APIs to bypass model_edit. No simulation while a duplicate working copy exists; do not publish partial intermediate model."
        },
        "ports": {
            "inports": [{"sid": b["sid"], "name": b["name"], "width": b["parameters"].get("PortDimensions")} for b in fpga["blocks"] if b["block_type"] == "Inport"],
            "outports": [{"sid": b["sid"], "name": b["name"], "width": b["parameters"].get("PortDimensions")} for b in fpga["blocks"] if b["block_type"] == "Outport"],
            "enable_port": {"sid": "392", "name": "FpgaRun"},
        },
        "groups": {
            "digital:d1": {
                "proposed_name": "D1Decode",
                "interface": {"inputs": [{"name": "RawD1", "width": 1}], "outputs": [{"name": "d1_v", "width": 1}]},
                "input_edges": ["blk_177.y1 -> D1Decode.u1"],
                "output_edges": ["D1Decode.y1 -> blk_128.u1", "D1Decode.y1 -> blk_194.u1"],
                "original_nodes": node_records(fpga_nodes["d1"]),
                "original_internal_connections": edges_for_nodes(fpga_nodes["d1"]),
                "external_semantics": ["RawFields.y1 is the scalar raw D1 word.", "D1CaptureBias.y1 is the existing d1_v output and also D1PlusD2.u1."],
            },
            "digital:d2": {
                "proposed_name": "D2Decode",
                "interface": {"inputs": [{"name": "RawD2", "width": 1}, {"name": "PublicPol", "width": 1}], "outputs": [{"name": "d2_v", "width": 1}]},
                "input_edges": ["blk_177.y2 -> D2Decode.u1", "blk_215.y1 -> D2Decode.u2"],
                "output_edges": ["D2Decode.y1 -> blk_129.u1", "D2Decode.y1 -> blk_194.u2"],
                "original_nodes": node_records(fpga_nodes["d2"]),
                "original_internal_connections": edges_for_nodes(fpga_nodes["d2"]),
                "shared_external_dependency": {"sid": "215", "name": "PublicPol", "note": "One shared polarity generator remains outside D2/DT; the single output branches to both wrappers."},
            },
            "digital:dt": {
                "proposed_name": "DTDecode",
                "interface": {"inputs": [{"name": "RawDT", "width": 1}, {"name": "PublicPol", "width": 1}], "outputs": [{"name": "dt_v", "width": 1}]},
                "input_edges": ["blk_177.y3 -> DTDecode.u1", "blk_215.y1 -> DTDecode.u2"],
                "output_edges": ["DTDecode.y1 -> blk_130.u1", "DTDecode.y1 -> blk_195.u2"],
                "original_nodes": node_records(fpga_nodes["dt"]),
                "original_internal_connections": edges_for_nodes(fpga_nodes["dt"]),
                "shared_external_dependency": {"sid": "215", "name": "PublicPol", "note": "The same polarity source also feeds D2. Keep D1 and PublicDither outside this demodulation."},
            },
        },
        "phase1_groups": [
            {
                "key_field": "D1", "wrapper": "D1Decode", "ref": "d1decode",
                "inputs": ["RawD1"], "outputs": ["d1_v"], "nodes": fpga_nodes["d1"],
                "edges": ["RawD1>D1TwiceRaw.u1", "RawD1>D1CoarseDivide.u1", "D1CoarseDivide.y1>D1CoarseFloor.u1", "D1CoarseFloor.y1>D1CoarseSubtract.u1", "D1TwiceRaw.y1>D1Units.u1", "D1CoarseSubtract.y1>D1Units.u2", "D1Units.y1>D1DacOffset.u1", "D1DacOffset.y1>D1DacVoltage.u1", "D1DacVoltage.y1>D1CaptureBias.u1", "D1CaptureBias.y1>d1_v"],
                "parent_inputs": [{"name": "RawFields", "port": 1}],
                "parent_outputs": [{"name": "d1_v", "port": 1}, {"name": "D1PlusD2", "port": 1}],
                "display_text": "D1 digital decode | scalar d1_v | virtual, stateless wrapper"
            },
            {
                "key_field": "D2", "wrapper": "D2Decode", "ref": "d2decode",
                "inputs": ["RawD2", "PublicPol"], "outputs": ["d2_v"], "nodes": fpga_nodes["d2"],
                "edges": ["RawD2>D2Divide.u1", "RawD2>D2UpperDivide.u1", "D2Divide.y1>D2Floor.u1", "D2UpperDivide.y1>D2UpperFloor.u1", "D2UpperFloor.y1>D2UpperTwice.u1", "D2Floor.y1>D2Bits.u1", "D2UpperTwice.y1>D2Bits.u2", "D2Bits.y1>D2Weighted.u1", "D2Weighted.y1>D2Offset.u1", "D2Offset.y1>D2InputReference.u1", "D2InputReference.y1>D2Demod.u1", "PublicPol>D2Demod.u2", "D2Demod.y1>d2_v"],
                "parent_inputs": [{"name": "RawFields", "port": 2}, {"name": "PublicPol", "port": 1}],
                "parent_outputs": [{"name": "d2_v", "port": 1}, {"name": "D1PlusD2", "port": 2}],
                "display_text": "D2 digital decode | shared PublicPol input | virtual, stateless wrapper"
            },
            {
                "key_field": "DT", "wrapper": "DTDecode", "ref": "dtdecode",
                "inputs": ["RawDT", "PublicPol"], "outputs": ["dt_v"], "nodes": fpga_nodes["dt"],
                "edges": ["RawDT>DTDivide.u1", "RawDT>DTUpperDivide.u1", "DTDivide.y1>DTFloor.u1", "DTUpperDivide.y1>DTUpperFloor.u1", "DTUpperFloor.y1>DTUpperTwice.u1", "DTFloor.y1>DTBits.u1", "DTUpperTwice.y1>DTBits.u2", "DTBits.y1>DTWeighted.u1", "DTWeighted.y1>DTBipolarTwice.u1", "DTBipolarTwice.y1>DTBipolarOffset.u1", "DTBipolarOffset.y1>DTInputReference.u1", "DTInputReference.y1>DTDemod.u1", "PublicPol>DTDemod.u2", "DTDemod.y1>dt_v"],
                "parent_inputs": [{"name": "RawFields", "port": 3}, {"name": "PublicPol", "port": 1}],
                "parent_outputs": [{"name": "dt_v", "port": 1}, {"name": "PlusTracking", "port": 2}],
                "display_text": "DT tracking decode | shared PublicPol input | virtual, stateless wrapper"
            }
        ],
        "visible_dependencies_to_keep_at_fpga_scope": [
            {"sid": "177", "name": "RawFields", "role": "six-field RAW demux: D1,D2,DT,sample_id,epoch,valid"},
            {"sid": "215", "name": "PublicPol", "role": "single shared public AZ polarity for D2Demod and DTDemod"},
            {"sid": "193", "name": "PublicDither", "role": "single public input-reference dither addback"},
            {"sid": "194", "name": "D1PlusD2", "role": "first nominal voltage sum"},
            {"sid": "195", "name": "PlusTracking", "role": "add tracking term"},
            {"sid": "196", "name": "PlusDither", "role": "add dither once"},
            {"sid": "197", "name": "Counts", "role": "scale voltage by 2^20/DecodeP.fsr_diff_v"},
            {"sid": "198", "name": "UnsignedMidpoint", "role": "bias by 2^19"},
            {"sid": "199", "name": "RoundCode", "role": "existing rounding"},
            {"sid": "200", "name": "SaturateCode", "role": "clamp [0,2^20-1], feeds Calibration nominal code"},
            {"sid": "375", "name": "Calibration", "role": "existing output code path; keep interface/order unchanged"},
        ],
        "preservation_gates": [
            "Fresh model_read confirms the same old IDs/types/ports/edges before any reconstruction.",
            "Copy every original block parameter, datatype, rounding, overflow and output width exactly; if model_read/query cannot establish a value, stop that wrapper and keep partial private by SHA.",
            "The three wrappers remain virtual (non-atomic); preserve FpgaRun, original Fpga in/out port order, RawReady and TrainRef connections.",
            "Map every old SID to its replacement SID in final model_navigation.json and static diff.",
            "After new outputs are connected to both original Outports and sum inputs, delete all old nodes in that group; final model must have one implementation per D1/D2/DT chain.",
            "model_read + model_check on the FPGA scope after each completed wrapper scope; no simulation in this task."
        ]
    }
    (out / "fpga_subgraphs.json").write_text(json.dumps(fpga_plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    phase1_spec = {
        "schema_version": "sar20-fpga-virtual-subsystems/v1",
        "baseline_sha256": actual,
        "scope_sid": "123",
        "groups": fpga_plan["phase1_groups"],
    }
    (out / "fpga_stage1_spec.json").write_text(json.dumps(phase1_spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    stages = [
        {"key": "exec:sample_ra_advance", "sid": "232", "name": "SampleRaAdvance", "order": 1, "owner": ["FE353", "RA48"], "functions": ["behavior_frontend_sfun:advance", "behavior_backend_sfun:advance"]},
        {"key": "exec:dac_ct_feedback", "sid": "244", "name": "DacCtFeedback", "order": 2, "owner": ["FE353", "RA48", "SAR51"], "functions": ["behavior_frontend_sfun:commit", "behavior_backend_sfun:commit", "behavior_control_stage_sfun:due"]},
        {"key": "exec:sar1_trial_ra_ct", "sid": "261", "name": "Sar1TrialRaCt", "order": 3, "owner": ["FE353", "RA48", "SAR51"], "functions": ["behavior_frontend_sfun:commit", "behavior_control_stage_sfun:prepare", "behavior_backend_sfun:commit"]},
        {"key": "exec:residue_ct_compare", "sid": "279", "name": "ResidueCtCompare", "order": 4, "owner": ["RA48"], "functions": ["Compare1", "Compare2"]},
        {"key": "exec:sar2_tracking", "sid": "285", "name": "SarDecisionTracking", "order": 5, "owner": ["SAR51"], "functions": ["behavior_control_stage_sfun:decide"]},
        {"key": "exec:charge_return_ra_reset", "sid": "297", "name": "ChargeReturnRaReset", "order": 6, "owner": ["FE353", "RA48"], "functions": ["behavior_frontend_sfun:commit", "behavior_backend_sfun:commit"]},
    ]
    nav_keys = {
        "physical:sample_dac1": ["exec:sample_ra_advance", "exec:dac_ct_feedback", "exec:sar1_trial_ra_ct", "exec:charge_return_ra_reset", "state:FE353"],
        "physical:sar1_6b": ["exec:dac_ct_feedback", "exec:sar1_trial_ra_ct", "exec:sar2_tracking", "state:SAR51"],
        "physical:residue": ["exec:dac_ct_feedback", "exec:sar1_trial_ra_ct", "exec:sample_ra_advance", "exec:residue_ct_compare", "exec:charge_return_ra_reset", "state:FE353", "state:RA48"],
        "physical:ra_az": ["exec:sample_ra_advance", "exec:dac_ct_feedback", "exec:sar1_trial_ra_ct", "exec:charge_return_ra_reset", "state:RA48"],
        "physical:cinc_ct": ["exec:dac_ct_feedback", "exec:sar1_trial_ra_ct", "exec:residue_ct_compare", "exec:charge_return_ra_reset", "state:RA48"],
        "physical:sar2_tracking": ["exec:sar2_tracking", "state:SAR51"],
        "physical:digital": ["digital:d1", "digital:d2", "digital:dt", "digital:sum_encode", "digital:calibration", "digital:public_output"],
        "physical:lvds": ["transport:lvds"],
        "physical:observer_sample5": ["observer:sample5"],
        "state:FE353": ["148"], "state:RA48": ["149"], "state:SAR51": ["150"],
        "digital:d1": ["model_read_name:D1Decode"],
        "digital:d2": ["model_read_name:D2Decode"],
        "digital:dt": ["model_read_name:DTDecode"],
        "digital:sum_encode": ["model_read_name:D1PlusD2", "model_read_name:PlusTracking", "model_read_name:PlusDither", "model_read_name:Counts", "model_read_name:UnsignedMidpoint", "model_read_name:RoundCode", "model_read_name:SaturateCode"],
        "digital:calibration": ["model_read_name:Calibration"],
        "digital:public_output": ["model_read_name:code20", "phase2_resolve_top_level:PublicCode"],
        "transport:lvds": ["393"],
        "observer:sample5": ["pending_phase2_observer_scope"],
    }
    top_note = {
        "target": "blk_105",
        "current_baseline_value": "ContentPreviewEnabled=on",
        "runtime_evidence": "Win GUI NativeGet via Simulink.ID.getFullName('SarAdc:105') returned ContentPreviewEnabled=on; model_edit configure returned PARAM_VALUE_INVALID: Parameter ContentPreviewEnabled not found for block type SubSystem.",
        "private_display_only_operation": {"native_api": "set_param(blockPath,'ContentPreviewEnabled','off')", "scope": "private candidate only", "whitelist_property": "ContentPreviewEnabled", "structural_changes": "none", "readback_required": "NativeGet after set plus model_read/model_check"},
        "note_template_owner": "current/src/model/behavior_applied_note.m",
        "constraint": "The AttributesFormatString is regenerated from applied model-workspace P on apply; a one-off annotation edit is not persistent. Shorten that helper's visible summary only after UI keeps the full parameter page, while preserving apply/run semantics."
    }
    nav_plan = {
        "baseline_sha256": actual,
        "model_name": "SarAdc",
        "model_file": "current/models/SarAdc.slx",
        "top_preview_and_note": top_note,
        "parent_scopes": {"EventStep": {"sid": "105", "id": "blk_105"}, "Adc": {"sid": "112", "id": "blk_112"}, "Fpga": {"sid": "123", "id": "blk_123"}, "Transport": {"sid": "393", "id": "blk_393"}},
        "execution_stages": stages,
        "state_owners": [
            {"key": "state:FE353", "sid": "148", "name": "SampleCharge", "block_type": "UnitDelay", "width": 353, "sourcepoint": "current/src/frontend/behavior_frontend_pack.m::behavior_frontend_pack"},
            {"key": "state:RA48", "sid": "149", "name": "RaCtState", "block_type": "UnitDelay", "width": 48, "sourcepoint": "current/src/physics/behavior_backend_pack.m::behavior_backend_pack"},
            {"key": "state:SAR51", "sid": "150", "name": "SarState", "block_type": "UnitDelay", "width": 51, "sourcepoint": "current/src/control/behavior_sar_pack.m::behavior_sar_pack"},
        ],
        "physical_view_keys": nav_keys,
        "resolution_policy": "The stage1 digital wrapper targets are semantic names until the successful parent-scope model_read returns new SIDs. Use the driver's resolved_navigation_stage1.json or root's fresh model_read, never the old baseline Fpga SID 123 as a wrapper SID.",
        "physical_view_contract": {
            "model_level_location": "inside EventStep (it spans Adc, Fpga and Transport)",
            "navigation_only": True,
            "calculates": False,
            "cards": ["Sample & DAC1", "Coarse / SAR1 6b", "Residue", "RA & AZ", "CINC & CT", "SAR2 & Tracking", "Digital", "LVDS"],
            "phase2_card": "Observer sample5 is appended only after the trace ports, logger, and registry are frozen.",
            "card_descriptions": {
                "Sample & DAC1": "Includes input sampling, DAC1, and the 6-bit coarse/fine SAR1 preconversion/trial path.",
                "Coarse / SAR1 6b": "Dedicated navigation card for the six-bit preconversion / SAR1 trial sequence, including due, prepare and decision stages.",
                "Residue": "Qres source charge/switch readout belongs to FE353; RA48.command.qres is an interval-latch command, not the physical source charge.",
                "LVDS": "One protocol container with on-chip TX and off-chip FPGA RX; default OFF; no electrical or CDC model."
            },
            "callback": "SAR20('focus','<semantic-key>','<owner-key>')",
            "callback_rule": "Focus callbacks carry semantic keys only; dashboard resolves only numeric current-model SIDs through Simulink.ID.getFullName and validates model ownership/hash."
        },
        "state_and_time_explanation": {
            "commit": "Applies the command for the current event. Persistent state is written only through the corresponding UnitDelay input.",
            "unitdelay": "z^-1 represents the previous effective discrete event/solver execution update in this event-driven model, not a fixed analog delay and not necessarily one full Ts.",
            "shared_ra": "All RA advance/commit/reset stages target the one RaCtState UnitDelay (SID 149); navigation cards must point to that owner and must not create another RA state."
        }
    }
    (out / "navigation_semantics.json").write_text(json.dumps(nav_plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    observer_segments = [
        ("FEAdvanceTrace", 1079, "SampleRaAdvance/Sample SID322 Output3"),
        ("FEDacFeedbackTrace", 1079, "DacCtFeedback/DacFeedback SID328 Output3"),
        ("FEDacTrialTrace", 1079, "Sar1TrialRaCt/DacTrial SID332 Output3"),
        ("FEChargeReturnTrace", 1079, "ChargeReturnRaReset/ChargeReturn SID347 Output3"),
        ("BackendAdvanceTrace", 164, "SampleRaAdvance/RaAdvance SID321 Output3"),
        ("BackendCtFeedbackTrace", 164, "DacCtFeedback/CtFeedback SID327 Output3"),
        ("BackendRaAzCtTrace", 164, "Sar1TrialRaCt/RaAzCt SID334 Output3"),
        ("BackendRaResetTrace", 164, "ChargeReturnRaReset/RaReset SID348 Output3"),
        ("ControlDueTrace", 150, "DacCtFeedback/DueFeedback SID331 Output4"),
        ("ControlPrepareTrace", 150, "Sar1TrialRaCt/PreconvertSar1 SID333 Output4"),
        ("ControlDecideTrace", 150, "SarDecisionTracking/Sar2Tracking SID346 Output4"),
        ("FE_old", 353, "Adc/SampleCharge UnitDelay SID148 Output1"),
        ("FE_next", 353, "ChargeReturnRaReset output FE_next SID297 Output3; same wire as SampleCharge UnitDelay input"),
        ("RA_old", 48, "Adc/RaCtState UnitDelay SID149 Output1"),
        ("RA_next", 48, "ChargeReturnRaReset output RA_next SID297 Output1; same wire as RaCtState UnitDelay input"),
        ("SAR_old", 51, "Adc/SarState UnitDelay SID150 Output1"),
        ("SAR_next", 51, "SarDecisionTracking output SAR_next SID285 Output3; same wire as SarState UnitDelay input"),
        ("EventTime", 3, "[Adc Event Inport SID116 cycle, groupIndex; SampleRaAdvance Time output SID232 Output2 eventTime_s]"),
    ]
    offset = 1
    for seg in observer_segments:
        seg_name, width, source_tap = seg
        seg_record = {"name": seg_name, "width": width, "source_tap": source_tap, "column_start_1based": offset, "column_end_1based": offset + width - 1}
        offset += width
        # Replace tuple with record for JSON output.
        observer_segments[observer_segments.index(seg)] = seg_record
    if offset - 1 != 6329:
        raise SystemExit(f"Observer width mismatch: {offset - 1}")
    observer_schema = {
        "schema_version": "sar20-sample5-observer/v1",
        "baseline_sha256": actual,
        "workspace_variable": "sar20_sample5_observer",
        "matlab_class": "timeseries",
        "save_format": "Timeseries",
        "sample_time": "-1 (inherited)",
        "time_axis": "timeseries.Time is the simulator sample time of enabled records; do not collapse rows by time.",
        "data_layout": {"class": "double", "shape": "N x 6329", "row_order": "enabled execution order; never sort, merge or deduplicate rows", "column_segments": observer_segments, "total_width": 6329},
        "trace_inner_layouts": {
            "frontend_width_1079": ["valid", "time_s", "context_id", "epoch", "kind_code (advance=1, commit=2)", "context_event", "old FE353 (353)", "advanced FE353 (353)", "after_command FE353 (353)", "advanced obs7", "after_command obs7"],
            "backend_width_164": ["valid", "eventTime_s", "kind_code", "advanced_valid", "old RA48 (48)", "advanced RA48 (48)", "after_command RA48 (48)", "predicted obs8", "actual obs8"],
            "control_width_150": {"slot_width": 75, "flatten": "[slot1(1:75),slot2(1:75)]", "record_valid_columns_within_trace_1based": [1, 76], "fields": ["record_valid", "time_s", "sample_id", "epoch", "group.events original 1-based ordinal", "stage_code", "event_code", "event_index", "event_bit", "comparison_used", "sample_v", "vres_v", "vy_v", "decision1", "decision2", "compare_valid", "compare_late", "cmp_effective_v", "cmp_offset_v", "cmp_noise_v", "decision", "record_ready", "feedback_changed", "trial_changed", "state_after51 (51)"], "record_rule": "Each slot is valid only when that stage actually handled that original group.events element; accepted event order stays unchanged."},
        },
        "window": {"enabled": True, "sample_id": 5, "time_interval": "[5*Ts, 6*Ts]", "includes": "sample ID 5 event window and the next CNV boundary", "enable_signal": "SampleRaAdvance diagnostic packed output element 1 (FEAdvanceTrace.valid) == 1", "validity_outside_window": "Trace fields are NaN outside the selected window; no zero fill. Control slots are NaN when unexecuted."},
        "actual_state_taps": {"FE353": {"old": "UnitDelay SID148.y1", "next": "ChargeReturnRaReset SID297.y3 / same UnitDelay SID148.u1 wire"}, "RA48": {"old": "UnitDelay SID149.y1", "next": "ChargeReturnRaReset SID297.y1 / same UnitDelay SID149.u1 wire"}, "SAR51": {"old": "UnitDelay SID150.y1", "next": "SarDecisionTracking SID285.y3 / same UnitDelay SID150.u1 wire"}},
        "logging_design": {"container": "Adc/Sample5Observer Enabled Subsystem", "stage_pass_through_outputs": ["SampleRaAdvance.y6 width1243 = FEAdvanceTrace+BackendAdvanceTrace", "DacCtFeedback.y6 width1393 = FEDacFeedbackTrace+BackendCtFeedbackTrace+ControlDueTrace", "Sar1TrialRaCt.y7 width1393 = FEDacTrialTrace+BackendRaAzCtTrace+ControlPrepareTrace", "SarDecisionTracking.y6 width150 = ControlDecideTrace", "ChargeReturnRaReset.y5 width1243 = FEChargeReturnTrace+BackendRaResetTrace"], "observer_internal": "Demux the five packed stage outputs by original widths; Mux the 18 canonical segments in data_layout order; one ToWorkspace sink only.", "enable": "Compare packed SampleRaAdvance element1 to 1; drive the Observer EnablePort. It is true only for the diagnostic window.", "ToWorkspace": {"VariableName": "sar20_sample5_observer", "SaveFormat": "Timeseries", "SampleTime": "-1", "MaxDataPoints": "inf", "Decimation": "1"}, "signals": "All new connections branch existing outputs; no kernel, state, RNG call, delay, trigger or input-path operation is added."},
        "estimated_payload": {"expected_rows": 49, "uncompressed_numeric_bytes": 2480968, "approx_mb_decimal": 2.481, "basis": "49 * 6329 doubles * 8 bytes; excludes MATLAB timeseries/container overhead; measure actual run later."},
        "evidence_boundary": "Plan only. No MATLAB/model_edit/model_check or simulation was run by this subagent; root must validate every new scope and log volume on Windows."
    }
    (out / "observer_schema.json").write_text(json.dumps(observer_schema, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    operation_driver = {
        "driver_version": "sar20-model-debug-graph/v1",
        "scope": "offline operation manifest only; root owns all Windows/MATLAB calls",
        "input_identity": {"path": str(slx), "sha256": actual, "required_baseline_prefix": "91973cf76507"},
        "required_first_call": "library.settingsLookup(); do not model_read/edit until gatePass or found=false.",
        "per_scope_contract": ["fresh model_read(scope)", "model_edit(scope, single-line JSON, layout_mode)", "model_read(scope)", "model_check(scope)", "If partial: immediately preserve a private temp copy and SHA, then model_read+model_check that partial and resume only from its recorded hash."],
        "scope_batches": [
            {"id": "root_preview", "scope": "root", "layout_mode": "native_display_only", "purpose": "On a private copy only, set EventStep ContentPreviewEnabled=off because Win runtime rejected that display property in model_edit. This is the sole native write exception and changes no structure or model math.", "operations": [{"op": "set_param", "target_sid_from_fresh_model_read": "EventStep", "property": "ContentPreviewEnabled", "value": "off"}], "runtime_model_edit_failure": "PARAM_VALUE_INVALID: Parameter ContentPreviewEnabled not found for block type SubSystem", "verify": "NativeGet off + root model_read + model_check; compare all ports/wires unchanged."},
            {"id": "eventstep_physical_view", "scope": "blk_105", "layout_mode": "incremental", "purpose": "Create an unconnected, non-computing PhysicalView subsystem; inside it create portless navigation cards with attributes '仅导航，不计算' and OpenFcn semantic-key callbacks. No duplicate calculations. Set ContentPreviewEnabled only with the private display-only native exception above.", "operation_template": {"op": "create_subsystem", "name": "PhysicalView", "ref": "physical_view", "interface": {"inputs": [], "outputs": []}}, "navigation_keys": list(nav_keys.keys()), "verify": "read scope after creation, then read/check PhysicalView after populating; no added data path."},
            {"id": "fpga_d1_wrapper", "scope": "blk_123", "layout_mode": "incremental", "purpose": "Create D1Decode with scalar RawD1 input/d1_v output; populate from exact original nodes in fpga_subgraphs.json; parent-wire both output branches; read/check before deleting old D1 nodes; then read/check again."},
            {"id": "fpga_d2_wrapper", "scope": "blk_123", "layout_mode": "incremental", "purpose": "Create D2Decode with RawD2+single shared PublicPol input and scalar d2_v output; preserve PublicPol fanout; exact original nodes in fpga_subgraphs.json."},
            {"id": "fpga_dt_wrapper", "scope": "blk_123", "layout_mode": "incremental", "purpose": "Create DTDecode with RawDT+same PublicPol input and scalar dt_v output; exact original nodes in fpga_subgraphs.json."},
            {"id": "observer_stage_taps", "scope": "each actual Sfun-containing stage scope", "layout_mode": "incremental", "purpose": "Branch each new Sfun final diagnostic output into one stage Mux and one appended Outport. Do not change or reorder original ports. Stage widths/order are in observer_schema.json."},
            {"id": "observer_logger", "scope": "blk_112", "layout_mode": "incremental", "purpose": "Create one enabled Sample5Observer; read fresh stage and UnitDelay IDs, connect exact taps, split only stage logging bundles, Mux 18 canonical segments and feed one standard Timeseries ToWorkspace. No solver/physical path input."},
            {"id": "note_template", "scope": "source-helper owner", "layout_mode": "not_model_edit", "purpose": "Shorten behavior_applied_note visible AttributesFormatString generator only after the dashboard retains full parameter/config details; a one-off annotation edit will be overwritten by apply."}
        ],
        "tool_capability_evidence": {"source": "dependencies/toolkit/tools/registry.json:model_edit", "supported_operations": ["add_block", "connect", "disconnect", "configure", "delete", "replace_block", "create_subsystem"], "no_move_or_encapsulate": True, "forbidden_bypass": "Do not use native APIs/evaluate_matlab_code to add, move, copy, connect, or delete model structures. The sole root-authorized native set_param is ContentPreviewEnabled='off' on a private candidate, after the recorded SDK PARAM_VALUE_INVALID for SATK configure; no other native writes."},
        "no_run": True,
        "no_source_or_model_write_by_generator": True,
    }
    (out / "driver_manifest.json").write_text(json.dumps(operation_driver, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "prepared", "out": str(out), "input_sha256": actual, "files": ["source_inventory.json", "fpga_subgraphs.json", "fpga_stage1_spec.json", "navigation_semantics.json", "observer_schema.json", "driver_manifest.json"]}, ensure_ascii=False))

if __name__ == "__main__":
    main()
