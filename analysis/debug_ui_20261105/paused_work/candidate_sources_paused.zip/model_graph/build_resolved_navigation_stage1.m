function nav = build_resolved_navigation_stage1(model, projectRoot, candidatePath, baselineSha, modelSha)
%BUILD_RESOLVED_NAVIGATION_STAGE1 Emit a private stage1 SID map from fresh reads.
% No SID is guessed. Every value is resolved from model_read plus Simulink.ID.
rootRead=read(model,'root');
eventId=idByName(rootRead,'EventStep');
eventRead=read(model,eventId);
adcId=idByName(eventRead,'Adc'); fpgaId=idByName(eventRead,'Fpga');
transportId=idByName(eventRead,'Transport');
adcRead=read(model,adcId); fpgaRead=read(model,fpgaId);
physicalId=idByName(eventRead,'PhysicalView'); physicalRead=read(model,physicalId);

stageNames={'SampleRaAdvance','DacCtFeedback','Sar1TrialRaCt','ResidueCtCompare','SarDecisionTracking','ChargeReturnRaReset'};
stageIds=cell(size(stageNames)); stageInner=cell(size(stageNames));
for k=1:numel(stageNames)
    stageIds{k}=idByName(adcRead,stageNames{k});
    stageInner{k}=subFunctions(model,read(model,stageIds{k}));
end
sample=stageIds{1}; due=stageIds{2}; sar1=stageIds{3}; residue=stageIds{4}; sar2=stageIds{5}; ret=stageIds{6};
feState=idByName(adcRead,'SampleCharge'); raState=idByName(adcRead,'RaCtState'); sarState=idByName(adcRead,'SarState');

D1=idByName(fpgaRead,'D1Decode'); D2=idByName(fpgaRead,'D2Decode'); DT=idByName(fpgaRead,'DTDecode');
sumNames={'D1PlusD2','PlusTracking','PlusDither','Counts','UnsignedMidpoint','RoundCode','SaturateCode'};
sumIds=cell(1,numel(sumNames)); for k=1:numel(sumNames), sumIds{k}=idByName(fpgaRead,sumNames{k}); end
cal=idByName(fpgaRead,'Calibration'); code=idByName(fpgaRead,'code20');
public=idByName(eventRead,'PublicCode'); topCode=idByName(rootRead,'Code20');
transportChild=read(model,transportId);
pinIds={};
try, pinIds={idByName(transportChild,'PinTransport')}; catch, end

T={};
T{end+1}=target(model,'exec:sample_ra_advance','SampleRaAdvance','execution',sample,stageInner{1},'FE353,RA48',false,true,'current/src/frontend/behavior_frontend_stage.m; current/src/physics/behavior_backend_stage.m');
T{end+1}=target(model,'exec:dac_ct_feedback','DacCtFeedback','execution',due,stageInner{2},'FE353,RA48,SAR51',false,true,'current/src/frontend/behavior_frontend_stage.m; current/src/physics/behavior_backend_stage.m; current/src/control/behavior_control_stage.m');
T{end+1}=target(model,'exec:sar1_trial_ra_ct','Sar1TrialRaCt','execution',sar1,stageInner{3},'FE353,RA48,SAR51',false,true,'current/src/frontend/behavior_frontend_stage.m; current/src/physics/behavior_backend_stage.m; current/src/control/behavior_control_stage.m');
T{end+1}=target(model,'exec:residue_ct_compare','ResidueCtCompare','execution',residue,{},'RA48',false,true,'current/src/physics/behavior_backend_stage.m');
T{end+1}=target(model,'exec:sar2_tracking','SarDecisionTracking','execution',sar2,stageInner{5},'SAR51',false,true,'current/src/control/behavior_control_stage.m');
T{end+1}=target(model,'exec:charge_return_ra_reset','ChargeReturnRaReset','execution',ret,stageInner{6},'FE353,RA48',false,true,'current/src/frontend/behavior_frontend_stage.m; current/src/physics/behavior_backend_stage.m');
T{end+1}=target(model,'state:FE353','SampleCharge','state_owner',feState,{},'SampleCharge',false,false,'current/src/frontend/behavior_frontend_pack.m::behavior_frontend_pack');
T{end+1}=target(model,'state:RA48','RaCtState','state_owner',raState,{},'RaCtState',false,false,'current/src/physics/behavior_backend_pack.m::behavior_backend_pack');
T{end+1}=target(model,'state:SAR51','SarState','state_owner',sarState,{},'SarState',false,false,'current/src/control/behavior_sar_pack.m::behavior_sar_pack');
T{end+1}=target(model,'digital:d1','D1Decode','digital_wrapper',D1,{},'',false,true,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'digital:d2','D2Decode','digital_wrapper',D2,{},'',false,true,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'digital:dt','DTDecode','digital_wrapper',DT,{},'',false,true,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'digital:sum_encode','D1PlusD2 through SaturateCode','digital_path',sumIds,{},'',false,true,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'digital:calibration','Calibration','digital_calibration',cal,{},'',false,true,'current/src/calibration/behavior_calibration_workflow.m::behavior_calibration_workflow');
T{end+1}=target(model,'digital:public_output','code20 to PublicCode to Code20','digital_output',{code,public,topCode},{},'',false,true,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'physical:sample_dac1','Sample & DAC1','physical_navigation', ...
    {sample,due,sar1,ret,feState},filterOwner([stageInner{1} stageInner{2} stageInner{3} stageInner{6}],'FE353'),'FE353',true,false, ...
    'current/src/frontend/behavior_frontend_stage.m; current/src/control/behavior_control_stage.m');
T{end+1}=target(model,'physical:sar1_6b','Coarse / SAR1 6-bit preconversion','physical_navigation', ...
    {due,sar1,sar2,sarState},filterOwner([stageInner{2} stageInner{3} stageInner{5}],'SAR51'), ...
    'SAR51',true,false,'current/src/control/behavior_control_stage.m');
residueImpl=[stageInner{1} stageInner{2} stageInner{3} stageInner{6}];
residueTarget=target(model,'physical:residue','Residue / Qres source vs command','physical_navigation', ...
    {sar1,due,sample,residue,ret,feState,raState},residueImpl, ...
    'FE353',true,false, ...
    'current/src/frontend/behavior_frontend_stage.m; current/src/physics/behavior_backend_stage.m');
residueTarget.owner_roles={struct('state_owner','FE353','source','SampleCharge', ...
    'role','Qres source charge and switching readout'),struct('state_owner','RA48', ...
    'source','RaCtState.command.qres','role','interval latch command')};
T{end+1}=residueTarget;
T{end+1}=target(model,'physical:ra_az','RA & AZ','physical_navigation',{sample,due,sar1,ret,raState},{},'RA48',true,false,'current/src/physics/behavior_backend_stage.m');
T{end+1}=target(model,'physical:cinc_ct','CINC & CT','physical_navigation',{due,sar1,residue,ret,raState},{},'RA48',true,false,'current/src/physics/behavior_backend_stage.m');
T{end+1}=target(model,'physical:sar2_tracking','SAR2 & Tracking','physical_navigation',{sar2,sarState},{},'SAR51',true,false,'current/src/control/behavior_control_stage.m');
T{end+1}=target(model,'physical:digital','Digital','physical_navigation',{fpgaId,D1,D2,DT,sumIds{:},cal,code},{},'FPGA',true,false,'current/src/digital/behavior_decode.m::behavior_decode');
T{end+1}=target(model,'physical:lvds','LVDS protocol container TX/RX','physical_navigation', ...
    [{transportId},pinIds],{},'Transport',true,false, ...
    'current/src/transport/behavior_transport_step.m; current/src/transport/sar20_lvds_tx_step.m; current/src/transport/sar20_lvds_rx_step.m; current/src/transport/behavior_transport_pp_sfun.m; P.transport.enabled=false; protocol-only, no electrical/CDC model');
T{end+1}=struct('key','physical:observer_sample5','title','Observer sample5','kind','pending_phase2', ...
    'status','not_added_in_stage1','focus_sid','','sids',{{}},'owner','Observer', ...
    'navigation_only',true,'calculates',false,'sourcepoints',{{'pending trace/registry freeze'}},'implementations',{{}});

cardKeys={'physical:sample_dac1','physical:sar1_6b','physical:residue','physical:ra_az','physical:cinc_ct','physical:sar2_tracking','physical:digital','physical:lvds'};
cardNames={'Physical_Sample_DAC1','Physical_Coarse_SAR1','Physical_Residue','Physical_RA_AZ','Physical_CINC_CT','Physical_SAR2_Tracking','Physical_Digital','Physical_LVDS'};
for k=1:numel(cardKeys)
    cid=idByName(physicalRead,cardNames{k});
    idx=find(cellfun(@(x)strcmp(x.key,cardKeys{k}),T),1);
    T{idx}.navigation_block_sid=sid(cid);
end
nav=struct('schema_version','sar20-model-navigation/v1', ...
    'model',struct('name','SarAdc','relative_path','current/models/SarAdc.slx', ...
    'private_candidate_path',candidatePath,'baseline_sha256',baselineSha,'model_sha256',modelSha), ...
    'stage1_only_incomplete',true,'targets',{T},'refresh_required_after_observer_phase',true, ...
    'evidence_boundary','Fresh IDs from the private stage1 model_read. Observer target remains pending; refresh after phase2.');
end

function value=target(model,key,title,kind,focusIds,extra,owner,navigationOnly,calculates,sourcepoints)
if iscell(focusIds), ids=focusIds; else, ids={focusIds}; end
impls={};
for k=1:numel(ids)
    if isempty(ids{k}), continue; end
    impls{end+1}=impl(model,ids{k},owner,sourcepoints); %#ok<AGROW>
end
if iscell(extra)
    for k=1:numel(extra), impls{end+1}=extra{k}; end %#ok<AGROW>
end
sidList=cell(1,numel(impls)); for k=1:numel(impls), sidList{k}=impls{k}.sid; end
sidList=unique(sidList,'stable'); focus=''; if ~isempty(sidList), focus=sidList{1}; end
value=struct('key',key,'title',title,'kind',kind,'focus_sid',focus,'sids',{sidList}, ...
    'owner',owner,'navigation_only',logical(navigationOnly),'calculates',logical(calculates), ...
    'sourcepoints',{{sourcepoints}},'implementations',{impls});
end

function items=subFunctions(model,readText)
rows=parseRows(readText); items={};
for k=1:numel(rows)
    if ~any(strcmp(rows(k).block_type,{'M-S-Function','S-Function'})), continue; end
    path=pathById(model,rows(k).id); fn=''; try, fn=get_param(path,'FunctionName'); catch, end
    items{end+1}=impl(model,rows(k).id,'',sourceForFunction(fn)); %#ok<AGROW>
end
end

function result=filterOwner(items,wanted)
result={};
for k=1:numel(items)
    if isfield(items{k},'owner')&&strcmp(items{k}.owner,wanted),result{end+1}=items{k};end %#ok<AGROW>
end
end

function value=impl(model,id,owner,sourcepoint)
path=pathById(model,id); bt=get_param(path,'BlockType'); nm=get_param(path,'Name'); fn='';
if any(strcmp(bt,{'M-S-Function','S-Function'})), try, fn=get_param(path,'FunctionName'); catch, end, end
if strcmp(fn,'behavior_frontend_sfun'), owner='FE353'; end
if strcmp(fn,'behavior_backend_sfun'), owner='RA48'; end
if strcmp(fn,'behavior_control_stage_sfun'), owner='SAR51'; end
if strcmp(fn,'behavior_wiring_sfun')
    try, prm=char(get_param(path,'Parameters')); catch, prm=''; end
    if contains(prm,'backend'), owner='RA48.command'; end
end
mapped=sourceForFunction(fn);
if ~isempty(mapped), sourcepoint=mapped; end
value=struct('sid',sid(id),'name',nm,'block_type',bt,'function_name',fn, ...
    'owner',owner,'sourcepoint',sourcepoint,'calculates',~any(strcmp(bt,{'UnitDelay','Outport','Inport'})));
end

function rows=parseRows(report)
lines=splitlines(string(report)); rows=struct('id',{},'name',{},'block_type',{}); cur=[];
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t)
        if ~isempty(cur)&&isfield(cur,'id')&&isfield(cur,'name'), rows(end+1)=cur; end %#ok<AGROW>
        cur=struct('id',t{1},'name','','block_type',''); continue
    end
    if isempty(cur), continue; end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once'); if ~isempty(t),cur.name=strtrim(t{1});continue;end
    t=regexp(line,'^\s*BlockType:\s*(.*?)\s*$','tokens','once'); if ~isempty(t),cur.block_type=strtrim(t{1});end
end
if ~isempty(cur)&&isfield(cur,'id')&&isfield(cur,'name'), rows(end+1)=cur; end
end

function id=idByName(report,name)
lines=splitlines(string(report)); cur=''; hits={};
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t),cur=t{1};continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(cur),hits{end+1}=cur;cur='';end %#ok<AGROW>
end
hits=unique(hits,'stable'); if numel(hits)~=1,error('sar20:navigation:Resolve','Expected one SID for %s, got %d.',name,numel(hits));end
id=hits{1};
end
function report=read(model,scope)
report=char(model_read(model,scope,'0'));
if ~startsWith(strtrim(report),'status: ok')&&~startsWith(strtrim(report),'status: success'),error('sar20:navigation:Read','model_read failed for %s: %s',scope,report);end
end
function path=pathById(model,id)
path=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
function n=sid(id),n=char(extractAfter(string(id),'blk_'));end
function p=sourceForFunction(fn)
switch char(fn)
 case 'behavior_frontend_sfun',p='current/src/frontend/behavior_frontend_sfun.m';
 case 'behavior_backend_sfun',p='current/src/physics/behavior_backend_sfun.m';
 case 'behavior_control_stage_sfun',p='current/src/control/behavior_control_stage_sfun.m';
 case 'behavior_wiring_sfun',p='current/src/model/behavior_wiring_sfun.m';
 case 'behavior_pol_sfun',p='current/src/digital/behavior_public_pol.m';
 case 'behavior_dither_sfun',p='current/src/digital/behavior_public_dither.m';
 case 'behavior_transport_pp_sfun',p='current/src/transport/behavior_transport_pp_sfun.m';
 otherwise,p='';
end
end
