# SAR20 9197 图与观察 driver 候选

这些文件是给 root Windows/MATLAB 调度使用的只读准备材料。唯一输入是 `current/models/SarAdc.slx`，SHA-256 `91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e`。生成器会拒绝其它模型哈希；没有读取 CAAZ632 或 Framepartial 模型作为底图。

## 文件

- `source_inventory.json`：从当前 SLX 内嵌 XML 提取 EventStep、Adc、Fpga 的 block、参数与连线；静态身份材料，不替代 root fresh `model_read`。
- `fpga_subgraphs.json`：D1/D2/DT 三组当前节点、参数、边界和连接。外层 D1PlusD2/PlusTracking/PlusDither/Counts/Round/Saturate/Calibration、共享 PublicPol 与 PublicDither 保持独立。
- `fpga_stage1_spec.json`：MATLAB driver实际读取的、数组化的D1/D2/DT wrapper/ports/edges/source outputs spec，避免JSON对象键中的冒号影响`jsondecode`。
- `fpga_ops_template.json`：按 `model_edit` 可用操作生成三组 virtual wrapper 的分步操作模板。`$inport:*` 等字段必须由新 wrapper 的 fresh `model_read` 结果填入；模板不能原样调用。
- `navigation_semantics.json`：六阶段顺序、三状态 owner、物理模块语义键、commit/UnitDelay 说明。
- `observer_schema.json`：11 个真实 trace port + 6 个 UnitDelay old/next tap + 3 字段 EventTime，合计 18 段、6329 列；ToWorkspace timeseries 的列布局、enable 与估算体积。
- `driver_manifest.json`：settingsLookup gate、每 scope read/edit/read/check、partial 私有 hash、root preview/physical view/FPGA/Observer 分批顺序。

## 调用准备脚本

```bash
python3 /tmp/sar20_model_debug_graph_luna/prepare_model_debug_graph.py
```

脚本只读取 SLX ZIP/XML，只写 `/tmp/sar20_model_debug_graph_luna/generated`。它不启动 MATLAB，不读写当前工程文件。

## root 调度约束

1. MATLAB 编辑前先 `library.settingsLookup()`；`gatePass=false` 时停止实际编辑。
2. 每个新 scope 都先 `model_read`。fresh IDs、rounding 参数、Interface 和 EnablePort 端口以 root 当次读回为准；不能从模板中的名字手工拼路径。
3. 每个 scope 完成后 `model_read` 再 `model_check`。若 `model_edit` 返回 partial，立刻将 partial 保存在私有路径并记录 SHA，再对该 partial read/check，后续只从记录 SHA 恢复。
4. model_edit 注册表没有 `move` 或 `encapsulate`。FPGA 计划只用 SATK `create_subsystem`、标准块重建与 readback；先完整建好虚拟 wrapper、验证父层端口/边，再删除原节点；中途不仿真，partial 不交付。
5. Observer 仅分支原 S-Function 诊断端口和三个状态 owner 的真实旧/下一状态线；ToWorkspace 只放在 EnabledLogger 内，enable 来自 SampleRaAdvance Trace `valid==1`。不新增 hits、延迟、触发、状态或随机调用。
6. `observer_schema.json` 给出 49 行的约 2.48 MB 数值数据估算（ToWorkspace 上限64）。真实体积、耗时与模型结构必须由 root Windows/MATLAB 实际结果记录；此候选没有验证运行。

## 当前证据边界

已经证实的是：本地当前 SLX 身份与 SHA 精确匹配；嵌入 XML 含 EventStep/Adc/Fpga 原始图；模型编辑工具清单没有 move/encapsulate。尚未证实的是：SATK 实际 gate、Windows fresh `model_read`/`model_check`、新端口刷新、wrapper 参数逐项读回、Observer ToWorkspace 真正行数/体积、仿真等价性。上述均由 root 后续在 Windows/R2024a 执行。

## MATLAB stage1 driver (root-owned; not run by this subagent)

Callable entrypoint:

```matlab
addpath('/tmp/sar20_model_debug_graph_luna');
r = run_modelgraph_stage1(projectRoot, privateWorkRoot, 'ColdOpenCompile', true);
```

`projectRoot` is the SAR20 project root. `privateWorkRoot` must be an external temporary directory outside that project. The driver copies the exact baseline there, runs `settingsLookup` first, resolves IDs from fresh `model_read` text, reads native dialog parameters for each FPGA source node, creates and verifies the three virtual wrappers through `model_edit`, saves the private model, cold-opens it, and runs `SimulationCommand='update'` for compile evidence. It does not execute a simulation. It reads `generated/fpga_stage1_spec.json` plus `source_inventory.json` and writes the model and receipts under `privateWorkRoot`, including `receipts/resolved_navigation_stage1.json` with SIDs resolved from the edited candidate.

The stage driver intentionally fails closed if `privateWorkRoot/SarAdc.slx` already exists; do not rerun the whole stage over a partial. A `partial` edit saves a private snapshot and SHA, then immediately reads/checks that scope before stopping. The root operator continues from that exact private snapshot by fresh `model_read`/`model_check` and a new scoped `model_edit`; do not use a stale block ID from before the partial.

The new FPGA wrapper interfaces are scalar: `D1Decode(RawD1)->d1_v`, `D2Decode(RawD2,PublicPol)->d2_v`, and `DTDecode(RawDT,PublicPol)->dt_v`. Parent connections branch the wrapper outputs to the existing FPGA Outports and sum inputs. The one existing `PublicPol` block continues to serve both D2 and DT. Original D1/D2/DT nodes are removed only after the replacement child scopes have passed read/check.

## 独立 layout-only 阶段

Stage1 首次实际运行并产生 `privateWorkRoot/SarAdc.slx`、`receipts/stage1_receipt.json` 后，再单独调用：

```matlab
addpath('/tmp/sar20_model_debug_graph_luna');
r = run_modelgraph_layout_stage(projectRoot, privateModelPath, stage1Sha);
```

它核对 stage1 receipt 的 9197 源身份和模型 SHA；读取六个实际 stage 与三个 UnitDelay owner 的 `Position`/尺寸及 `PortHandles` 计数；按真实尺寸计算六阶段左到右、状态 owner 单独一行、Diagnostics 底部的坐标；随后仅通过 SATK `model_edit.configure(Position)` 移动现存块，读回位置与端口数、`model_check`、保存及冷开 `update`。不添加/删除/重接线，也不使用 Goto/From。如果回执显示布局器改写了目标坐标，脚本会留私有失败快照并停止，root可根据实际模型视图更新坐标算法。

## Classification checkpoint 的 FPGA-only continuation

Win SDK 对 `ContentPreviewEnabled` 的 `model_edit.configure` 返回过 `PARAM_VALUE_INVALID`。root 已在隔离分类副本对这一显示属性使用唯一允许的私有 `set_param` 白名单，并完成八张 portless PhysicalView 卡片。本续跑入口不会再次设置预览、不创建/删除/修改卡片，也不会从 9197 重新复制：

```matlab
r = run_modelgraph_fpga_continue(projectRoot, checkpointModelPath, exactCheckpointSha, ...
    'ColdOpenCompile', true);
```

它要求私有 checkpoint SHA 与 root 提供的一致、PhysicalView 恰有八个 portless 空导航卡、源工程仍是 9197；然后只读 fresh scopes/Native dialog，采用 SATK `model_edit` 创建三 wrapper、核对内部/父层每条连线、删除原 FPGA 节点并留私有回执。它不会设置 `ContentPreviewEnabled`，不会重跑已完成分类，不运行仿真。partial 会另存 SHA 与即时 read/check，需 root 从该 checkpoint 逐 scope 继续。
