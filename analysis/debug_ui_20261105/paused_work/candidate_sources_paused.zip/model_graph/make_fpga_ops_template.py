#!/usr/bin/env python3
"""Build placeholder-bearing model_edit ops from the exact 9197 XML inventory."""
import json
from pathlib import Path
root=Path('/tmp/sar20_model_debug_graph_luna/generated')
fpga=json.load(open(root/'fpga_subgraphs.json',encoding='utf-8'))
source=json.load(open(root/'source_inventory.json',encoding='utf-8'))
raw=source['systems']['fpga']['blocks']
by_name={b['name']:b for b in raw}

def ref(name):
    return 'r_'+''.join(c.lower() if c.isalnum() else '_' for c in name).strip('_')

graphs={
'digital:d1':{
 'wrapper':'D1Decode','inputs':['RawD1'],'outputs':['d1_v'],
 'members':['D1TwiceRaw','D1CoarseDivide','D1CoarseFloor','D1CoarseSubtract','D1Units','D1DacOffset','D1DacVoltage','D1CaptureBias'],
 'edges':[
 ('RawD1','D1TwiceRaw.u1'),('RawD1','D1CoarseDivide.u1'),
 ('D1CoarseDivide.y1','D1CoarseFloor.u1'),('D1CoarseFloor.y1','D1CoarseSubtract.u1'),
 ('D1TwiceRaw.y1','D1Units.u1'),('D1CoarseSubtract.y1','D1Units.u2'),
 ('D1Units.y1','D1DacOffset.u1'),('D1DacOffset.y1','D1DacVoltage.u1'),
 ('D1DacVoltage.y1','D1CaptureBias.u1'),('D1CaptureBias.y1','d1_v')],
 'parent_inputs':[('blk_177.y1','u1')],
 'parent_outputs':[('y1','blk_128.u1'),('y1','blk_194.u1')],
 'old_sids':['181','178','179','180','182','183','184','185']},
'digital:d2':{
 'wrapper':'D2Decode','inputs':['RawD2','PublicPol'],'outputs':['d2_v'],
 'members':['D2Divide','D2Floor','D2UpperDivide','D2UpperFloor','D2UpperTwice','D2Bits','D2Weighted','D2Offset','D2InputReference','D2Demod'],
 'edges':[
 ('RawD2','D2Divide.u1'),('RawD2','D2UpperDivide.u1'),
 ('D2Divide.y1','D2Floor.u1'),('D2UpperDivide.y1','D2UpperFloor.u1'),('D2UpperFloor.y1','D2UpperTwice.u1'),
 ('D2Floor.y1','D2Bits.u1'),('D2UpperTwice.y1','D2Bits.u2'),('D2Bits.y1','D2Weighted.u1'),
 ('D2Weighted.y1','D2Offset.u1'),('D2Offset.y1','D2InputReference.u1'),
 ('D2InputReference.y1','D2Demod.u1'),('PublicPol','D2Demod.u2'),('D2Demod.y1','d2_v')],
 'parent_inputs':[('blk_177.y2','u1'),('blk_215.y1','u2')],
 'parent_outputs':[('y1','blk_129.u1'),('y1','blk_194.u2')],
 'old_sids':['203','204','205','206','207','208','186','187','188','216']},
'digital:dt':{
 'wrapper':'DTDecode','inputs':['RawDT','PublicPol'],'outputs':['dt_v'],
 'members':['DTDivide','DTFloor','DTUpperDivide','DTUpperFloor','DTUpperTwice','DTBits','DTWeighted','DTBipolarTwice','DTBipolarOffset','DTInputReference','DTDemod'],
 'edges':[
 ('RawDT','DTDivide.u1'),('RawDT','DTUpperDivide.u1'),
 ('DTDivide.y1','DTFloor.u1'),('DTUpperDivide.y1','DTUpperFloor.u1'),('DTUpperFloor.y1','DTUpperTwice.u1'),
 ('DTFloor.y1','DTBits.u1'),('DTUpperTwice.y1','DTBits.u2'),('DTBits.y1','DTWeighted.u1'),
 ('DTWeighted.y1','DTBipolarTwice.u1'),('DTBipolarTwice.y1','DTBipolarOffset.u1'),
 ('DTBipolarOffset.y1','DTInputReference.u1'),('DTInputReference.y1','DTDemod.u1'),
 ('PublicPol','DTDemod.u2'),('DTDemod.y1','dt_v')],
 'parent_inputs':[('blk_177.y3','u1'),('blk_215.y1','u2')],
 'parent_outputs':[('y1','blk_130.u1'),('y1','blk_195.u2')],
 'old_sids':['209','210','211','212','213','214','189','190','191','192','217']},
}
ops={
 'evidence':{'baseline_sha256':fpga['evidence']['baseline_sha256'],'source_inventory':'source_inventory.json'},
 'not_directly_executable_until_hydrated':True,
 'placeholder_grammar':{'$scope:d1':'fresh model_read ID of D1Decode scope','$scope:d2':'fresh model_read ID of D2Decode scope','$scope:dt':'fresh model_read ID of DTDecode scope','$inport:RawD1':'fresh model_read ID for auto-created D1Decode RawD1 Inport','$outport:d1_v':'fresh model_read ID for D1Decode d1_v Outport','same pattern for RawD2/PublicPol/RawDT/d2_v/dt_v':'fresh model_read IDs; never construct from block names','<created:D1Decode>':'new subsystem ID returned by create_subsystem, then use concrete blk_N on later calls'},
 'batch_order':[
  'settingsLookup gate, then model_read blk_123 from the current 9197 file',
  'Create all three empty virtual subsystem wrappers in FPGA scope; private-save/hash if partial.',
  'For each wrapper: model_read the new scope; populate the exact original block list and links below; model_read and model_check that wrapper.',
  'In FPGA scope, connect new wrapper inputs from RawFields/PublicPol and outputs to unchanged Outports/sums; read back all destinations.',
  'Only after all three wrapper read/checks and parent readback, delete old SIDs for the corresponding groups; model_read+model_check FPGA scope.',
  'Never simulate with old and replacement nodes coexisting; do not publish partial model.'
 ],
 'groups':{}
}
for key,g in graphs.items():
    source_nodes=[by_name[n] for n in g['members']]
    create={"op":"create_subsystem","name":g['wrapper'],"ref":ref(g['wrapper']),"interface":{"inputs":g['inputs'],"outputs":g['outputs']}}
    add=[]
    ref_map={}
    for b in source_nodes:
        r=ref(b['name']); ref_map[b['name']]=r
        item={"op":"add_block","type":b['block_type'],"name":b['name'],"ref":r}
        params=b['parameters']
        if params:
            item['params']=params
        add.append(item)
    con=[]
    for a,b in g['edges']:
        def endpoint(x):
            if x in g['inputs']:
                return f"$inport:{x}.y1"
            if x in g['outputs']:
                return f"$outport:{x}.u1"
            if '.' not in x:
                raise ValueError(x)
            nm,port=x.split('.',1)
            return f"#{ref_map[nm]}.{port}"
        con.append({"op":"connect","target":f"{endpoint(a)} -> {endpoint(b)}"})
    parent=[]
    parent_inputs={
      'digital:d1':[('blk_177.y1','#new.u1')],
      'digital:d2':[('blk_177.y2','#new.u1'),('blk_215.y1','#new.u2')],
      'digital:dt':[('blk_177.y3','#new.u1'),('blk_215.y1','#new.u2')]
    }[key]
    for src,dst in parent_inputs:
        parent.append({"op":"connect","target":f"{src} -> {dst}"})
    parent_outputs={
      'digital:d1':[('#new.y1','blk_128.u1'),('#new.y1','blk_194.u1')],
      'digital:d2':[('#new.y1','blk_129.u1'),('#new.y1','blk_194.u2')],
      'digital:dt':[('#new.y1','blk_130.u1'),('#new.y1','blk_195.u2')]
    }[key]
    for src,dst in parent_outputs:
        parent.append({"op":"connect","target":f"{src} -> {dst}"})
    delete=[{"op":"delete","target":"blk_"+sid} for sid in g['old_sids']]
    ops['groups'][key]={
       "wrapper":g['wrapper'],
       "interface_template":create,
       "populate_operations_template":add+con,
       "auto_created_ports_to_read":g['inputs']+g['outputs'],
       "replacement_parent_wiring_template":parent,
       "old_nodes_delete_operations_after_readback":delete,
       "expected_original_node_params":source_nodes,
       "internal_edges":g['edges'],
       "preservation_note":"ModelEdit tool response IDs replace placeholders only after fresh model_read. Rounding blocks have no explicit params in baseline XML; verify their exact RndMeth/current default with root model_read/query before adding.",
    }
(root/'fpga_ops_template.json').write_text(json.dumps(ops,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'prepared','file':str(root/'fpga_ops_template.json'),'groups':list(ops['groups'])},ensure_ascii=False))
