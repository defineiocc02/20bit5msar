function receipt = run_modelgraph_layout_stage(projectRoot, privateModelPath, expectedStage1Sha, varargin)
%RUN_MODELGRAPH_LAYOUT_STAGE Position-only cleanup on a private 9197 derivative.
% Root-owned Windows/MATLAB call after run_modelgraph_stage1 has returned a private
% candidate and fresh readouts. No blocks, connections, signals, state, triggers,
% delays, source parameters, or observer logic are created/changed here.
%
% Usage:
%   r = run_modelgraph_layout_stage(projectRoot, privateModelPath, stage1Sha)
%
% Layout contract:
%   - Six existing execution blocks are placed left-to-right in the true event
%     order: SampleRaAdvance -> DacCtFeedback -> Sar1TrialRaCt ->
%     ResidueCtCompare -> SarDecisionTracking -> ChargeReturnRaReset.
%   - The three existing UnitDelay owners are placed in a distinct state row above
%     the execution chain; their wires remain explicit.
%   - Diagnostics is placed in a lower side region.
%   - Positions and block sizes are read from the actual private SLX first. The
%     row is laid out using those sizes; no block name paths or guessed dimensions.
%   - The change uses model_edit configure(Position) only. It does not rewire any
%     line, add Goto/From, move, copy, or delete any computation.
%   - A backup SHA is stored before editing. Partial saves remain private.

p=inputParser;
addParameter(p,'ColdOpenCompile',true,@(x)islogical(x)&&isscalar(x));
addParameter(p,'KeepModelOpen',true,@(x)islogical(x)&&isscalar(x));
parse(p,varargin{:}); opt=p.Results;
projectRoot=char(projectRoot); privateModelPath=char(privateModelPath); expectedStage1Sha=char(expectedStage1Sha);
if ~isfile(privateModelPath), error('sar20:layout:CandidateMissing','Missing private stage1 candidate: %s',privateModelPath); end
if startsWith(lower(canonical(privateModelPath)),lower(canonical(projectRoot)))
    error('sar20:layout:ProductionBoundary','Layout stage only accepts a private path outside projectRoot.');
end
stage1ReceiptPath=fullfile(fileparts(privateModelPath),'receipts','stage1_receipt.json');
if ~isfile(stage1ReceiptPath),error('sar20:layout:Stage1Receipt','Missing stage1 receipt %s.',stage1ReceiptPath);end
stage1Receipt=jsondecode(fileread(stage1ReceiptPath));
lockedBase='91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e';
if ~isfield(stage1Receipt,'baseline_sha256')||~strcmpi(stage1Receipt.baseline_sha256,lockedBase)
    error('sar20:layout:Baseline','Private candidate does not trace to the locked 9197 baseline.');
end

oldPath=path; pathCleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
toolRoot=fullfile(projectRoot,'dependencies','toolkit','tools');
paths={fullfile(toolRoot,'common'),fullfile(toolRoot,'common','autolayout'), ...
    fullfile(toolRoot,'model_read'),fullfile(toolRoot,'model_edit'),fullfile(toolRoot,'model_check')};
for k=1:numel(paths), if ~isfolder(paths{k}),error('sar20:layout:Toolkit','Missing %s',paths{k});end,end
addpath(paths{:}); addpath(genpath(fullfile(projectRoot,'current','src')));
% Gate before model_read or any model inspection.
gate=library.settingsLookup();
if gate.found&&~gate.gatePass,error('sar20:layout:Gate','settingsLookup gatePass=false.');end
if gate.found&&gate.gatePass, kgText=fileread(gate.kgIndexPath); %#ok<NASGU> 
end

inputSha=sha256(privateModelPath);
if isempty(expectedStage1Sha)||~strcmpi(inputSha,expectedStage1Sha)
    error('sar20:layout:InputSha','Private stage1 SHA mismatch: expected %s got %s.',expectedStage1Sha,inputSha);
end
if ~isfield(stage1Receipt,'final_model_sha256')||~strcmpi(stage1Receipt.final_model_sha256,inputSha)
    error('sar20:layout:ReceiptSha','Stage1 receipt hash does not match the private model file.');
end
workDir=fileparts(privateModelPath); receipts=fullfile(workDir,'receipts');
if ~isfolder(receipts),mkdir(receipts);end
backupPath=fullfile(receipts,['before_layout_' inputSha '.slx']);
if ~isfile(backupPath), [ok,msg]=copyfile(privateModelPath,backupPath); if ~ok,error('sar20:layout:Backup','%s',msg);end,end
if ~strcmpi(sha256(backupPath),inputSha),error('sar20:layout:BackupSha','Layout backup SHA mismatch.');end

model='SarAdc';
loaded=find_system('Type','block_diagram','Name',model);
if isempty(loaded), open_system(privateModelPath);
elseif ~strcmpi(canonical(get_param(model,'FileName')),canonical(privateModelPath))
    error('sar20:layout:ModelAlreadyOpen','SarAdc is loaded from another path; do not close it automatically.');
end

receipt=struct('schema_version','sar20-modelgraph-layout-receipt/v1', ...
    'candidate_path',privateModelPath,'input_sha256',inputSha,'backup_path',backupPath, ...
    'backup_sha256',inputSha,'settings_lookup',gate,'simulated',false,'scopes',{{}});
try
    rootRead=read(model,'root'); eventId=findId(rootRead,'EventStep');
    eventRead=read(model,eventId); adcId=findId(eventRead,'Adc');
    adcRead=read(model,adcId);
    stageNames={'SampleRaAdvance','DacCtFeedback','Sar1TrialRaCt','ResidueCtCompare','SarDecisionTracking','ChargeReturnRaReset'};
    stageIds=cell(1,numel(stageNames)); oldStage=cell(1,numel(stageNames)); widths=zeros(1,numel(stageNames)); heights=widths;
    stagePorts=cell(1,numel(stageNames));
    for k=1:numel(stageNames)
        stageIds{k}=findId(adcRead,stageNames{k});
        [oldStage{k},widths(k),heights(k)]=positionAndSize(model,stageIds{k});
        stagePorts{k}=portSignature(model,stageIds{k});
    end
    stateNames={'SampleCharge','RaCtState','SarState'};
    stateIds=cell(1,3); oldState=cell(1,3); stateWidths=zeros(1,3); stateHeights=zeros(1,3);
    statePorts=cell(1,3);
    for k=1:numel(stateNames)
        stateIds{k}=findId(adcRead,stateNames{k});
        [oldState{k},stateWidths(k),stateHeights(k)]=positionAndSize(model,stateIds{k});
        statePorts{k}=portSignature(model,stateIds{k});
        pathName=pathFromId(model,stateIds{k});
        if ~strcmp(get_param(pathName,'BlockType'),'UnitDelay')
            error('sar20:layout:StateOwnerType','%s is not a UnitDelay.',stateNames{k});
        end
    end
    diagId=findId(adcRead,'Diagnostics'); [oldDiag,diagW,diagH]=positionAndSize(model,diagId);
    diagPorts=portSignature(model,diagId);
    % Use measured block sizes with deterministic spacing. The Stage row preserves
    % each block's actual width/height; state owners occupy a separate upper row.
    currentLeft=cellfun(@(x)x(1),oldStage); x0=max(80,min(currentLeft));
    stageY=max(320,median(cellfun(@(x)x(2),oldStage)));
    maxPortLoad=max(cellfun(@(x)max(x(1:2)),stagePorts));
    gapX=max(110,round(0.35*median(widths))+15*maxPortLoad);
    stagePositions=zeros(6,4); cursor=x0;
    for k=1:6
        stagePositions(k,:)=[cursor stageY cursor+widths(k) stageY+heights(k)];
        cursor=cursor+widths(k)+gapX;
    end
    maxStateH=max(stateHeights); stateY=max(25,stageY-maxStateH-180);
    stateCenters=[stagePositions(1,1)+widths(1)/2, ...
        stagePositions(3,1)+widths(3)/2, stagePositions(5,1)+widths(5)/2];
    statePositions=zeros(3,4);
    for k=1:3
        left=stateCenters(k)-stateWidths(k)/2;
        statePositions(k,:)=[left stateY left+stateWidths(k) stateY+stateHeights(k)];
    end
    diagY=stageY+max(heights)+160;
    diagPos=[x0 diagY x0+diagW diagY+diagH];

    ops={};
    for k=1:6
        ops{end+1}=struct('op','configure','target',stageIds{k}, ...
            'params',struct('Position',stagePositions(k,:))); %#ok<AGROW>
    end
    for k=1:3
        ops{end+1}=struct('op','configure','target',stateIds{k}, ...
            'params',struct('Position',statePositions(k,:))); %#ok<AGROW>
    end
    ops{end+1}=struct('op','configure','target',diagId,'params',struct('Position',diagPos));
    scopeBefore=adcRead;
    reply=char(model_edit(model,adcId,jsonencode(ops),'incremental'));
    if startsWith(strtrim(reply),'status: partial')||startsWith(strtrim(reply),'status: error')||startsWith(strtrim(reply),'status: failed')
        partialSave(model,privateModelPath,receipts,adcId,'layout_only',reply,scopeBefore);
    end
    adcAfter=read(model,adcId); check=char(model_check(model,adcId,'["unconnected_ports","unconnected_lines"]'));
    if contains(check,'status: has_errors')||contains(check,'severity: error')
        partialSave(model,privateModelPath,receipts,adcId,'layout_only_check',reply,scopeBefore,adcAfter,check);
    end
    actualStage=cell(1,6); actualState=cell(1,3);
    for k=1:6
        id=findId(adcAfter,stageNames{k}); [actualStage{k},~,~]=positionAndSize(model,id);
        if ~isequal(stagePorts{k},portSignature(model,id)),error('sar20:layout:PortsChanged','PortHandles changed for %s.',stageNames{k});end
        if any(abs(actualStage{k}-stagePositions(k,:))>1)
            error('sar20:layout:AutolayoutMoved','SATK autolayout changed requested position for %s.',stageNames{k});
        end
    end
    for k=1:3
        id=findId(adcAfter,stateNames{k}); [actualState{k},~,~]=positionAndSize(model,id);
        if ~isequal(statePorts{k},portSignature(model,id)),error('sar20:layout:PortsChanged','PortHandles changed for %s.',stateNames{k});end
        if any(abs(actualState{k}-statePositions(k,:))>1)
            error('sar20:layout:AutolayoutMoved','SATK autolayout changed requested position for %s.',stateNames{k});
        end
    end
    for k=1:numel(stageNames)
        currentId=findId(adcAfter,stageNames{k});
        if ~strcmp(currentId,stageIds{k}), error('sar20:layout:IdentityChanged','Stage SID changed for %s.',stageNames{k}); end
    end
    for k=1:numel(stateNames)
        currentId=findId(adcAfter,stateNames{k});
        if ~strcmp(currentId,stateIds{k}), error('sar20:layout:IdentityChanged','State owner SID changed for %s.',stateNames{k}); end
    end
    save_system(model);
    receipt.scopes={struct('name','adc_layout_only','scope',adcId, ...
        'model_read_before',scopeBefore,'model_edit',reply,'model_read_after',adcAfter, ...
        'model_check',check,'old_stage_positions',{oldStage},'new_stage_positions',stagePositions, ...
        'stage_port_counts_before',{stagePorts}, ...
        'old_state_positions',{oldState},'new_state_positions',statePositions, ...
        'state_port_counts_before',{statePorts},'diagnostics_old_position',oldDiag, ...
        'diagnostics_new_position',diagPos,'diagnostics_port_counts_before',diagPorts)};
    if opt.ColdOpenCompile
        shaBefore=sha256(privateModelPath); close_system(model,0); open_system(privateModelPath);
        set_param(model,'SimulationCommand','update');
        if ~strcmp(get_param(model,'SimulationStatus'),'stopped'),error('sar20:layout:Simulation','Update started a simulation.');end
        save_system(model); shaAfter=sha256(privateModelPath);
        receipt.cold_open_compile=struct('method','save -> close -> open -> SimulationCommand=update -> save', ...
            'sha_before',shaBefore,'sha_after',shaAfter,'simulation_started',false);
    end
    receipt.status='layout_candidate_saved'; receipt.output_sha256=sha256(privateModelPath);
    receiptPath=fullfile(receipts,'layout_stage_receipt.json'); writeJson(receiptPath,receipt); receipt.receipt_path=receiptPath;
    writeJson(receiptPath,receipt);
    if ~opt.KeepModelOpen&&bdIsLoaded(model),close_system(model,0);end
catch cause
    try
        save_system(model);
        partial=partialSnapshot(privateModelPath,receipts,'layout_failure');
        receipt.status='partial_private_saved'; receipt.partial_snapshot=partial;
    catch saveCause
        receipt.status='partial_not_persisted'; receipt.save_error=getReport(saveCause,'extended','hyperlinks','off');
    end
    receipt.error=getReport(cause,'extended','hyperlinks','off');
    writeJson(fullfile(receipts,'layout_stage_receipt.json'),receipt);
    rethrow(cause);
end
end

function [pos,w,h]=positionAndSize(model,id)
p=pathFromId(model,id); pos=double(get_param(p,'Position')); w=pos(3)-pos(1); h=pos(4)-pos(2);
if numel(pos)~=4||w<=0||h<=0,error('sar20:layout:BlockSize','Cannot read valid Position for %s.',id);end
end
function sig=portSignature(model,id)
% Read actual PortHandles before/after layout; no PortHandles are changed.
p=pathFromId(model,id); h=get_param(p,'PortHandles');
fields={'Inport','Outport','Enable','Trigger'}; sig=zeros(1,numel(fields));
for k=1:numel(fields)
    if isfield(h,fields{k}), sig(k)=numel(h.(fields{k})); end
end
end
function r=read(model,scope)
r=char(model_read(model,scope,'0'));
if ~startsWith(strtrim(r),'status: ok')&&~startsWith(strtrim(r),'status: success'),error('sar20:layout:Read','model_read failed in %s: %s',scope,r);end
end
function id=findId(report,name)
lines=splitlines(string(report)); cur=''; hits={};
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t),cur=t{1};continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(cur),hits{end+1}=cur;cur='';end %#ok<AGROW>
end
hits=unique(hits,'stable'); if numel(hits)~=1,error('sar20:layout:Resolve','Expected one ID for %s, got %d.',name,numel(hits));end
id=hits{1};
end
function p=pathFromId(model,id)
p=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
function c=canonical(p)
try,c=char(java.io.File(char(p)).getCanonicalPath());catch,c=char(p);end
end
function h=sha256(p)
f=fopen(p,'rb');if f<0,error('sar20:layout:HashOpen','Cannot read %s.',p);end
cl=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while true,x=fread(f,1024*1024,'*uint8');if isempty(x),break;end;md.update(x);end
b=typecast(md.digest(),'uint8');h=lower(reshape(dec2hex(b,2).',1,[]));
end
function partialSave(model,pathName,receipts,scope,label,reply,before,varargin)
saveErr='';try,save_system(model);catch e,saveErr=getReport(e,'extended','hyperlinks','off');end
post='';check='';
try,post=char(model_read(model,scope,'0'));catch e,post=getReport(e,'extended','hyperlinks','off');end
try,check=char(model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));catch e,check=getReport(e,'extended','hyperlinks','off');end
if ~isempty(saveErr),error('sar20:layout:PartialSaveFailed','Layout partial not saved: %s',saveErr);end
snap=partialSnapshot(pathName,receipts,label);
r=struct('status','partial_private_saved','scope',scope,'model_read_before',before, ...
    'model_edit',reply,'model_read_after_partial',post,'model_check_after_partial',check,'partial_snapshot',snap);
writeJson(fullfile(receipts,'layout_stage_receipt.json'),r);
error('sar20:layout:PartialStop','Layout stage stopped; private SHA=%s. Root must resume from this fresh read/checkpoint.',snap.sha256);
end
function s=partialSnapshot(pathName,receipts,label)
p=fullfile(receipts,[label '_' datestr(now,'yyyymmddTHHMMSS') '.slx']);[ok,msg]=copyfile(pathName,p,'f');if ~ok,error('sar20:layout:PartialCopy','%s',msg);end
s=struct('path',p,'sha256',sha256(p),'candidate_sha256',sha256(pathName));
if ~strcmpi(s.sha256,s.candidate_sha256),error('sar20:layout:PartialHash','Snapshot hash mismatch.');end
end
function writeJson(p,v)
f=fopen(p,'w','n','UTF-8');if f<0,error('sar20:layout:Receipt','Cannot write %s',p);end
cl=onCleanup(@()fclose(f)); %#ok<NASGU>
fwrite(f,jsonencode(v,'PrettyPrint',true),'char');fwrite(f,newline,'char');
end
