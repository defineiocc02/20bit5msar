function receipt = sar20_debug_regression(stage, cfg)
%SAR20_DEBUG_REGRESSION Native staged regression for the SAR20 debug view.
% This driver is intentionally kept outside the production SAR20 tree.
% It only uses a pinned N256 run as the reference, then runs the candidate
% model in an isolated MATLAB worker with SimulationInput overrides.
%
% Stages (each requires a fresh cfg.output_dir):
%   preflight      Pin/read reference files; no model load or simulation.
%   coldopen       Load candidate, resolve explicit SIDs, compile/update only.
%   smoke_n8       Run 8 selected records (12 cycles incl. first_id=4) and save
%                  the candidate run; follow with offline on its run_dir.
%   final_n256      Run the pinned N256 P with only declared P.debug overrides;
%                  follow with offline for full baseline and state-trace checks.
%   offline         Read an existing candidate run, compare native logs/roots/
%                  records, and validate the sample-5 observer trace; no model load.
%
% Required cfg fields:
%   baseline_id_file, baseline_manifest_file, baseline_source_zip,
%   reference_run_dir, candidate_root, output_dir.
% Optional fields:
%   candidate_model_file, expected_candidate_sha256, state_owner_map,
%   root_port_map, trace_contract_file, debug_overrides, allowed_debug_paths,
%   run_dir. expected_candidate_sha256 is mandatory for both simulation stages.

    if nargin < 2 || isempty(cfg)
        error('sar20debug:ConfigRequired','Pass an explicit isolated-worker configuration struct or JSON file.');
    end
    cfg = normalize_config(cfg);
    stage = lower(char(stage));
    supported = {'preflight','coldopen','smoke_n8','final_n256','offline'};
    assert(any(strcmp(stage,supported)), 'sar20debug:Stage', 'Unknown stage: %s.', stage);
    runDir = prepare_output_dir(cfg.output_dir);
    startedUtc = utc_now();
    receipt = base_receipt(stage,cfg,runDir,startedUtc);
    write_json(fullfile(runDir,'driver_receipt.json'),receipt);

    try
        ref = verify_reference(cfg);
        receipt.reference = ref.receipt;
        receipt.status = 'preflight_pass';
        write_json(fullfile(runDir,'driver_receipt.json'),receipt);

        switch stage
            case 'preflight'
                receipt.status = 'passed';
                receipt.simulation_run = false;
                receipt.candidate_model = candidate_identity(cfg);
                receipt = finish_receipt(receipt,runDir);
                return;

            case 'coldopen'
                [receipt.candidate_model, receipt.state_owners, receipt.root_ports] = ...
                    coldopen_compile(cfg,ref.P,runDir);
                receipt.status = 'passed';
                receipt.simulation_run = false;
                receipt.compile_only = true;
                receipt = finish_receipt(receipt,runDir);
                return;

            case 'smoke_n8'
                mode = 'prefix';
                P = make_run_parameters(ref.P,cfg,'smoke_n8');

            case 'final_n256'
                mode = 'full';
                P = make_run_parameters(ref.P,cfg,'final_n256');

            case 'offline'
                assert(isfield(cfg,'run_dir') && isfolder(cfg.run_dir), ...
                    'sar20debug:RunDir','offline requires cfg.run_dir pointing to a saved candidate run.');
                assert(isfield(cfg,'trace_contract_file')&&isfile(cfg.trace_contract_file), ...
                    'sar20debug:TraceContract','offline requires the frozen trace contract.');
                mode = saved_run_mode(cfg.run_dir,cfg.max_file_bytes);
                [receipt.comparison,receipt.trace] = offline_check(cfg,ref,cfg.run_dir,mode,runDir);
                receipt.status = receipt.comparison.status;
                receipt.simulation_run = false;
                receipt.mat_files = mat_inventory(cfg.run_dir);
                receipt = finish_receipt(receipt,runDir);
                return;
        end

        if any(strcmp(stage,{'smoke_n8','final_n256'}))
            contract = read_trace_contract(cfg);
            receipt.trace_contract_sha256=file_sha256_value(cfg.trace_contract_file,cfg.max_file_bytes);
            verify_trace_window(contract);
            enforce_trace_size_bound(contract,ref.receipt.simout_bytes);
        else
            contract = read_trace_contract_optional(cfg);
        end

        [candidate, stateOwners, rootPorts, elapsed, runPath] = ...
            run_candidate(cfg,P,stage,runDir,contract);
        receipt.candidate_model = candidate;
        receipt.state_owners = stateOwners;
        receipt.root_ports = rootPorts;
        receipt.sim_elapsed_seconds = elapsed;
        receipt.candidate_run_dir = runPath;
        receipt.simulation_run = true;
        receipt.mat_files = mat_inventory(runPath);
        receipt.status = 'simulation_saved_offline_pending';
        receipt = finish_receipt(receipt,runDir);
    catch err
        receipt.status = 'failed';
        receipt.failure_identifier = err.identifier;
        receipt.failure_message = err.message;
        receipt.failure_stage = stage;
        partialRun=fullfile(runDir,'native_run');
        if isfolder(partialRun)
            try,receipt.partial_run_mat_files=mat_inventory(partialRun);catch,end
        end
        if isfield(cfg,'run_dir')&&isfolder(cfg.run_dir)
            try,receipt.saved_run_mat_files=mat_inventory(cfg.run_dir);catch,end
        end
        receipt = finish_receipt(receipt,runDir);
        rethrow(err);
    end
end

function cfg = normalize_config(cfg)
    if (ischar(cfg) && isrow(cfg)) || (isstring(cfg) && isscalar(cfg))
        cfg = jsondecode(fileread(char(cfg)));
    end
    assert(isstruct(cfg)&&isscalar(cfg),'sar20debug:Config','cfg must be a scalar struct or JSON path.');
    required = {'baseline_id_file','baseline_manifest_file','baseline_source_zip', ...
        'reference_run_dir','candidate_root','output_dir'};
    for k=1:numel(required)
        assert(isfield(cfg,required{k})&&~isempty(cfg.(required{k})), ...
            'sar20debug:ConfigField','cfg.%s is required.',required{k});
    end
    cfg.baseline_id_file = char(cfg.baseline_id_file);
    cfg.baseline_manifest_file = char(cfg.baseline_manifest_file);
    cfg.baseline_source_zip = char(cfg.baseline_source_zip);
    cfg.reference_run_dir = char(cfg.reference_run_dir);
    cfg.candidate_root = char(cfg.candidate_root);
    cfg.output_dir = char(cfg.output_dir);
    if ~isfield(cfg,'candidate_model_file') || isempty(cfg.candidate_model_file)
        cfg.candidate_model_file = fullfile(cfg.candidate_root,'current','models','SarAdc.slx');
    else
        cfg.candidate_model_file = char(cfg.candidate_model_file);
    end
    if ~isfield(cfg,'max_file_bytes'),cfg.max_file_bytes=300e6;end
    if ~isfield(cfg,'model_name'),cfg.model_name='SarAdc';end
    if ~isfield(cfg,'state_owner_map') || isempty(cfg.state_owner_map)
        cfg.state_owner_map = default_state_owner_map();
    end
    if ~isfield(cfg,'root_port_map') || isempty(cfg.root_port_map)
        cfg.root_port_map = default_root_port_map();
    end
    if ~isfield(cfg,'allowed_debug_paths'),cfg.allowed_debug_paths={};end
    if isstring(cfg.allowed_debug_paths),cfg.allowed_debug_paths=cellstr(cfg.allowed_debug_paths);end
    if ~isfield(cfg,'debug_overrides'),cfg.debug_overrides=struct();end
    if ~isfield(cfg,'smoke_records'),cfg.smoke_records=8;end
    assert(cfg.max_file_bytes>0&&cfg.max_file_bytes<=300e6, ...
        'sar20debug:FileCap','max_file_bytes must be <= 300 MB.');
end

function receipt = base_receipt(stage,cfg,runDir,startedUtc)
    matlabInfo=ver('MATLAB');
    receipt = struct('schema','sar20-native-debug-regression/v1', ...
        'stage',stage,'status','started','started_utc',startedUtc, ...
        'output_dir',runDir,'simulation_run',false, ...
        'matlab',struct('version',matlabInfo.Version,'release',matlabInfo.Release,'computer',computer), ...
        'production_model_write','forbidden_and_not_attempted', ...
        'gui_evidence','not_claimed; native GUI actions are recorded by the Windows operator only');
end

function outDir = prepare_output_dir(outDir)
    outDir = char(outDir);
    assert(~isfile(outDir)&&~isfolder(outDir),'sar20debug:OutputExists', ...
        'Refuse to reuse or overwrite output directory: %s.',outDir);
    [ok,msg,msgid] = mkdir(outDir);
    assert(ok&&isempty(msgid),'sar20debug:OutputCreate','Cannot create output directory: %s',msg);
end

function ref = verify_reference(cfg)
    bounded_file(cfg.baseline_id_file,cfg.max_file_bytes);
    bounded_file(cfg.baseline_manifest_file,cfg.max_file_bytes);
    bounded_file(cfg.baseline_source_zip,cfg.max_file_bytes);
    id = jsondecode(fileread(cfg.baseline_id_file));
    active = jsondecode(fileread(cfg.baseline_manifest_file));
    assert(isfolder(cfg.reference_run_dir),'sar20debug:ReferenceRun','Missing pinned reference run directory.');
    names = {'SarAdc.slx','parameters.mat','parameters.json','simout.mat', ...
        'selected.mat','summary.json','source.zip','source_manifest.json'};
    hashes = struct(); sizes = struct();
    for k=1:numel(names)
        f = fullfile(cfg.reference_run_dir,names{k});
        [hashes.(matlab.lang.makeValidName(names{k})),sizes.(matlab.lang.makeValidName(names{k}))] = ...
            file_sha256(f,cfg.max_file_bytes);
    end
    summary = jsondecode(fileread(fullfile(cfg.reference_run_dir,'summary.json')));
    sourceManifest = jsondecode(fileread(fullfile(cfg.reference_run_dir,'source_manifest.json')));
    loadedP = load(fullfile(cfg.reference_run_dir,'parameters.mat'),'P');
    selectedFile = load(fullfile(cfg.reference_run_dir,'selected.mat'),'selected');
    assert(isfield(loadedP,'P')&&isstruct(loadedP.P)&&isscalar(loadedP.P), ...
        'sar20debug:ReferenceP','Reference parameters.mat has no scalar P.');
    assert(isfield(selectedFile,'selected')&&isstruct(selectedFile.selected), ...
        'sar20debug:ReferenceSelected','Reference selected.mat has no selected struct.');
    P = loadedP.P; S = selectedFile.selected;

    assert(strcmp(id.model_sha256,summary.model_sha256)&& ...
        strcmp(summary.model_sha256,hashes.SarAdc_slx), ...
        'sar20debug:ModelPin','Reference model identity is not the pinned 9197 baseline.');
    assert(strcmp(active.schema,'sar20-active-normal/v1')&&active.N==256&& ...
        strcmp(active.model_sha256,id.model_sha256), ...
        'sar20debug:ActiveManifest','BASELINE_MANIFEST does not declare the pinned normal N256 model.');
    assert(strcmp(summary.model_sha256,'91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e'), ...
        'sar20debug:ModelPin','Reference model SHA differs from the authorized 91973cf baseline.');
    assert(strcmp(id.active_manifest_sha256,file_sha256_value(cfg.baseline_manifest_file,cfg.max_file_bytes)), ...
        'sar20debug:ManifestPin','BASELINE_MANIFEST does not match BASELINE_ID.');
    assert(strcmp(id.source_model_backup_sha256,file_sha256_value(cfg.baseline_source_zip,cfg.max_file_bytes)), ...
        'sar20debug:SourceArchivePin','Pinned baseline source/model archive SHA mismatch.');
    assert(strcmp(summary.status,'complete')&&summary.simulation_completed, ...
        'sar20debug:ReferenceStatus','Reference run is not marked complete.');
    assert(summary.records==256&&summary.global_rng_unchanged, ...
        'sar20debug:ReferenceRunFacts','Pinned reference must contain 256 records and preserve MATLAB global RNG.');
    assert(strcmp(summary.config_sha256,hashes.parameters_mat), ...
        'sar20debug:ConfigPin','Actual parameters.mat SHA differs from summary.');
    assert(strcmp(summary.selected_sha256,hashes.selected_mat), ...
        'sar20debug:SelectedPin','Actual selected.mat SHA differs from summary.');
    assert(strcmp(summary.source_zip_sha256,hashes.source_zip), ...
        'sar20debug:RunSourcePin','Actual source.zip SHA differs from summary.');
    assert(strcmp(summary.config_sha256,'aa9f8f6d97108fbfae66701e8d09db123940a1b5f1b75fc9187c9b0203aba3c3'), ...
        'sar20debug:ConfigPin','Reference P SHA differs from the public N256 release.');
    assert(isequal(size(S.raw),[256 6])&&numel(S.code20)==256&&numel(S.time_s)==256, ...
        'sar20debug:SelectedShape','Reference selected output must contain 256 rows.');
    assert(isequal(S.raw(:,4),(4:259).')&&all(S.raw(:,5)==1)&&all(S.raw(:,6)==1), ...
        'sar20debug:SelectedIDs','Reference RAW ID/epoch/valid sequence does not match IDs 4..259.');
    assert(all(isfinite(S.code20(:))&S.code20(:)==floor(S.code20(:))& ...
        S.code20(:)>=0&S.code20(:)<2^20), ...
        'sar20debug:SelectedCodes','Reference contains invalid integer output codes.');
    assert(strcmp(P.schema,'sar20-behavior/v1')&&P.N==256&&P.n_cycles==260&& ...
        P.first_id==4&&P.seed==20261020&&P.Ts_s==200e-9&&P.fs_hz==5e6&& ...
        P.input.frequency_hz==97656.25&&P.input.amplitude_v==4.456254690668728, ...
        'sar20debug:ReferenceP','Reference physical configuration is not the pinned normal N256 run.');
    assert(numel(P.groups)==48&&P.epoch==1&&P.stop_time_s==5.189e-5, ...
        'sar20debug:ReferenceCalendar','Reference event calendar/cycle window differs from pinned release.');
    assert(isequal(double(S.raw(2,:)),[1924 2473 19 5 1 1])&&double(S.code20(2))==979623, ...
        'sar20debug:Sample5Pin','Reference sample ID 5 RAW/code fingerprint mismatch.');
    assert(numel(summary.sample_ids)==256&&isequal(double(summary.sample_ids(:)),(4:259).'), ...
        'sar20debug:SummaryIDs','Readable summary sample IDs disagree with selected.mat.');
    assert(isequal(double(summary.raw_words),double(S.raw))&& ...
        isequal(double(summary.code20(:)),double(S.code20(:))), ...
        'sar20debug:SummarySelected','Readable summary code/RAW projection disagrees with selected.mat.');
    check_manifest_rows(sourceManifest,summary.source_files);
    ref = struct('P',P,'selected',S,'summary',summary,'source_manifest',sourceManifest, ...
        'simout_path',fullfile(cfg.reference_run_dir,'simout.mat'), ...
        'receipt',struct('run_id','behavior_12d08121-d679-40cd-9ee2-bc334ff42955', ...
        'model_sha256',hashes.SarAdc_slx,'config_sha256',hashes.parameters_mat, ...
        'selected_sha256',hashes.selected_mat,'simout_sha256',hashes.simout_mat, ...
        'simout_bytes',sizes.simout_mat,'source_zip_sha256',hashes.source_zip, ...
        'source_manifest_sha256',hashes.source_manifest_json, ...
        'active_manifest_sha256',file_sha256_value(cfg.baseline_manifest_file,cfg.max_file_bytes), ...
        'baseline_source_archive_sha256',file_sha256_value(cfg.baseline_source_zip,cfg.max_file_bytes), ...
        'elapsed_seconds',summary.elapsed_s,'mat_files',mat_inventory(cfg.reference_run_dir), ...
        'N',P.N,'n_cycles',P.n_cycles,'first_id',P.first_id,'seed',P.seed, ...
        'sample5_raw',S.raw(2,:),'sample5_code20',S.code20(2),'selected_rows',size(S.raw,1)));
end

function check_manifest_rows(sourceManifest,summaryRows)
    assert(isfield(sourceManifest,'files')&&numel(sourceManifest.files)==numel(summaryRows), ...
        'sar20debug:SourceManifest','Run source manifest and summary file inventory lengths differ.');
    for k=1:numel(summaryRows)
        assert(strcmp(sourceManifest.files(k).path,summaryRows(k).path)&& ...
            strcmp(sourceManifest.files(k).sha256,summaryRows(k).sha256), ...
            'sar20debug:SourceManifest','Source manifest row %d differs from the as-run summary.',k);
    end
end

function [modelInfo,ownerInfo,portInfo] = coldopen_compile(cfg,P,runDir)
    originalModelHash = file_sha256_value(cfg.candidate_model_file,cfg.max_file_bytes);
    sourceBefore = candidate_source_inventory(cfg);
    write_json(fullfile(runDir,'candidate_source_manifest.json'),sourceBefore);
    assert(bdIsLoaded(cfg.model_name)==0,'sar20debug:ModelAlreadyLoaded', ...
        'Refuse to attach to a preloaded same-name model; run this stage in the isolated scheduler worker.');
    oldPath = path; pathGuard = onCleanup(@()path(oldPath)); %#ok<NASGU>
    install_candidate_path(cfg);
    load_system(cfg.candidate_model_file);
    modelGuard = onCleanup(@()close_no_save(cfg.model_name)); %#ok<NASGU>
    assert(strcmp(get_param(cfg.model_name,'FileName'),cfg.candidate_model_file)|| ...
        same_canonical_path(get_param(cfg.model_name,'FileName'),cfg.candidate_model_file), ...
        'sar20debug:WrongModel','Loaded model is not the candidate file.');
    Pcompile = make_run_parameters(P,cfg,'final_n256');
    ws = get_param(cfg.model_name,'ModelWorkspace');
    ws.assignin('P',Pcompile);ws.assignin('DecodeP',Pcompile.digital);ws.assignin('TrainCaptureFile','');
    ownerInfo = verify_state_owners(cfg,cfg.model_name,Pcompile);
    portInfo = verify_root_ports(cfg,cfg.model_name);
    set_param(cfg.model_name,'SimulationCommand','update');
    assert(strcmp(file_sha256_value(cfg.candidate_model_file,cfg.max_file_bytes),originalModelHash), ...
        'sar20debug:ModelMutated','Cold open/compile changed the candidate SLX on disk.');
    sourceAfter = candidate_source_inventory(cfg);
    write_json(fullfile(runDir,'candidate_source_after_compile.json'),sourceAfter);
    assert(strcmp(sourceBefore.tree_sha256,sourceAfter.tree_sha256), ...
        'sar20debug:SourceMutated','Cold open/compile changed a candidate source file on disk.');
    modelInfo = candidate_identity(cfg);
    modelInfo.compile = 'passed';modelInfo.compile_only = true;
    modelInfo.source_tree_sha256 = sourceAfter.tree_sha256;
    write_json(fullfile(runDir,'compile_receipt.json'),struct('status','passed', ...
        'candidate_model',modelInfo,'state_owners',ownerInfo,'root_ports',portInfo, ...
        'simulation_run',false,'model_file_sha256_after',originalModelHash));
end

function P = make_run_parameters(baseP,cfg,stage)
    P = baseP;
    if strcmp(stage,'smoke_n8')
        assert(cfg.smoke_records==8,'sar20debug:SmokeN','Only the declared N8 smoke is supported.');
        P.N=8;
        P.n_cycles=P.first_id+P.N;
        assert(isfield(P,'groups')&&~isempty(P.groups),'sar20debug:SmokeCalendar','Missing actual groups.');
        P.stop_time_s=(P.n_cycles-1)*P.Ts_s+P.groups(end).time_s;
    elseif strcmp(stage,'final_n256')
        assert(P.N==256&&P.n_cycles==260&&P.stop_time_s==5.189e-5, ...
            'sar20debug:FinalN256','Final run must keep the actual archived N256 extent.');
    end
    if ~isempty(fieldnames(cfg.debug_overrides))
        assert(isfield(P,'debug')&&isstruct(P.debug)&&isscalar(P.debug), ...
            'sar20debug:DebugNamespace','The baseline P.debug namespace is missing.');
        P.debug=merge_struct(P.debug,cfg.debug_overrides);
    end
    allowed = cfg.allowed_debug_paths;
    if strcmp(stage,'smoke_n8')
        allowed = [allowed {'P.N','P.n_cycles','P.stop_time_s'}];
    end
    diffs = diff_paths(baseP,P,'P');
    unexpected = {};
    for k=1:numel(diffs)
        if ~allowed_path(diffs{k},allowed),unexpected{end+1}=diffs{k};end %#ok<AGROW>
    end
    assert(isempty(unexpected),'sar20debug:PhysicalPChanged', ...
        'Only declared P.debug paths and N8 extent may differ; unexpected: %s.',strjoin(unexpected,', '));
    if strcmp(stage,'smoke_n8')
        assert(P.input.frequency_hz==baseP.input.frequency_hz&&P.seed==baseP.seed&& ...
            isequaln(P.front,baseP.front)&&isequaln(P.backend,baseP.backend)&& ...
            isequaln(P.control,baseP.control), ...
            'sar20debug:SmokePhysics','N8 smoke altered physical settings, input, or seed.');
    end
    assert(P.seed==20261020&&P.first_id==4&&P.epoch==1&&numel(P.groups)==48, ...
        'sar20debug:InputIdentity','Input seed, event calendar or ID window differs from the reference.');
end

function [modelInfo,ownerInfo,portInfo,elapsed,runPath] = run_candidate(cfg,P,stage,stageDir,contract)
    runPath = fullfile(stageDir,'native_run');
    assert(~isfolder(runPath)&&~isfile(runPath),'sar20debug:RunExists','Refuse to overwrite native_run directory.');
    [ok,msg,msgid]=mkdir(runPath);assert(ok&&isempty(msgid),'sar20debug:RunCreate','%s',msg);
    modelHash = file_sha256_value(cfg.candidate_model_file,cfg.max_file_bytes);
    traceContractHash = trace_contract_sha(cfg);
    sourceBefore = candidate_source_inventory(cfg);
    write_json(fullfile(runPath,'candidate_source_manifest.json'),sourceBefore);
    if isfield(cfg,'expected_candidate_sha256')&&~isempty(cfg.expected_candidate_sha256)
        assert(strcmpi(modelHash,char(cfg.expected_candidate_sha256)), ...
            'sar20debug:CandidatePin','Candidate model SHA differs from the frozen candidate manifest.');
    end
    assert(~strcmpi(modelHash,'91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e')&& ...
        isfield(cfg,'expected_candidate_sha256')&&~isempty(cfg.expected_candidate_sha256), ...
        'sar20debug:CandidatePin','A frozen debug candidate model SHA is required; the plain 9197 baseline cannot be used as candidate.');
    assert(bdIsLoaded(cfg.model_name)==0,'sar20debug:ModelAlreadyLoaded', ...
        'Refuse to attach to a preloaded same-name model; run this stage in the isolated scheduler worker.');
    oldPath=path;pathGuard=onCleanup(@()path(oldPath)); %#ok<NASGU>
    install_candidate_path(cfg);
    load_system(cfg.candidate_model_file);
    modelGuard=onCleanup(@()close_no_save(cfg.model_name)); %#ok<NASGU>
    ownerInfo=verify_state_owners(cfg,cfg.model_name,P);
    portInfo=verify_root_ports(cfg,cfg.model_name);
    check_trace_namespace(contract,cfg,P,stage);
    save(fullfile(runPath,'parameters.mat'),'P','-v7.3');
    modelSnapshot=fullfile(runPath,'SarAdc.slx');
    [ok,msg]=copyfile(cfg.candidate_model_file,modelSnapshot);assert(ok,'sar20debug:Snapshot','%s',msg);
    assert(strcmp(file_sha256_value(modelSnapshot,cfg.max_file_bytes),modelHash), ...
        'sar20debug:SnapshotHash','Candidate model snapshot changed during copy.');
    simInput=Simulink.SimulationInput(cfg.model_name);
    simInput=simInput.setVariable('P',P,'Workspace',cfg.model_name);
    simInput=simInput.setVariable('DecodeP',P.digital,'Workspace',cfg.model_name);
    simInput=simInput.setVariable('TrainCaptureFile','','Workspace',cfg.model_name);
    simInput=simInput.setModelParameter('ReturnWorkspaceOutputs','on', ...
        'CaptureErrors','on','StartTime','0','StopTime',sprintf('%.17g',P.stop_time_s));
    rngBefore=rng;
    timer=tic;
    simout=[];
    try
        simout=sim(simInput);
    catch err
        elapsed=toc(timer);
        if ~isempty(simout),save(fullfile(runPath,'simout.mat'),'simout','-v7.3');end
        write_json(fullfile(runPath,'simulation_failure.json'),struct('status','sim_call_threw', ...
            'identifier',err.identifier,'message',err.message,'elapsed_seconds',elapsed, ...
            'partial_simout_saved',~isempty(simout)));
        rethrow(err);
    end
    elapsed=toc(timer);
    % Save the actual output before any post-run check; errors keep this file.
    save(fullfile(runPath,'simout.mat'),'simout','-v7.3');
    rngUnchanged=isequal(rngBefore,rng);
    assert(rngUnchanged,'sar20debug:RngMutation','MATLAB global RNG changed during model execution.');
    if isprop(simout,'ErrorMessage')&&~isempty(simout.ErrorMessage)
        write_json(fullfile(runPath,'simulation_failure.json'),struct('status','simout_error', ...
            'message',simout.ErrorMessage,'elapsed_seconds',elapsed,'partial_simout_saved',true));
        error('sar20debug:SimulationError','SimulationOutput ErrorMessage: %s',simout.ErrorMessage);
    end
    assert(strcmp(file_sha256_value(cfg.candidate_model_file,cfg.max_file_bytes),modelHash), ...
        'sar20debug:ModelMutated','Simulation changed the candidate SLX on disk.');
    assert(strcmp(traceContractHash,trace_contract_sha(cfg)), ...
        'sar20debug:TraceContractMutated','Frozen observer contract changed during model execution.');
    sourceAfter = candidate_source_inventory(cfg);
    write_json(fullfile(runPath,'candidate_source_after_simulation.json'),sourceAfter);
    assert(strcmp(sourceBefore.tree_sha256,sourceAfter.tree_sha256), ...
        'sar20debug:SourceMutated','Simulation changed a candidate source file on disk.');
    modelInfo=candidate_identity(cfg);modelInfo.sim_model_sha256=modelHash;
    modelInfo.source_tree_sha256=sourceAfter.tree_sha256;
    modelInfo.run_stage=stage;modelInfo.sim_elapsed_seconds=elapsed;
    modelInfo.global_rng_unchanged=rngUnchanged;
    save(fullfile(runPath,'parameters.mat'),'P','-v7.3');
    configHash=file_sha256_value(fullfile(runPath,'parameters.mat'),cfg.max_file_bytes);
    write_json(fullfile(runPath,'summary.json'),struct('schema','sar20-debug-native-run/v1', ...
        'action','run','status','complete','simulation_completed',true, ...
        'run_path',runPath,'model_sha256',modelHash,'config_sha256',configHash, ...
        'reference_run_id','behavior_12d08121-d679-40cd-9ee2-bc334ff42955', ...
        'N',P.N,'n_cycles',P.n_cycles,'first_id',P.first_id,'epoch',P.epoch, ...
        'seed',P.seed,'sample_id_for_full_trace',5,'next_cnv_id',6, ...
        'elapsed_s',elapsed,'global_rng_unchanged',rngUnchanged));
    write_json(fullfile(runPath,'native_run_receipt.json'),struct('status','simulated', ...
        'run_stage',stage,'model_sha256',modelHash,'sim_elapsed_seconds',elapsed, ...
        'global_rng_unchanged',rngUnchanged,'reference_run_id','behavior_12d08121-d679-40cd-9ee2-bc334ff42955', ...
        'sample_id_for_full_trace',5,'expected_next_cnv_id',6, ...
        'candidate_source_tree_sha256',sourceAfter.tree_sha256, ...
        'trace_contract_sha256',traceContractHash, ...
        'gui_actions','not attempted by this headless/native driver'));
end

function [comparison,traceResult] = offline_check(cfg,ref,runPath,mode,auditDir)
    % No model load, sim(), state stepping, random calls, or writes to runPath.
    bounded_file(fullfile(runPath,'simout.mat'),cfg.max_file_bytes);
    bounded_file(fullfile(runPath,'parameters.mat'),cfg.max_file_bytes);
    saved=load(fullfile(runPath,'simout.mat'),'simout');
    pfile=load(fullfile(runPath,'parameters.mat'),'P');
    assert(isfield(saved,'simout')&&isa(saved.simout,'Simulink.SimulationOutput'), ...
        'sar20debug:OfflineOutput','Candidate simout.mat lacks an actual SimulationOutput.');
    assert(isfield(pfile,'P')&&isstruct(pfile.P),'sar20debug:OfflineP','Missing saved actual candidate P.');
    candidateOut=saved.simout;candidateP=pfile.P;
    stageForP='final_n256';if strcmp(mode,'prefix'),stageForP='smoke_n8';end
    expectedP=make_run_parameters(ref.P,cfg,stageForP);
    assert(isequaln(candidateP,expectedP),'sar20debug:OfflineParameterPin', ...
        'Saved candidate P differs from the pinned physical P plus declared debug namespace/extent.');
    baselineFile=load(ref.simout_path,'simout');
    assert(isfield(baselineFile,'simout')&&isa(baselineFile.simout,'Simulink.SimulationOutput'), ...
        'sar20debug:BaselineOutput','Pinned baseline simout.mat lacks SimulationOutput.');
    baselineOut=baselineFile.simout;

    oldPath=path;pathGuard=onCleanup(@()path(oldPath)); %#ok<NASGU>
    install_candidate_path(cfg);
    verify_source_resolution(cfg);
    comparison=sar20_debug_compare_native(baselineOut,candidateOut,mode,cfg.root_port_map);
    comparison.state_initial_vectors=compare_initial_state_vectors(ref.P,candidateP);
    Vcandidate=behavior_record_view(candidateOut,candidateP);
    Vbaseline=behavior_record_view(baselineOut,smoke_extent(ref.P,candidateP));
    comparison.record_stream=compare_record_views(Vbaseline,Vcandidate,candidateP,mode,ref.selected);
    D=behavior_sample_debug(candidateOut,candidateP,5);
    comparison.sample5=verify_sample5_events(D,candidateP);
    write_json(fullfile(auditDir,'offline_comparison.json'),struct('status','checking', ...
        'mode',mode,'comparison',comparison,'trace',struct('status','not_checked')));
    assert(comparison.legacy_logs.missing_required_count==0&&comparison.legacy_logs.missing_count==0&& ...
        comparison.legacy_logs.mismatch_count==0, ...
        'sar20debug:LegacyMismatch','Legacy native logger mismatch; see comparison receipt.');
    assert(strcmp(comparison.tout.status,'passed'), ...
        'sar20debug:ToutMismatch','Native solver tout differs; see comparison receipt.');
    assert(strcmp(comparison.root_output_ports.status,'passed'), ...
        'sar20debug:RootPorts','One or more top-level output ports did not match bit-exactly.');
    assert(strcmp(comparison.state_initial_vectors.status,'passed'), ...
        'sar20debug:InitialRoots','One or more FE/RA/SAR initial-state root vectors changed.');
    assert(strcmp(comparison.record_stream.status,'passed'), ...
        'sar20debug:RecordMismatch','RAW identity/validity/integer code stream mismatch.');
    assert(strcmp(comparison.sample5.status,'passed'), ...
        'sar20debug:Sample5Events','Sample 5 actual 48-event contract failed.');

    traceResult=struct('status','not_checked','reason','Trace contract was not requested for this stage.');
    if isfield(cfg,'trace_contract_file')&&isfile(cfg.trace_contract_file)
        contract=read_trace_contract(cfg);
        runReceipt=jsondecode(fileread(fullfile(runPath,'native_run_receipt.json')));
        assert(isfield(runReceipt,'trace_contract_sha256')&& ...
            strcmp(runReceipt.trace_contract_sha256,trace_contract_sha(cfg)), ...
            'sar20debug:TraceContractPin','Trace contract changed between simulation and offline analysis.');
        traceResult=run_trace_validator(cfg,contract,candidateOut,candidateP,runPath);
        assert(strcmp(traceResult.status,'passed'), ...
            'sar20debug:TraceMismatch','Full state/decision trace validation did not pass.');
    end
    comparison.status='passed';
    comparison.reference_model_sha256=ref.receipt.model_sha256;
    comparison.candidate_model_sha256=file_sha256_value(cfg.candidate_model_file,cfg.max_file_bytes);
    comparison.full_trace_status=traceResult.status;
    refMat=ref.receipt.mat_files;candidateMat=mat_inventory(runPath);
    comparison.mat_volume=struct('reference_total_bytes',refMat.total_mat_bytes, ...
        'candidate_total_bytes',candidateMat.total_mat_bytes, ...
        'delta_bytes',candidateMat.total_mat_bytes-refMat.total_mat_bytes, ...
        'reference_simout_bytes',ref.receipt.simout_bytes, ...
        'candidate_simout_bytes',file_size(fullfile(runPath,'simout.mat'),cfg.max_file_bytes), ...
        'simout_delta_bytes',file_size(fullfile(runPath,'simout.mat'),cfg.max_file_bytes)-ref.receipt.simout_bytes, ...
        'reference_files',refMat.files,'candidate_files',candidateMat.files, ...
        'per_file_cap_bytes',300e6);
    runReceiptPath=fullfile(runPath,'native_run_receipt.json');
    if isfile(runReceiptPath)
        rr=jsondecode(fileread(runReceiptPath));
        comparison.runtime=struct('reference_seconds',ref.receipt.elapsed_seconds, ...
            'candidate_seconds',rr.sim_elapsed_seconds, ...
            'delta_seconds',rr.sim_elapsed_seconds-ref.receipt.elapsed_seconds);
    end
    write_json(fullfile(auditDir,'offline_comparison.json'),struct('status',comparison.status, ...
        'mode',mode,'comparison',comparison,'trace',traceResult));
end

function result=compare_initial_state_vectors(referenceP,candidateP)
    map=struct('semantic_owner',{'FE','RA','SAR'}, ...
        'field',{'xFE0','xBK0','xSC0'},'width',{353,48,51});
    rows=struct('semantic_owner',{},'parameter_field',{},'width',{},'status',{});
    for k=1:numel(map)
        f=map(k).field;
        assert(isfield(referenceP,f)&&isfield(candidateP,f), ...
            'sar20debug:InitialRootMissing','Missing actual P.%s initial-state root.',f);
        a=referenceP.(f);b=candidateP.(f);
        ok=numel(a)==map(k).width&&numel(b)==map(k).width&& ...
            bit_equal(double(a(:)),double(b(:)));
        rows(end+1)=struct('semantic_owner',map(k).semantic_owner,'parameter_field',f, ...
            'width',map(k).width,'status',ternary(ok,'passed','mismatch')); %#ok<AGROW>
    end
    result=struct('status',ternary(all(strcmp({rows.status},'passed')),'passed','mismatch'), ...
        'baseline_full_state_history_available',false, ...
        'boundary','Pinned initial P vectors; reference simout has no three-owner state-history taps.', ...
        'owners',rows);
end

function tf=bit_equal(a,b)
    tf=false;
    if ~isequal(size(a),size(b)),return;end
    if isa(a,'double')&&isa(b,'double'),tf=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
    elseif isa(a,'single')&&isa(b,'single'),tf=isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
    else,tf=isequaln(a,b);end
end

function recordResult=compare_record_views(base,cand,P,mode,pinnedSelected)
    if strcmp(mode,'prefix')
        want=(P.first_id:P.first_id+P.N-1).';
    else
        want=(4:259).';
    end
    assert(isequal(cand.raw(:,4),want)&&all(cand.raw(:,5)==P.epoch)&&all(cand.raw(:,6)==1), ...
        'sar20debug:CandidateRecordIDs','Candidate selected RAW IDs/epoch/valid are wrong.');
    assert(isequal(base.raw(:,4),want),'sar20debug:BaselinePrefixIDs','Reference selected rows do not contain expected IDs.');
    same=isequaln(double(base.raw),double(cand.raw))&& ...
        bit_equal(double(base.code20(:)),double(cand.code20(:)))&& ...
        bit_equal(double(base.time_s(:)),double(cand.time_s(:)));
    if strcmp(mode,'full')
        same=same&&isequaln(double(cand.raw),double(pinnedSelected.raw))&& ...
            bit_equal(double(cand.code20(:)),double(pinnedSelected.code20(:)))&& ...
            bit_equal(double(cand.time_s(:)),double(pinnedSelected.time_s(:)));
    else
        ix=ismember(pinnedSelected.raw(:,4),want);
        same=same&&isequaln(double(cand.raw),double(pinnedSelected.raw(ix,:)))&& ...
            bit_equal(double(cand.code20(:)),double(pinnedSelected.code20(ix)))&& ...
            bit_equal(double(cand.time_s(:)),double(pinnedSelected.time_s(ix)));
    end
    recordResult=struct('status',ternary(same,'passed','mismatch'), ...
        'readiness_boundary',cand.readiness_boundary,'selected_count',size(cand.raw,1), ...
        'first_id',cand.raw(1,4),'last_id',cand.raw(end,4), ...
        'all_selected_valid',all(cand.raw(:,6)==1),'raw_bits_equal',same);
end

function r=verify_sample5_events(D,P)
    assert(isequal(D.event(:,1),5*ones(48,1))&&isequal(D.event(:,2),(1:48).'), ...
        'sar20debug:Sample5GroupOrder','Sample 5 must have exactly 48 ordered executed groups.');
    expected=zeros(48,1);
    for k=1:48,expected(k)=5*P.Ts_s+P.groups(k).time_s;end
    assert(bit_equal(double(D.time(:)),expected), ...
        'sar20debug:Sample5Times','Sample 5 actual event time sequence differs from the saved calendar.');
    types={};
    for k=1:numel(P.groups)
        ev=P.groups(k).events;
        for q=1:numel(ev),types{end+1}=char(ev(q).type);end %#ok<AGROW>
    end
    d2Count=sum(strcmp(types,'d2_decide'));
    compareCount=sum(strcmp(types,'ta_compare'));
    updateCount=sum(strcmp(types,'ta_feedback'));
    assert(d2Count==12&&compareCount==8&&updateCount==7, ...
        'sar20debug:EventCardinality','Require 12 D2, 8 tracking comparisons, and 7 tracking updates.');
    record=struct('status','passed','sample_id',5,'event_group_count',48, ...
        'event_order',D.event(:,2).','d2_decision_configured_count',d2Count, ...
        'tracking_compare_configured_count',compareCount,'tracking_update_configured_count',updateCount, ...
        'raw_latch',D.adc_raw,'raw_latch_time_s',D.adc_ready_time_s, ...
        'first_D2_group_index',[],'first_D2_absolute_time_s',[], ...
        'first_D2_BackLog_VX_V',[],'first_D2_BackLog_VY_V',[], ...
        'first_D2_comparator_decision','unrecorded in legacy logs', ...
        'BackLog_scope','backend event log; not the effective noisy comparator input');
    for k=1:numel(P.groups)
        ev=P.groups(k).events;
        if any(strcmp({ev.type},'d2_decide'))
            record.first_D2_group_index=k;
            record.first_D2_absolute_time_s=D.time(k);
            record.first_D2_BackLog_VX_V=D.back(k,1);
            record.first_D2_BackLog_VY_V=D.back(k,2);
            break;
        end
    end
end

function ownerInfo=verify_state_owners(cfg,model,P)
    map=cfg.state_owner_map;
    requiredKeys={'FE','RA','SAR'};
    actualKeys={map.key};
    assert(numel(map)==3&&all(ismember(requiredKeys,actualKeys))&&numel(unique(actualKeys))==3, ...
        'sar20debug:OwnerMap','State-owner map must explicitly cover FE, RA and SAR exactly once.');
    ownerInfo=struct('key',{},'semantic_name',{},'baseline_sid',{},'candidate_sid',{}, ...
        'resolved_path',{},'width',{},'initial_parameter',{},'status',{});
    for k=1:numel(map)
        m=map(k);
        for f={'key','semantic_name','baseline_sid','candidate_sid','width','initial_parameter'}
            assert(isfield(m,f{1})&&~isempty(m.(f{1})),'sar20debug:OwnerMapField', ...
                'State-owner mapping lacks %s.',f{1});
        end
        sidPath=[model ':' char(m.candidate_sid)];
        try,path=Simulink.ID.getFullName(sidPath);catch,path='';end
        assert(~isempty(path)&&strcmp(bdroot(path),char(model))&&strcmp(get_param(path,'BlockType'),'UnitDelay')&& ...
            strcmp(get_param(path,'Name'),char(m.semantic_name)), ...
            'sar20debug:OwnerUnmatched','SID %s does not resolve to the declared %s UnitDelay; no path guessing allowed.', ...
            m.candidate_sid,m.semantic_name);
        initial=get_param(path,'InitialCondition');
        assert(strcmp(strtrim(initial),char(m.initial_parameter)), ...
            'sar20debug:OwnerInitial','State owner %s initial condition differs from declared parameter %s.', ...
            m.semantic_name,m.initial_parameter);
        assert(isfield(P,char(m.initial_parameter(3:end)))&& ...
            numel(P.(char(m.initial_parameter(3:end))))==double(m.width), ...
            'sar20debug:OwnerWidth','State owner %s width does not match its actual P initial vector.',m.semantic_name);
        ownerInfo(end+1)=struct('key',char(m.key),'semantic_name',char(m.semantic_name), ...
            'baseline_sid',char(m.baseline_sid),'candidate_sid',char(m.candidate_sid), ...
            'resolved_path',path,'width',double(m.width),'initial_parameter',char(m.initial_parameter), ...
            'status','matched_by_explicit_SID_and_semantic_role'); %#ok<AGROW>
    end
end

function portInfo=verify_root_ports(cfg,model)
    map=cfg.root_port_map;
    assert(numel(map)==3,'sar20debug:RootPortMap','Require an explicit three-output root-port map.');
    portInfo=struct('semantic_name',{},'baseline_sid',{},'candidate_sid',{},'port',{},'resolved_path',{});
    for k=1:numel(map)
        m=map(k);sidPath=[model ':' char(m.candidate_sid)];
        try,path=Simulink.ID.getFullName(sidPath);catch,path='';end
        assert(~isempty(path)&&strcmp(get_param(path,'BlockType'),'Outport')&& ...
            strcmp(get_param(path,'Name'),char(m.semantic_name))&& ...
            str2double(char(get_param(path,'Port')))==double(m.port), ...
            'sar20debug:RootPortUnmatched','Root port SID %s does not match explicit %s/port %d mapping.', ...
            m.candidate_sid,m.semantic_name,m.port);
        portInfo(end+1)=struct('semantic_name',char(m.semantic_name), ...
            'baseline_sid',char(m.baseline_sid),'candidate_sid',char(m.candidate_sid), ...
            'port',double(m.port),'resolved_path',path); %#ok<AGROW>
    end
end

function verify_source_resolution(cfg)
    root=cfg.candidate_root;src=fullfile(root,'current','src');config=fullfile(root,'config');
    addpath(genpath(src),config,root,'-begin');
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(root,'SAR20.m'))];
    names=cell(numel(files),1);expected=cell(numel(files),1);
    for k=1:numel(files)
        [~,names{k}]=fileparts(files(k).name);expected{k}=canonical(fullfile(files(k).folder,files(k).name));
        actual=which(names{k});
        assert(~isempty(actual)&&same_canonical_path(actual,expected{k}), ...
            'sar20debug:SourceResolution','%s resolves outside the frozen candidate source: %s.',names{k},actual);
    end
    assert(numel(unique(lower(string(names))))==numel(names), ...
        'sar20debug:DuplicateSource','Candidate has duplicate project MATLAB function names.');
end

function install_candidate_path(cfg)
    root=cfg.candidate_root;
    src=fullfile(root,'current','src');config=fullfile(root,'config');
    assert(isfolder(src)&&isfolder(config),'sar20debug:CandidateTree','Candidate source/config roots are missing.');
    clear_candidate_function_cache(cfg);
    addpath(genpath(src),config,root,'-begin');
    verify_source_resolution(cfg);
end

function clear_candidate_function_cache(cfg)
    root=cfg.candidate_root;src=fullfile(root,'current','src');config=fullfile(root,'config');
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(root,'SAR20.m'))];
    names=cell(numel(files),1);
    for k=1:numel(files)
        [~,names{k}]=fileparts(files(k).name);
        assert(isvarname(names{k}),'sar20debug:FunctionName','Unsafe MATLAB function basename in candidate source.');
    end
    assert(numel(unique(lower(string(names))))==numel(names), ...
        'sar20debug:DuplicateSource','Candidate has duplicate MATLAB function basenames.');
    % Clear only function basenames owned by this project source manifest. This
    % worker is isolated; never use clear all or affect the retained GUI process.
    for k=1:numel(files)
        evalin('base',['clear ' names{k}]);
    end
end

function contract=read_trace_contract(cfg)
    assert(isfield(cfg,'trace_contract_file')&&isfile(cfg.trace_contract_file), ...
        'sar20debug:TraceContract','Smoke/final/offline requires the frozen trace contract JSON.');
    contract=jsondecode(fileread(cfg.trace_contract_file));
    assert(isstruct(contract)&&isfield(contract,'schema'), ...
        'sar20debug:TraceContract','Malformed trace contract.');
end

function h=trace_contract_sha(cfg)
    assert(isfield(cfg,'trace_contract_file')&&isfile(cfg.trace_contract_file), ...
        'sar20debug:TraceContract','Missing frozen trace contract file.');
    h=file_sha256_value(cfg.trace_contract_file,cfg.max_file_bytes);
end

function contract=read_trace_contract_optional(cfg)
    contract=struct();
    if isfield(cfg,'trace_contract_file')&&isfile(cfg.trace_contract_file)
        contract=jsondecode(fileread(cfg.trace_contract_file));
    end
end

function verify_trace_window(contract)
    assert(isfield(contract,'window')&&isfield(contract.window,'sample_id')&& ...
        isfield(contract.window,'next_cnv_id')&&isfield(contract.window,'max_rows'), ...
        'sar20debug:TraceWindow','Trace contract must declare window, next_cnv_id and max_rows.');
    assert(contract.window.sample_id==5&&contract.window.next_cnv_id==6&& ...
        contract.window.max_rows<=49&&contract.window.max_rows>=49, ...
        'sar20debug:TraceWindow','Full trace must be limited to sample ID 5 plus exactly its next-CNV boundary (<=49 rows).');
end

function enforce_trace_size_bound(contract,baselineSimoutBytes)
    % Bound storage by the configured ToWorkspace cap, while acceptance checks
    % the actual row count and sample/event tags independently.
    bundle=observer_bundle(contract);
    perRowColumns=double(bundle.width);
    storageRows=double(bundle.max_data_points);
    bound=storageRows*perRowColumns*8+double(baselineSimoutBytes)+8e6;
    assert(bound<300e6,'sar20debug:TraceSizeBound', ...
        'Declared full trace worst-case exceeds the 300 MB per-file limit.');
end

function check_trace_namespace(contract,cfg,P,stage)
    if any(strcmp(stage,{'smoke_n8','final_n256'}))
        verify_trace_window(contract);
        assert(~isempty(fieldnames(cfg.debug_overrides))&&~isempty(cfg.allowed_debug_paths), ...
            'sar20debug:DebugOverride','Smoke/final trace needs explicit P.debug overrides and approved paths.');
        assert(all(cellfun(@(x)startsWith(x,'P.debug.'),cfg.allowed_debug_paths)), ...
            'sar20debug:DebugPathScope','Only P.debug.* configuration paths may be added or changed.');
    end
    assert(P.N==256||strcmp(stage,'smoke_n8'),'sar20debug:RunN','Unexpected N for stage.');
end

function trace=run_trace_validator(cfg,contract,out,P,runPath)
    fn='sar20_debug_sample';
    if isfield(contract,'sample_function')&&~isempty(contract.sample_function)
        fn=char(contract.sample_function);
    end
    assert(isvarname(fn),'sar20debug:ValidatorName','Trace validator function name is invalid.');
    pathName=which(fn);
    assert(~isempty(pathName)&&startsWith(lower(canonical(pathName)), ...
        lower(canonical(fullfile(cfg.candidate_root,'current','src')))), ...
        'sar20debug:ValidatorPath','Read-only sample function must resolve inside the frozen candidate source tree.');
    observer=verify_observer_window(out,P,contract);
    D=feval(fn,runPath,5);
    assert(isstruct(D)&&isscalar(D)&&isfield(D,'validation')&&isfield(D,'firstD2')&&isfield(D,'handoffs'), ...
        'sar20debug:TraceResult','Read-only sample function must return validation, firstD2 and handoffs.');
    v=D.validation;d2=D.firstD2;h=D.handoffs;
    if istable(d2)
        assert(height(d2)==1,'sar20debug:FirstD2Shape','Expected one first-D2 row.');
        d2=table2struct(d2);
    end
    assert(strcmp(v.status,'passed')&&v.eventGroupCount==48&&v.eventGroupExpectedCount==48&& ...
        v.nextCnvId==6,'sar20debug:TraceEvents','Require 48 actual sample-5 groups and a separately identified next CNV ID 6.');
    assert(v.trackingCompareConfigured==8&&v.trackingCompareActual==8&& ...
        v.trackingUpdateConfigured==7&&v.trackingUpdateActual==7&&v.trackingUnknown==0, ...
        'sar20debug:TrackingCounts','Require distinct actual 8 tracking comparisons and 7 physical updates, with no unknown event slots.');
    assert(d2.sample_id==5&&isfinite(d2.time_s)&&~isempty(d2.phase)&& ...
        isfinite(d2.VX_stage_v)&&isfinite(d2.VY_stage_v)&&isfinite(d2.cmp_actual_v)&& ...
        isfinite(d2.cmp_offset_v)&&isfinite(d2.cmp_noise_v)&& ...
        ismember(double(d2.decision),[0 1])&&strcmp(d2.decision_source,'actual_comparator_output'), ...
        'sar20debug:FirstD2','First D2 requires actual sample-5 VX/VY/decision, phase and comparator input/offset/noise provenance.');
    requiredHandoffCols={'sample_id','epoch','owner','prevEventGroupRow','nextEventGroupRow', ...
        'prevTime_s','nextTime_s','prevExecutionValid','nextExecutionValid','boundaryClass', ...
        'nextTapValid','oldTapValid','bitwise_equal','sourceTapNext','sourceTapOld'};
    assert(istable(h)&&all(ismember(requiredHandoffCols,h.Properties.VariableNames)), ...
        'sar20debug:HandoffTable','State handoff table must expose owners, execution validity, sources, equality and boundaryClass.');
    matched=strcmp(string(h.boundaryClass),'matched');
    matchedEqual=double(h.bitwise_equal(matched));
    classes=string(h.boundaryClass);
    windowEntry=strcmp(classes,'window_entry');
    initClass=strcmp(classes,'initialization');inactiveClass=strcmp(classes,'inactive_hold');
    sourceNext=string(h.sourceTapNext(matched));sourceOld=string(h.sourceTapOld(matched));
    matchedOwners=unique(string(h.owner(matched)));
    nextTapValid=double(h.nextTapValid(matched));oldTapValid=double(h.oldTapValid(matched));
    prevExec=double(h.prevExecutionValid(matched));nextExec=double(h.nextExecutionValid(matched));
    prevRows=double(h.prevEventGroupRow(matched));nextRows=double(h.nextEventGroupRow(matched));
    matchedIds=double(h.sample_id(matched));matchedEpochs=double(h.epoch(matched));
    matchedTimes=[double(h.prevTime_s(matched)) double(h.nextTime_s(matched))];
    assert(any(matched)&&all(isfinite(matchedEqual)&matchedEqual==1)&& ...
        all(isfinite(nextTapValid)&nextTapValid==1)&&all(isfinite(oldTapValid)&oldTapValid==1)&& ...
        all(isfinite(prevExec)&prevExec==1)&&all(isfinite(nextExec)&nextExec==1)&& ...
        all(ismember(matchedIds,[5 6]))&&all(matchedEpochs==P.epoch)&& ...
        all(isfinite(prevRows)&prevRows==floor(prevRows)&prevRows>=1&prevRows<=48)&& ...
        all(isfinite(nextRows)&nextRows==floor(nextRows)&nextRows>=1&nextRows<=48)&& ...
        all(isfinite(matchedTimes),'all')&&all(~ismissing(sourceNext)&strlength(sourceNext)>0)&& ...
        all(~ismissing(sourceOld)&strlength(sourceOld)>0)&& ...
        all(ismember(["FE353" "RA48" "SAR51"],matchedOwners))&&any(windowEntry)&& ...
        sum(initClass)==v.handoffInitialization&&sum(inactiveClass)==v.handoffInactive&& ...
        v.handoffMatched==sum(matched)&&v.handoffUnmatched==0&&v.handoffMissing==0&&v.handoffUnknown==0, ...
        'sar20debug:HandoffMismatch','Every matched next→old state pair must compare bitwise; unmatched/missing/unknown pairs block pass.');
    assert(v.handoffInitialization>=0&&v.handoffInactive>=0, ...
        'sar20debug:HandoffBoundaries','Initialization and inactive-boundary counts must be explicitly reported.');
    inventory=mat_inventory(runPath);
    assert(~inventory.any_file_over_300MB,'sar20debug:TraceFileCap', ...
        'A native trace MAT file exceeds 300 MB.');
    trace=struct('status','passed','sample_id',5,'next_cnv_id',6, ...
        'observer',observer, ...
        'event_group_count',v.eventGroupCount,'event_group_expected',v.eventGroupExpectedCount, ...
        'tracking_compare_configured',v.trackingCompareConfigured, ...
        'tracking_compare_actual',v.trackingCompareActual, ...
        'tracking_update_configured',v.trackingUpdateConfigured, ...
        'tracking_update_actual',v.trackingUpdateActual,'tracking_unknown',v.trackingUnknown, ...
        'first_d2',d2,'state_handoff_counts',struct('matched',v.handoffMatched, ...
        'unmatched',v.handoffUnmatched,'initialization',v.handoffInitialization, ...
        'inactive',v.handoffInactive,'missing',v.handoffMissing,'unknown',v.handoffUnknown), ...
        'total_mat_bytes',inventory.total_mat_bytes,'mat_file_count',inventory.mat_file_count, ...
        'validator_function',fn,'validator_is_read_only',true);
end

function result=verify_observer_window(out,P,contract)
    bundle=observer_bundle(contract);
    logger=char(bundle.logger_name);width=double(bundle.width);
    maxRows=double(bundle.expected_selected_sample_rows);
    assert(maxRows==49&&double(bundle.max_data_points)==64&&width==6329, ...
        'sar20debug:ObserverContract','Frozen bundle must declare 49 selected rows, 64 max points, and width 6329.');
    names=cellstr(out.who);
    assert(any(strcmp(names,logger)),'sar20debug:ObserverLogger','Missing actual full-state observer logger %s.',logger);
    ts=out.get(logger);assert(isa(ts,'timeseries'),'sar20debug:ObserverTimeseries','Observer logger must be native timeseries.');
    [t,x]=observer_timeseries_rows(ts);
    assert(size(x,1)==maxRows&&size(x,2)==width&&maxRows==contract.window.max_rows&& ...
        size(x,1)<=bundle.max_data_points, ...
        'sar20debug:ObserverExtent','Observer must contain exactly 49 rows of the frozen %d-column trace.',width);
    expectedCycle=[5*ones(48,1);6];expectedGroup=[(1:48).';1];
    expectedTime=zeros(49,1);
    for k=1:48,expectedTime(k)=5*P.Ts_s+P.groups(k).time_s;end
    expectedTime(49)=6*P.Ts_s+P.groups(1).time_s;
    actualTags=double(x(:,end-2:end));
    assert(bit_equal(double(t),expectedTime)&&bit_equal(actualTags(:,1),expectedCycle)&& ...
        bit_equal(actualTags(:,2),expectedGroup)&&bit_equal(actualTags(:,3),expectedTime), ...
        'sar20debug:ObserverWindowTags','Underlying observer rows must be exactly sample 5 groups 1..48 and sample 6 CNV group 1.');
    result=struct('logger',logger,'rows',size(x,1),'width',size(x,2), ...
        'sample_ids',unique(actualTags(:,1)).','boundary_ids',unique(actualTags(:,1)).', ...
        'last_cnv_sample_id',actualTags(end,1),'last_group_index',actualTags(end,2), ...
        'outside_window_rows',0,'status','passed');
end

function bundle=observer_bundle(contract)
    if isfield(contract,'R')&&isstruct(contract.R)&&isfield(contract.R,'bundle')
        bundle=contract.R.bundle;
    elseif isfield(contract,'bundle')
        bundle=contract.bundle;
    else
        error('sar20debug:ObserverContract','Trace contract must include the frozen R.bundle registry.');
    end
    assert(all(isfield(bundle,{'logger_name','max_data_points','expected_selected_sample_rows','width','sections'})), ...
        'sar20debug:ObserverContract','R.bundle lacks logger name, storage cap, row count, width or semantic sections.');
    assert(numel(bundle.sections)==18,'sar20debug:ObserverSections','Expected exactly 18 semantic observer sections.');
    sectionNames={bundle.sections.section};signalNames={bundle.sections.signal};
    tagSection=find(strcmp(sectionNames,'EventTime3')|strcmp(signalNames,'EventTime3'));
    assert(isscalar(tagSection)&&bundle.sections(tagSection).index==6327&& ...
        bundle.sections(tagSection).width==3&&bundle.width==6329, ...
        'sar20debug:ObserverTagMap','Registry EventTime3 must map to observer columns 6327:6329.');
    covered=false(1,double(bundle.width));
    for k=1:numel(bundle.sections)
        first=double(bundle.sections(k).index);count=double(bundle.sections(k).width);
        assert(isfinite(first)&&isfinite(count)&&first>=1&&count>=1&& ...
            first==floor(first)&&count==floor(count)&&first+count-1<=bundle.width, ...
            'sar20debug:ObserverSectionRange','Observer section %s has an invalid column range.',char(bundle.sections(k).section));
        cols=first:first+count-1;
        assert(~any(covered(cols)),'sar20debug:ObserverSectionOverlap','Observer sections overlap columns.');
        covered(cols)=true;
    end
    assert(all(covered),'sar20debug:ObserverSectionGap','Observer registry has unassigned columns.');
end

function [t,x]=observer_timeseries_rows(ts)
    t=double(ts.Time(:));d=ts.Data;
    assert(all(isfinite(t)),'sar20debug:ObserverTime','Observer times must be finite.');
    if ts.IsTimeFirst,x=reshape(d,numel(t),[]);else,x=reshape(permute(d,[ndims(d) 1:ndims(d)-1]),numel(t),[]);end
    assert(size(x,1)==numel(t),'sar20debug:ObserverShape','Observer data rows do not match actual times.');
end

function smokeP=smoke_extent(baseP,candidateP)
    smokeP=baseP;smokeP.N=candidateP.N;smokeP.n_cycles=candidateP.n_cycles;
    smokeP.stop_time_s=candidateP.stop_time_s;smokeP.debug=candidateP.debug;
end

function mode=saved_run_mode(runPath,cap)
    bounded_file(fullfile(runPath,'parameters.mat'),cap);
    pfile=load(fullfile(runPath,'parameters.mat'),'P');
    assert(isfield(pfile,'P')&&isstruct(pfile.P)&&isfield(pfile.P,'N'), ...
        'sar20debug:RunP','Cannot select offline mode without saved P.N.');
    if pfile.P.N==8&&pfile.P.n_cycles==12
        mode='prefix';
    elseif pfile.P.N==256&&pfile.P.n_cycles==260
        mode='full';
    else
        error('sar20debug:RunExtent','Offline run must be the declared N8 smoke or N256 case.');
    end
end

function ownerMap=default_state_owner_map()
    ownerMap=struct('key',{'FE','RA','SAR'}, ...
        'semantic_name',{'SampleCharge','RaCtState','SarState'}, ...
        'baseline_sid',{'148','149','150'},'candidate_sid',{'148','149','150'}, ...
        'width',{353,48,51},'initial_parameter',{'P.xFE0','P.xBK0','P.xSC0'});
end

function portMap=default_root_port_map()
    portMap=struct('semantic_name',{'Code20','CodeValid','CodeMeta'}, ...
        'baseline_sid',{'463','464','465'},'candidate_sid',{'463','464','465'}, ...
        'port',{1,2,3});
end

function cfgOut=candidate_identity(cfg)
    [h,n]=file_sha256(cfg.candidate_model_file,cfg.max_file_bytes);
    cfgOut=struct('model_name',char(cfg.model_name),'model_file',char(cfg.candidate_model_file), ...
        'model_sha256',h,'model_bytes',n,'candidate_root',char(cfg.candidate_root));
end

function inventory=candidate_source_inventory(cfg)
    root=canonical(cfg.candidate_root);src=fullfile(root,'current','src');config=fullfile(root,'config');
    files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m')); ...
        dir(fullfile(config,'*.mat'));dir(fullfile(root,'SAR20.m'));dir(cfg.candidate_model_file)];
    assert(~isempty(files),'sar20debug:CandidateInventory','Candidate source/model inventory is empty.');
    rels=cell(numel(files),1);
    for k=1:numel(files)
        full=canonical(fullfile(files(k).folder,files(k).name));
        rels{k}=strrep(full,[root filesep],'');
    end
    [rels,order]=sort(rels);
    files=files(order);
    rows=struct('path',{},'bytes',{},'sha256',{});total=0;material='';
    for k=1:numel(files)
        p=fullfile(files(k).folder,files(k).name);
        [h,n]=file_sha256(p,300e6);
        rows(end+1)=struct('path',rels{k},'bytes',n,'sha256',h); %#ok<AGROW>
        total=total+n;
        material=[material rels{k} char(9) h char(10)]; %#ok<AGROW>
    end
    inventory=struct('schema','sar20-candidate-source-inventory/v1', ...
        'candidate_root',root,'file_count',numel(rows),'total_bytes',total, ...
        'tree_sha256',sha256_text(material),'files',rows);
end

function h=sha256_text(textValue)
    md=java.security.MessageDigest.getInstance('SHA-256');
    bytes=unicode2native(char(textValue),'UTF-8');
    md.update(typecast(uint8(bytes(:)),'int8'));
    h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function inv=mat_inventory(folder)
    d=dir(fullfile(folder,'*.mat'));rows=struct('name',{},'bytes',{},'sha256',{});total=0;
    for k=1:numel(d)
        p=fullfile(folder,d(k).name);
        if d(k).bytes>300e6
            rows(end+1)=struct('name',d(k).name,'bytes',d(k).bytes,'sha256','OVERSIZED_NOT_READ'); %#ok<AGROW>
        else
            rows(end+1)=struct('name',d(k).name,'bytes',d(k).bytes, ...
                'sha256',file_sha256_value(p,300e6)); %#ok<AGROW>
        end
        total=total+d(k).bytes;
    end
    inv=struct('mat_file_count',numel(rows),'total_mat_bytes',total,'files',rows, ...
        'any_file_over_300MB',any([rows.bytes]>300e6));
end

function receipt=finish_receipt(receipt,runDir)
    receipt.finished_utc=utc_now();
    if isfield(receipt,'mat_files')&&receipt.mat_files.any_file_over_300MB
        receipt.status='failed_file_cap';
    end
    write_json(fullfile(runDir,'driver_receipt.json'),receipt);
end

function out=merge_struct(base,patch)
    assert(isstruct(base)&&isscalar(base)&&isstruct(patch)&&isscalar(patch), ...
        'sar20debug:DebugPatch','Debug overrides must be scalar structs.');
    out=base;fields=fieldnames(patch);
    for k=1:numel(fields)
        f=fields{k};
        if isfield(out,f)&&isstruct(out.(f))&&isscalar(out.(f))&&isstruct(patch.(f))&&isscalar(patch.(f))
            out.(f)=merge_struct(out.(f),patch.(f));
        else
            out.(f)=patch.(f);
        end
    end
end

function diffs=diff_paths(a,b,prefix)
    diffs={};
    if isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)
        af=fieldnames(a);bf=fieldnames(b);allf=unique([af;bf]);
        for k=1:numel(allf)
            f=allf{k};child=[prefix '.' f];
            if ~isfield(a,f)||~isfield(b,f),diffs{end+1}=child; %#ok<AGROW>
            else,diffs=[diffs diff_paths(a.(f),b.(f),child)]; %#ok<AGROW>
            end
        end
    elseif ~isequaln(a,b)
        diffs={prefix};
    end
end

function tf=allowed_path(pathValue,allowed)
    tf=false;
    for k=1:numel(allowed)
        item=char(allowed{k});
        if strcmp(pathValue,item)||startsWith(pathValue,[item '.']),tf=true;return;end
    end
end

function [h,n]=file_sha256(pathValue,cap)
    n=bounded_file(pathValue,cap);
    fid=fopen(pathValue,'rb');assert(fid>=0,'sar20debug:ReadFile','Cannot read %s.',pathValue);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    md=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(fid)
        bytes=fread(fid,1024*1024,'*uint8');
        if ~isempty(bytes),md.update(typecast(bytes(:),'int8'));end
    end
    h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end

function h=file_sha256_value(pathValue,cap)
    h=file_sha256(pathValue,cap);
end

function n=bounded_file(pathValue,cap)
    d=dir(pathValue);
    assert(isscalar(d)&&~d.isdir,'sar20debug:MissingFile','Missing required file: %s.',pathValue);
    assert(d.bytes<=cap&&d.bytes<=300e6,'sar20debug:FileCap', ...
        'Refuse to read file larger than 300 MB: %s (%d bytes).',pathValue,d.bytes);
    n=d.bytes;
end

function n=file_size(pathValue,cap)
    n=bounded_file(pathValue,cap);
end

function tf=same_canonical_path(a,b)
    tf=strcmpi(canonical(a),canonical(b));
end

function p=canonical(p)
    p=char(java.io.File(char(p)).getCanonicalPath());
end

function close_no_save(model)
    if bdIsLoaded(model)&&strcmp(get_param(model,'SimulationStatus'),'stopped')
        close_system(model,0);
    end
end

function write_json(pathValue,value)
    tmp=[pathValue '.partial'];
    fid=fopen(tmp,'w','n','UTF-8');assert(fid>=0,'sar20debug:WriteFile','Cannot write %s.',tmp);
    cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%s\n',jsonencode(value));clear cleanup;
    [ok,msg]=movefile(tmp,pathValue,'f');assert(ok,'sar20debug:WriteFile','Cannot commit receipt: %s',msg);
end

function s=ternary(flag,a,b)
    if flag,s=a;else,s=b;end
end

function s=utc_now()
    s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
end
