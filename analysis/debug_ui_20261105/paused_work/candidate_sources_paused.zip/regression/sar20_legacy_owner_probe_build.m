function R = sar20_legacy_owner_probe_build(cfg)
%SAR20_LEGACY_OWNER_PROBE_BUILD Build a private passive-state probe from 9197.
% All graph changes use SATK model_edit. The old SAR20 source is extracted from
% the pinned real N256 run and is never edited. No physical simulation occurs.
%
% Required cfg fields: reference_run_dir, private_root, toolkit_tools,
% registry_source_root, expected_registry_sha256. Optional: max_file_bytes.

    cfg=normalize_cfg(cfg);cap=cfg.max_file_bytes;R=struct('schema','sar20-old-owner-probe/v1', ...
        'status','started','simulation_run',false,'production_model_write',false, ...
        'private_root',cfg.private_root,'started_utc',utc_now());
    assert(~isfolder(cfg.private_root)&&~isfile(cfg.private_root), ...
        'sar20owner:PrivateRoot','Refuse to overwrite existing private_root.');
    mkdir(cfg.private_root);write_json(fullfile(cfg.private_root,'build_receipt.json'),R);

    model='SarAdc';opened=false;oldPath=path;pathGuard=onCleanup(@()path(oldPath)); %#ok<NASGU>
    try
        ref=pin_reference_run(cfg);
        R.reference=ref.receipt;R.registry=load_registry(cfg);
        selected=selected_sections(R.registry.bundle);
        R.owner_bundle=selected;
        projectRoot=fullfile(cfg.private_root,'baseline_project');
        mkdir(projectRoot);
        unzip(fullfile(cfg.reference_run_dir,'source.zip'),projectRoot);
        verify_run_source(projectRoot,ref.source_manifest,cfg.max_file_bytes);
        modelFile=fullfile(projectRoot,'current','models','SarAdc.slx');
        modelDir=fileparts(modelFile);if ~isfolder(modelDir),mkdir(modelDir);end
        [ok,msg]=copyfile(fullfile(cfg.reference_run_dir,'SarAdc.slx'),modelFile);assert(ok,'sar20owner:ModelCopy','%s',msg);
        assert(strcmp(sha256(modelFile,cap),ref.receipt.model_sha256), ...
            'sar20owner:ModelCopySha','Private old model copy differs from the actual N256 reference.');
        R.private_model_file=modelFile;R.original_source_tree_sha256=source_tree_hash(projectRoot);
        R.registry_source_sha256=sha256(which('sar20_debug_fields'),cap);

        addpath(fullfile(cfg.toolkit_tools,'common'),fullfile(cfg.toolkit_tools,'common','autolayout'), ...
            fullfile(cfg.toolkit_tools,'model_read'),fullfile(cfg.toolkit_tools,'model_edit'), ...
            fullfile(cfg.toolkit_tools,'model_check'),'-begin');
        gate=library.settingsLookup();
        assert(isstruct(gate)&&isfield(gate,'found')&&isfield(gate,'gatePass')&& ...
            (~gate.found||gate.gatePass),'sar20owner:LibraryGate','SATK library gate blocked the private build.');
        R.library_gate=gate;
        assert(bdIsLoaded(model)==0,'sar20owner:ModelLoaded','Use the isolated root-owned Windows worker.');
        open_system(modelFile);opened=true;
        assert(strcmpi(canonical(get_param(model,'FileName')),canonical(modelFile))&& ...
            strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
            'sar20owner:ModelIdentity','Loaded graph is not the private stopped 9197 copy.');
        ws=get_param(model,'ModelWorkspace');ws.assignin('P',ref.P);ws.assignin('DecodeP',ref.P.digital);
        ws.assignin('TrainCaptureFile','');

        rootRead=read_scope(model,'root');eventId=find_id(rootRead,'EventStep');
        eventRead=read_scope(model,eventId);adcId=find_id(eventRead,'Adc');
        adcRead=read_scope(model,adcId);R.scopes=struct('root',rootRead,'event_step',eventRead,'adc_before',adcRead);
        sources=resolve_probe_sources(model,adcId,adcRead,selected);
        R.source_mapping=sources;
        ops=build_parent_ops(sources,R.registry.bundle);
        reply=edit_scope(model,adcId,ops,'incremental');R.parent_model_edit=reply;
        afterParent=read_scope(model,adcId);probeId=find_id(afterParent,'OwnerProbeCapture');
        childBefore=read_scope(model,probeId);traceIn=find_id(childBefore,'OwnerTraceData');
        childOps={struct('op','add_block','type','EnablePort','name','OwnerProbeEnable','ref','probe_enable'), ...
            struct('op','add_block','type','ToWorkspace','name','OwnerProbeSink','ref','probe_sink', ...
            'params',struct('VariableName','owner_probe_log','SaveFormat','Timeseries', ...
            'MaxDataPoints','64','Decimation','1','SampleTime','-1')), ...
            struct('op','connect','target',[traceIn '.y1 -> #probe_sink.u1'])};
        childReply=edit_scope(model,probeId,childOps,'full');R.child_model_edit=childReply;
        childAfter=read_scope(model,probeId);R.scopes.owner_probe_child=childAfter;
        childCheck=check_scope(model,probeId);require_check_healthy(childCheck);R.child_model_check=childCheck;

        afterChild=read_scope(model,adcId);probeId=find_id(afterChild,'OwnerProbeCapture');
        gateId=find_id(afterChild,'OwnerProbeWindowGate');
        probePath=path_by_id(model,probeId);portHandles=get_param(probePath,'PortHandles');
        assert(isfield(portHandles,'Enable')&&numel(portHandles.Enable)==1, ...
            'sar20owner:EnablePort','OwnerProbeCapture did not expose exactly one Enabled Subsystem control port.');
        parentConnect={struct('op','connect','target',[gateId '.y1 -> ' probeId '.enable'])};
        parentConnectReply=edit_scope(model,adcId,parentConnect,'incremental');
        R.parent_enable_connect=parentConnectReply;
        finalAdcRead=read_scope(model,adcId);R.scopes.adc_after=finalAdcRead;
        check=check_scope(model,adcId);require_check_healthy(check);R.adc_model_check=check;
        validate_probe_blocks(model,probeId,gateId,R.bundle,R.owner_bundle);

        save_system(model,modelFile);
        savedSha=sha256(modelFile,cap);
        assert(~strcmp(savedSha,ref.receipt.model_sha256), ...
            'sar20owner:ProbeNoDelta','Saved private probe graph did not change from its 9197 input identity.');
        set_param(model,'SimulationCommand','update');
        assert(strcmp(sha256(modelFile,cap),savedSha), ...
            'sar20owner:CompileMutated','Cold compile changed the saved private probe graph.');
        assert(isequaln(getVariable(ws,'P'),ref.P)&&isequaln(getVariable(ws,'DecodeP'),ref.P.digital)&& ...
            isempty(getVariable(ws,'TrainCaptureFile')), ...
            'sar20owner:WorkspaceChanged','Private probe compile changed the saved physical P/DecodeP/TrainCaptureFile values.');
        close_system(model,0);opened=false;
        assert(strcmp(sha256(modelFile,cap),savedSha), ...
            'sar20owner:CloseMutated','Closing the private probe changed its saved model file.');
        R.status='private_probe_built_compile_pass_simulation_not_run';
        R.probe_model_sha256=savedSha;R.probe_model_bytes=dir(modelFile).bytes;
        R.source_tree_unchanged=strcmp(R.original_source_tree_sha256,source_tree_hash(projectRoot));
        assert(R.source_tree_unchanged,'sar20owner:SourceChanged','Old extracted source tree changed during build.');
        R.finished_utc=utc_now();write_json(fullfile(cfg.private_root,'owner_probe_manifest.json'),R);
        write_json(fullfile(cfg.private_root,'build_receipt.json'),R);
    catch err
        R.status='failed';R.failure_identifier=err.identifier;R.failure_message=err.message;
        R.keep_worker_alive=false;
        if opened&&bdIsLoaded(model)
            try
                partial=fullfile(cfg.private_root,'SarAdc_partial.slx');save_system(model,partial);
                R.partial_model_file=partial;R.partial_model_sha256=sha256(partial,cap);
            catch saveErr
                R.keep_worker_alive=true;R.partial_save_error=saveErr.message;
            end
            if ~R.keep_worker_alive
                try,close_system(model,0);opened=false;catch closeErr,R.keep_worker_alive=true;R.close_error=closeErr.message;end
            end
        end
        R.finished_utc=utc_now();write_json(fullfile(cfg.private_root,'build_receipt.json'),R);rethrow(err);
    end
end

function cfg=normalize_cfg(cfg)
    if (ischar(cfg)&&isrow(cfg))||(isstring(cfg)&&isscalar(cfg)),cfg=jsondecode(fileread(char(cfg)));end
    assert(isstruct(cfg)&&isscalar(cfg),'sar20owner:Config','cfg must be scalar struct or JSON path.');
    required={'reference_run_dir','private_root','toolkit_tools','registry_source_root','expected_registry_sha256'};
    for k=1:numel(required),assert(isfield(cfg,required{k})&&~isempty(cfg.(required{k})), ...
            'sar20owner:ConfigField','Missing cfg.%s.',required{k});end
    cfg.reference_run_dir=char(cfg.reference_run_dir);cfg.private_root=char(cfg.private_root);
    cfg.toolkit_tools=char(cfg.toolkit_tools);cfg.registry_source_root=char(cfg.registry_source_root);
    cfg.expected_registry_sha256=char(cfg.expected_registry_sha256);
    if ~isfield(cfg,'max_file_bytes'),cfg.max_file_bytes=300e6;end
    assert(cfg.max_file_bytes>0&&cfg.max_file_bytes<=300e6,'sar20owner:FileCap','File read cap must be <=300MB.');
end

function ref=pin_reference_run(cfg)
    names={'SarAdc.slx','parameters.mat','simout.mat','selected.mat','summary.json','source.zip','source_manifest.json'};
    hashes=struct();sizes=struct();
    for k=1:numel(names)
        f=fullfile(cfg.reference_run_dir,names{k});[hashes.(matlab.lang.makeValidName(names{k})),sizes.(matlab.lang.makeValidName(names{k}))]=sha256(f,cfg.max_file_bytes);
    end
    summary=jsondecode(fileread(fullfile(cfg.reference_run_dir,'summary.json')));
    sourceManifest=jsondecode(fileread(fullfile(cfg.reference_run_dir,'source_manifest.json')));
    pfile=load(fullfile(cfg.reference_run_dir,'parameters.mat'),'P');assert(isfield(pfile,'P'),'sar20owner:ReferenceP','Missing actual P.');P=pfile.P;
    assert(strcmp(summary.status,'complete')&&summary.simulation_completed&&summary.records==256&& ...
        summary.global_rng_unchanged,'sar20owner:ReferenceStatus','Require complete actual N256 reference.');
    assert(strcmp(summary.model_sha256,'91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e')&& ...
        strcmp(hashes.SarAdc_slx,summary.model_sha256),'sar20owner:ReferenceModel','Actual reference model is not the 9197 baseline.');
    assert(strcmp(summary.config_sha256,hashes.parameters_mat)&& ...
        strcmp(summary.source_zip_sha256,hashes.source_zip)&&strcmp(summary.selected_sha256,hashes.selected_mat), ...
        'sar20owner:ReferenceHash','Reference P/Source/selected hashes disagree with summary.');
    assert(P.N==256&&P.n_cycles==260&&P.first_id==4&&P.seed==20261020&&P.epoch==1&& ...
        numel(P.groups)==48&&P.Ts_s==200e-9,'sar20owner:ReferenceConfig','Reference P is not the exact saved N256 normal input.');
    ref=struct('P',P,'summary',summary,'source_manifest',sourceManifest, ...
        'receipt',struct('run_id',char(extractAfter(string(summary.run_path),'behavior_')), ...
        'model_sha256',hashes.SarAdc_slx,'config_sha256',hashes.parameters_mat, ...
        'simout_sha256',hashes.simout_mat,'simout_bytes',sizes.simout_mat, ...
        'selected_sha256',hashes.selected_mat,'source_zip_sha256',hashes.source_zip, ...
        'source_manifest_sha256',hashes.source_manifest_json,'elapsed_seconds',summary.elapsed_s));
end

function R=load_registry(cfg)
    root=char(cfg.registry_source_root);src=fullfile(root,'current','src');
    if isfolder(src),addpath(genpath(src),root,'-begin');else,addpath(root,'-begin');end
    f=which('sar20_debug_fields');assert(~isempty(f),'sar20owner:Registry','sar20_debug_fields not found in frozen registry root.');
    actualSha=sha256(f,cfg.max_file_bytes);
    assert(strcmpi(actualSha,cfg.expected_registry_sha256),'sar20owner:RegistrySha','Registry source SHA mismatch.');
    R=sar20_debug_fields();assert(strcmp(R.schema,'sar20-debug-fields/v1'),'sar20owner:RegistrySchema','Unexpected registry schema.');
    assert(strcmp(R.bundle.logger_name,'observer_log')&&R.bundle.width==6329&& ...
        R.bundle.max_data_points==64&&R.bundle.expected_selected_sample_rows==49, ...
        'sar20owner:Bundle','Registry bundle constants differ from root-frozen contract.');
end

function sections=selected_sections(bundle)
    wanted={'FEold353','FEnext353','RAold48','RAnext48','SARold51','SARnext51','EventTime3'};
    names={bundle.sections.section};
    indices=zeros(1,numel(wanted));
    for k=1:numel(wanted)
        ix=find(strcmp(names,wanted{k}));assert(isscalar(ix),'sar20owner:BundleSection','Expected one registry section %s.',wanted{k});
        indices(k)=ix;
    end
    assert(isequal(indices,sort(indices)),'sar20owner:BundleOrder','Required owner sections are not in declared R.bundle order.');
    sections=bundle.sections(indices);
    assert(sum([sections.width])==907&&sections(end).width==3&&strcmp(sections(end).section,'EventTime3'), ...
        'sar20owner:BundleWidth','Selected owner+event segments must derive to 907 columns from R.bundle.');
end

function sources=resolve_probe_sources(model,adcId,adcRead,sections)
    sources=struct('section',{},'owner',{},'width',{},'bundle_index',{},'token',{},'source_block',{},'source_signal',{});
    for k=1:numel(sections)-1
        q=sections(k);owner=char(q.owner);ownerId=find_id(adcRead,owner);ownerPath=path_by_id(model,ownerId);
        assert(strcmp(get_param(ownerPath,'Name'),owner)&&strcmp(get_param(ownerPath,'BlockType'),'UnitDelay'), ...
            'sar20owner:StateOwner','Registry owner %s does not resolve to actual UnitDelay.',owner);
        if contains(q.source,'UnitDelay output')
            portHandles=get_param(ownerPath,'PortHandles');assert(numel(portHandles.Outport)==1,'sar20owner:StateOutput','Expected one UnitDelay output.');
            port=double(get_param(portHandles.Outport(1),'PortNumber'));token=[ownerId '.y' num2str(port)];srcName=owner;srcSignal='UnitDelay output';
        elseif contains(q.source,'UnitDelay input')
            portHandles=get_param(ownerPath,'PortHandles');assert(numel(portHandles.Inport)==1,'sar20owner:StateInput','Expected one UnitDelay input.');
            line=get_param(portHandles.Inport(1),'Line');assert(isscalar(line)&&line~=-1,'sar20owner:StateInputLine','UnitDelay input line is unconnected.');
            srcPort=get_param(line,'SrcPortHandle');assert(isscalar(srcPort)&&srcPort~=-1,'sar20owner:StateInputSource','Cannot resolve UnitDelay input driver.');
            srcPath=get_param(srcPort,'Parent');srcBlockName=get_param(srcPath,'Name');srcBlockId=id_from_path(model,srcPath);
            port=double(get_param(srcPort,'PortNumber'));token=[srcBlockId '.y' num2str(port)];
            srcName=srcBlockName;srcSignal=get_param(line,'Name');
        else
            error('sar20owner:RegistrySource','Unrecognized registry source semantics for %s.',q.section);
        end
        sources(end+1)=struct('section',char(q.section),'owner',owner,'width',double(q.width), ...
            'bundle_index',double(q.index),'token',token,'source_block',srcName,'source_signal',char(srcSignal)); %#ok<AGROW>
    end
    eventId=find_id(adcRead,'Calendar');eventPath=path_by_id(model,eventId);
    assert(strcmp(get_param(eventPath,'BlockType'),'Inport'),'sar20owner:EventSource','Calendar event must be an ADC input port.');
    eventToken=[eventId '.y1'];
    stageId=find_id(adcRead,'SampleRaAdvance');timePort=outport_index(model,stageId,'Time_s');
    timeToken=[stageId '.y' num2str(timePort)];
    sources(end+1)=struct('section','EventTime3.cycle_group','owner','Calendar','width',2, ...
        'bundle_index',sections(end).index,'token',eventToken,'source_block','Calendar','source_signal','cycle/group'); %#ok<AGROW>
    sources(end+1)=struct('section','EventTime3.modelEventTime_s','owner','SampleRaAdvance','width',1, ...
        'bundle_index',sections(end).index+2,'token',timeToken,'source_block','SampleRaAdvance','source_signal','Time_s'); %#ok<AGROW>
end

function ops=build_parent_ops(sources,bundle)
    ops={struct('op','add_block','type','Mux','name','OwnerProbeMux','ref','owner_mux', ...
        'params',struct('Inputs','8')),...
        struct('op','add_block','type','Fcn','name','OwnerProbeWindowGate','ref','owner_gate', ...
        'params',struct('Expr','(u(1)==5) || ((u(1)==6) && (u(2)==1))','SampleTime','-1')),...
        struct('op','create_subsystem','name','OwnerProbeCapture','ref','owner_probe', ...
        'interface',struct('inputs',{{'OwnerTraceData'}},'outputs',{{}}))};
    for k=1:8
        if k<=6,token=sources(k).token;else,token=sources(5+k-5).token;end
        ops{end+1}=struct('op','connect','target',[token ' -> #owner_mux.u' num2str(k)]); %#ok<AGROW>
    end
    ops{end+1}=struct('op','connect','target',[sources(7).token ' -> #owner_gate.u1']); %#ok<AGROW>
    ops{end+1}=struct('op','connect','target','#owner_mux.y1 -> #owner_probe.u1'); %#ok<AGROW>
    assert(numel(sources)==8&&bundle.width==6329,'sar20owner:ParentOps','Unexpected owner source count or full bundle width.');
end

function validate_probe_blocks(model,probeId,gateId,bundle,sections)
    probePath=path_by_id(model,probeId);gatePath=path_by_id(model,gateId);
    ports=get_param(probePath,'PortHandles');assert(numel(ports.Inport)==1&&numel(ports.Enable)==1, ...
        'sar20owner:ProbePorts','OwnerProbeCapture needs one data and one enable port.');
    fcnParams=get_param(gatePath,'Expr');expected='(u(1)==5) || ((u(1)==6) && (u(2)==1))';
    assert(strcmp(strrep(fcnParams,' ',''),strrep(expected,' ','')), ...
        'sar20owner:WindowGate','Window gate expression differs from sample5 plus nextCNV.');
    d=find_system(probePath,'SearchDepth',1,'BlockType','ToWorkspace');
    assert(numel(d)==1&&strcmp(get_param(d{1},'VariableName'),'owner_probe_log')&& ...
        strcmp(get_param(d{1},'MaxDataPoints'),'64')&&strcmp(get_param(d{1},'SaveFormat'),'Timeseries')&& ...
        strcmp(get_param(d{1},'Decimation'),'1')&&strcmp(get_param(d{1},'SampleTime'),'-1'), ...
        'sar20owner:Sink','Owner probe sink must be a 64-point timeseries logger.');
    assert(sum([sections.width])==907&&bundle.width==6329,'sar20owner:Widths','Registry-derived widths changed.');
end

function port=outport_index(model,subsystemId,name)
    txt=read_scope(model,subsystemId);outId=find_id(txt,name);p=path_by_id(model,outId);
    assert(strcmp(get_param(p,'BlockType'),'Outport'),'sar20owner:Outport','%s is not an Outport.',name);
    port=str2double(char(get_param(p,'Port')));assert(isfinite(port)&&port>=1,'sar20owner:OutportIndex','Invalid port number.');
end

function id=id_from_path(model,p)
    sid=char(get_param(p,'SID'));parts=regexp(sid,':','split');n=parts{end};
    assert(~isempty(n)&&~isnan(str2double(n)),'sar20owner:SID','Cannot map path back to native SID.');
    id=['blk_' n];
    resolved=path_by_id(model,id);assert(strcmpi(canonical(resolved),canonical(p)), ...
        'sar20owner:SIDRoundtrip','Native SID did not resolve back to the input signal block.');
end

function id=find_id(text,name)
    lines=splitlines(string(text));current='';hits={};
    for k=1:numel(lines)
        line=char(lines(k));t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
        if ~isempty(t),current=t{1};continue;end
        t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
        if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(current),hits{end+1}=current;current='';end %#ok<AGROW>
    end
    hits=unique(hits,'stable');assert(isscalar(hits),'sar20owner:Resolve','Expected one fresh model_read ID for %s, got %d.',name,numel(hits));id=hits{1};
end

function p=path_by_id(model,id)
    p=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
function text=read_scope(model,scope)
    text=char(model_read(model,scope,'0'));require_status(text,{'status: ok','status: success'});
end
function reply=edit_scope(model,scope,ops,layout)
    js=regexprep(jsonencode(ops),'[\r\n]','');reply=char(model_edit(model,scope,js,layout));
    if contains(strtrim(reply),'status: partial')||contains(strtrim(reply),'status: error')||contains(strtrim(reply),'status: failed')
        try,read_scope(model,scope);model_check(model,scope,'["unconnected_ports","unconnected_lines"]');catch,end
        error('sar20owner:ModelEdit','SATK model_edit returned a partial/error response: %s',reply);
    end
    require_status(reply,{'status: ok','status: success'});
end
function check=check_scope(model,scope)
    check=char(model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));
    assert(contains(check,'status: healthy')||contains(check,'status: no_errors'), ...
        'sar20owner:ModelCheck','model_check failed for %s: %s',scope,check);
end
function require_status(s,allowed)
    first=strtrim(strtok(char(s),newline));assert(any(strcmp(first,allowed)),'sar20owner:SATK','Unexpected SATK response status %s.',first);
end
function manifest=load_registry(cfg)
    oldPath=path;restore=onCleanup(@()path(oldPath)); %#ok<NASGU>
    src=fullfile(cfg.registry_source_root,'current','src');addpath(genpath(src),cfg.registry_source_root,'-begin');
    f=which('sar20_debug_fields');assert(~isempty(f),'sar20owner:Registry','Frozen sar20_debug_fields source missing.');
    manifest=sar20_debug_fields();assert(strcmp(manifest.schema,'sar20-debug-fields/v1'),'sar20owner:RegistrySchema','Unexpected registry schema.');
end
function rows=source_inventory(root)
    files=[dir(fullfile(root,'current','src','**','*.m'));dir(fullfile(root,'config','*.m'));dir(fullfile(root,'config','*.mat'));dir(fullfile(root,'SAR20.m'))];
    rows=struct('path',{},'bytes',{},'sha256',{});
    for k=1:numel(files)
        p=fullfile(files(k).folder,files(k).name);[h,n]=sha256(p,300e6);
        rows(end+1)=struct('path',relative_path(p,root),'bytes',n,'sha256',h); %#ok<AGROW>
    end
end
function hash=source_tree_hash(root)
    rows=source_inventory(root);[~,ix]=sort({rows.path});rows=rows(ix);text='';
    for k=1:numel(rows),text=[text rows(k).path char(9) rows(k).sha256 char(10)];end %#ok<AGROW>
    hash=sha_text(text);
end
function verify_run_source(root,manifest,cap)
    assert(isfield(manifest,'files'),'sar20owner:SourceManifest','Missing actual run source_manifest.files.');
    for k=1:numel(manifest.files)
        rel=strrep(char(manifest.files(k).path),'\','/');p=fullfile(root,strrep(rel,'/',filesep));
        assert(strcmp(sha256(p,cap),manifest.files(k).sha256),'sar20owner:SourceHash','As-run source SHA differs: %s.',rel);
    end
end
function [h,n]=sha256(p,cap)
    d=dir(p);assert(isscalar(d)&&~d.isdir&&d.bytes<=cap&&d.bytes<=300e6, ...
        'sar20owner:FileCap','Missing or oversized file: %s.',p);n=d.bytes;
    f=fopen(p,'rb');assert(f>=0,'sar20owner:Read','Cannot read %s.',p);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    m=java.security.MessageDigest.getInstance('SHA-256');while ~feof(f),b=fread(f,1024*1024,'*uint8');if ~isempty(b),m.update(typecast(b(:),'int8'));end,end
    h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
function h=sha_text(s)
    m=java.security.MessageDigest.getInstance('SHA-256');b=unicode2native(s,'UTF-8');m.update(typecast(uint8(b(:)),'int8'));
    h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function rel=relative_path(p,r),rel=replace(canonical(p),[canonical(r) filesep],'');end
function close_model(model),if bdIsLoaded(model)&&strcmp(get_param(model,'SimulationStatus'),'stopped'),close_system(model,0);end,end
function s=utc_now(),s=char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));end
function write_json(p,v),f=fopen(p,'w','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'%s\n',jsonencode(v));end
