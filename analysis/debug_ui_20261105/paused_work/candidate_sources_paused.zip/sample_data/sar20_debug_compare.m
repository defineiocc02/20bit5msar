function C = sar20_debug_compare(runPathA, runPathB, sampleID)
%SAR20_DEBUG_COMPARE Compare two archived SAR20 runs by ID and signal meaning.
%   C = sar20_debug_compare(runPathA,runPathB,sampleID)
%   Pure read-only comparison. It calls sar20_debug_sample for each archive,
%   then aligns event tokens by sample/epoch/type/index/bit/occurrence and taps
%   by the shared registry semantics. It does not use block paths, tolerances,
%   model factories, simulators, or file outputs.

    if nargin~=3
        error('sar20DebugCompare:arity','Usage: C = sar20_debug_compare(runPathA,runPathB,sampleID).');
    end
    if ~(isnumeric(sampleID)&&isreal(sampleID)&&isscalar(sampleID)&&isfinite(sampleID)&&sampleID>=0&&sampleID==floor(sampleID))
        error('sar20DebugCompare:id','sampleID must be a nonnegative integer; it is not a row number.');
    end
    sampleID=double(sampleID);
    A=sar20_debug_sample(runPathA,sampleID);
    B=sar20_debug_sample(runPathB,sampleID);

    [eventMatches,eventAKeys,eventBKeys]=compare_events(A.events,B.events);
    [signalComparisons,missingFields]=compare_waveforms(A,B,eventAKeys,eventBKeys);
    configDiffs=diff_config(A.configuration,B.configuration);
    output=compare_outputs(A,B);
    keyAlignment=compare_keys(A.keys,B.keys);
    validity=compare_validity(A,B,output.recordsAligned);
    first=first_difference(eventMatches,signalComparisons,output,keyAlignment);

    matched=nnz(strcmp(eventMatches.status,'matched'));
    eventMissing=nnz(ismember(eventMatches.status,{'missingA','missingB'}));
    eventDiff=nnz(ismember(eventMatches.status,{'time_mismatch','order_mismatch','event_identity_mismatch','co_timed_group_mismatch'})| ...
        strcmp(eventMatches.phaseExecutionStatus,'mismatch'));
    eventUnknown=nnz(ismember(eventMatches.phaseExecutionStatus,{'unobserved','missing'})| ...
        strcmp(eventMatches.status,'time_unrecorded'));
    signalEqual=nnz(strcmp(signalComparisons.status,'equal_bitwise'));
    signalDiff=nnz(strcmp(signalComparisons.status,'different_bitwise'));
    signalUnknown=nnz(ismember(signalComparisons.status,{'unrecorded','missing','unmatched_event','nonfinite_uncompared'}));
    outputMissing=nnz(ismember(output.rows.status,{'missing','unmatched_id_epoch','unmatched_time','unrecorded'}));
    validityUnknown=nnz(strcmp(validity.rows.status,'unrecorded'));

    C=struct();C.schema='sar20-debug-compare/v1';C.sampleID=sampleID;
    C.runA=A.run;C.runB=B.run;
    C.configuration=struct('hashA',A.run.configSHA256,'hashB',B.run.configSHA256, ...
        'exactDiffCount',height(configDiffs),'diffs',configDiffs, ...
        'comparison','Saved P structs compared recursively with exact MATLAB value equality.');
    C.samples=struct('requestedID',sampleID,'requestedEpochA',A.sample.requestedEpoch, ...
        'requestedEpochB',B.sample.requestedEpoch,'rawA',A.validity.selected, ...
        'rawB',B.validity.selected,'keysA',A.keys,'keysB',B.keys, ...
        'sameEpoch',isequaln(A.sample.requestedEpoch,B.sample.requestedEpoch), ...
        'sameRecordIdentity',output.sameRecordIdentity);
    C.keyAlignment=keyAlignment;
    C.events=eventMatches;
    C.signals=signalComparisons;
    C.missingFields=missingFields;
    C.output=output;
    C.validity=validity;
    C.firstDifference=first;
    C.summary=struct('matchedEvents',matched,'missingEvents',eventMissing, ...
        'eventMismatches',eventDiff,'eventExecutionUnknown',eventUnknown, ...
        'bitwiseEqualSignalRows',signalEqual,'differentSignalRows',signalDiff, ...
        'signalRowsUnmatchedOrUnrecorded',signalUnknown,'missingSemanticFields',height(missingFields), ...
        'outputRowsMissing',outputMissing,'validityRowsUnrecorded',validityUnknown, ...
        'configDiffs',height(configDiffs),'status',compare_status(first,eventMissing,signalUnknown, ...
        eventUnknown,outputMissing,validityUnknown,height(configDiffs)));
    C.method='Exact ID/epoch and semantic-field alignment. Numeric vectors compare IEEE bit patterns; no tolerance is used.';
end

function [T,keyA,keyB]=compare_events(A,B)
    [keyA,occA]=event_keys(A);[keyB,occB]=event_keys(B);
    rows=repmat(event_compare_proto(),0,1);usedB=false(height(B),1);
    for i=1:height(A)
        j=find(strcmp(keyB,keyA{i}));
        x=event_compare_proto();x.eventKey=keyA{i};x.eventName=char(string(A.eventName(i)));
        x.sampleID=A.sampleID(i);x.epoch=A.epoch(i);x.eventIndex=A.eventIndex(i);x.eventBit=A.eventBit(i);
        x.occurrence=occA(i);x.orderA=i;x.groupIndexA=A.groupIndex(i);x.phaseOrdinalA=A.phaseOrdinal(i);
        x.timeA_s=A.time_s(i);x.phaseExecutedA=A.phaseExecuted(i);x.identityMatchA=A.phaseIdentityMatch(i);
        x.phaseOrdinalEqual=NaN;x.eventGroupSignatureA=event_group_signature(A,i,keyA);
        if isscalar(j)
            usedB(j)=true;x.orderB=j;x.groupIndexB=B.groupIndex(j);x.phaseOrdinalB=B.phaseOrdinal(j);
            x.timeB_s=B.time_s(j);x.phaseExecutedB=B.phaseExecuted(j);x.identityMatchB=B.phaseIdentityMatch(j);
            x.eventGroupSignatureB=event_group_signature(B,j,keyB);
            x.phaseOrdinalEqual=double(A.phaseOrdinal(i)==B.phaseOrdinal(j));
            x.timeBitwiseEqual=double(isfinite(x.timeA_s)&&isfinite(x.timeB_s)&&bitwise_equal(x.timeA_s,x.timeB_s));
            x.orderEqual=double(i==j);
            if x.identityMatchA==0||x.identityMatchB==0
                x.status='event_identity_mismatch';
            elseif x.orderEqual==0
                x.status='order_mismatch';
            elseif ~strcmp(x.eventGroupSignatureA,x.eventGroupSignatureB)
                x.status='co_timed_group_mismatch';
            elseif ~isfinite(x.timeA_s)||~isfinite(x.timeB_s)
                x.status='time_unrecorded';
            elseif x.timeBitwiseEqual==0
                x.status='time_mismatch';
            else
                x.status='matched';
            end
            if isnan(x.phaseExecutedA)||isnan(x.phaseExecutedB)
                x.phaseExecutionStatus='unobserved';
            elseif x.phaseExecutedA~=x.phaseExecutedB
                x.phaseExecutionStatus='mismatch';
            elseif x.phaseExecutedA==1
                x.phaseExecutionStatus='both_executed';
            else
                x.phaseExecutionStatus='both_not_executed';
            end
            if isnan(x.identityMatchA)||isnan(x.identityMatchB),x.identityStatus='unrecorded';
            elseif x.identityMatchA==1&&x.identityMatchB==1,x.identityStatus='matched';
            else,x.identityStatus='mismatch';end
        else
            x.orderB=NaN;x.groupIndexB=NaN;x.phaseOrdinalB=NaN;x.timeB_s=NaN;
            x.phaseExecutedB=NaN;x.identityMatchB=NaN;x.timeBitwiseEqual=NaN;x.orderEqual=NaN;
            x.phaseOrdinalEqual=NaN;x.eventGroupSignatureB='';
            x.phaseExecutionStatus='missing';x.identityStatus='missingB';x.status='missingB';
        end
        rows(end+1,1)=x; %#ok<AGROW>
    end
    for j=find(~usedB(:)).'
        x=event_compare_proto();x.eventKey=keyB{j};x.eventName=char(string(B.eventName(j)));
        x.sampleID=B.sampleID(j);x.epoch=B.epoch(j);x.eventIndex=B.eventIndex(j);x.eventBit=B.eventBit(j);
        x.occurrence=occB(j);x.orderA=NaN;x.groupIndexA=NaN;x.phaseOrdinalA=NaN;x.timeA_s=NaN;
        x.phaseExecutedA=NaN;x.identityMatchA=NaN;x.orderB=j;x.groupIndexB=B.groupIndex(j);
        x.phaseOrdinalB=B.phaseOrdinal(j);x.timeB_s=B.time_s(j);x.phaseExecutedB=B.phaseExecuted(j);
        x.identityMatchB=B.phaseIdentityMatch(j);x.timeBitwiseEqual=NaN;x.orderEqual=NaN;
        x.phaseOrdinalEqual=NaN;x.eventGroupSignatureA='';x.eventGroupSignatureB=event_group_signature(B,j,keyB);
        x.phaseExecutionStatus='missing';x.identityStatus='missingA';x.status='missingA';
        rows(end+1,1)=x; %#ok<AGROW>
    end
    if isempty(rows),T=struct2table(repmat(event_compare_proto(),0,1));else,T=struct2table(rows);end
end

function p=event_compare_proto()
    p=struct('eventKey','','eventName','','sampleID',NaN,'epoch',NaN,'eventIndex',NaN, ...
        'eventBit',NaN,'occurrence',NaN,'orderA',NaN,'orderB',NaN, ...
        'groupIndexA',NaN,'groupIndexB',NaN,'phaseOrdinalA',NaN,'phaseOrdinalB',NaN, ...
        'eventGroupSignatureA','','eventGroupSignatureB','','phaseOrdinalEqual',NaN, ...
        'timeA_s',NaN,'timeB_s',NaN,'timeBitwiseEqual',NaN,'orderEqual',NaN, ...
        'phaseExecutedA',NaN,'phaseExecutedB',NaN,'phaseExecutionStatus','', ...
        'identityMatchA',NaN,'identityMatchB',NaN,'identityStatus','','status','');
end

function [keys,occ]=event_keys(E)
    keys=cell(height(E),1);occ=zeros(height(E),1);seen={};counts=[];
    for i=1:height(E)
        base=sprintf('id=%s|epoch=%s|type=%s|index=%s|bit=%s', ...
            numeric_key(E.sampleID(i)),numeric_key(E.epoch(i)),char(string(E.eventName(i))), ...
            numeric_key(E.eventIndex(i)),numeric_key(E.eventBit(i)));
        q=find(strcmp(seen,base),1,'first');
        if isempty(q),seen{end+1}=base;counts(end+1)=0;q=numel(seen);end %#ok<AGROW>
        counts(q)=counts(q)+1;occ(i)=counts(q);keys{i}=sprintf('%s|occurrence=%d',base,occ(i));
    end
end

function s=event_group_signature(E,row,keys)
    s='unmapped_group';
    if isfinite(E.eventGroupRow(row))
        ix=find(E.eventGroupRow==E.eventGroupRow(row));
    elseif isfinite(E.observerOuterRow(row))
        ix=find(E.observerOuterRow==E.observerOuterRow(row));
    else
        ix=row;
    end
    if isempty(ix),return;end
    [~,ord]=sort(E.phaseOrdinal(ix),'ascend');ix=ix(ord);
    s=['group[' strjoin(keys(ix),'||') ']'];
end

function x=numeric_key(v)
    if isnumeric(v)&&isscalar(v)&&isnan(v),x='NaN';
    elseif isnumeric(v)&&isscalar(v),x=sprintf('%.17g',double(v));
    else,x=char(string(v));end
end

function [C,missing]=compare_waveforms(A,B,eventKeysA,eventKeysB)
    [obsA,fieldA,missA]=flatten_waveforms(A);
    [obsB,fieldB,missB]=flatten_waveforms(B);
    fieldKeysA={fieldA.semanticKey};fieldKeysB={fieldB.semanticKey};
    allFields=unique([fieldKeysA fieldKeysB],'stable');
    missingRows=repmat(missing_field_proto(),0,1);
    for k=1:numel(allFields)
        hasA=any(strcmp(fieldKeysA,allFields{k}));hasB=any(strcmp(fieldKeysB,allFields{k}));
        if ~hasA||~hasB
            f=fieldA([]);if hasA,f=fieldA(find(strcmp(fieldKeysA,allFields{k}),1));elseif hasB,f=fieldB(find(strcmp(fieldKeysB,allFields{k}),1));end
            m=missing_field_proto();m.semanticKey=allFields{k};m.tapKey=f.tapKey;m.group=f.group;m.signal=f.signal;
            m.unit=f.unit;m.voltageReference=f.voltageReference;m.owner=f.owner;m.updateStage=f.updateStage;
            if hasA,m.side='B';m.reason='Semantic field is not present in run B registry taps.';
            else,m.side='A';m.reason='Semantic field is not present in run A registry taps.';end
            missingRows(end+1,1)=m; %#ok<AGROW>
        end
    end
    missingRows=[missingRows;missA(:);missB(:)];
    rows=repmat(signal_compare_proto(),0,1);usedB=false(numel(obsB),1);
    for i=1:numel(obsA)
        a=obsA(i);j=find(strcmp({obsB.semanticKey},a.semanticKey)&strcmp({obsB.eventKey},a.eventKey)& ...
            [obsB.occurrence]==a.occurrence);
        x=signal_compare_proto();x.semanticKey=a.semanticKey;x.tapKey=a.tapKey;x.group=a.group;x.signal=a.signal;
        x.unit=a.unit;x.voltageReference=a.voltageReference;x.meaning=a.meaning;x.owner=a.owner;
        x.updateStage=a.updateStage;x.observationGroup=a.observationGroup;x.eventKey=a.eventKey;
        x.eventName=a.eventName;x.eventOrderA=a.eventOrder;x.sourceTapA=a.sourceTap;x.valueA=a.value;
        x.recordedA=a.recorded;x.reasonA=a.reason;x.status='';
        if isscalar(j)
            b=obsB(j);usedB(j)=true;x.eventOrderB=b.eventOrder;x.sourceTapB=b.sourceTap;x.valueB=b.value;
            x.recordedB=b.recorded;x.reasonB=b.reason;
            if ~(a.recorded==1&&b.recorded==1)
                x.status='unrecorded';
            elseif contains_nonfinite(a.value)||contains_nonfinite(b.value)
                x.status='nonfinite_uncompared';
                x.reasonA=[x.reasonA ' | NaN/Inf is not treated as a measured matching value.'];
                x.reasonB=[x.reasonB ' | NaN/Inf is not treated as a measured matching value.'];
            elseif exact_value_equal(a.value,b.value)
                x.status='equal_bitwise';
            else
                x.status='different_bitwise';
            end
        else
            x.eventOrderB=NaN;x.sourceTapB='';x.valueB=[];x.recordedB=NaN;x.reasonB='No same semantic event observation in run B.';
            x.status='missing';
        end
        rows(end+1,1)=x; %#ok<AGROW>
    end
    for j=find(~usedB(:)).'
        b=obsB(j);x=signal_compare_proto();x.semanticKey=b.semanticKey;x.tapKey=b.tapKey;x.group=b.group;x.signal=b.signal;
        x.unit=b.unit;x.voltageReference=b.voltageReference;x.meaning=b.meaning;x.owner=b.owner;
        x.updateStage=b.updateStage;x.observationGroup=b.observationGroup;x.eventKey=b.eventKey;
        x.eventName=b.eventName;x.eventOrderA=NaN;x.eventOrderB=b.eventOrder;x.sourceTapA='';x.sourceTapB=b.sourceTap;
        x.valueA=[];x.valueB=b.value;x.recordedA=NaN;x.recordedB=b.recorded;
        x.reasonA='No same semantic event observation in run A.';x.reasonB=b.reason;
        x.status='missing';rows(end+1,1)=x; %#ok<AGROW>
    end
    if isempty(rows),C=struct2table(repmat(signal_compare_proto(),0,1));else,C=struct2table(rows);end
    if isempty(missingRows),missing=struct2table(repmat(missing_field_proto(),0,1));else,missing=struct2table(missingRows);end
end

function [obs,fields,missing]=flatten_waveforms(D)
    obs=repmat(observation_proto(),0,1);fields=repmat(field_proto(),0,1);
    missing=repmat(missing_field_proto(),0,1);occSeen={};occCount=[];
    for wi=1:numel(D.waveforms)
        W=D.waveforms(wi);defs=W.fields;
        if isempty(defs),continue;end
        for fi=1:numel(defs)
            f=defs(fi);signal=char(f.signal);variable=signal;
            if ~istable(W.values),continue;end
            vars=W.values.Properties.VariableNames;
            if ~any(strcmp(vars,variable))
                if exist('matlab.lang.makeValidName','file')==2,variable=matlab.lang.makeValidName(signal);end
            end
            fd=field_proto();fd.tapKey=W.tapKey;fd.semanticKey=field_key(f,W);fd.group=field_text(f,'group',W.group);
            fd.signal=signal;fd.unit=field_text(f,'unit','');fd.voltageReference=field_text(f,'voltage_reference','');
            fd.meaning=field_text(f,'meaning','');fd.owner=field_text(f,'owner','');
            fd.updateStage=field_text(f,'update_stage','');fields(end+1,1)=fd; %#ok<AGROW>
            if ~any(strcmp(vars,variable))
                m=missing_field_proto();m.semanticKey=fd.semanticKey;m.tapKey=fd.tapKey;m.group=fd.group;m.signal=fd.signal;
                m.unit=fd.unit;m.voltageReference=fd.voltageReference;m.owner=fd.owner;m.updateStage=fd.updateStage;
                m.side='both';m.reason='Registered signal has no corresponding values-table column.';missing(end+1,1)=m; %#ok<AGROW>
                continue;
            end
            col=W.values.(variable);n=min(height(W.values),height(W.metadata));
            for r=1:n
                [ek,eventName,eventOrder,scopeReason]=row_event_key(D,r,W.metadata,event_keys(D.events));
                [recorded,reason]=row_recorded(W.metadata,r,W.available,W.reason);
                base=[fd.semanticKey '|' ek];idx=find(strcmp(occSeen,base),1,'first');
                if isempty(idx),occSeen{end+1}=base;occCount(end+1)=0;idx=numel(occSeen);end %#ok<AGROW>
                occCount(idx)=occCount(idx)+1;
                value=col(r);if iscell(value)&&isscalar(value),value=value{1};end
                o=observation_proto();o.semanticKey=fd.semanticKey;o.tapKey=fd.tapKey;o.group=fd.group;o.signal=fd.signal;
                o.unit=fd.unit;o.voltageReference=fd.voltageReference;o.meaning=fd.meaning;o.owner=fd.owner;
                o.updateStage=fd.updateStage;o.observationGroup=W.tapKey;
                o.eventKey=ek;o.eventName=eventName;o.eventOrder=eventOrder;o.occurrence=occCount(idx);
                o.value=value;o.recorded=recorded;o.reason=[reason scopeReason];o.sourceTap=W.sourceTap;
                obs(end+1,1)=o; %#ok<AGROW>
            end
        end
    end
    % Keep one field definition per semantic key.
    if ~isempty(fields)
        [~,ix]=unique({fields.semanticKey},'stable');fields=fields(ix);
    end
end

function [key,name,order,reason]=row_event_key(D,row,M,eventKeys)
    key='unmatched_event';name='';order=NaN;reason=' No exact semantic event link in tap metadata.';
    if ~istable(M)||row>height(M),return;end
    rows=[];
    if any(strcmp(M.Properties.VariableNames,'eventRow'))&&isfinite(double(M.eventRow(row)))
        rows=double(M.eventRow(row));
    elseif any(strcmp(M.Properties.VariableNames,'eventRows'))
        q=M.eventRows{row};if isnumeric(q),rows=q(:).';end
    end
    if isempty(rows),return;end
    rows=rows(rows>=1&rows<=height(D.events));if isempty(rows),return;end
    if numel(rows)==1
        order=rows(1);key=eventKeys{order};name=char(string(D.events.eventName(order)));reason='';return;
    end
    parts=eventKeys(rows);key=['group[' strjoin(parts,'||') ']'];name='co-timed event group';order=min(rows);
    reason=' Tap row is group-scoped across multiple co-timed event tokens.';
end

function [recorded,reason]=row_recorded(M,row,groupAvailable,groupReason)
    recorded=NaN;reason=groupReason;
    if istable(M)&&row<=height(M)
        names=M.Properties.VariableNames;
        if any(strcmp(names,'decoded_tap_recorded')),recorded=double(M.decoded_tap_recorded(row));
        elseif any(strcmp(names,'recorded')),recorded=double(M.recorded(row));
        elseif groupAvailable,recorded=1;end
        if any(strcmp(names,'decoded_reason')),reason=char(string(M.decoded_reason(row)));
        elseif any(strcmp(names,'reason')),reason=char(string(M.reason(row)));end
    end
end

function key=field_key(f,W)
    key=strjoin({W.tapKey,field_text(f,'group',W.group),field_text(f,'signal',''), ...
        field_text(f,'unit',''),field_text(f,'voltage_reference',''), ...
        field_text(f,'owner',''),field_text(f,'update_stage','')},'|');
end

function x=field_text(S,name,fallback)
    x=fallback;if isfield(S,name),v=S.(name);if isstring(v),x=char(v);elseif ischar(v),x=v;end,end
end

function p=field_proto()
    p=struct('semanticKey','','tapKey','','group','','signal','','unit','','voltageReference','', ...
        'meaning','','owner','','updateStage','');
end

function p=observation_proto()
    p=struct('semanticKey','','tapKey','','group','','signal','','unit','','voltageReference','', ...
        'meaning','','owner','','updateStage','','observationGroup','','eventKey','', ...
        'eventName','','eventOrder',NaN,'occurrence',NaN,'value',[],'recorded',NaN, ...
        'reason','','sourceTap','');
end

function p=missing_field_proto()
    p=struct('semanticKey','','tapKey','','group','','signal','','unit','','voltageReference','', ...
        'owner','','updateStage','','side','','reason','');
end

function p=signal_compare_proto()
    p=struct('semanticKey','','tapKey','','group','','signal','','unit','','voltageReference','', ...
        'meaning','','owner','','updateStage','','observationGroup','','eventKey','', ...
        'eventName','','eventOrderA',NaN,'eventOrderB',NaN,'sourceTapA','','sourceTapB','', ...
        'valueA',[],'valueB',[],'recordedA',NaN,'recordedB',NaN,'reasonA','','reasonB','','status','');
end

function p=cfg_diff_proto()
    p=struct('path','','status','','classA','','classB','','valueA','','valueB','');
end

function T=diff_config(A,B)
    rows=repmat(cfg_diff_proto(),0,1);rows=diff_value(A,B,'P',rows);
    if isempty(rows),T=struct2table(rows);else,T=struct2table(rows);end
end

function rows=diff_value(a,b,path,rows)
    if strcmp(class(a),class(b))&&isequaln(a,b),return;end
    if isstruct(a)&&isstruct(b)&&isequal(size(a),size(b))
        fa=fieldnames(a);fb=fieldnames(b);allFields=unique([fa;fb],'stable');
        for i=1:numel(a)
            for k=1:numel(allFields)
                f=allFields{k};sub=[path '.' f];
                if ~isfield(a(i),f),rows=append_config_diff(rows,sub,'missingA',[],b(i).(f));
                elseif ~isfield(b(i),f),rows=append_config_diff(rows,sub,'missingB',a(i).(f),[]);
                else,rows=diff_value(a(i).(f),b(i).(f),sub,rows);end
            end
        end
        return;
    end
    if iscell(a)&&iscell(b)&&isequal(size(a),size(b))
        for k=1:numel(a),rows=diff_value(a{k},b{k},sprintf('%s{%d}',path,k),rows);end
        return;
    end
    rows=append_config_diff(rows,path,'different',a,b);
end

function rows=append_config_diff(rows,path,status,a,b)
    q=cfg_diff_proto();q.path=path;q.status=status;q.classA=class(a);q.classB=class(b);
    q.valueA=short_value(a);q.valueB=short_value(b);rows(end+1,1)=q;
end

function s=short_value(x)
    if ischar(x),s=x;return;end
    if isstring(x),s=strjoin(cellstr(x(:).'),',');return;end
    if isnumeric(x)||islogical(x)
        if isempty(x),s='[]';return;end
        flat=x(:);n=min(numel(flat),8);
        if isnumeric(x),s=[mat2str(size(x)) ':' mat2str(flat(1:n).',17)];
        else,s=[mat2str(size(x)) ':' mat2str(flat(1:n).')];end
        if numel(flat)>n,s=[s ' ...'];end
    else
        s=sprintf('%s %s',class(x),mat2str(size(x)));
    end
end

function O=compare_outputs(A,B)
    a=A.validity.selected;b=B.validity.selected;
    sameID=a.available&&b.available&&isequaln(a.recordID,b.recordID);
    sameEpoch=a.available&&b.available&&isequaln(a.recordEpoch,b.recordEpoch);
    identityMatch=NaN;identityStatus='unrecorded_both';
    if a.available&&b.available
        identityMatch=double(sameID&&sameEpoch);
        if identityMatch,identityStatus='matched_same_ID_epoch';else,identityStatus='unmatched_ID_epoch';end
    elseif xor(a.available,b.available)
        identityMatch=0;identityStatus='record_missing_one_run';
    end
    recordTimeEqual=NaN;
    if a.available&&b.available&&isfinite(a.time_s)&&isfinite(b.time_s)
        recordTimeEqual=double(bitwise_equal(a.time_s,b.time_s));
    end
    recordsAligned=identityMatch==1&&recordTimeEqual==1;
    names={'recordID','recordEpoch','time_s','D1','D2','DT','code20'};rows=repmat(output_compare_proto(),0,1);
    for k=1:numel(names)
        name=names{k};va=a.(name);vb=b.(name);q=output_compare_proto();
        q.signal=name;q.valueA=va;q.valueB=vb;
        if any(strcmp(name,{'recordID','recordEpoch','time_s'}))
            q.alignedA=a.available;q.alignedB=b.available;
        elseif strcmp(name,'code20')
            q.alignedA=a.available&&a.code20Aligned;q.alignedB=b.available&&b.code20Aligned;
        else
            q.alignedA=a.available;q.alignedB=b.available;
        end
        q.status='missing';
        if q.alignedA&&q.alignedB
            if any(strcmp(name,{'recordID','recordEpoch','time_s'}))
                if exact_value_equal(va,vb),q.status='equal_bitwise';else,q.status='different_bitwise';end
            elseif identityMatch==0
                q.status='unmatched_id_epoch';
            elseif identityMatch==1&&recordTimeEqual==0
                q.status='unmatched_time';
            elseif isnan(identityMatch)||isnan(recordTimeEqual)
                q.status='unrecorded';
            elseif ~isfinite(double(va))||~isfinite(double(vb))
                q.status='unrecorded';
            elseif exact_value_equal(va,vb)
                q.status='equal_bitwise';
            else
                q.status='different_bitwise';
            end
        end
        rows(end+1,1)=q; %#ok<AGROW>
    end
    O=struct('rows',struct2table(rows),'recordIdA',a.recordID,'recordIdB',b.recordID, ...
        'epochA',a.recordEpoch,'epochB',b.recordEpoch,'timeA_s',a.time_s,'timeB_s',b.time_s, ...
        'sameRecordIdentity',identityMatch,'identityStatus',identityStatus, ...
        'recordTimeBitwiseEqual',recordTimeEqual,'recordsAligned',recordsAligned, ...
        'validRecordA',a.validRecord,'validRecordB',b.validRecord, ...
        'rawAndCodeAlignedA',a.available&&a.code20Aligned,'rawAndCodeAlignedB',b.available&&b.code20Aligned);
end

function p=output_compare_proto()
    p=struct('signal','','valueA',NaN,'valueB',NaN,'alignedA',false,'alignedB',false,'status','');
end

function V=compare_validity(A,B,recordsAligned)
    fields={'RecordReady','RAW_valid','validRecord_event','oldCodeValidBank','code20Aligned','code20Legal'};
    rows=repmat(output_compare_proto(),0,1);
    for k=1:numel(fields)
        f=fields{k};a=A.validity.(f);b=B.validity.(f);
        q=output_compare_proto();q.signal=f;q.valueA=a;q.valueB=b;
        q.alignedA=isfinite(double(a));q.alignedB=isfinite(double(b));
        if q.alignedA&&q.alignedB
            if ~recordsAligned,q.status='unmatched_time_or_ID_epoch';
            elseif exact_value_equal(a,b),q.status='equal_bitwise';else,q.status='different_bitwise';end
        else,q.status='unrecorded';end
        rows(end+1,1)=q; %#ok<AGROW>
    end
    V=struct('rows',struct2table(rows),'bankEnabledA',A.validity.bank_enabled, ...
        'bankEnabledB',B.validity.bank_enabled,'label',A.validity.oldCodeValidLabel, ...
        'semantics','old CodeValid is Bank qualification only; record validity is RecordReady && RAW.valid.');
end

function first=first_difference(events,signals,output)
    first=struct('found',false,'eventRowA',NaN,'eventRowB',NaN,'eventName','', ...
        'phase','','field','','valueA',[],'valueB',[],'sourceTapA','','sourceTapB','', ...
        'status','equal_or_unobserved','reason','No observed bitwise difference was found in matched evidence.');
    if output.sameRecordIdentity==0
        first.found=true;first.field='output.record_identity';first.status='unmatched_id_epoch';
        first.valueA=[output.recordIdA output.epochA];first.valueB=[output.recordIdB output.epochB];
        first.reason='Output RAW ID/epoch do not match; code and validity words are not paired across rows.';return;
    end
    if output.sameRecordIdentity==1&&output.recordTimeBitwiseEqual==0
        first.found=true;first.field='output.recordTime_s';first.status='unmatched_time';
        first.valueA=output.timeA_s;first.valueB=output.timeB_s;
        first.reason='Same-ID/epoch output rows have different exact RecordReady times; their values are not paired.';return;
    end
    if ~isempty(events)
        ix=find(ismember(events.status,{'missingA','missingB','time_mismatch','order_mismatch','event_identity_mismatch','co_timed_group_mismatch'})| ...
            strcmp(events.phaseExecutionStatus,'mismatch'),1,'first');
        if ~isempty(ix)
            first.found=true;first.eventRowA=events.orderA(ix);first.eventRowB=events.orderB(ix);
            first.eventName=char(string(events.eventName(ix)));
            first.phase=sprintf('%s[%g]',first.eventName,events.phaseOrdinalA(ix));
            first.field='event';first.status=char(string(events.status(ix)));
            if strcmp(events.phaseExecutionStatus(ix),'mismatch'),first.status='phase_execution_mismatch';end
            first.reason='First event sequence, timing, execution or identity difference.';return;
        end
    end
    if ~isempty(signals)
        candidates=find(strcmp(signals.status,'different_bitwise'));
        valid=[];
        if ~isempty(candidates)
            order=signals.eventOrderA(candidates);order(~isfinite(order))=Inf;
            [~,ix]=sort(order,'ascend');valid=candidates(ix(1));
        end
        if ~isempty(valid)
            q=signals(valid);first.found=true;first.eventRowA=q.eventOrderA;first.eventRowB=q.eventOrderB;
            first.eventName=q.eventName;first.phase=q.observationGroup;first.field=q.signal;
            first.valueA=q.valueA;first.valueB=q.valueB;first.sourceTapA=q.sourceTapA;first.sourceTapB=q.sourceTapB;
            first.status=q.status;first.reason='First semantic signal with different exact numeric bit pattern.';return;
        end
    end
    if ~isempty(output.rows)
        ix=find(strcmp(output.rows.status,'different_bitwise'),1,'first');
        if ~isempty(ix)
            first.found=true;first.field=['output.' output.rows.signal{ix}];
            first.valueA=output.rows.valueA(ix);first.valueB=output.rows.valueB(ix);
            first.status=output.rows.status{ix};first.reason='First difference in the same-ID/epoch public RAW/code record.';
        end
    end
end

function s=compare_status(first,eventMissing,signalUnknown,eventUnknown,outputMissing,validityUnknown,configDiffCount)
    if first.found,s='different';
    elseif eventMissing>0||signalUnknown>0||eventUnknown>0||outputMissing>0||validityUnknown>0,s='incomplete_or_unmatched';
    elseif configDiffCount>0,s='configuration_diff';
    else,s='equal_on_recorded_fields';end
end

function yes=contains_nonfinite(value)
    yes=false;
    if isnumeric(value),yes=any(~isfinite(value(:)));end
end

function yes=exact_value_equal(a,b)
    yes=false;
    if isnumeric(a)&&isnumeric(b)&&strcmp(class(a),class(b))&&isequal(size(a),size(b))
        if isa(a,'double'),yes=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
        elseif isa(a,'single'),yes=isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
        else,yes=isequal(a,b);end
    else
        yes=isequaln(a,b);
    end
end
'''
p.write_text(s[:a]+new+s[b:])
PY
