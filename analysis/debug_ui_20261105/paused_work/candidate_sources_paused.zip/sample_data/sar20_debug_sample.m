function D = sar20_debug_sample(runPath, sampleID)
%SAR20_DEBUG_SAMPLE Read one archived SAR20 conversion without running a model.
%   D = sar20_debug_sample(runPath, sampleID)
%   Reads only the selected archive's simout.mat, parameters.mat and summary.json.
%   It never calls a model/configuration/physics factory and never writes files.
%
% sampleID is the actual conversion/event ID. It is not a row number. Event
% rows preserve the source log order, and tokens preserve P.groups(g).events
% order (including co-timed tokens). Values whose source tap was not logged are
% represented by NaN and an explicit reason.

    if nargin ~= 2
        error('sar20DebugSample:arity','Usage: D = sar20_debug_sample(runPath, sampleID).');
    end
    runPath = char(runPath);
    if ~isfolder(runPath)
        error('sar20DebugSample:runPath','Archive run folder does not exist: %s',runPath);
    end
    sampleID = validate_id(sampleID);
    files = struct('simout',fullfile(runPath,'simout.mat'), ...
        'parameters',fullfile(runPath,'parameters.mat'), ...
        'summary',fullfile(runPath,'summary.json'), ...
        'observerContract',fullfile(runPath,'observer_contract.json'));
    require_small_file(files.simout);
    require_small_file(files.parameters);
    require_small_file(files.summary);
    require_small_file(files.observerContract);
    if ~isfile(files.simout) || ~isfile(files.parameters) || ~isfile(files.summary)
        error('sar20DebugSample:archive','Require simout.mat, parameters.mat and summary.json in the run folder.');
    end

    meta = jsondecode(fileread(files.summary));
    pLoad = load(files.parameters,'P');
    sLoad = load(files.simout,'simout');
    if ~isfield(pLoad,'P') || ~isstruct(pLoad.P) || ~isscalar(pLoad.P)
        error('sar20DebugSample:parameters','parameters.mat does not contain one saved P struct.');
    end
    if ~isfield(sLoad,'simout') || ~isa(sLoad.simout,'Simulink.SimulationOutput')
        error('sar20DebugSample:simout','simout.mat does not contain a Simulink.SimulationOutput.');
    end
    P = pLoad.P;
    out = sLoad.simout;
    if ~isempty(out.ErrorMessage)
        error('sar20DebugSample:simulationError','Archived SimulationOutput contains ErrorMessage.');
    end
    if ~isfield(meta,'simulation_completed') || ~meta.simulation_completed
        error('sar20DebugSample:incomplete','The archived simulation is not marked completed in summary.json.');
    end
    if ~all(isfield(P,{'epoch','Ts_s','groups'}))
        error('sar20DebugSample:P','Saved P lacks epoch, Ts_s or groups.');
    end
    if exist('sar20_debug_fields','file')~=2
        error('sar20DebugSample:registry','sar20_debug_fields is required for the unique signal schema.');
    end
    R=sar20_debug_fields();observerContract=observer_bundle_contract(R);

    listed = out.who;
    if isstring(listed), listed = cellstr(listed); end
    if ischar(listed), listed = cellstr(listed); end
    groups = P.groups;
    if isfield(P,'transport') && isfield(P.transport,'enabled') && P.transport.enabled && isfield(P,'adc_groups')
        groups = P.adc_groups;
    end
    validate_groups(groups);

    d2empty = struct('available',false,'eventRow',NaN,'eventGroupRow',NaN, ...
        'sampleID',sampleID,'epoch',double(P.epoch),'groupIndex',NaN,'phaseOrdinal',NaN, ...
        'time_s',NaN,'timeFromCnv_s',NaN,'eventName','d2_decide', ...
        'comparisonUsed',NaN,'comparisonInput_v',NaN,'comparisonOffset_v',NaN, ...
        'comparisonNoise_v',NaN,'decision',NaN,'decisionValid',NaN, ...
        'decision_source','unrecorded_actual_comparator','VX_stage_v',NaN, ...
        'VY_stage_v',NaN,'VX_stage_source','','VY_stage_source','', ...
        'stageValueReason','VX/VY stage values are not actual comparator input without a comparison tap.', ...
        'rawFinalD2',NaN,'rawFinalD2Reason','', ...
        'sample_id',sampleID,'phase','d2_decide','actualSimulationTime_s',NaN, ...
        'modelEventTime_s',NaN,'phaseModelEventTime_s',NaN, ...
        'phaseTimeBitwiseEqual',NaN,'phaseTimeCompareReason','', ...
        'eventTimeBitwiseEqual',NaN, ...
        'sourceTap','','reason','未记录首次 D2 的真实比较器输入/判决。');

    eventAlias=registry_log_alias(R,'EventLog2');parentAlias=registry_log_alias(R,'ParentEventLog2');
    eventLog = decode_event_log(read_log(out,listed,eventAlias.logger_name,eventAlias.width),eventAlias.group,'sample_id');
    parentLog = decode_event_log(read_log(out,listed,parentAlias.logger_name,parentAlias.width),parentAlias.group,'parent_id');
    [events,eventRows] = build_events(eventLog,parentLog,groups,P,sampleID);
    records = build_records(out,listed,R,P,sampleID,eventLog,events);
    events = attach_event_flags(events,records,eventLog,sampleID,P);

    D = struct();
    D.schema = 'sar20-debug-sample/v1';
    D.run = run_identity(runPath,meta,files);
    D.configuration = P;
    D.sample = struct('requestedID',sampleID,'requestedEpoch',double(P.epoch), ...
        'sampleIDMeaning','Actual event/conversion ID; not an array row index.', ...
        'eventWindowStatus','Calendar/event-log view; missing phase taps remain explicitly unknown.');
    D.keys = struct();
    D.events = events;
    D.eventGroups = table();
    D.waveforms = repmat(waveform_proto(),0,1);
    D.traces = repmat(trace_proto(),0,1);
    D.records = records.table;
    D.validity = records.validity;
    D.snapshots = missing_snapshots(events,runPath);
    D.handoffs = empty_handoffs('No exact next/old state taps were available in this archive.');
    D.observer = struct('available',false,'logger',observerContract.logger_name, ...
        'expectedRows',observerContract.expected_selected_sample_rows, ...
        'maxDataPoints',observerContract.max_data_points, ...
        'reason','Observer trace not recorded in this archived run.');
    D.firstD2 = d2empty;

    % Legacy event-aligned observations. Each logger remains its own source
    % group; no interpolation and no resampling are applied.
    specs={'RAW6','Ready1','FrontendObs7','BackendObs8','Control13'};
    for k = 1:numel(specs)
        groupName=specs{k};alias=registry_log_alias(R,groupName);name=alias.logger_name;
        L = read_log(out,listed,name,alias.width);
        if ~L.present, continue; end
        [keep,groupRow,linkReason] = select_event_rows(L.time,L.values,eventRows,sampleID,P);
        if ~any(keep), continue; end
        L.time = L.time(keep); L.values = L.values(keep,:);
        groupRow = groupRow(keep); linkReason = linkReason(keep);
        metaRows = make_row_meta(L.time,groupRow,linkReason,events,eventRows,sampleID,P);
        decoded = [];
        if ~isempty(groupName)
            decoded = decode_group(groupName,L.values,metaRows,name);
        end
        if ~isempty(decoded) && isstruct(decoded) && isfield(decoded,'values') && istable(decoded.values)
            valueTable = decoded.values;
        else
            valueTable = array2table(L.values);
        end
        item = trace_proto();
        item.group = groupName; item.logger = name;
        item.sourceTap = ['SimulationOutput.' name];
        item.observationKind = legacy_observation_kind(groupName);
        item.time_s = L.time; item.values = valueTable; item.rawValues=L.values;item.metadata = metaRows;
        item.fields = decoded_fields(decoded); item.decoded = decoded;
        item.available = true; item.reason = '';
        if isempty(decoded)
            item.reason='Registry decoder not loaded; values contain unnamed raw columns only.';
        end
        D.traces(end+1,1) = item; %#ok<AGROW>
        D.waveforms(end+1,1) = waveform_from_trace(item); %#ok<AGROW>
    end
    [recordTraces,recordWaves]=build_output_traces(records,D.events,R,sampleID,double(P.epoch));
    D.traces=[D.traces;recordTraces(:)];D.waveforms=[D.waveforms;recordWaves(:)];

    % New passive observer: one saved Timeseries row per event package. The
    % decoder owns the 18-section bundle layout and all ABI column mappings.
    observerReadError='';
    try
        observerLog = read_log(out,listed,observerContract.logger_name,-1);
    catch cause
        if strcmp(cause.identifier,'sar20DebugSample:loggerClass')
            observerReadError=cause.message;
            observerLog=struct('present',false,'name',observerContract.logger_name, ...
                'time',zeros(0,1),'values',zeros(0,0),'reason',cause.message);
        else,rethrow(cause);end
    end
    contractInfo=read_observer_contract(files.observerContract,observerLog,observerContract,R);
    if ~isempty(observerReadError)
        contractInfo.status='unsupported_logger_type';contractInfo.compatible=false;contractInfo.complete=false;
        contractInfo.reason=observerReadError;
    end
    D.observer.contract=contractInfo;
    if ~isempty(observerReadError),D.observer.reason=observerReadError;end
    if observerLog.present
        if size(observerLog.values,2)~=observerContract.width||isequal(contractInfo.compatible,false)
            D.observer.time_s=observerLog.time;D.observer.rawValues=observerLog.values;
            D.observer.reason=contractInfo.reason;
        else
        obsMeta = struct('sourceLogger',observerContract.logger_name, ...
            'outerSimulationTime_s',observerLog.time,'requestedSampleID',sampleID, ...
            'requestedEpoch',double(P.epoch),'groups',groups,'samplePeriod_s',double(P.Ts_s), ...
            'eventGroupRows',eventRows,'eventLogTime_s',eventLog.time, ...
            'eventLogValues',eventLog.values);
        decoded = decode_group(observerContract.logger_name,observerLog.values,obsMeta,observerContract.logger_name);
        if isempty(decoded)
            D.observer.reason = [observerContract.logger_name ' exists but sar20_debug_decode is unavailable.'];
        else
            D.observer = struct('available',true,'logger',observerContract.logger_name, ...
                'time_s',observerLog.time,'decoded',decoded,'time_check',[], ...
                'expectedRows',observerContract.expected_selected_sample_rows, ...
                'maxDataPoints',observerContract.max_data_points, ...
                'contract',contractInfo,'reason','');
            if isfield(decoded,'time_check'),D.observer.time_check=decoded.time_check;end
            if isfield(decoded,'completeness'),D.observer.completeness=decoded.completeness;end
            D.events = merge_observer_context(D.events,decoded,groups,eventLog,P,sampleID);
            phaseEvents=observer_event_rows(decoded,groups,D.events,P,sampleID);
            D.observer.eventSlots=phaseEvents;
            if ~isempty(phaseEvents),D.observer.unmatchedEventSlots=phaseEvents(phaseEvents.identityMatch~=1,:);
            else,D.observer.unmatchedEventSlots=phaseEvents;end
            D.events=merge_observer_events(D.events,phaseEvents);
            [obsEvents,obsWaves,obsSnaps,obsHandoffs,eventGroups] = observer_views(decoded,observerLog,D.events,groups,P,sampleID);
            D.events = merge_observer_events(D.events,obsEvents);
            D.waveforms = [D.waveforms;obsWaves(:)];
            if ~isempty(obsSnaps), D.snapshots = obsSnaps; end
            if ~isempty(obsHandoffs), D.handoffs = obsHandoffs; end
            D.eventGroups = eventGroups;
        end
        end
    end

    D.keys = sample_keys(D.events,records,sampleID,P,D.waveforms);
    D.firstD2 = find_first_d2(D.events,D.waveforms,sampleID,P,d2empty);
    D.firstD2.rawFinalD2=records.validity.selected.D2;
    D.firstD2.rawFinalD2Reason='Final RAW D2 word from the same-ID/epoch public record; it is not the first comparator decision bit.';
    D.validation = validation_summary(D.events,sampleID,D.observer,groups,D.handoffs,observerContract,records.validity,D.firstD2,P);
    D.run = classify_run(D.run,P,D.observer);
    D.traces = D.waveforms;
    D.eventRows = eventRows;
    D.scope = struct('traceSource','Archived SimulationOutput only; no model execution.', ...
        'actualTime','Logger Time is retained as actual time. Calendar token times are separate planned values.', ...
        'sameTimeEvents','Original group.events order and duplicate event rows are preserved.', ...
        'validRecord','RecordReady && RAW.valid on the same actual record row; ID and epoch are reported separately.', ...
        'oldCodeValid','Bank output qualification only; it never substitutes for RecordReady or RAW.valid.', ...
        'missingValue','NaN plus reason; a state vector is not copied from another phase to fill a missing tap.');
end

function id = validate_id(id)
    if ~(isnumeric(id)&&isreal(id)&&isscalar(id)&&isfinite(id)&&id>=0&&id==floor(id))
        error('sar20DebugSample:id','sampleID must be a nonnegative integer scalar.');
    end
    id = double(id);
end

function require_small_file(path)
    if ~isfile(path), return; end
    d = dir(path);
    if d.bytes > 300*1024*1024
        error('sar20DebugSample:largeFile','Refusing to inspect archive file over 300 MB without explicit authorization: %s',path);
    end
end

function validate_groups(groups)
    if ~isstruct(groups)||isempty(groups)||~all(isfield(groups,{'time_s','events'}))
        error('sar20DebugSample:groups','Saved P.groups is malformed.');
    end
    for k=1:numel(groups)
        if ~isstruct(groups(k).events)
            error('sar20DebugSample:events','P.groups(%d).events is malformed.',k);
        end
    end
end

function L=decode_event_log(L,groupName,idSignal)
    if ~L.present, L.sampleID=zeros(0,1);L.groupIndex=zeros(0,1);return;end
    meta=table(L.time(:),'VariableNames',{'time_s'});
    d=decode_group(groupName,L.values,meta,L.name);
    if isempty(d)||~isstruct(d)||~isfield(d,'values')||~istable(d.values)
        error('sar20DebugSample:eventRegistry','Required semantic event logger decoder %s is unavailable.',groupName);
    end
    v=d.values;
    if ~all(ismember({idSignal,'group_index'},v.Properties.VariableNames))
        error('sar20DebugSample:eventRegistry','%s must expose %s and group_index by semantic name.',groupName,idSignal);
    end
    L.sampleID=double(v.(idSignal));L.groupIndex=double(v.group_index);
end

function A=registry_log_alias(R,groupName)
    if ~isfield(R,'log_aliases')||~isstruct(R.log_aliases)||isempty(R.log_aliases)
        error('sar20DebugSample:registryAliases','Unique registry lacks log_aliases.');
    end
    ix=find(strcmp({R.log_aliases.group},groupName));
    if numel(ix)~=1,error('sar20DebugSample:registryAlias','Expected one SimulationOutput logger alias for group %s; found %d.',groupName,numel(ix));end
    A=R.log_aliases(ix);
    if ~all(isfield(A,{'logger_name','group','width'}))
        error('sar20DebugSample:registryAlias','Logger alias for %s lacks name/group/width.',groupName);
    end
    sameLogger=find(strcmp({R.log_aliases.logger_name},A.logger_name));
    if numel(sameLogger)~=1,error('sar20DebugSample:registryAlias','Logger name %s maps to multiple canonical groups.',A.logger_name);end
end

function f=registry_group_fields(R,groupName)
    f=struct([]);
    if isfield(R,'fields')&&isstruct(R.fields)&&~isempty(R.fields)
        f=R.fields(strcmp({R.fields.group},groupName));
    end
end

function v=decoded_single_registered_signal(decoded,R,groupName)
    if isempty(decoded)||~isstruct(decoded)||~isfield(decoded,'values')||~istable(decoded.values)
        error('sar20DebugSample:decoder','Decoder for %s did not return named values.',groupName);
    end
    f=registry_group_fields(R,groupName);
    if numel(f)~=1
        error('sar20DebugSample:registry','Expected one registered field in scalar group %s.',groupName);
    end
    name=f.signal;
    if ~any(strcmp(decoded.values.Properties.VariableNames,name))
        error('sar20DebugSample:decoder','Decoder for %s omitted registered signal %s.',groupName,name);
    end
    v=double(decoded.values.(name));v=v(:);
end

function L = read_log(out,listed,name,width)
    L = struct('present',false,'name',name,'time',zeros(0,1),'values',zeros(0,0), ...
        'reason',[name '未记录']);
    if ~any(strcmp(listed,name)), return; end
    s = out.get(name);
    if isa(s,'Simulink.SimulationData.Signal')
        s = s.Values;
    end
    if ~isa(s,'timeseries')
        error('sar20DebugSample:loggerClass','Logger %s is %s, expected timeseries.',name,class(s));
    end
    t = double(s.Time(:));
    x = s.Data;
    if ~isnumeric(x)||~isreal(x)
        error('sar20DebugSample:loggerData','Logger %s data must be real numeric.',name);
    end
    if s.IsTimeFirst
        x = reshape(double(x),numel(t),[]);
    else
        x = reshape(permute(double(x),[ndims(x) 1:ndims(x)-1]),numel(t),[]);
    end
    if width>=0 && size(x,2)~=width
        error('sar20DebugSample:loggerWidth','Logger %s has width %d; expected %d.',name,size(x,2),width);
    end
    if numel(t)~=size(x,1)||any(~isfinite(t))||any(diff(t)<0)||any(~isfinite(x)&~isnan(x),'all')
        error('sar20DebugSample:loggerShape','Logger %s has malformed time/data rows.',name);
    end
    L.present=true; L.time=t; L.values=x; L.reason='';
end

function [E,groupRows] = build_events(eventLog,parentLog,groups,P,requestedID)
    proto = event_proto(); rows = repmat(proto,0,1); groupRows = struct('row',{},'sampleID',{},'epoch',{},'groupIndex',{},'time_s',{},'executed',{});
    if eventLog.present
        hit = find(eventLog.sampleID==requestedID);
        % Retain the next actual CNV boundary, where it is present in the same
        % archive, so state handoff/retirement is visible without relabeling ID.
        nextCNV = find_next_cnv_row(eventLog,groups,requestedID);
        if ~isempty(nextCNV), hit = [hit(:);nextCNV(:)]; end
        for q=1:numel(hit)
            r=hit(q); eventID=eventLog.sampleID(r); g=eventLog.groupIndex(r);
            if ~(isfinite(g)&&g==floor(g)&&g>=1&&g<=numel(groups))
                x=proto; x.eventRow=numel(rows)+1; x.eventGroupRow=r;
                x.selectedSampleID=requestedID; x.sampleID=eventID; x.epoch=double(P.epoch);
                x.groupIndex=NaN; x.phaseOrdinal=NaN; x.eventName='<unmapped-group>';
                x.time_s=eventLog.time(r); x.plannedTime_s=NaN; x.timeFromCnv_s=NaN;
                x.actualGroupObserved=1; x.phaseExecuted=NaN;
                x.phaseTimeScope='Observed event_log row; group index cannot be mapped to P.groups.';
                rows(end+1,1)=x; %#ok<AGROW>
                groupRows(end+1)=struct('row',r,'sampleID',eventID,'epoch',double(P.epoch), ...
                    'groupIndex',NaN,'time_s',eventLog.time(r),'executed',NaN); %#ok<AGROW>
                continue;
            end
            g=double(g); tokenList=groups(g).events;
            parentExec=parent_status(parentLog,eventLog.time(r),eventID,g);
            for j=1:numel(tokenList)
                tok=tokenList(j); x=proto;
                x.eventRow=numel(rows)+1; x.eventGroupRow=r;
                x.selectedSampleID=requestedID; x.sampleID=eventID; x.epoch=double(P.epoch);
                x.groupIndex=g; x.phaseOrdinal=j;
                x.eventName=event_type(tok); x.eventIndex=event_number(tok,'index'); x.eventBit=event_number(tok,'bit');
                x.eventPriority=event_number(tok,'priority');
                x.time_s=eventLog.time(r); x.plannedTime_s=double(eventID)*double(P.Ts_s)+double(groups(g).time_s);
                x.timeFromCnv_s=NaN; x.actualGroupObserved=1;
                x.parentSampleID=parentExec.parentSampleID;x.parentGroupIndex=parentExec.parentGroupIndex;
                x.parentEventTime_s=parentExec.parentEventTime_s;x.parentEventMatched=parentExec.matched;
                x.phaseExecuted=NaN;
                x.phaseTimeScope='Actual scheduler-group time; co-timed group.events token order comes from saved P.';
                x.executionReason=[parentExec.reason ' | this archive has no phase-level execution tap'];
                if parentExec.value==0,x.phaseExecuted=0;end
                rows(end+1,1)=x; %#ok<AGROW>
            end
            groupRows(end+1)=struct('row',r,'sampleID',eventID,'epoch',double(P.epoch), ...
                'groupIndex',g,'time_s',eventLog.time(r),'executed',parentExec.value); %#ok<AGROW>
        end
    else
        % A calendar-only listing is not presented as an executed event trace.
        for g=1:numel(groups)
            tokenList=groups(g).events;
            for j=1:numel(tokenList)
                tok=tokenList(j); x=proto;
                x.eventRow=numel(rows)+1; x.eventGroupRow=NaN;
                x.selectedSampleID=requestedID; x.sampleID=requestedID; x.epoch=double(P.epoch);
                x.groupIndex=g; x.phaseOrdinal=j;
                x.eventName=event_type(tok); x.eventIndex=event_number(tok,'index'); x.eventBit=event_number(tok,'bit');
                x.eventPriority=event_number(tok,'priority'); x.time_s=NaN;
                x.plannedTime_s=double(requestedID)*double(P.Ts_s)+double(groups(g).time_s);
                x.timeFromCnv_s=NaN; x.actualGroupObserved=NaN; x.phaseExecuted=NaN;
                x.phaseTimeScope='Schedule token only; no event_log row in archive, execution/time unknown.';
                x.executionReason='未记录 event_log'; rows(end+1,1)=x; %#ok<AGROW>
            end
        end
    end
    E=struct2table(rows);
    if isempty(rows), E=struct2table(proto); E(1,:)=[]; end
    E.eventSampleID=E.sampleID;
    cnv = find(strcmp(E.eventName,'cnv') & E.sampleID==requestedID & isfinite(E.time_s),1,'first');
    if ~isempty(cnv), E.timeFromCnv_s=E.time_s-E.time_s(cnv); end
end

function r = find_next_cnv_row(eventLog,groups,id)
    r=[];
    if ~eventLog.present, return; end
    for k=1:numel(groups)
        types=event_types(groups(k).events);
        if any(strcmp(types,'cnv'))
            candidates=find(eventLog.sampleID>id & eventLog.groupIndex==k);
            if ~isempty(candidates)
                [~,m]=min(eventLog.time(candidates)); r=candidates(m); return;
            end
        end
    end
end

function q=parent_status(parentLog,t,id,g)
    q=struct('value',1,'matched',NaN,'parentSampleID',NaN,'parentGroupIndex',NaN, ...
        'parentEventTime_s',NaN,'reason','event_log observed actual scheduler group; no parent tag logger.');
    if ~parentLog.present, return; end
    hit=find(parentLog.time==t);
    if isempty(hit)
        q.value=NaN; q.reason='parent_event_log has no exact time row; parent identity unrecorded'; return;
    end
    match=hit(parentLog.sampleID(hit)==id & parentLog.groupIndex(hit)==g);
    if isscalar(match)
        q.value=1;q.matched=1;q.parentSampleID=parentLog.sampleID(match);
        q.parentGroupIndex=parentLog.groupIndex(match);q.parentEventTime_s=parentLog.time(match);
        q.reason='event_log and parent_event_log exact ID/group/time aligned';
    elseif isempty(match)
        q.value=0;q.matched=0;q.parentSampleID=parentLog.sampleID(hit(1));
        q.parentGroupIndex=parentLog.groupIndex(hit(1));q.parentEventTime_s=parentLog.time(hit(1));
        q.reason='parent_event_log observed at time but not this ID/group';
    else
        q.value=NaN;q.reason='parent_event_log has duplicate matching rows; parent association ambiguous';
    end
end

function E=event_proto()
    E=struct('eventRow',NaN,'eventGroupRow',NaN,'selectedSampleID',NaN,'sampleID',NaN,'epoch',NaN, ...
        'eventSampleID',NaN,'groupIndex',NaN,'phaseOrdinal',NaN,'eventName','','eventIndex',NaN,'eventBit',NaN,'eventPriority',NaN, ...
        'parentSampleID',NaN,'parentGroupIndex',NaN,'parentEventTime_s',NaN,'parentEventMatched',NaN, ...
        'controllerSampleID',NaN,'controllerEpoch',NaN,'controllerIDSourceTap','', ...
        'time_s',NaN,'plannedTime_s',NaN,'timeFromCnv_s',NaN,'actualGroupObserved',NaN,'phaseExecuted',NaN, ...
        'phaseTimeScope','','executionReason','','observerOuterRow',NaN, ...
        'RecordReady',NaN,'RAW_valid',NaN,'validRecord',NaN,'recordID',NaN,'recordEpoch',NaN, ...
        'recordFlagScope','record/ready logger values aligned at this actual timestamp; not a token-level phase tap', ...
        'readinessField','','readinessSemantic','', ...
        'oldCodeValidBank',NaN,'controllerTraceObserved',NaN,'comparisonUsed',NaN, ...
        'comparisonInput_v',NaN,'comparisonOffset_v',NaN,'comparisonNoise_v',NaN, ...
        'decision',NaN,'decisionValid',NaN,'decisionLate',NaN,'stageName','','decisionSourceTap','', ...
        'phaseIdentityMatch',NaN,'phaseObservedEventName','','phaseObservedEventCode',NaN, ...
        'phaseIdentityReason','', ...
        'observerOuterTime_s',NaN,'modelEventTime_s',NaN,'eventLogTime_s',NaN, ...
        'observerTimeBitwiseEqual',NaN,'eventTimeBitwiseEqual',NaN, ...
        'observerTimeCompareReason','','eventTimeCompareReason','', ...
        'phaseModelEventTime_s',NaN,'phaseTimeBitwiseEqual',NaN,'phaseTimeCompareReason','');
end

function typ=event_type(tok)
    typ='';
    if isfield(tok,'type')
        if isstring(tok.type), typ=char(tok.type); else, typ=char(tok.type); end
    end
end

function x=event_number(tok,name)
    x=NaN;
    if isfield(tok,name)&&isnumeric(tok.(name))&&isscalar(tok.(name))&&isfinite(tok.(name))
        x=double(tok.(name));
    end
end

function types=event_types(tokens)
    types=cell(1,numel(tokens));
    for k=1:numel(tokens), types{k}=event_type(tokens(k)); end
end

function R=build_records(out,listed,registry,P,requestedID,eventLog,events)
    transport=isfield(P,'transport')&&isfield(P.transport,'enabled')&&P.transport.enabled;
    publicRaw=registry_log_alias(registry,'PublicRecord6');
    publicReady=registry_log_alias(registry,'PublicRecordReady1');
    directRaw=registry_log_alias(registry,'RAW6');
    directReady=registry_log_alias(registry,'Ready1');
    codeAlias=registry_log_alias(registry,'Code20_1');
    bankAlias=registry_log_alias(registry,'LegacyCodeValid1');
    rawName='';readyName='';
    hasRaw=any(strcmp(listed,publicRaw.logger_name));hasReady=any(strcmp(listed,publicReady.logger_name));
    if hasRaw~=hasReady
        rawAlias=struct();readyAlias=struct();source='';reason='public record/ready logger pair is partial';
    elseif hasRaw
        rawAlias=publicRaw;readyAlias=publicReady;source='public record boundary';reason='';
    elseif transport
        rawAlias=struct();readyAlias=struct();source='public RX record';
        reason='Transport on but public record logger missing; ADC raw is not substituted.';
    else
        rawAlias=directRaw;readyAlias=directReady;source='legacy direct RAW / RecordReady boundary';reason='';
    end
    empty=table(zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
        zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
        'VariableNames',{'recordRow','time_s','RecordReady','D1','D2','DT','RAW_ID','RAW_epoch','RAW_valid', ...
        'validRecord','code20','oldCodeValidBank','selectedRequestedID'});
    F=empty;
    if ~isempty(fieldnames(rawAlias))
        rawName=rawAlias.logger_name;readyName=readyAlias.logger_name;
        rawLog=read_log(out,listed,rawName,rawAlias.width);
        readyLog=read_log(out,listed,readyName,readyAlias.width);
        if ~rawLog.present||~readyLog.present
            reason=[reason ' required logger absent'];
        else
            readyDecoded=decode_group(readyAlias.group,readyLog.values, ...
                table(readyLog.time(:),'VariableNames',{'time_s'}),readyName);
            readyValues=decoded_single_registered_signal(readyDecoded,registry,readyAlias.group);
            rawDecoded=decode_group(rawAlias.group,rawLog.values, ...
                table(rawLog.time(:),'VariableNames',{'time_s'}),rawName);
            rawTable=decoded_values(rawDecoded,rawAlias.group);
            rawRequired={'D1','D2','DT','sample_id','epoch','valid'};
            rawFields=registry_group_fields(registry,rawAlias.group);
            registered={rawFields.signal};
            if ~all(ismember(rawRequired,registered))||~all(ismember(rawRequired,rawTable.Properties.VariableNames))
                error('sar20DebugSample:registry','RAW decoder lacks one or more registered semantic fields.');
            end
            rawValues=table2array(rawTable(:,rawRequired));
            rawAt=align_exact(readyLog.time,rawLog.time,rawValues);
            n=numel(readyValues);raw=rawAt.values;raw(~rawAt.present,:)=NaN;
            col=struct();for k=1:numel(rawRequired),col.(rawRequired{k})=k;end
            D1=raw(:,col.D1);D2=raw(:,col.D2);DT=raw(:,col.DT);
            rawID=raw(:,col.sample_id);rawEpoch=raw(:,col.epoch);rawValid=raw(:,col.valid);
            codeAt=struct('values',nan(n,1),'present',false(n,1),'reason',repmat({'code log not recorded'},n,1));
            codeLog=read_log(out,listed,codeAlias.logger_name,codeAlias.width);
            if codeLog.present
                codeDecoded=decode_group(codeAlias.group,codeLog.values, ...
                    table(codeLog.time(:),'VariableNames',{'time_s'}),codeLog.name);
                codeValues=decoded_single_registered_signal(codeDecoded,registry,codeAlias.group);
                codeAt=align_exact(readyLog.time,codeLog.time,codeValues);
            end
            bankAt=struct('values',nan(n,1),'present',false(n,1), ...
                'reason',repmat({'Bank CodeValid logger not recorded'},n,1));
            bankLog=read_log(out,listed,bankAlias.logger_name,bankAlias.width);
            if bankLog.present
                bankDecoded=decode_group(bankAlias.group,bankLog.values, ...
                    table(bankLog.time(:),'VariableNames',{'time_s'}),bankLog.name);
                bankValues=decoded_single_registered_signal(bankDecoded,registry,bankAlias.group);
                bankAt=align_exact(readyLog.time,bankLog.time,bankValues);
            end
            code=codeAt.values(:);code(~codeAt.present)=NaN;
            bank=bankAt.values(:);bank(~bankAt.present)=NaN;
            validRecord=nan(n,1);readyKnown=ismember(readyValues,[0 1]);rawValidKnown=ismember(rawValid,[0 1]);
            known=rawAt.present&isfinite(rawValid)&readyKnown&rawValidKnown;
            validRecord(known)=double(readyValues(known)==1&rawValid(known)==1);
            selected=double(rawID==requestedID&rawEpoch==double(P.epoch));
            F=table((1:n).',readyLog.time(:),readyValues(:),D1,D2,DT,rawID,rawEpoch,rawValid, ...
                validRecord,code,bank,selected,'VariableNames',empty.Properties.VariableNames);
            F.rawSource=repmat(string(rawName),n,1);F.readySource=repmat(string(readyName),n,1);
            readyFields=registry_group_fields(registry,readyAlias.group);readinessField=char(readyFields(1).signal);
            if strcmp(source,'legacy direct RAW / RecordReady boundary')
                readinessSemantic='ADC_RawReady is shown at the direct RAW readiness boundary under the legacy direct_raw contract.';
            else
                readinessSemantic='RecordReady from the public record/RX readiness interface.';
            end
            F.readinessField=repmat(string(readinessField),n,1);
            F.readinessSemantic=repmat(string(readinessSemantic),n,1);
            F.rawAligned=rawAt.present;F.codeAligned=codeAt.present;F.bankAligned=bankAt.present;
            F.code20Reason=repmat(string(''),n,1);F.code20Reason(~codeAt.present)=string('code log lacks a unique exact-time row');
            F.oldCodeValidBankReason=string(bankAt.reason(:));
            F.RecordReadyReason=repmat(string('Actual archived readiness logger row'),n,1);
            F.validRecordReason=repmat(string(''),n,1);
            F.validRecordReason(~rawAt.present)=string('RAW row missing/ambiguous at exact RecordReady timestamp.');
            F.validRecordReason(~readyKnown)=string('Readiness flag is nonbinary or unrecorded.');
            F.validRecordReason(rawAt.present&isfinite(rawValid)&~rawValidKnown)=string('RAW.valid is nonbinary; effective record status is unknown.');
            F.validRecordReason(known)=string('RecordReady && RAW.valid on the same exact-time, ID/epoch-tagged record row.');
            T=F(F.RecordReady==1,:);
            T.recordRow=find(F.RecordReady==1);
        end
    end
    if exist('T','var')~=1,T=empty;end
    selected=find(T.RAW_ID==requestedID&T.RAW_epoch==double(P.epoch));
    current=struct('available',false,'validRecord',NaN,'RecordReady',NaN,'RAW_valid',NaN, ...
        'time_s',NaN,'recordID',NaN,'recordEpoch',NaN,'D1',NaN,'D2',NaN,'DT',NaN,'code20',NaN, ...
        'code20Aligned',false,'code20Legal',NaN,'oldCodeValidBank',NaN, ...
        'validRecordReason','', ...
        'reason','No unique same-ID/epoch RecordReady RAW row was recorded.');
    if isscalar(selected)
        k=selected(1);current.available=true;current.validRecord=T.validRecord(k);current.RecordReady=T.RecordReady(k);
        current.RAW_valid=T.RAW_valid(k);current.time_s=T.time_s(k);current.recordID=T.RAW_ID(k);
        current.recordEpoch=T.RAW_epoch(k);current.D1=T.D1(k);current.D2=T.D2(k);current.DT=T.DT(k);
        current.code20=T.code20(k);current.oldCodeValidBank=T.oldCodeValidBank(k);
        current.code20Aligned=T.codeAligned(k);
        if isfinite(T.code20(k))
            current.code20Legal=double(T.code20(k)==floor(T.code20(k))&&T.code20(k)>=0&&T.code20(k)<2^20);
        else
            current.code20Legal=NaN;
        end
        current.validRecordReason=char(string(T.validRecordReason(k)));
        current.reason='One actual row matched by RAW ID/epoch; validRecord is RecordReady && RAW.valid on that row.';
    elseif numel(selected)>1
        current.reason='Multiple same-ID/epoch ready rows; no row was selected.';
    elseif ~isempty(reason)
        current.reason=reason;
    end
    label=registry_display_alias(registry,'CodeValid','Bank output qualification〔旧 CodeValid〕');
    readinessField='';readinessSemantic='Readiness source not recorded.';
    if ~isempty(fieldnames(readyAlias))
        readyFields=registry_group_fields(registry,readyAlias.group);
        if ~isempty(readyFields),readinessField=char(readyFields(1).signal);end
        if strcmp(source,'legacy direct RAW / RecordReady boundary')
            readinessSemantic='ADC_RawReady is shown at the direct RAW readiness boundary under the legacy direct_raw contract.';
        elseif strcmp(source,'public record boundary')
            readinessSemantic='RecordReady from the public record/RX readiness interface.';
        end
    end
    readinessLogger='';rawLogger='';
    if ~isempty(fieldnames(readyAlias)),readinessLogger=readyAlias.logger_name;end
    if ~isempty(fieldnames(rawAlias)),rawLogger=rawAlias.logger_name;end
    validity=struct('boundary',source,'bankEnabled',bank_enabled(P),'bank_enabled',bank_enabled(P), ...
        'recordReadySignal',readinessLogger,'rawSignal',rawLogger, ...
        'readinessField',readinessField,'readinessSemantic',readinessSemantic, ...
        'validityExpression','RecordReady && RAW.valid','eventFlags',F,'records',T,'selected',current, ...
        'oldCodeValidLabel',label,'oldCodeValidIsBankOnly',true, ...
        'oldCodeValidReason','Legacy CodeValid is Bank qualification only; absence is not converted to zero.', ...
        'publicOutputQualification','unverified', ...
        'publicOutputQualificationReason','Public output mode and code alignment are reported separately; no synthetic boolean is created.');
    validity.RecordReady=current.RecordReady;validity.RAW_valid=current.RAW_valid;
    validity.validRecordReason=current.validRecordReason;
    validity.validRecord_event=current.validRecord;validity.recordID=current.recordID;
    validity.epoch=current.recordEpoch;validity.time_s=current.time_s;validity.source=source;
    validity.oldCodeValidBank=current.oldCodeValidBank;validity.code20=current.code20;
    validity.code20Aligned=current.code20Aligned;validity.code20Legal=current.code20Legal;
    if bank_enabled(P)
        validity.publicOutputMode='Bank enabled; qualification requires recorded CodeValid and Bank metadata.';
    else
        validity.publicOutputMode='nominal bypass output; uncalibrated and without Bank qualification.';
    end
    R=struct('table',T,'eventFlags',F,'validity',validity,'source',source,'reason',reason,'selectedRows',selected);
end

function T=decoded_values(d,groupName)
    if isempty(d)||~isstruct(d)||~isfield(d,'values')||~istable(d.values)
        error('sar20DebugSample:registry','Decoder for %s did not return named values.',groupName);
    end
    T=d.values;
end

function label=registry_display_alias(R,legacyName,fallback)
    label=fallback;
    if ~isfield(R,'display_aliases')||~isstruct(R.display_aliases),return;end
    if isfield(R.display_aliases,'legacy_name')
        ix=find(strcmp({R.display_aliases.legacy_name},legacyName));
    else,ix=[];end
    if numel(ix)>1,error('sar20DebugSample:displayAlias','Legacy display alias %s is not unique.',legacyName);end
    if isscalar(ix)&&isfield(R.display_aliases,'label'),label=char(R.display_aliases(ix).label);end
end

function a=align_exact(wanted,sourceTime,sourceData)
    n=numel(wanted); width=size(sourceData,2);
    a=struct('values',nan(n,width),'present',false(n,1),'reason',repmat({'No exact source row'},n,1));
    for i=1:n
        hit=find(sourceTime==wanted(i));
        if isempty(hit), continue; end
        prior=sum(wanted(1:i-1)==wanted(i));
        slot=prior+1;
        wantedCount=nnz(wanted==wanted(i));
        if numel(hit)==wantedCount && slot<=numel(hit)
            a.values(i,:)=sourceData(hit(slot),:);a.present(i)=true;a.reason{i}='Exact timestamp and occurrence-order aligned';
        elseif numel(hit)==1 && wantedCount==1
            a.values(i,:)=sourceData(hit,:);a.present(i)=true;a.reason{i}='Unique exact timestamp aligned';
        else
            a.reason{i}='Duplicate exact-time rows do not have a unique one-to-one occurrence match';
        end
    end
end

function E=attach_event_flags(E,R,eventLog,requestedID,P)
    if isempty(E)||~istable(R.eventFlags)||height(R.eventFlags)==0,return;end
    % Attach the readiness and RAW values from the same exact event timestamp.
    % A single group-level logger observation can annotate its co-timed tokens;
    % duplicated source rows remain ambiguous unless occurrence counts match.
    groupRows=unique(E.eventGroupRow(isfinite(E.eventGroupRow)),'stable');
    for gr=reshape(groupRows,1,[])
        ev=find(E.eventGroupRow==gr);t=E.time_s(ev(1));if ~isfinite(t),continue;end
        readyHit=find(R.eventFlags.time_s==t);
        if isscalar(readyHit)
            E=attach_flag_row(E,ev,R.eventFlags,readyHit);continue;
        end
        if numel(readyHit)>1
            sameTimeGroups=unique(E.eventGroupRow(isfinite(E.eventGroupRow)&E.time_s==t),'stable');
            if numel(readyHit)==numel(sameTimeGroups)
                occurrence=find(sameTimeGroups==gr,1);E=attach_flag_row(E,ev,R.eventFlags,readyHit(occurrence));
            else
                old=char(string(E.executionReason(ev(1))));
                E=assign_text(E,'executionReason',ev(1),[old ' | duplicate same-time RAW/ready rows are not one-to-one']);
            end
        end
    end
    % Observer-only event rows can be joined only by the exact real timestamp.
    noEventLog=find(isnan(E.eventGroupRow)&isfinite(E.observerOuterTime_s));
    for i=reshape(noEventLog,1,[])
        hit=find(R.eventFlags.time_s==E.observerOuterTime_s(i));
        if isscalar(hit),E=attach_flag_row(E,i,R.eventFlags,hit);end
    end
end

function E=attach_flag_row(E,rows,F,sourceRow)
    for i=reshape(rows,1,[])
        E.RecordReady(i)=F.RecordReady(sourceRow);E.RAW_valid(i)=F.RAW_valid(sourceRow);
        E.validRecord(i)=F.validRecord(sourceRow);E.recordID(i)=F.RAW_ID(sourceRow);
        E.recordEpoch(i)=F.RAW_epoch(sourceRow);E.oldCodeValidBank(i)=F.oldCodeValidBank(sourceRow);
        if any(strcmp(F.Properties.VariableNames,'readinessField'))
            E=assign_text(E,'readinessField',i,char(string(F.readinessField(sourceRow))));
            E=assign_text(E,'readinessSemantic',i,char(string(F.readinessSemantic(sourceRow))));
        end
    end
end

function id=sample_keys(E,R,requestedID,P,W)
    cnv=find(E.sampleID==requestedID & strcmp(E.eventName,'cnv'),1,'first');
    capture=key_value(NaN,double(P.epoch),NaN,'FE_Sample_after_commandFE353.capture_id', ...
        'Actual FE capture ID/epoch tap was not recorded for this sample.');
    target=key_value(NaN,double(P.epoch),NaN,'event_log','未记录该sampleID的实际CNV group。');
    if ~isempty(cnv)
        target=key_value(E.sampleID(cnv),E.epoch(cnv),E.time_s(cnv), ...
            'event_log.Time + Event ID/group','CNV event group observed; token is its acquisition target.');
        captureID=waveform_value_at_event(W,{'FE_Sample_after_commandFE353'},'capture_id',cnv);
        captureValid=waveform_value_at_event(W,{'FE_Sample_after_commandFE353'},'capture_valid',cnv);
        if isfinite(captureID.value)&&captureValid.value==1
            capture=key_value(captureID.value,E.epoch(cnv),E.time_s(cnv),captureID.source, ...
                'Actual FE capture tag from the Sample stage after-command tap.');
        else
            capture.reason=['No valid exact FE capture tag: ' captureID.reason];
        end
    end
    current=key_value(NaN,double(P.epoch),NaN,'Control13.sample_id','未记录控制状态中的当前转换ID。');
    if ~isempty(cnv)
        phaseRow=find(E.sampleID==requestedID&isfinite(E.controllerSampleID),1,'first');
        currentValue=struct('value',NaN,'source','','reason','No controller-tagged conversion ID row.');
        currentEpoch=struct('value',NaN,'source','','reason','No controller-tagged epoch row.');
        currentTime=E.time_s(cnv);
        if ~isempty(phaseRow)
            currentValue.value=E.controllerSampleID(phaseRow);currentValue.source=E.controllerIDSourceTap(phaseRow);
            currentEpoch.value=E.controllerEpoch(phaseRow);currentEpoch.source=E.controllerIDSourceTap(phaseRow);
            currentTime=E.time_s(phaseRow);
        else
            currentValue=waveform_value_at_event(W,{'Control13'},'sample_id',cnv);
            currentEpoch=waveform_value_at_event(W,{'Control13'},'epoch',cnv);
        end
        if isfinite(currentValue.value)
            current=key_value(currentValue.value,currentEpoch.value,currentTime,currentValue.source, ...
                'Current conversion ID read from an explicit controller sample_id tag; distinct from event cycle ID.');
        end
    end
    raw=key_value(R.validity.selected.recordID,R.validity.selected.recordEpoch, ...
        R.validity.selected.time_s,R.validity.rawSignal,R.validity.selected.reason);
    output=key_value(NaN,double(P.epoch),NaN,'record_log/record_ready_log','未记录公共输出记录。');
    if R.validity.selected.available
        output=key_value(R.validity.selected.recordID,R.validity.selected.recordEpoch, ...
            R.validity.selected.time_s,R.validity.boundary, ...
            'Output record ID/epoch/time read from the same actual RecordReady RAW row.');
    end
    id=struct('requestedSampleID',requestedID,'requestedEpoch',double(P.epoch), ...
        'acquisitionTargetID',target,'captureID',capture,'currentConversionID',current, ...
        'rawID',raw,'outputRecordID',output,'recordBoundary',R.validity.boundary);
end

function k=key_value(value,epoch,time,source,reason)
    k=struct('value',value,'epoch',epoch,'time_s',time,'source',source,'reason',reason);
end

function q=waveform_value_at_event(W,groups,signal,eventRow)
    q=struct('value',NaN,'source','','reason','Signal not recorded in named waveforms.');
    preferred=groups(~strcmp(groups,'BackendObs8')&~strcmp(groups,'FrontendObs7'));
    [q,found]=scan_waveforms(W,preferred,signal,eventRow,true);
    if found,return;end
    [q,~]=scan_waveforms(W,groups,signal,eventRow,false);
end

function [q,found]=scan_waveforms(W,groups,signal,eventRow,sourceOnly)
    q=struct('value',NaN,'source','','reason','Signal not recorded in named waveforms.');found=false;
    for i=1:numel(W)
        if sourceOnly
            groupMatch=false;
            for g=groups
                if contains(lower(W(i).sourceTap),lower(g{1}))||contains(lower(W(i).tapKey),lower(g{1}))
                    groupMatch=true;break;
                end
            end
        else
            groupMatch=any(strcmp(groups,W(i).group));
            if ~groupMatch
                for g=groups,if contains(lower(W(i).group),lower(g{1})),groupMatch=true;break;end,end
            end
        end
        if ~groupMatch||~istable(W(i).values),continue;end
        names=W(i).values.Properties.VariableNames;
        if ~any(strcmp(names,signal)),continue;end
        row=[];
        if istable(W(i).metadata)&&any(strcmp(W(i).metadata.Properties.VariableNames,'eventRows'))
            for m=1:height(W(i).metadata)
                link=W(i).metadata.eventRows{m};
                if any(link==eventRow),row(end+1)=m;end %#ok<AGROW>
            end
        elseif istable(W(i).metadata)&&any(strcmp(W(i).metadata.Properties.VariableNames,'eventRow'))
            row=find(W(i).metadata.eventRow==eventRow);
        end
        if isscalar(row)
            vcol=W(i).values.(signal);v=vcol(row);
            if isnumeric(v)&&isscalar(v)
                q.value=double(v);q.source=W(i).sourceTap;
                q.reason='Exact event-row link matched; value remains at its declared tap scope.';found=true;return;
            end
        end
    end
end

function [keep,groupRow,reason]=select_event_rows(t,x,eventRows,id,P)
    groupRow=nan(numel(t),1); reason=repmat({''},numel(t),1); keep=false(numel(t),1);
    if isempty(eventRows)
        reason(:)={'No event_log mapping; do not select by row number.'}; return;
    end
    for i=1:numel(t)
        hit=find([eventRows.time_s].'==t(i) & [eventRows.sampleID].'==id);
        if isscalar(hit)
            groupRow(i)=eventRows(hit).row;keep(i)=true;reason{i}='Exact logger time to event_log row';
        elseif numel(hit)>1
            reason{i}='Duplicate event_log time rows; no one-to-one source mapping';
        end
    end
end

function M=make_row_meta(t,groupRow,reason,E,eventRows,id,P)
    n=numel(t); sample=nan(n,1); epoch=nan(n,1); group=nan(n,1); eventRowsByTrace=cell(n,1);
    for i=1:n
        if ~isfinite(groupRow(i)), continue; end
        ix=find(E.eventGroupRow==groupRow(i));
        if ~isempty(ix)
            sample(i)=E.sampleID(ix(1));epoch(i)=E.epoch(ix(1));group(i)=E.groupIndex(ix(1));eventRowsByTrace{i}=ix(:).';
        end
    end
    eventRow=nan(n,1);for i=1:n,if numel(eventRowsByTrace{i})==1,eventRow(i)=eventRowsByTrace{i}(1);end,end
    M=table(t(:),t(:),groupRow(:),eventRow,sample,epoch,group,eventRowsByTrace,string(reason(:)), ...
        'VariableNames',{'time_s','outerSimulationTime_s','eventGroupRow','eventRow','sampleID','epoch','groupIndex','eventRows','linkReason'});
    M.decoded_tap_recorded=double(isfinite(groupRow(:)));
    M.decoded_reason=string(reason(:));
end

function d=decode_group(groupName,rows,meta,sourceName)
    d=[];
    if exist('sar20_debug_decode','file')~=2, return; end
    d=sar20_debug_decode(groupName,rows,meta);
    if isstruct(d)&&~isfield(d,'sourceLogger'), d.sourceLogger=sourceName; end
end

function E=merge_observer_context(E,decoded,groups,eventLog,P,requestedID)
    if ~isstruct(decoded)||~isfield(decoded,'context')||~isstruct(decoded.context)|| ...
            ~isfield(decoded.context,'values')||~istable(decoded.context.values)
        return;
    end
    C=decoded.context.values; names=C.Properties.VariableNames;
    needed={'cycle_index','group_index','outerSimulationTime_s','modelEventTime_s'};
    if ~all(ismember(needed,names)),return;end
    cycle=double(C.cycle_index); group=double(C.group_index);
    outer=double(C.outerSimulationTime_s); model=double(C.modelEventTime_s);
    n=numel(cycle); if any(strcmp(names,'outerRow')),outerRow=double(C.outerRow);else,outerRow=(1:n).';end
    hasCnv=false(n,1);
    for i=1:n
        if isfinite(group(i))&&group(i)>=1&&group(i)<=numel(groups)
            hasCnv(i)=any(strcmp(event_types(groups(group(i)).events),'cnv'));
        end
    end
    selected=cycle==requestedID;
    currentCnv=find(selected&hasCnv&isfinite(outer),1,'first');
    nextCnv=[];
    if ~isempty(currentCnv)
        q=find(cycle>requestedID&hasCnv&isfinite(outer)&outer>outer(currentCnv));
        if ~isempty(q),[~,m]=min(outer(q));nextCnv=q(m);end
    end
    if ~isempty(nextCnv),selected(nextCnv)=true;end
    seenCycle=zeros(0,1);seenGroup=zeros(0,1);
    for i=find(selected(:)).'
        sid=cycle(i);g=group(i);
        if ~(isfinite(sid)&&isfinite(g)&&g==floor(g)&&g>=1&&g<=numel(groups)&&isfinite(outer(i)))
            continue;
        end
        occ=nnz(seenCycle==sid&seenGroup==g)+1;
        seenCycle(end+1,1)=sid;seenGroup(end+1,1)=g; %#ok<AGROW>
        matching=find(E.sampleID==sid&E.groupIndex==g);
        groupEventRows=unique(E.eventGroupRow(matching(isfinite(E.eventGroupRow(matching)))),'stable');
        contextCount=nnz(cycle==sid&group==g);
        mappedRow=NaN;
        if numel(groupEventRows)==1 && contextCount==1
            mappedRow=groupEventRows(1);
        elseif numel(groupEventRows)==contextCount && occ<=numel(groupEventRows)
            mappedRow=groupEventRows(occ);
        elseif isempty(groupEventRows)
            pending=matching(isnan(E.observerOuterRow(matching)));
            if ~isempty(pending)
                for j=1:numel(pending)
                    E.observerOuterRow(pending(j))=outerRow(i);
                    E.actualGroupObserved(pending(j))=1;
                    E.phaseTimeScope(pending(j))='Actual outer SimulationOutput Timeseries.Time; token order remains calendar ordinal.';
                    E.executionReason(pending(j))='Observer group context observed; token-specific phase execution requires a matching trace slot.';
                    E.time_s(pending(j))=outer(i);
                    E.observerOuterTime_s(pending(j))=outer(i);E.modelEventTime_s(pending(j))=model(i);
                    E.eventLogTime_s(pending(j))=NaN;
                    E.eventTimeBitwiseEqual(pending(j))=bitwise_status(outer(i),model(i));
                    E.eventTimeCompareReason(pending(j))='EventLog.Time is unavailable; observer and model event times remain separate.';
                    E.observerTimeCompareReason(pending(j))='No event_log.Time source row is available for comparison.';
                end
                continue;
            end
        end
        if isfinite(mappedRow)
            target=find(E.eventGroupRow==mappedRow);
        elseif isempty(matching)
            E=append_context_group(E,sid,g,outer(i),model(i),outerRow(i),requestedID,P,groups);
            continue;
        else
            target=[];
        end
        if isempty(target)
            already=find(E.observerOuterRow==outerRow(i));
            if isempty(already)
                E=append_context_group(E,sid,g,outer(i),model(i),outerRow(i),requestedID,P,groups);
            end
            continue;
        end
        % Only map a context occurrence to a distinct event-group row. Equal
        % timestamps remain separate rows and are never collapsed.
        target=target(isnan(E.observerOuterRow(target))|E.observerOuterRow(target)==outerRow(i));
        for j=1:numel(target)
            r=target(j); oldTime=E.time_s(r);
            E.observerOuterRow(r)=outerRow(i);E.actualGroupObserved(r)=1;
            E.observerOuterTime_s(r)=outer(i);E.modelEventTime_s(r)=model(i);
            if isfinite(oldTime),E.eventLogTime_s(r)=oldTime;
            else,E.eventLogTime_s(r)=NaN;E.time_s(r)=outer(i);end
            E.observerTimeBitwiseEqual(r)=bitwise_status(E.eventLogTime_s(r),outer(i));
            E.eventTimeBitwiseEqual(r)=bitwise_status(outer(i),model(i));
            if isfinite(E.eventLogTime_s(r))
                E.observerTimeCompareReason(r)='Exact bitwise comparison of event_log.Time and observer_log Timeseries.Time.';
            else
                E.observerTimeCompareReason(r)='event_log.Time not recorded for this observer row.';
            end
            if isfinite(outer(i))&&isfinite(model(i))
                E.eventTimeCompareReason(r)='Exact bitwise comparison of actual ToWorkspace.Time and modelEventTime_s.';
            else
                E.eventTimeCompareReason(r)='One or both outer/model event times are not recorded.';
            end
            E.phaseTimeScope(r)='Outer SimulationOutput Timeseries.Time is actual; modelEventTime_s is a separate wiring calculation.';
        end
    end
    cnv=find(E.sampleID==requestedID&strcmp(E.eventName,'cnv')&isfinite(E.time_s),1,'first');
    if ~isempty(cnv),E.timeFromCnv_s=E.time_s-E.time_s(cnv);end
end

function E=append_context_group(E,sid,g,outer,model,outerRow,requestedID,P,groups)
    tokens=groups(g).events;
    for j=1:numel(tokens)
        tok=tokens(j);x=event_proto();x.eventRow=height(E)+1;x.eventGroupRow=NaN;
        x.selectedSampleID=requestedID;x.sampleID=sid;x.epoch=double(P.epoch);
        x.eventSampleID=sid;
        x.groupIndex=g;x.phaseOrdinal=j;x.eventName=event_type(tok);
        x.eventIndex=event_number(tok,'index');x.eventBit=event_number(tok,'bit');
        x.eventPriority=event_number(tok,'priority');x.time_s=outer;
        x.plannedTime_s=double(sid)*double(P.Ts_s)+double(groups(g).time_s);
        x.actualGroupObserved=1;x.phaseExecuted=NaN;x.observerOuterRow=outerRow;
        x.observerOuterTime_s=outer;x.modelEventTime_s=model;x.eventLogTime_s=NaN;
        x.eventTimeBitwiseEqual=bitwise_status(outer,model);
        x.eventTimeCompareReason='Actual ToWorkspace.Time is separate from wiring-calculated modelEventTime_s.';
        x.observerTimeCompareReason='No event_log.Time source row is available for comparison.';
        x.phaseTimeScope='Actual outer SimulationOutput Timeseries.Time; modelEventTime_s is separately reported.';
        x.executionReason='Observer event/group context recorded; no phase-specific slot matched yet.';
        E=[E;struct2table(x)]; %#ok<AGROW>
    end
end

function f=decoded_fields(d)
    f=struct([]);
    if isstruct(d)&&isfield(d,'fields'), f=d.fields; end
end

function w=waveform_proto()
    w=struct('group','','tapKey','','logger','','sourceTap','','observationKind','','time_s',zeros(0,1), ...
        'values',table(),'rawValues',zeros(0,0),'metadata',table(),'fields',struct([]),'available',false,'reason','');
end

function w=waveform_from_trace(item)
    w=waveform_proto(); w.group=item.group; w.tapKey=item.group;w.logger=item.logger; w.sourceTap=item.sourceTap;
    w.observationKind=item.observationKind; w.time_s=item.time_s; w.values=item.values;w.rawValues=item.rawValues;
    w.metadata=item.metadata; w.fields=item.fields; w.available=item.available; w.reason=item.reason;
    if isstruct(item.decoded)&&isfield(item.decoded,'values'), w.values=item.decoded.values; end
end

function t=trace_proto()
    t=struct('group','','logger','','sourceTap','','observationKind','','time_s',zeros(0,1), ...
        'values',zeros(0,0),'rawValues',zeros(0,0),'metadata',table(),'fields',struct([]),'decoded',[],'available',false,'reason','');
end

function [T,W]=build_output_traces(records,E,R,requestedID,requestedEpoch)
    T=repmat(trace_proto(),0,1);W=repmat(waveform_proto(),0,1);
    F=records.eventFlags;if ~istable(F)||height(F)==0,return;end
    eventTimes=E.time_s(E.actualGroupObserved==1&isfinite(E.time_s));
    keep=false(height(F),1);
    for i=1:height(F)
        keep(i)=any(eventTimes==F.time_s(i)) || ...
            (F.RecordReady(i)==1&&F.RAW_ID(i)==requestedID&&F.RAW_epoch(i)==requestedEpoch);
    end
    if ~any(keep),return;end
    sourceRows=find(keep);X=F(keep,:);groups={'PublicRecord6','PublicRecordReady1','Code20_1','LegacyCodeValid1'};
    for gi=1:numel(groups)
        groupName=groups{gi};alias=registry_log_alias(R,groupName);
        fields=registry_group_fields(R,groupName);signals={fields.signal};
        values=nan(height(X),numel(signals));
        for si=1:numel(signals)
            signal=signals{si};
            switch groupName
                case 'PublicRecord6'
                    switch signal
                        case 'D1',values(:,si)=X.D1;
                        case 'D2',values(:,si)=X.D2;
                        case 'DT',values(:,si)=X.DT;
                        case 'sample_id',values(:,si)=X.RAW_ID;
                        case 'epoch',values(:,si)=X.RAW_epoch;
                        case 'valid',values(:,si)=X.RAW_valid;
                        otherwise,values(:,si)=NaN;
                    end
                case 'PublicRecordReady1'
                    if strcmp(signal,'RecordReady'),values(:,si)=X.RecordReady;end
                case 'Code20_1'
                    values(:,si)=X.code20;
                case 'LegacyCodeValid1'
                    values(:,si)=X.oldCodeValidBank;
            end
        end
        valueTable=array2table(values,'VariableNames',signals);
        sourceTime=X.time_s;
        eventRows=cell(height(X),1);eventRow=nan(height(X),1);eventGroupRow=nan(height(X),1);
        eventSampleID=nan(height(X),1);eventGroupIndex=nan(height(X),1);
        eventLinkType=repmat("unlinked",height(X),1);
        eventLinkReason=repmat("No ID/epoch-matched event or parent path at exact output time.",height(X),1);
        for i=1:height(X)
            sameTime=find(E.time_s==X.time_s(i)&E.actualGroupObserved==1);
            direct=sameTime(E.sampleID(sameTime)==X.RAW_ID(i)&E.epoch(sameTime)==X.RAW_epoch(i));
            parent=sameTime(E.parentEventMatched(sameTime)==1& ...
                E.parentSampleID(sameTime)==X.RAW_ID(i)&E.epoch(sameTime)==X.RAW_epoch(i));
            hits=[];link='unlinked';
            if ~isempty(direct),hits=direct;link='direct_event_ID_epoch_time';
            elseif ~isempty(parent),hits=parent;link='parent_event_ID_epoch_time';end
            groupIds=unique(E.eventGroupRow(hits(isfinite(E.eventGroupRow(hits)))),'stable');
            if numel(groupIds)>1
                hits=[];eventLinkReason(i)="Multiple ID/epoch-matched event groups share the same actual time; association is ambiguous.";
            elseif ~isempty(hits)
                eventLinkType(i)=string(link);eventLinkReason(i)=string('Exact ID/epoch/time path matched; co-timed token list remains group-scoped.');
            end
            eventRows{i}=hits(:).';
            if ~isempty(hits)
                eventSampleID(i)=E.sampleID(hits(1));eventGroupIndex(i)=E.groupIndex(hits(1));
                if isscalar(groupIds),eventGroupRow(i)=groupIds(1);end
                if isscalar(hits),eventRow(i)=hits(1);end
            end
        end
        meta=table(sourceRows,sourceTime,sourceTime,eventGroupRow,eventRow,eventRows,eventSampleID, ...
            eventGroupIndex,eventLinkType,eventLinkReason,X.RAW_ID,X.RAW_epoch,X.RecordReady,X.RAW_valid,X.validRecord, ...
            X.codeAligned,'VariableNames',{'sourceRow','time_s','outerSimulationTime_s','eventGroupRow', ...
            'eventRow','eventRows','eventSampleID','groupIndex','eventLinkType','eventLinkReason', ...
            'recordID','recordEpoch','RecordReady', ...
            'RAW_valid','validRecord','code20Aligned'});
        item=trace_proto();item.group=groupName;item.logger=alias.logger_name;
        item.sourceTap=['SimulationOutput.' alias.logger_name];item.observationKind='actual_record_boundary_observation';
        item.time_s=sourceTime;item.values=valueTable;item.rawValues=values;item.metadata=meta;item.fields=fields;
        item.decoded=struct('values',valueTable,'fields',fields);item.available=true;
        item.reason='Exact actual readiness-time join; record ID/epoch remain explicit.';
        T(end+1,1)=item;W(end+1,1)=waveform_from_trace(item); %#ok<AGROW>
    end
end

function k=legacy_observation_kind(groupName)
    switch groupName
        case {'FrontendObs7','BackendObs8','Control13','RAW6','Ready1'}
            k='actual_observation_at_scheduler_group';
        otherwise
            k='actual_record_or_branch_observation';
    end
end

function S=missing_snapshots(E,runPath)
    proto=snapshot_proto(); S=repmat(proto,0,1);
    if isempty(E), return; end
    actual=unique(E.eventGroupRow(isfinite(E.eventGroupRow)),'stable');
    for r=reshape(actual,1,[])
        ix=find(E.eventGroupRow==r); row=E(ix(1),:);
        for owner={'FE353','RA48','SAR51'}
            q=proto;q.owner=owner{1};q.sampleID=row.sampleID;q.epoch=row.epoch;q.time_s=row.time_s;
            q.groupIndex=row.groupIndex;q.eventGroupRow=r;q.eventRows=[];q.exactEvent=false;
            q.stageName='legacy_run_no_state_taps';q.observerOuterRow=NaN;q.scope='event_group';
            q.old=missing_stage([owner{1} ' UnitDelay old output absent from archived run.']);
            q.advanced=missing_stage('Interval/advanced state tap absent from archived run.');
            q.after_command=missing_stage('After-command state tap absent from archived run.');
            q.next=missing_stage('Final next-state UnitDelay input absent from archived run.');
            q.reason=['No state snapshot logger found in archive ' runPath];
            S(end+1,1)=q; %#ok<AGROW>
            for j=reshape(ix,1,[])
                q2=q;q2.stageName='legacy_event_snapshot_unrecorded';q2.scope='event';
                q2.eventRows=j;q2.exactEvent=true;q2.phaseOrdinal=E.phaseOrdinal(j);
                q2.sampleID=E.sampleID(j);q2.epoch=E.epoch(j);q2.time_s=E.time_s(j);
                q2.reason='This event row is selected, but the archived run has no event-specific state snapshot tap.';
                S(end+1,1)=q2; %#ok<AGROW>
            end
        end
    end
end

function s=missing_stage(reason)
    s=struct('value',NaN,'sourceTap','','available',false,'reason',reason,'aliasOf','');
end

function p=snapshot_proto()
    p=struct('owner','','sampleID',NaN,'epoch',NaN,'time_s',NaN,'groupIndex',NaN, ...
        'eventGroupRow',NaN,'observerOuterRow',NaN,'phaseOrdinal',NaN,'eventRows',[], ...
        'exactEvent',false,'scope','event_group','stageName','', ...
        'old',missing_stage(''),'advanced',missing_stage(''), ...
        'after_command',missing_stage(''),'next',missing_stage(''),'reason','');
end

function H=empty_handoffs(reason)
    H=table(zeros(0,1),zeros(0,1),strings(0,1),zeros(0,1),zeros(0,1), ...
        zeros(0,1),zeros(0,1),false(0,1),false(0,1),strings(0,1), ...
        false(0,1),false(0,1),nan(0,1),strings(0,1),strings(0,1), ...
        'VariableNames',{'sample_id','epoch','owner','prevEventGroupRow','nextEventGroupRow', ...
        'prevTime_s','nextTime_s','prevExecutionValid','nextExecutionValid','boundaryClass', ...
        'nextTapValid','oldTapValid','bitwise_equal','sourceTapNext','sourceTapOld'});
    H.Properties.UserData=reason;
end

function H=state_handoffs(S)
    H=empty_handoffs('');
    if isempty(S),H.Properties.UserData='No state snapshot rows were available.';return;end
    use=false(numel(S),1);
    for k=1:numel(S)
        use(k)=strcmp(S(k).scope,'event_group')||strcmp(S(k).stageName,'UnitDelay_boundary')|| ...
            strcmp(S(k).stageName,'legacy_run_no_state_taps');
    end
    S=S(use);if isempty(S),H.Properties.UserData='No group-boundary UnitDelay old/next tap rows were available.';return;end
    owners=unique({S.owner},'stable');
    for oi=1:numel(owners)
        ix=find(strcmp({S.owner},owners{oi}));
        keys=nan(numel(ix),1);
        for k=1:numel(ix)
            keys(k)=S(ix(k)).observerOuterRow;
            if ~isfinite(keys(k)),keys(k)=S(ix(k)).eventGroupRow;end
        end
        [~,ord]=sort(keys,'ascend');ix=ix(ord);
        if isempty(ix),continue;end
        first=S(ix(1));
        H=[H;handoff_row(owners{oi},'window_entry',[],first,missing_stage('Previous final next tap lies outside the selected sample window.'))]; %#ok<AGROW>
        for k=1:numel(ix)-1
            previous=S(ix(k));following=S(ix(k+1));nextTap=previous.next;oldTap=following.old;
            class='missing_tap';eq=NaN;
            if isfinite(previous.epoch)&&isfinite(following.epoch)&&previous.epoch~=following.epoch
                class='initialization';
            elseif nextTap.available&&oldTap.available
                eq=double(bitwise_equal(nextTap.value,oldTap.value));
                if eq==1,class='matched';else,class='unmatched';end
            end
            H=[H;handoff_row(owners{oi},class,previous,following,nextTap)]; %#ok<AGROW>
        end
    end
end

function T=handoff_row(owner,boundary,a,b,nextTap)
    if isempty(a)
        prevGroup=NaN;prevTime=NaN;srcNext='';nextValid=false;prevExec=false;
    else
        prevGroup=a.eventGroupRow;prevTime=a.time_s;prevExec=logical(a.next.available);
        nextValid=logical(a.next.available);srcNext=a.next.sourceTap;
    end
    oldValid=logical(b.old.available);srcOld=b.old.sourceTap;
    T=table(b.sampleID,b.epoch,string(owner),prevGroup,b.eventGroupRow,prevTime,b.time_s, ...
        prevExec,oldValid,string(boundary),nextValid,oldValid,NaN,string(srcNext),string(srcOld), ...
        'VariableNames',{'sample_id','epoch','owner','prevEventGroupRow','nextEventGroupRow', ...
        'prevTime_s','nextTime_s','prevExecutionValid','nextExecutionValid','boundaryClass', ...
        'nextTapValid','oldTapValid','bitwise_equal','sourceTapNext','sourceTapOld'});
    if ~isempty(a)&&nextTap.available&&b.old.available
        T.bitwise_equal=double(bitwise_equal(nextTap.value,b.old.value));
    end
end

function [obsEvents,obsWaves,obsSnaps,obsHandoffs,eventGroups]=observer_views(decoded,observerLog,E,groups,P,id)
    obsEvents=empty_observer_events();
    obsWaves=repmat(waveform_proto(),0,1);
    obsSnaps=repmat(snapshot_proto(),0,1);
    obsHandoffs=empty_handoffs('No exact next/old state taps were available in this archive.');
    eventGroups=empty_event_groups();
    if ~isstruct(decoded),return;end
    obsEvents=observer_event_rows(decoded,groups,E,P,id);
    if isfield(decoded,'taps')&&isstruct(decoded.taps)
        taps=decoded.taps; tapNames=fieldnames(taps);
        for k=1:numel(tapNames)
            name=tapNames{k};tap=taps.(name);
            if ~isstruct(tap)||~isfield(tap,'values')||~istable(tap.values),continue;end
            w=waveform_proto();w.group=tap_group(tap,name);
            w.tapKey=name;
            w.logger='observer_log';w.sourceTap=tap_source(tap,name);
            w.observationKind=tap_kind(tap,name);w.values=tap.values;
            if isfield(tap,'raw'),w.rawValues=tap.raw;else,w.rawValues=table2array(tap.values);end
            w.fields=[];if isfield(tap,'fields'),w.fields=tap.fields;end
            w.metadata=make_tap_metadata(tap,observerLog,E);
            w.time_s=actual_time_from_meta(w.metadata,observerLog.time);
            w.available=height(w.values)>0;w.reason='';
            if isfield(tap,'meta')&&istable(tap.meta)&&any(strcmp(tap.meta.Properties.VariableNames,'recorded'))
                w.available=any(logical(tap.meta.recorded));
            end
            if ~w.available,w.reason='Tap present in schema but no actual recorded rows.';end
            obsWaves(end+1,1)=w; %#ok<AGROW>
        end
        [obsSnaps,obsHandoffs]=observer_snapshots(taps,obsEvents,E,observerLog,P);
    end
    eventGroups=observer_event_groups(decoded,E,observerLog,groups,id);
end

function T=empty_observer_events()
    p=struct('sampleID',{},'epoch',{},'controllerSampleID',{},'controllerEpoch',{}, ...
        'groupIndex',{},'phaseOrdinal',{},'eventName',{}, ...
        'eventIndex',{},'eventBit',{},'record_valid',{},'comparison_used',{}, ...
        'cmp_effective_v',{},'cmp_offset_v',{},'cmp_noise_v',{},'decision',{}, ...
        'compare_valid',{},'compare_late',{},'sample_v',{},'vres_v',{},'vy_v',{}, ...
        'slot',{},'sourceTap',{},'stageName',{},'outerRow',{},'outerSimulationTime_s',{}, ...
        'identityMatch',{},'observedEventName',{},'observedEventCode',{}, ...
        'identityReason',{}, ...
        'modelEventTime_s',{},'phaseModelEventTime_s',{},'phaseTimeBitwiseEqual',{}, ...
        'phaseTimeCompareReason',{},'executionReason',{});
    T=struct2table(p);
end

function O=observer_event_rows(decoded,groups,E,P,requestedID)
    O=empty_observer_events();rows=struct([]);
    if ~isfield(decoded,'events')||~isstruct(decoded.events),return;end
    stages=fieldnames(decoded.events);context=table();
    if isfield(decoded,'context')&&isstruct(decoded.context)&&isfield(decoded.context,'values')
        context=decoded.context.values;
    end
    for si=1:numel(stages)
        stage=stages{si};T=decoded.events.(stage);
        if ~istable(T)||~any(strcmp(T.Properties.VariableNames,'record_valid')),continue;end
        names=T.Properties.VariableNames;
        for r=1:height(T)
            valid=table_number(T,r,{'record_valid'},NaN);
            if valid~=1,continue;end
            controllerSid=table_number(T,r,{'sample_id','sampleID'},NaN);
            controllerEpoch=table_number(T,r,{'epoch'},NaN);
            ordinal=table_number(T,r,{'ordinal','phaseOrdinal','event_ordinal'},NaN);
            outerRow=table_number(T,r,{'outerRow','outer_row'},NaN);
            cRow=find_context_row(context,outerRow);
            contextKnown=~isempty(cRow);
            sid=NaN;eventEpoch=NaN;g=table_number(T,r,{'group_index','groupIndex'},NaN);
            if contextKnown
                sid=table_number(context,cRow,{'cycle_index'},NaN);
                gContext=table_number(context,cRow,{'group_index'},NaN);
                if isfinite(gContext),g=gContext;end
                eventEpoch=double(P.epoch);
            end
            traceIndex=table_number(T,r,{'event_index','eventIndex'},NaN);
            traceBit=table_number(T,r,{'event_bit','eventBit'},NaN);
            traceName=table_text(T,r,{'event_name','eventName'});
            traceCode=table_number(T,r,{'event_code','eventCode'},NaN);
            slot=table_number(T,r,{'slot','slot_index'},NaN);
            if ~isfinite(slot)&&isfinite(outerRow)&&any(strcmp(names,'outerRow'))
                prior=find(double(T.outerRow(1:r))==outerRow);slot=numel(prior);
            end
            tokenKnown=contextKnown&&isfinite(g)&&g==floor(g)&&g>=1&&g<=numel(groups)&& ...
                isfinite(ordinal)&&ordinal==floor(ordinal)&&ordinal>=1&&ordinal<=numel(groups(g).events);
            eventName=traceName;eventIndex=traceIndex;eventBit=traceBit;
            if tokenKnown
                tok=groups(g).events(ordinal);eventName=event_type(tok);
                eventIndex=event_number(tok,'index');eventBit=event_number(tok,'bit');
            end
            identityKnown=contextKnown&&tokenKnown&&~isempty(traceName)&&isfinite(traceIndex)&&isfinite(traceBit)&& ...
                isfinite(controllerSid)&&isfinite(controllerEpoch)&&isfinite(sid);
            identityMatch=NaN;
            if identityKnown
                identityMatch=double(controllerSid==sid&&controllerEpoch==eventEpoch&& ...
                    strcmp(traceName,event_type(groups(g).events(ordinal)))&& ...
                    isequaln(traceIndex,eventIndex)&&isequaln(traceBit,eventBit));
            end
            x=observer_event_proto();x.sampleID=sid;x.epoch=eventEpoch;
            x.controllerSampleID=controllerSid;x.controllerEpoch=controllerEpoch;
            x.groupIndex=g;x.phaseOrdinal=ordinal;x.eventName=eventName;
            x.eventIndex=eventIndex;x.eventBit=eventBit;x.record_valid=valid;x.slot=slot;
            x.identityMatch=identityMatch;x.observedEventName=traceName;x.observedEventCode=traceCode;
            x.comparison_used=table_number(T,r,{'comparison_used','comparisonUsed'},NaN);
            x.cmp_effective_v=table_number(T,r,{'cmp_effective_v','comparisonInput_v'},NaN);
            x.cmp_offset_v=table_number(T,r,{'cmp_offset_v','comparisonOffset_v'},NaN);
            x.cmp_noise_v=table_number(T,r,{'cmp_noise_v','comparisonNoise_v'},NaN);
            x.decision=table_number(T,r,{'decision'},NaN);
            x.compare_valid=table_number(T,r,{'compare_valid','decisionValid'},NaN);
            x.compare_late=table_number(T,r,{'compare_late','decisionLate'},NaN);
            x.sample_v=table_number(T,r,{'sample_v'},NaN);
            x.vres_v=table_number(T,r,{'vres_v'},NaN);x.vy_v=table_number(T,r,{'vy_v'},NaN);
            x.sourceTap=['observer_log.events.' stage];x.stageName=stage;x.outerRow=outerRow;
            x.outerSimulationTime_s=NaN;x.modelEventTime_s=NaN;
            if contextKnown
                x.outerSimulationTime_s=table_number(context,cRow,{'outerSimulationTime_s'},NaN);
                x.modelEventTime_s=table_number(context,cRow,{'modelEventTime_s'},NaN);
            end
            x.phaseModelEventTime_s=table_number(T,r,{'time_s','eventTime_s'},NaN);
            x.phaseTimeBitwiseEqual=bitwise_status(x.phaseModelEventTime_s,x.modelEventTime_s);
            if ~isfinite(x.phaseModelEventTime_s)||~isfinite(x.modelEventTime_s)
                x.phaseTimeCompareReason='One or both model event time words are unrecorded.';
            else
                x.phaseTimeCompareReason='Exact bitwise compare of SC event time and modelEventTime_s.';
            end
            if ~contextKnown
                x.executionReason='Valid SC slot retained, but no unique outer EventTime context row; not assigned to a sample/group.';
            elseif ~tokenKnown
                x.executionReason='Valid SC slot retained, but original event ordinal does not resolve to saved P.groups.';
            elseif identityMatch==1
                x.executionReason='Controller sample/epoch and event code/name/index/bit match the saved P.groups ordinal.';
            elseif identityMatch==0
                x.executionReason='Valid SC slot exists, but controller ID/epoch or event code/name/index/bit mismatches the saved context.';
            else
                x.executionReason='Valid SC slot retained, but one or more identity tags are unrecorded.';
            end
            rows(end+1,1)=x; %#ok<AGROW>
        end
    end
    if isempty(rows),O=empty_observer_events();else,O=struct2table(rows);end
end

function x=observer_event_proto()
    x=struct('sampleID',NaN,'epoch',NaN,'controllerSampleID',NaN,'controllerEpoch',NaN, ...
        'groupIndex',NaN,'phaseOrdinal',NaN, ...
        'eventName','','eventIndex',NaN,'eventBit',NaN,'record_valid',NaN, ...
        'comparison_used',NaN,'cmp_effective_v',NaN,'cmp_offset_v',NaN,'cmp_noise_v',NaN, ...
        'decision',NaN,'compare_valid',NaN,'compare_late',NaN,'sample_v',NaN, ...
        'vres_v',NaN,'vy_v',NaN,'slot',NaN,'sourceTap','','stageName','', ...
        'outerRow',NaN,'outerSimulationTime_s',NaN,'modelEventTime_s',NaN, ...
        'identityMatch',NaN,'observedEventName','','observedEventCode',NaN, ...
        'identityReason','', ...
        'phaseModelEventTime_s',NaN,'phaseTimeBitwiseEqual',NaN, ...
        'phaseTimeCompareReason','','executionReason','');
end

function T=observer_event_groups(decoded,E,observerLog,groups,requestedID)
    proto=struct('selectedSampleID',{},'sampleID',{},'epoch',{},'groupIndex',{}, ...
        'eventGroupRow',{},'outerRow',{},'eventRows',{},'stageName',{},'stageKey',{},'stageCalled',{}, ...
        'sourceTap',{},'outerSimulationTime_s',{},'modelEventTime_s',{},'timeBitwiseEqual',{},'timeMatch',{}, ...
        'inRequestedWindow',{},'reason',{});
    rows=repmat(proto,0,1);
    if ~isfield(decoded,'trace_headers')||~isstruct(decoded.trace_headers),T=struct2table(rows);return;end
    context=table();if isfield(decoded,'context')&&isstruct(decoded.context)&&isfield(decoded.context,'values'),context=decoded.context.values;end
    startRows=find(E.sampleID==requestedID&strcmp(E.eventName,'cnv')&isfinite(E.time_s));
    boundaryRows=find(E.sampleID==requestedID+1&strcmp(E.eventName,'cnv')&isfinite(E.time_s));
    startTime=NaN;boundaryTime=NaN;
    if ~isempty(startRows),startTime=min(E.time_s(startRows));end
    if ~isempty(boundaryRows),boundaryTime=min(E.time_s(boundaryRows));end
    metaAll=struct();if isfield(decoded,'trace_header_meta')&&isstruct(decoded.trace_header_meta),metaAll=decoded.trace_header_meta;end
    stages=fieldnames(decoded.trace_headers);
    for si=1:numel(stages)
        stage=stages{si};
        if startsWith(stage,'SC_'),continue;end % SC phase slots are already in D.events.
        H=decoded.trace_headers.(stage);if ~istable(H),continue;end
        HM=table();if isfield(metaAll,stage),HM=metaAll.(stage);end
        for r=1:height(H)
            outerRow=table_number(HM,r,{'outerRow','outer_row'},NaN);
            if ~isfinite(outerRow),outerRow=table_number(H,r,{'outerRow','outer_row'},NaN);end
            cRow=find_context_row(context,outerRow);
            if isempty(cRow),continue;end
            sid=table_number(context,cRow,{'cycle_index'},NaN);g=table_number(context,cRow,{'group_index'},NaN);
            if ~isfinite(sid)||~isfinite(g),continue;end
            stageCalled=table_number(H,r,{'stage_called','valid','record_valid'},NaN);
            if isfinite(stageCalled)&&stageCalled~=1,continue;end
            eRows=find(E.observerOuterRow==outerRow);
            groupRows=unique(E.eventGroupRow(eRows(isfinite(E.eventGroupRow(eRows)))),'stable');
            actualTime=table_number(context,cRow,{'outerSimulationTime_s'},NaN);
            modelTime=table_number(context,cRow,{'modelEventTime_s'},NaN);
            q=struct('selectedSampleID',requestedID,'sampleID',sid,'epoch',NaN,'groupIndex',g, ...
                'eventGroupRow',NaN,'outerRow',outerRow,'eventRows',eRows(:).','stageName',stage,'stageKey',stage, ...
                'stageCalled',stageCalled,'sourceTap',['observer_log.' stage], ...
                'outerSimulationTime_s',actualTime,'modelEventTime_s',modelTime, ...
                'timeBitwiseEqual',bitwise_status(actualTime,modelTime), ...
                'timeMatch',bitwise_status(actualTime,modelTime), ...
                'inRequestedWindow',logical(stage_row_in_window(sid,g,actualTime,groups,requestedID,startTime,boundaryTime)), ...
                'reason','Group-scope FE/BE stage observation; no SC event ordinal is inferred.');
            if ~q.inRequestedWindow,q.reason='Observer stage row lies outside the selected sample through next-CNV window; retained and not merged into the selected event table.';end
            if isscalar(groupRows),q.eventGroupRow=groupRows;end
            if isfinite(table_number(H,r,{'epoch'},NaN)),q.epoch=table_number(H,r,{'epoch'},NaN);end
            rows(end+1,1)=q; %#ok<AGROW>
        end
    end
    T=struct2table(rows);
end

function yes=stage_row_in_window(sid,g,t,groups,id,startTime,boundaryTime)
    yes=false;if ~isfinite(sid)||~isfinite(g)||~isfinite(t),return;end
    if sid==id
        yes=~isfinite(startTime)||t>=startTime;
        if isfinite(boundaryTime),yes=yes&&t<=boundaryTime;end
    elseif sid==id+1&&g>=1&&g<=numel(groups)&& ...
            any(strcmp(event_types(groups(g).events),'cnv'))&&isfinite(boundaryTime)
        yes=bitwise_equal(t,boundaryTime);
    end
end

function t=event_types_from_group(E,rows)
    t={};
    if isempty(rows),return;end
    for r=reshape(rows,1,[]),t{end+1}=char(string(E.eventName(r)));end %#ok<AGROW>
end

function [S,H]=observer_snapshots(taps,O,E,observerLog,P)
    p=snapshot_proto();S=repmat(p,0,1);
    if ~isstruct(taps),H=empty_handoffs('Observer tap structure is missing.');return;end
    names=fieldnames(taps);owners={'FE353','RA48','SAR51'};prefixes={'FE','RA','SAR'};
    % Exact UnitDelay old and next wires define group-boundary snapshots.
    for oi=1:numel(owners)
        owner=owners{oi};pre=prefixes{oi};oldName=[pre '_old'];nextName=[pre '_next'];
        oldTap=[];nextTap=[];if isfield(taps,oldName),oldTap=taps.(oldName);end
        if isfield(taps,nextName),nextTap=taps.(nextName);end
        outerRows=unique([tap_outer_rows(oldTap) tap_outer_rows(nextTap)],'stable');
        for outerRow=reshape(outerRows,1,[])
            if ~isfinite(outerRow),continue;end
            q=p;q.owner=owner;q.stageName='UnitDelay_boundary';q.scope='event_group';q.observerOuterRow=outerRow;
            q.old=tap_stage_at(oldTap,outerRow,[owner ' UnitDelay old output']);
            q.next=tap_stage_at(nextTap,outerRow,[owner ' UnitDelay final next input']);
            q.advanced=missing_stage('No separate interval-stage state tap at the UnitDelay boundary.');
            q.after_command=missing_stage('No event-specific after-command tap at the UnitDelay boundary.');
            [q.sampleID,q.epoch,q.groupIndex,q.time_s,q.eventRows,q.eventGroupRow]=snapshot_context(E,outerRow);
            q.eventRows=[];q.exactEvent=false;
            q.reason='Direct UnitDelay boundary taps are group-scoped; no single co-timed phase is inferred.';
            S(end+1,1)=q; %#ok<AGROW>
        end
    end
    % FE and RA each retain one snapshot entry per actual physical stage. Rows
    % are joined by outerRow; tap row numbers are never assumed to align.
    stageKeys={};
    for k=1:numel(names)
        [owner,stageName,part]=parse_state_tap_name(names{k});
        if isempty(owner)||~ismember(owner,{'FE353','RA48'})|| ...
                ~ismember(part,{'old','advanced','after_command'})||strcmp(stageName,'UnitDelay_boundary')
            continue;
        end
        for outerRow=reshape(unique(tap_outer_rows(taps.(names{k})),'stable'),1,[])
            key=sprintf('%s|%s|%.0f',owner,stageName,outerRow);
            if any(strcmp(stageKeys,key)),continue;end
            stageKeys{end+1}=key; %#ok<AGROW>
            q=p;q.owner=owner;q.stageName=stageName;q.scope='stage';q.observerOuterRow=outerRow;
            [q.sampleID,q.epoch,q.groupIndex,q.time_s,groupEventRows,q.eventGroupRow]=snapshot_context(E,outerRow);
            suffix='FE353';if strcmp(owner,'RA48'),suffix='RA48';end
            base=stageName;
            q.old=stage_tap_value(taps,[base '_old' suffix],outerRow,owner,'old');
            q.advanced=stage_tap_value(taps,[base '_advanced' suffix],outerRow,owner,'advanced');
            q.after_command=stage_tap_value(taps,[base '_after_command' suffix],outerRow,owner,'after_command');
            q.next=missing_stage('The saved-state next wire is a separate group-boundary tap.');
            if stage_is_final(stageName,owner)
                direct=[pre_for_owner(owner) '_next'];
                if isfield(taps,direct),q.next=tap_stage_at(taps.(direct),outerRow,[owner ' final UnitDelay input']);end
            end
            meta=meta_for_outer(taps.(names{k}),outerRow);
            q.eventRows=exact_stage_event_rows(E,groupEventRows,meta);q.exactEvent=isscalar(q.eventRows);
            if q.exactEvent,q.phaseOrdinal=E.phaseOrdinal(q.eventRows);q.scope='event';
            else,q.eventRows=[];q.reason='Stage trace is present at this scheduler group; no unique token ordinal identifies a co-timed phase.';end
            S(end+1,1)=q; %#ok<AGROW>
        end
    end
    % SC emits one exact state-after-event tap per valid slot. The UnitDelay
    % old/next vectors apply only at the first/last token of the co-timed group.
    for k=1:numel(names)
        name=names{k};if ~contains(name,'slot')||~contains(name,'after_SAR51'),continue;end
        tap=taps.(name);if ~isstruct(tap)||~isfield(tap,'values')||~istable(tap.values),continue;end
        for outerRow=reshape(unique(tap_outer_rows(tap),'stable'),1,[])
            ix=tap_row_for_outer(tap,outerRow);if ~isscalar(ix),continue;end
            meta=meta_for_outer(tap,outerRow);slot=slot_from_name(name);
            oe=find(O.outerRow==outerRow & O.slot==slot & O.record_valid==1);
            if ~isscalar(oe),continue;end
            g=O.groupIndex(oe);ordinal=O.phaseOrdinal(oe);sid=O.sampleID(oe);epoch=O.epoch(oe);
            tokenRows=find(E.observerOuterRow==outerRow&E.sampleID==sid&E.epoch==epoch& ...
                E.groupIndex==g&E.phaseOrdinal==ordinal&E.phaseExecuted==1);
            if ~isscalar(tokenRows),continue;end
            q=p;q.owner='SAR51';q.stageName=O.stageName{oe};q.scope='event';q.phaseOrdinal=ordinal;
            q.observerOuterRow=outerRow;q.eventRows=tokenRows;q.exactEvent=true;
            q.sampleID=sid;q.epoch=epoch;q.groupIndex=g;q.eventGroupRow=E.eventGroupRow(tokenRows);q.time_s=E.time_s(tokenRows);
            q.old=missing_stage('SAR UnitDelay old output is a group-entry tap, not per-slot state.');
            if ordinal==1&&isfield(taps,'SAR_old')
                ri=tap_row_for_outer(taps.SAR_old,outerRow);if isscalar(ri),q.old=tap_stage_at(taps.SAR_old,outerRow,'SarState UnitDelay old output');end
            end
            q.advanced=missing_stage('SAR controller has no separate interval-advanced state tap.');
            q.after_command=tap_stage(tap,ix,'SAR51','after_event');
            q.next=missing_stage('Final SAR UnitDelay input follows all co-timed event slots.');
            groupRows=find(E.observerOuterRow==outerRow&E.sampleID==sid&E.epoch==epoch);
            ordinals=E.phaseOrdinal(groupRows);ordinals=ordinals(isfinite(ordinals));
            if ~isempty(ordinals)&&ordinal==max(ordinals)&&isfield(taps,'SAR_next')
                ri=tap_row_for_outer(taps.SAR_next,outerRow);if isscalar(ri),q.next=tap_stage_at(taps.SAR_next,outerRow,'SarState UnitDelay final next input');end
            end
            q.reason='SAR after-event state is a phase-level local state tap; old/next are separately observed group-boundary wires.';
            S(end+1,1)=q; %#ok<AGROW>
        end
    end
    H=state_handoffs(S);
end

function q=stage_tap_value(taps,name,outerRow,owner,stage)
    q=missing_stage(['Tap ' name ' not recorded.']);
    if isfield(taps,name),q=tap_stage_at(taps.(name),outerRow,[owner ' ' stage]);end
end

function [sid,epoch,g,tm,eventRows,groupRow]=snapshot_context(E,outerRow)
    sid=NaN;epoch=NaN;g=NaN;tm=NaN;eventRows=[];groupRow=NaN;
    if ~istable(E)||~any(strcmp(E.Properties.VariableNames,'observerOuterRow')),return;end
    eventRows=find(E.observerOuterRow==outerRow);
    if isempty(eventRows),return;end
    q=eventRows(1);sid=E.sampleID(q);epoch=E.epoch(q);g=E.groupIndex(q);tm=E.time_s(q);
    rows=unique(E.eventGroupRow(eventRows(isfinite(E.eventGroupRow(eventRows)))),'stable');
    if isscalar(rows),groupRow=rows(1);end
end

function q=tap_stage_at(tap,outerRow,label)
    q=missing_stage(['Missing exact tap row: ' label]);
    r=tap_row_for_outer(tap,outerRow);if ~isscalar(r),return;end
    q=tap_stage(tap,r,'','');
end

function q=tap_stage(tap,r,owner,stage)
    q=missing_stage('');
    if ~isstruct(tap)||~isfield(tap,'values')||~istable(tap.values)||r>height(tap.values)
        q.reason='Missing exact source tap row.';return;
    end
    meta=meta_row(tap,r);
    recorded=meta_value(meta,{'decoded_tap_recorded','recorded','valid'});
    if recorded==0
        q.reason=meta_text(meta,{'decoded_reason','reason'},'Tap row explicitly marked not recorded.');return;
    end
    q.sourceTap='observer_log';
    if isfield(tap,'sourceTap'),q.sourceTap=char(string(tap.sourceTap));end
    if isfield(tap,'raw')&&size(tap.raw,1)>=r,q.value=tap.raw(r,:);
    else,q.value=table2array(tap.values(r,:));end
    if isempty(q.value)||~isnumeric(q.value)||all(isnan(q.value(:)))
        q.value=NaN;q.reason=meta_text(meta,{'decoded_reason','reason'},'All-NaN tap vector; no state value is recorded.');return;
    end
    q.available=true;
    if any(isnan(q.value(:))),q.reason='Recorded tap contains original NaN fields; no replacement values were inserted.';end
    if isfield(meta,'aliasOf'),q.aliasOf=char(string(meta.aliasOf));end
    if isempty(q.sourceTap),q.sourceTap=[owner ' ' stage];end
end

function s=meta_text(meta,names,fallback)
    s=fallback;
    for k=1:numel(names)
        if isfield(meta,names{k}),s=char(string(meta.(names{k})));return;end
    end
end

function meta=meta_for_outer(tap,outerRow)
    meta=struct();r=tap_row_for_outer(tap,outerRow);if isscalar(r),meta=meta_row(tap,r);end
end

function slot=slot_from_name(name)
    slot=NaN;q=regexp(name,'slot([12])_after_SAR51','tokens','once');if ~isempty(q),slot=str2double(q{1});end
end

function M=make_tap_metadata(tap,observerLog,E)
    M=table();if isfield(tap,'meta')&&istable(tap.meta),M=tap.meta;end
    n=height(tap.values);
    if ~any(strcmp(M.Properties.VariableNames,'outerSimulationTime_s'))
        outer=nan(n,1);
        if any(strcmp(M.Properties.VariableNames,'outerRow'))
            for i=1:n,ix=double(M.outerRow(i));if isfinite(ix)&&ix>=1&&ix<=numel(observerLog.time),outer(i)=observerLog.time(ix);end,end
        elseif n==numel(observerLog.time),outer=observerLog.time(:);end
        M.outerSimulationTime_s=outer;
    end
    if ~any(strcmp(M.Properties.VariableNames,'eventRows'))
        eventRows=cell(n,1);
        if any(strcmp(M.Properties.VariableNames,'outerRow'))
            for i=1:n,eventRows{i}=find(E.observerOuterRow==M.outerRow(i)).';end
        end
        M.eventRows=eventRows;
    end
    if ~any(strcmp(M.Properties.VariableNames,'eventRow'))
        eventRow=nan(height(M),1);
        if any(strcmp(M.Properties.VariableNames,'eventRows'))
            for i=1:height(M),if numel(M.eventRows{i})==1,eventRow(i)=M.eventRows{i}(1);end,end
        end
        M.eventRow=eventRow;
    end
    if ~any(strcmp(M.Properties.VariableNames,'decoded_tap_recorded'))
        if any(strcmp(M.Properties.VariableNames,'recorded'))
            M.decoded_tap_recorded=double(logical(M.recorded));
        else
            M.decoded_tap_recorded=nan(height(M),1);
        end
    end
    if ~any(strcmp(M.Properties.VariableNames,'decoded_reason'))
        if any(strcmp(M.Properties.VariableNames,'reason'))
            M.decoded_reason=string(M.reason);
        else
            M.decoded_reason=repmat(string('tap metadata reason not recorded'),height(M),1);
        end
    end
end

function t=actual_time_from_meta(M,outer)
    t=nan(height(M),1);
    if any(strcmp(M.Properties.VariableNames,'outerSimulationTime_s'))
        t=double(M.outerSimulationTime_s);return;
    end
    if any(strcmp(M.Properties.VariableNames,'outerRow'))
        for i=1:height(M),r=double(M.outerRow(i));if isfinite(r)&&r>=1&&r<=numel(outer),t(i)=outer(r);end,end
    elseif height(M)==numel(outer),t=outer(:);end
end

function S=empty_event_groups()
    p=struct('selectedSampleID',{},'sampleID',{},'epoch',{},'groupIndex',{}, ...
        'eventGroupRow',{},'outerRow',{},'eventRows',{},'stageName',{},'stageCalled',{}, ...
        'sourceTap',{},'outerSimulationTime_s',{},'modelEventTime_s',{},'timeBitwiseEqual',{}, ...
        'inRequestedWindow',{},'reason',{});
    S=struct2table(p);
end

function x=table_number(T,r,candidates,default)
    x=default;if ~istable(T)||r<1||r>height(T),return;end
    for k=1:numel(candidates)
        if any(strcmp(T.Properties.VariableNames,candidates{k}))
            v=T.(candidates{k});if iscell(v),v=v{r};else,v=v(r);end
            if (isnumeric(v)||islogical(v))&&isscalar(v),x=double(v);return;end
        end
    end
end

function x=table_text(T,r,candidates)
    x='';if ~istable(T)||r<1||r>height(T),return;end
    for k=1:numel(candidates)
        if any(strcmp(T.Properties.VariableNames,candidates{k}))
            v=T.(candidates{k});if iscell(v),v=v{r};else,v=v(r);end
            if isstring(v)&&isscalar(v),x=char(v);return;end
            if ischar(v),x=v;return;end
        end
    end
end

function r=find_context_row(C,outerRow)
    r=[];if ~istable(C)||~isfinite(outerRow),return;end
    if any(strcmp(C.Properties.VariableNames,'outerRow'))
        q=find(double(C.outerRow)==outerRow);if isscalar(q),r=q;end
    end
end

function e=event_row_table_index(E,sid,epoch,g,ordinal)
    e=find(E.sampleID==sid&E.epoch==epoch&E.groupIndex==g&E.phaseOrdinal==ordinal & E.phaseExecuted==1,1,'first');
end

function t=tap_outer_rows(tap)
    t=[];if ~isstruct(tap)||~isfield(tap,'meta')||~istable(tap.meta),return;end
    if any(strcmp(tap.meta.Properties.VariableNames,'outerRow')),t=double(tap.meta.outerRow(:)).';end
end

function r=tap_row_for_outer(tap,outerRow)
    r=[];if ~isstruct(tap)||~isfield(tap,'meta')||~istable(tap.meta)||~any(strcmp(tap.meta.Properties.VariableNames,'outerRow')),return;end
    q=find(double(tap.meta.outerRow)==outerRow);
    if isscalar(q),r=q;end
end

function [owner,stage,part]=parse_state_tap_name(name)
    owner='';stage='';part='';
    if any(strcmp(name,{'FE_old','FE_next'})),owner='FE353';stage='UnitDelay_boundary';if endsWith(name,'old'),part='old';else,part='next';end;return;end
    if any(strcmp(name,{'RA_old','RA_next'})),owner='RA48';stage='UnitDelay_boundary';if endsWith(name,'old'),part='old';else,part='next';end;return;end
    if any(strcmp(name,{'SAR_old','SAR_next'})),owner='SAR51';stage='UnitDelay_boundary';if endsWith(name,'old'),part='old';else,part='next';end;return;end
    if contains(name,'FE353'),owner='FE353';suffix='FE353';
    elseif contains(name,'RA48'),owner='RA48';suffix='RA48';
    elseif contains(name,'SAR51'),owner='SAR51';suffix='SAR51';
    else,return;end
    if contains(name,'_old'),part='old';stage=extractBefore(name,'_old');
    elseif contains(name,'_advanced'),part='advanced';stage=extractBefore(name,'_advanced');
    elseif contains(name,'_after_command'),part='after_command';stage=extractBefore(name,'_after_command');
    elseif contains(name,'slot')&&contains(name,'after_SAR51'),part='after_command';stage=extractBefore(name,'_slot');
    end
    if isempty(stage),stage=name;end
end

function s=stage_name_from_tap(name)
    q=regexp(name,'^(.*)_slot[12]_after_SAR51$','tokens','once');if isempty(q),s=name;else,s=q{1};end
end

function p=pre_for_owner(owner)
    switch owner,case 'FE353',p='FE';case 'RA48',p='RA';otherwise,p='SAR';end
end

function tf=stage_is_final(stageName,owner)
    if strcmp(owner,'FE353'),tf=contains(stageName,'ChargeReturn');
    elseif strcmp(owner,'RA48'),tf=contains(stageName,'RaReset');
    else,tf=contains(stageName,'Decide');end
end

function v=tap_stage_at(tap,outerRow,label)
    v=missing_stage(['Missing exact tap row: ' label]);
    r=tap_row_for_outer(tap,outerRow);if ~isscalar(r),return;end
    v=tap_stage(tap,r,'','');
end

function q=exact_stage_event_rows(E,groupRows,meta)
    q=[];ordinal=meta_value(meta,{'phaseOrdinal','ordinal'});
    sid=meta_value(meta,{'sampleID','sample_id','cycle_index'});
    epoch=meta_value(meta,{'epoch'});g=meta_value(meta,{'groupIndex','group_index'});
    if isfinite(ordinal)&&isfinite(sid)&&isfinite(epoch)&&isfinite(g)
        q=event_row_table_index(E,sid,epoch,g,ordinal);return;
    end
    % A single token in a group does not prove which physical stage consumed
    % it unless the stage tap carries its original ordinal and identity tags.
end

function tf=bitwise_equal(a,b)
    tf=false;
    if ~isnumeric(a)||~isnumeric(b)||~isequal(size(a),size(b))||~strcmp(class(a),class(b)),return;end
    if isa(a,'double'),tf=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
    elseif isa(a,'single'),tf=isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
    else,tf=isequal(a,b);end
end

function q=bitwise_status(a,b)
    q=NaN;
    if isnumeric(a)&&isnumeric(b)&&isreal(a)&&isreal(b)&&isscalar(a)&&isscalar(b)&&isfinite(a)&&isfinite(b)
        q=double(bitwise_equal(double(a),double(b)));
    end
end

function tap=first_available(taps)
    tap=[];
    for k=1:numel(taps)
        if isstruct(taps{k})&&isfield(taps{k},'values')&&istable(taps{k}.values)&&height(taps{k}.values)>0,tap=k;return;end
    end
end

function r=owner_prefix(owner)
    switch owner,case 'FE353',r='FE';case 'RA48',r='RA';otherwise,r='SAR';end
end

function m=meta_row(tap,r)
    m=struct();
    if isfield(tap,'meta')
        x=tap.meta;
        if istable(x)&&height(x)>=r
            for k=1:width(x),m.(x.Properties.VariableNames{k})=x{r,k};end
        elseif isstruct(x)&&numel(x)>=r
            m=x(r);
        end
    end
end

function x=meta_value(m,names)
    x=NaN;
    for k=1:numel(names)
        if isfield(m,names{k})
            v=m.(names{k});if iscell(v)&&isscalar(v),v=v{1};end
            if isnumeric(v)&&isscalar(v)&&isfinite(v),x=double(v);return;end
        end
    end
end

function t=metadata_time(m,outer)
    t=outer(:);
    if istable(m)
        nms=m.Properties.VariableNames;
        for name={'time_s','eventTime_s','actualTime_s'}
            if any(strcmp(nms,name{1}))&&height(m)==numel(outer),t=double(m.(name{1}));return;end
        end
    end
end

function g=tap_group(tap,name)
    g=name;
    if isfield(tap,'fields')&&~isempty(tap.fields)&&isfield(tap.fields,'group')
        q=unique({tap.fields.group});if isscalar(q),g=q{1};end
    end
end

function s=tap_source(tap,name)
    s=name;
    if isfield(tap,'sourceTap'),s=char(tap.sourceTap);
    elseif isfield(tap,'fields')&&~isempty(tap.fields)&&isfield(tap.fields,'source')
        q=unique({tap.fields.source});if isscalar(q),s=q{1};end
    end
end

function k=tap_kind(tap,name)
    k='actual_observation';
    if contains(lower(name),'predicted'),k='stage_value_predicted';
    elseif contains(lower(name),'ideal')||contains(lower(name),'reference'),k='diagnostic_reference';
    elseif contains(lower(name),'drift'),k='condition_drift';
    end
    if isfield(tap,'fields')&&~isempty(tap.fields)&&isfield(tap.fields,'validity')
        q=unique({tap.fields.validity});if isscalar(q),k=q{1};end
    end
end

function E=merge_observer_events(E,O)
    if isempty(O)||~istable(O)||isempty(E),return;end
    names=O.Properties.VariableNames;
    required={'sampleID','epoch','controllerSampleID','controllerEpoch','groupIndex','phaseOrdinal', ...
        'eventName','eventIndex','eventBit','record_valid','identityMatch'};
    if ~all(ismember(required,names)),return;end
    for r=1:height(O)
        if any(strcmp(names,'outerRow'))&&isfinite(O.outerRow(r))
            hit=find(E.observerOuterRow==O.outerRow(r)&E.groupIndex==O.groupIndex(r)& ...
                E.phaseOrdinal==O.phaseOrdinal(r));
        else
            hit=find(E.sampleID==O.sampleID(r)&E.epoch==O.epoch(r)& ...
                E.groupIndex==O.groupIndex(r)&E.phaseOrdinal==O.phaseOrdinal(r));
        end
        if ~isscalar(hit)||O.record_valid(r)~=1,continue;end
        rowIdentity=(isequaln(E.sampleID(hit),O.sampleID(r))&&isequaln(E.epoch(hit),O.epoch(r)));
        if ~rowIdentity
            E.controllerTraceObserved(hit)=1;E.phaseIdentityMatch(hit)=0;
            E.controllerSampleID(hit)=O.controllerSampleID(r);E.controllerEpoch(hit)=O.controllerEpoch(r);
            E=assign_text(E,'controllerIDSourceTap',hit,char(string(O.sourceTap(r))));
            E=assign_text(E,'phaseObservedEventName',hit,char(string(O.observedEventName(r))));
            E.phaseObservedEventCode(hit)=O.observedEventCode(r);
            E=assign_text(E,'phaseIdentityReason',hit,'Outer event sample/epoch does not match the event-table sample/epoch; phase not credited.');
            continue;
        end
        E.controllerTraceObserved(hit)=1;E.phaseIdentityMatch(hit)=O.identityMatch(r);
        E.controllerSampleID(hit)=O.controllerSampleID(r);E.controllerEpoch(hit)=O.controllerEpoch(r);
        E=assign_text(E,'controllerIDSourceTap',hit,char(string(O.sourceTap(r))));
        E=assign_text(E,'phaseObservedEventName',hit,char(string(O.observedEventName(r))));
        E.phaseObservedEventCode(hit)=O.observedEventCode(r);
        E=assign_text(E,'phaseIdentityReason',hit,char(string(O.identityReason(r))));
        if O.identityMatch(r)~=1
            E=assign_text(E,'executionReason',hit,char(string(O.executionReason(r))));
            continue;
        end
        E.phaseExecuted(hit)=1;
        E.executionReason=assign_text(E,'executionReason',hit,'SC event-code/name/index/bit matched the saved P.groups ordinal.');
        maps={'comparison_used','comparisonUsed';'cmp_effective_v','comparisonInput_v'; ...
            'cmp_offset_v','comparisonOffset_v';'cmp_noise_v','comparisonNoise_v'; ...
            'decision','decision';'compare_valid','decisionValid';'compare_late','decisionLate'; ...
            'phaseModelEventTime_s','phaseModelEventTime_s';'phaseTimeBitwiseEqual','phaseTimeBitwiseEqual'};
        for k=1:size(maps,1)
            if any(strcmp(names,maps{k,1}))
                col=E.(maps{k,2});col(hit)=O.(maps{k,1})(r);E.(maps{k,2})=col;
            end
        end
        if any(strcmp(names,'stageName')),E=assign_text(E,'stageName',hit,char(string(O.stageName(r))));end
        if any(strcmp(names,'sourceTap')),E=assign_text(E,'decisionSourceTap',hit,char(string(O.sourceTap(r))));end
        if any(strcmp(names,'phaseTimeCompareReason'))
            E=assign_text(E,'phaseTimeCompareReason',hit,char(string(O.phaseTimeCompareReason(r))));
        end
    end
end

function E=assign_text(E,name,row,value)
    col=E.(name);
    if iscell(col),col{row}=value;else,col(row)=string(value);end
    E.(name)=col;
end

function D2=find_first_d2(E,W,id,P,proto)
    D2=proto;
    if isempty(E)||~istable(E),return;end
    hit=find(E.sampleID==id & strcmp(E.eventName,'d2_decide') & E.phaseExecuted==1,1,'first');
    if isempty(hit)
        hit=find(E.sampleID==id & strcmp(E.eventName,'d2_decide'),1,'first');
    end
    if isempty(hit),D2.reason='该sampleID没有已记录的d2_decide日历token。';return;end
    D2.eventRow=hit;D2.eventGroupRow=E.eventGroupRow(hit);D2.groupIndex=E.groupIndex(hit);
    D2.phaseOrdinal=E.phaseOrdinal(hit);D2.time_s=E.time_s(hit);D2.timeFromCnv_s=E.timeFromCnv_s(hit);
    D2.sample_id=E.sampleID(hit);D2.phase=char(string(E.eventName(hit)));
    D2.actualSimulationTime_s=E.time_s(hit);D2.modelEventTime_s=E.modelEventTime_s(hit);
    D2.eventTimeBitwiseEqual=E.eventTimeBitwiseEqual(hit);
    D2.phaseModelEventTime_s=E.phaseModelEventTime_s(hit);D2.phaseTimeBitwiseEqual=E.phaseTimeBitwiseEqual(hit);
    D2.phaseTimeCompareReason=char(string(E.phaseTimeCompareReason(hit)));
    D2.phaseExecuted=E.phaseExecuted(hit);D2.decision=E.decision(hit);D2.decisionValid=E.decisionValid(hit);
    D2.comparisonUsed=E.comparisonUsed(hit);D2.comparisonInput_v=E.comparisonInput_v(hit);
    D2.comparisonOffset_v=E.comparisonOffset_v(hit);D2.comparisonNoise_v=E.comparisonNoise_v(hit);
    D2.sourceTap=char(string(E.decisionSourceTap(hit)));
    vx=waveform_value_at_event(W,{'BackendObs8','BackendRaAzCtTrace','RaAzCt'},'VX',hit);
    vy=waveform_value_at_event(W,{'BackendObs8','BackendRaAzCtTrace','RaAzCt'},'VY',hit);
    D2.VX_stage_v=vx.value;D2.VY_stage_v=vy.value;D2.VX_stage_source=vx.source;D2.VY_stage_source=vy.source;
    actualCmp=D2.phaseExecuted==1&&D2.comparisonUsed==1&&D2.decisionValid==1&& ...
        all(isfinite([D2.comparisonInput_v D2.comparisonOffset_v D2.comparisonNoise_v D2.decision]));
    if actualCmp
        D2.available=true;D2.decision_source='actual_comparator_output';
        D2.reason='Actual ControlDecide trace slot includes comparison input/offset/noise and decision.';
    elseif isfinite(D2.time_s)
        D2.reason='Event and actual time are located, but complete actual comparator input/decision evidence is not recorded. VX/VY are stage values only.';
    else
        D2.reason='事件token存在，但无实际执行时间或比较器输入tap。';
    end
end

function s=run_identity(runPath,meta,files)
    [~,runId]=fileparts(runPath);
    s=struct('runPath',runPath,'runID',runId,'archiveRunPath','', ...
        'status','','simulationCompleted',false,'modelKind','','modelSHA256','', ...
        'configSHA256','','sourceZipSHA256','','captureBoundary','','utc','', ...
        'finishedUtc','','records',NaN,'files',files,'summaryRunID','', ...
        'identityBinding','summary.json identity copied; MAT payload not independently hash-bound.');
    maps={'run_path','archiveRunPath';'status','status';'simulation_completed','simulationCompleted'; ...
        'model_kind','modelKind';'model_sha256','modelSHA256';'config_sha256','configSHA256'; ...
        'source_zip_sha256','sourceZipSHA256';'capture_boundary','captureBoundary'; ...
        'utc','utc';'finished_utc','finishedUtc';'records','records'};
    for k=1:size(maps,1)
        if isfield(meta,maps{k,1}),s.(maps{k,2})=meta.(maps{k,1});end
    end
    if isfield(meta,'run_path')
        parts=regexp(char(meta.run_path),'[\\/]','split');
        if ~isempty(parts),s.summaryRunID=parts{end};end
        if ~strcmp(s.summaryRunID,runId)
            s.identityBinding='summary run_path tail does not match selected archive folder; identity is unverified.';
        end
    end
end

function yes=bank_enabled(P)
    yes=false;
    if isfield(P,'bank')&&isstruct(P.bank)&&isfield(P.bank,'enabled')
        yes=logical(P.bank.enabled);
    end
end

function V=validation_summary(E,id,observer,groups,H,observerContract,validity,firstD2,P)
    token=E.sampleID==id;
    compares=token & strcmp(E.eventName,'ta_compare');
    updates=token & strcmp(E.eventName,'ta_feedback');
    expectedCompare=0;expectedUpdate=0;
    expectedD2=0;
    for g=1:numel(groups)
        kinds=event_types(groups(g).events);
        expectedCompare=expectedCompare+nnz(strcmp(kinds,'ta_compare'));
        expectedUpdate=expectedUpdate+nnz(strcmp(kinds,'ta_feedback'));
        expectedD2=expectedD2+nnz(strcmp(kinds,'d2_decide'));
    end
    actualGroups=unique(E.groupIndex(token & E.actualGroupObserved==1 & isfinite(E.groupIndex)),'stable');
    next=E(E.sampleID>id & strcmp(E.eventName,'cnv') & E.actualGroupObserved==1,:);
    nextId=NaN;
    if ~isempty(next)
        times=next.time_s;times(~isfinite(times))=Inf;[~,k]=min(times);nextId=next.sampleID(k);
    end
    [compareActual,compareUnknown]=count_actual(compares,E.phaseExecuted,expectedCompare);
    [updateActual,updateUnknown]=count_actual(updates,E.phaseExecuted,expectedUpdate);
    d2Mask=token&strcmp(E.eventName,'d2_decide');
    [d2Actual,d2Unknown]=count_actual(d2Mask,E.phaseExecuted,expectedD2);
    allUnknown=nnz(token & isnan(E.phaseExecuted));
    if isempty(E),groupCount=0;else,groupCount=numel(actualGroups);end
    [observerRows,observerSampleIds,observerBoundaryIds,observerOutside,observerExpected,observerLimit, ...
        observerRowCountMatches,observerWindowComplete,observerCurrentGroupCount,observerMissingGroups, ...
        observerDuplicateRows,observerBoundaryRowCount,observerBoundaryIdMatches,observerBoundaryDelta_s, ...
        observerBoundaryPeriodBitwiseEqual]= ...
        observer_row_summary(observer,id,groups,observerContract,P);
    if observer.available && observerWindowComplete && compareUnknown==0 && updateUnknown==0 && ...
            compareActual==expectedCompare && updateActual==expectedUpdate
        status='observer_window_and_tracking_counts_passed';
    elseif groupCount>0
        status='partial_unobserved_phase';
    else
        status='unmatched';
    end
    hand=handoff_counts(H);
    V=struct('status',status,'eventGroupCount',groupCount, ...
        'eventGroupExpectedCount',numel(groups),'nextCnvId',nextId, ...
        'trackingCompareConfigured',expectedCompare,'trackingCompareActual',compareActual, ...
        'trackingCompareUnknown',compareUnknown,'trackingUpdateConfigured',expectedUpdate, ...
        'trackingUpdateActual',updateActual,'trackingUnknown',compareUnknown+updateUnknown, ...
        'd2Configured',expectedD2,'d2Actual',d2Actual,'d2Unknown',d2Unknown, ...
        'firstD2ActualComparatorOutput',strcmp(firstD2.decision_source,'actual_comparator_output'), ...
        'recordReady',validity.RecordReady,'RAW_valid',validity.RAW_valid, ...
        'validRecord_event',validity.validRecord_event,'recordCode20Aligned',validity.code20Aligned, ...
        'recordCode20Legal',validity.code20Legal, ...
        'phaseExecutedKnown',nnz(token & ~isnan(E.phaseExecuted)), ...
        'phaseExecutedUnknown',allUnknown,'handoffMatched',hand.matched, ...
        'handoffUnmatched',hand.unmatched,'handoffInitialization',hand.initialization, ...
        'handoffInactive',hand.inactive,'handoffMissing',hand.missing, ...
        'handoffUnknown',hand.unknown,'observerMaxRowsPerLogger',observerRows, ...
        'observerTotalRows',observerRows,'observerSampleIds',observerSampleIds, ...
        'observerBoundaryIds',observerBoundaryIds,'observerRowsOutsideWindow',observerOutside, ...
        'observerRowsExpected',observerExpected,'observerMaxDataPoints',observerLimit, ...
        'observerRowCountMatchesExpected',observerRowCountMatches, ...
        'observerCurrentGroupCount',observerCurrentGroupCount, ...
        'observerMissingGroupIndices',observerMissingGroups, ...
        'observerDuplicateRows',observerDuplicateRows, ...
        'observerBoundaryRowCount',observerBoundaryRowCount, ...
        'observerBoundaryIdMatchesExpected',observerBoundaryIdMatches, ...
        'observerBoundaryDelta_s',observerBoundaryDelta_s, ...
        'observerBoundaryPeriodBitwiseEqual',observerBoundaryPeriodBitwiseEqual, ...
        'observerWindowComplete',observerWindowComplete, ...
        'fullSampleStatus','not_assessed', ...
        'statusScope','Observer window completeness and configured tracking counts only; not a full sample, D2, record, or state-handoff pass.', ...
        'reason','Configured counts and archived phase-execution counts are reported separately; D2, record, and handoff evidence remain independent.');
end

function [n,ids,boundaryIds,outside,expected,limit,matches,windowComplete,currentGroupCount,missingGroups,duplicateRows,boundaryRowCount,boundaryIdMatches,boundaryDelta,boundaryPeriodEqual]=observer_row_summary(observer,id,groups,C,P)
    n=0;ids=zeros(0,1);boundaryIds=zeros(0,1);outside=0;
    expected=C.expected_selected_sample_rows;limit=C.max_data_points;matches=false;windowComplete=false;
    currentGroupCount=0;missingGroups=1:numel(groups);duplicateRows=0;boundaryRowCount=0;
    boundaryIdMatches=false;boundaryDelta=NaN;boundaryPeriodEqual=false;
    if ~observer.available||~isfield(observer,'decoded')||~isfield(observer.decoded,'context')|| ...
            ~isfield(observer.decoded.context,'values')||~istable(observer.decoded.context.values)
        return;
    end
    T=observer.decoded.context.values;n=height(T);
    if any(strcmp(T.Properties.VariableNames,'cycle_index')),cycle=double(T.cycle_index);else,return;end
    if any(strcmp(T.Properties.VariableNames,'group_index')),g=double(T.group_index);else,return;end
    if any(strcmp(T.Properties.VariableNames,'outerSimulationTime_s')),tm=double(T.outerSimulationTime_s);else,tm=nan(n,1);end
    ids=unique(cycle,'stable');ids=ids(:);
    cnvGroup=false(numel(groups),1);for k=1:numel(groups),cnvGroup(k)=any(strcmp(event_types(groups(k).events),'cnv'));end
    isCnv=false(n,1);for k=1:n,if isfinite(g(k))&&g(k)>=1&&g(k)<=numel(groups),isCnv(k)=cnvGroup(g(k));end,end
    current=find(cycle==id&isCnv&isfinite(tm),1,'first');
    nextRows=[];if ~isempty(current)
        q=find(cycle>id&isCnv&isfinite(tm)&tm>tm(current));
        if ~isempty(q),[~,m]=min(tm(q));nextRows=q(m);end
    end
    if ~isempty(nextRows)
        boundaryId=cycle(nextRows);boundaryGroup=g(nextRows);boundaryTime=tm(nextRows);
        boundaryRows=find(cycle==boundaryId&g==boundaryGroup&tm==boundaryTime);
        boundaryIds=unique(cycle(boundaryRows),'stable');
        boundaryIdMatches=isscalar(boundaryIds)&&boundaryIds==id+1;
        if ~isempty(current),boundaryDelta=boundaryTime-tm(current);boundaryPeriodEqual=bitwise_equal(boundaryDelta,double(P.Ts_s));end
    else
        boundaryRows=[];
    end
    inWindow=cycle==id;inWindow(boundaryRows)=true;outside=nnz(~inWindow);
    matches=(n==expected);
    observedGroups=unique(g(cycle==id&isfinite(g)),'stable');
    currentGroupCount=numel(observedGroups);missingGroups=setdiff(1:numel(groups),observedGroups(:).');
    duplicateRows=max(0,nnz(cycle==id)-currentGroupCount);
    boundaryRowCount=numel(boundaryRows);
    complete=matches&&n<=limit&&outside==0&&isempty(missingGroups)&&duplicateRows==0&& ...
        boundaryRowCount==1&&boundaryIdMatches&&boundaryPeriodEqual;
    if isfield(observer.decoded,'completeness')&&isstruct(observer.decoded.completeness)&& ...
            isfield(observer.decoded.completeness,'isComplete')
        complete=complete&&logical(observer.decoded.completeness.isComplete);
    end
    if ~isfield(observer,'contract')||~isstruct(observer.contract)|| ...
            ~isfield(observer.contract,'complete')||~logical(observer.contract.complete)
        complete=false;
    end
    windowComplete=complete;
end

function K=read_observer_contract(path,L,C,R)
    K=struct('present',false,'status','not_recorded','logStatus','not_recorded', ...
        'reason','observer_contract.json is absent; observer contract was not recorded.', ...
        'compatible',NaN,'complete',false,'registryShaExpected','','registryShaActual','', ...
        'registryShaMatched',NaN,'registrySchemaVersion','','loggerClass','','loggerVariable',C.logger_name, ...
        'bundleWidth',NaN,'observedWidth',size(L.values,2),'expectedRows',C.expected_selected_sample_rows, ...
        'observedRows',numel(L.time));
    if ~isfile(path),return;end
    K.present=true;
    try
        q=jsondecode(fileread(path));
    catch cause
        K.status='unsupported_invalid_contract_json';K.logStatus=K.status;
        K.compatible=false;K.reason=['observer_contract.json could not be decoded: ' cause.message];return;
    end
    if isfield(q,'log_status'),K.logStatus=char(string(q.log_status));end
    if isfield(q,'reason'),K.reason=char(string(q.reason));end
    if isfield(q,'logger_variable'),K.loggerVariable=char(string(q.logger_variable));end
    if isfield(q,'logger_class'),K.loggerClass=char(string(q.logger_class));end
    if isfield(q,'bundle_width'),K.bundleWidth=double(q.bundle_width);end
    if isfield(q,'observed_width'),K.observedWidth=double(q.observed_width);end
    if isfield(q,'observed_rows'),K.observedRows=double(q.observed_rows);end
    if isfield(q,'registry_source_sha'),K.registryShaExpected=lower(char(string(q.registry_source_sha)));end
    if isfield(q,'registry_schema_version'),K.registrySchemaVersion=char(string(q.registry_schema_version));end
    registryPath=which('sar20_debug_fields');
    if ~isempty(registryPath)
        K.registryShaActual=sha256_file(registryPath);
        if ~isempty(K.registryShaExpected)&&~strcmp(K.registryShaExpected,'unknown')&&~isempty(K.registryShaActual)
            K.registryShaMatched=double(strcmpi(K.registryShaExpected,K.registryShaActual));
        end
    end
    qBundleMatches=isfield(q,'bundle')&&isstruct(q.bundle)&&isequaln(q.bundle,R.bundle);
    rowsMatch=K.observedRows==numel(L.time);
    widthMatch=K.observedWidth==size(L.values,2)&&K.bundleWidth==C.width&&size(L.values,2)==C.width;
    loggerMatch=strcmp(K.loggerVariable,C.logger_name)&&strcmp(K.loggerClass,'timeseries')&&L.present;
    hashMatch=(K.registryShaMatched==1);
    schemaMatch=isfield(R,'schema')&&strcmp(K.registrySchemaVersion,char(string(R.schema)));
    if ~loggerMatch
        K.status='unsupported_logger_identity';K.compatible=false;
        K.reason='observer_contract logger name/class does not match the saved SimulationOutput Timeseries.';
    elseif ~widthMatch
        K.status='unsupported_width_mismatch';K.compatible=false;
        K.reason='observer_contract width does not match the actual observer_log and registry bundle width.';
    elseif ~rowsMatch
        K.status='unsupported_row_count_mismatch';K.compatible=false;
        K.reason='observer_contract row count does not match the saved SimulationOutput Timeseries rows.';
    elseif ~qBundleMatches
        K.status='unsupported_bundle_contract_mismatch';K.compatible=false;
        K.reason='Archived R.bundle differs from the active field registry bundle.';
    elseif ~hashMatch
        K.status='unsupported_registry_hash_mismatch';K.compatible=false;
        K.reason='observer_contract registry source hash does not match the active sar20_debug_fields.m bytes.';
    elseif ~schemaMatch
        K.status='unsupported_registry_schema_mismatch';K.compatible=false;
        K.reason='observer_contract registry schema version does not match the active field registry.';
    elseif ~strcmp(K.logStatus,'logged')
        K.status=K.logStatus;K.compatible=false;
        if isempty(K.reason),K.reason='observer_contract log_status is not logged.';end
    else
        K.status='verified_logged';K.compatible=true;K.complete=(K.observedRows==C.expected_selected_sample_rows && K.observedRows<=C.max_data_points);
        K.reason='Archived logger class, row/width metadata, bundle contract and registry SHA agree.';
    end
end

function h=sha256_file(path)
    h='';if isempty(path)||~isfile(path),return;end
    d=dir(path);if d.bytes>300*1024*1024,return;end
    fid=fopen(path,'rb');if fid<0,return;end
    cleanup=onCleanup(@()fclose(fid));bytes=fread(fid,Inf,'*uint8'); %#ok<NASGU>
    try
        md=java.security.MessageDigest.getInstance('SHA-256');
        md.update(typecast(bytes(:),'int8'));
        digest=typecast(md.digest(),'uint8');h=lower(reshape(dec2hex(digest,2).',1,[]));
    catch
        h='';
    end
end

function C=observer_bundle_contract(R)
    if ~isstruct(R)||~isfield(R,'bundle')||~isstruct(R.bundle)||~isscalar(R.bundle)|| ...
            ~all(isfield(R.bundle,{'logger_name','width','max_data_points','expected_selected_sample_rows'}))
        error('sar20DebugSample:registry','sar20_debug_fields lacks the observer bundle contract.');
    end
    C=struct('logger_name',char(R.bundle.logger_name), ...
        'width',double(R.bundle.width), ...
        'max_data_points',double(R.bundle.max_data_points), ...
        'expected_selected_sample_rows',double(R.bundle.expected_selected_sample_rows));
end

function [actual,unknown]=count_actual(mask,phaseExecuted,expected)
    x=phaseExecuted(mask);knownTrue=nnz(x==1);knownFalse=nnz(x==0);
    unknown=max(0,expected-knownTrue-knownFalse);
    if unknown>0,actual=NaN;else,actual=knownTrue;end
end

function C=handoff_counts(H)
    C=struct('matched',0,'unmatched',0,'initialization',0,'inactive',0,'missing',0,'unknown',0);
    if isempty(H)||~istable(H)||~any(strcmp(H.Properties.VariableNames,'boundaryClass'))
        C.unknown=NaN;return;
    end
    b=string(H.boundaryClass);
    C.matched=nnz(b=='matched');C.unmatched=nnz(b=='unmatched');
    C.initialization=nnz(b=='initialization');C.inactive=nnz(b=='inactive_hold');
    C.missing=nnz(b=='missing_tap');C.unknown=nnz(b=='unknown');
end

function R=classify_run(R,P,observer)
    sha=char(R.modelSHA256);
    R.baseline_family='other_model_family';
    if startsWith(lower(sha),'91973cf76507'),R.baseline_family='default9197_model_family';end
    R.history_class='historical_archive';
    if observer.available,R.observation_class='observer_stage_trace';
    else,R.observation_class='legacy_logs_only';end
    R.identityBinding='summary.json identity copied; simout.mat and parameters.mat are not independently hash-bound by this read-only viewer.';
    if isempty(sha),R.support_class='unsupported_identity_unverified';
    elseif strcmp(R.baseline_family,'default9197_model_family'),R.support_class='baseline_family_candidate';
    else,R.support_class='other_family_explicit_archive';end
    R.savedN=NaN;if isfield(P,'N'),R.savedN=double(P.N);end
    R.savedSampleRateHz=NaN;if isfield(P,'fs_hz'),R.savedSampleRateHz=double(P.fs_hz);end
end
