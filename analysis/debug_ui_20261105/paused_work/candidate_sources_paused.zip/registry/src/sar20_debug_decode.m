function D = sar20_debug_decode(group,rows,meta)
%SAR20_DEBUG_DECODE Name packed SAR20 vectors and unpack the sample observer.
%Version: v1 (2026-11-05). Reads saved real-double logs only; no model/RNG/I/O.
%   D=sar20_debug_decode(group,rows,meta) accepts a registered N-by-width group
%   or the complete 6329-column observer_log row bundle. All component
%   columns are named from sar20_debug_fields; raw source words remain unchanged.
%Missing rows/fields remain NaN and carry a reason. No interpolation or zero fill.
    if nargin<3,meta=[];end
    assert((ischar(group)&&isrow(group))||(isstring(group)&&isscalar(group)), ...
        'sar20Debug:group','group must be a registered group or observer schema name.');
    assert(isnumeric(rows)&&isa(rows,'double')&&isreal(rows), ...
        'sar20Debug:dataType','Source data must be real double so exact stored values are preserved.');
    if any(isinf(rows(:)))
        error('sar20Debug:infinite','Infinite logger values are malformed; NaN is reserved for unrecorded values.');
    end
    R=sar20_debug_fields();
    group=char(group);
    canonical=canonical_group(group,R);
    if ~isempty(canonical)
        D=decode_group(R,canonical,rows,meta);
    elseif strcmpi(group,R.bundle.logger_name)
        D=decode_observer_bundle(R,rows,meta);
    else
        error('sar20Debug:unknownGroup','Unknown debug group/schema: %s.',group);
    end
end

function D=decode_group(R,group,rows,meta)
    F=R.fields(strcmp({R.fields.group},group));
    assert(~isempty(F),'sar20Debug:registry','Registry has no group %s.',group);
    w=max([F.index]);
    absent=isempty(rows);
    if absent
        n=meta_height(meta);
        if n==0,n=1;if istable(meta),meta=[];end;end
        rows=nan(n,w);
    else
        if isvector(rows)&&numel(rows)==w
            rows=reshape(rows,1,w);
        end
        assert(size(rows,2)==w,'sar20Debug:width','%s requires N x %d, got N x %d.',group,w,size(rows,2));
    end
    n=size(rows,1);
    M=normalize_meta(meta,n);
    presentName='decoded_tap_recorded';
    reasonName='decoded_reason';
    if absent
        present=false(n,1);
        why=repmat("No source row was supplied for group " + string(group) + ".",n,1);
    elseif hasvar(M,presentName)
        column=M.(presentName);
        present=logical(column(:));
        assert(numel(present)==n,'sar20Debug:metaRows','decoded_tap_recorded must have one value per source row.');
        why=reason_for_rows(M,n,"Tap was explicitly marked unrecorded.");
    else
        present=any(isfinite(rows),2);
        why=reason_for_rows(M,n,"All source fields are NaN; the logger did not record this group.");
    end
    assert(all(present | all(isnan(rows),2)), ...
        'sar20Debug:unrecordedValues','An unrecorded row must contain NaN only; finite values would be a false observation.');
    assert(all(~present | any(isfinite(rows),2)), ...
        'sar20Debug:emptyRecordedRow','A row marked recorded cannot contain only NaN values.');
    rows(~present,:)=NaN;
    M=add_column(M,'decoded_row_index',(1:n).');
    if ~hasvar(M,'decoded_source_tap'),M=add_column(M,'decoded_source_tap',repmat("unspecified",n,1));end
    if ~hasvar(M,'decoded_stage'),M=add_column(M,'decoded_stage',repmat("unspecified",n,1));end
    if hasvar(M,presentName)
        M.(presentName)=present;
    else
        M=add_column(M,presentName,present);
    end
    if absent
        if hasvar(M,reasonName)
            M.(reasonName)=why;
        else
            M=add_column(M,reasonName,why);
        end
    elseif ~hasvar(M,reasonName)
        M=add_column(M,reasonName,why);
    else
        column=M.(reasonName);q=string(column(:));blank=ismissing(q)|strlength(q)==0;
        q(blank)=why(blank);M.(reasonName)=q;
    end
    values=array2table(rows,'VariableNames',{F.signal});
    column=M.(reasonName);missing=missing_table(F,rows,present,string(column(:)));
    D=struct('schema','sar20-debug-decoded/v1','group',group, ...
        'values',values,'raw',rows,'meta',M,'fields',F,'missing',missing);
end

function D=decode_observer_bundle(R,rows,meta)
    absent=isempty(rows);
    sourceRowCount=0;
    if absent
        n=meta_height(meta);
        if n==0,n=1;if istable(meta),meta=[];end;end
        rows=nan(n,R.bundle_width);
    else
        if isvector(rows)
            assert(numel(rows)==R.bundle_width,'sar20Debug:bundleWidth', ...
                'observer_log requires %d words, got %d.',R.bundle_width,numel(rows));
            rows=reshape(rows,1,R.bundle_width);
        end
        assert(size(rows,2)==R.bundle_width,'sar20Debug:bundleWidth', ...
            'observer_log requires N x %d, got N x %d.',R.bundle_width,size(rows,2));
        sourceRowCount=size(rows,1);
    end
    n=size(rows,1);
    expected=R.bundle.expected_selected_sample_rows;
    rowCap=R.bundle.max_data_points;
    outer=normalize_meta(meta,n);
    outer=add_if_missing(outer,'decoded_outer_row',(1:n).');
    eventRange=find(strcmp({R.bundle.sections.section},'EventTime3'),1);
    eventSection=R.bundle.sections(eventRange);
    eventWords=rows(:,eventSection.index:(eventSection.index+eventSection.width-1));
    tagRowsOK=false(n,1);
    if ~absent&&size(eventWords,2)==3,tagRowsOK=all(isfinite(eventWords),2);end
    outerTimeAvailable=hasvar(outer,'outerSimulationTime_s')&& ...
        numel(outer.outerSimulationTime_s)==n&&all(isfinite(double(outer.outerSimulationTime_s(:))));
    rowCountOK=~absent&&sourceRowCount==expected;
    capOK=sourceRowCount<=rowCap;
    isComplete=rowCountOK&&capOK&&all(tagRowsOK)&&outerTimeAvailable;
    issues={};
    if absent,issues{end+1}='observer_log is absent';end %#ok<AGROW>
    if ~rowCountOK,issues{end+1}=sprintf('expected %d selected-window rows, received %d',expected,sourceRowCount);end %#ok<AGROW>
    if ~capOK,issues{end+1}=sprintf('source has %d rows above MaxDataPoints=%d',sourceRowCount,rowCap);end %#ok<AGROW>
    if ~all(tagRowsOK),issues{end+1}='one or more EventTime3 tags/time words are missing';end %#ok<AGROW>
    if ~outerTimeAvailable,issues{end+1}='actual timeseries.Time was not supplied or contains missing values';end %#ok<AGROW>
    completenessReason="";
    if ~isempty(issues),completenessReason=string(strjoin(issues,'; '));end
    D=struct('schema','sar20-debug-observer/v1','bundle_schema',R.bundle.schema, ...
        'bundle_width',R.bundle_width,'registry',R,'sections',struct(), ...
        'section_meta',struct(),'taps',struct(),'events',struct(), ...
        'trace_headers',struct(),'trace_header_meta',struct(), ...
        'context',[],'time_check',table(),'meta',outer,'source_meta',outer, ...
        'raw',rows,'source_row_count',sourceRowCount, ...
        'completeness',struct('isComplete',isComplete,'reason',completenessReason, ...
        'source_row_count',sourceRowCount,'expected_selected_sample_rows',expected, ...
        'max_data_points',rowCap,'row_count_ok',rowCountOK,'cap_ok',capOK, ...
        'event_time_tags_ok',all(tagRowsOK),'outer_time_available',outerTimeAvailable));
    for k=1:numel(R.bundle.sections)
        b=R.bundle.sections(k);
        raw=rows(:,b.index:(b.index+b.width-1));
        D.sections.(b.section)=raw;
        sectionPresent=~absent & any(isfinite(raw),2);
        sectionReason=repmat("",n,1);
        sectionReason(~sectionPresent)="Bundle section missing; source values remain NaN.";
        if absent,sectionReason(:)="Entire observer bundle was not recorded.";end
        sectionMeta=add_column(outer,'decoded_bundle_section',repmat(string(b.section),n,1));
        sectionMeta=add_column(sectionMeta,'decoded_bundle_start',repmat(b.index,n,1));
        sectionMeta=add_column(sectionMeta,'decoded_bundle_width',repmat(b.width,n,1));
        sectionMeta=add_column(sectionMeta,'bundle_present',sectionPresent);
        sectionMeta=add_column(sectionMeta,'bundle_reason',sectionReason);
        D.section_meta.(b.section)=with_tap_meta(sectionMeta,b.section,b.update_stage,sectionPresent,sectionReason);
        switch b.group
            case 'FETrace1079'
                [taps,H]=decode_fe_trace(R,b.section,raw,sectionMeta);
                D.taps=merge_struct(D.taps,taps);
                D.trace_headers.(b.section)=H.values;
                D.trace_header_meta.(b.section)=H.meta;
                D.events.(b.section)=fe_event_rows(b.section,H,R.enums);
            case 'BackendTrace164'
                [taps,H]=decode_backend_trace(R,b.section,raw,sectionMeta);
                D.taps=merge_struct(D.taps,taps);
                D.trace_headers.(b.section)=H.values;
                D.trace_header_meta.(b.section)=H.meta;
                D.events.(b.section)=backend_event_rows(b.section,H,taps);
            case 'ControlTrace150'
                [events,taps,H,Hmeta]=decode_control_trace(R,b.section,raw,sectionMeta);
                D.events.(b.section)=events;
                D.taps=merge_struct(D.taps,taps);
                D.trace_headers.(b.section)=H;
                D.trace_header_meta.(b.section)=Hmeta;
            case {'FE353','RA48','SAR51'}
                switch b.group
                    case 'FE353',tap='FE_old';role='UD-old';
                    case 'RA48',tap='RA_old';role='UD-old';
                    otherwise,tap='SAR_old';role='UD-old';
                end
                if strcmp(b.section,'FEnext353'),tap='FE_next';role='UD-next';end
                if strcmp(b.section,'RAnext48'),tap='RA_next';role='UD-next';end
                if strcmp(b.section,'SARnext51'),tap='SAR_next';role='UD-next';end
                tm=with_tap_meta(sectionMeta,tap,role,sectionPresent,sectionReason);
                D.taps.(tap)=decode_group(R,b.group,raw,tm);
            case 'ObserverEventTime3'
                tm=with_tap_meta(sectionMeta,'EventTime3','outer-event-context',sectionPresent,sectionReason);
                D.context=decode_group(R,b.group,raw,tm);
            otherwise
                error('sar20Debug:bundleSchema','Unhandled registered bundle section %s (%s).',b.section,b.group);
        end
    end
    [D.context,D.time_check]=compare_outer_event_time(D.context,outer);
    if ~isempty(D.context)
        for k=1:numel(R.bundle.sections)
            section=R.bundle.sections(k).section;
            if isfield(D.events,section)
                D.events.(section)=attach_event_context(D.events.(section),D.context.values);
            end
            if isfield(D.section_meta,section)
                D.section_meta.(section)=attach_event_context(D.section_meta.(section),D.context.values);
            end
        end
        tapNames=fieldnames(D.taps);
        for k=1:numel(tapNames)
            tap=D.taps.(tapNames{k});
            tap.meta=attach_event_context(tap.meta,D.context.values);
            D.taps.(tapNames{k})=tap;
        end
    end
end

function [taps,H]=decode_fe_trace(R,section,raw,outer)
    headWidth=group_width(R,'FETraceHeader6');
    H=decode_group(R,'FETraceHeader6',raw(:,1:headWidth), ...
        trace_meta(outer,'header',section,raw(:,1:headWidth), ...
        'FE trace header absent at this scheduler event.'));
    h=H.values;
    widths=[group_width(R,'FE353'),group_width(R,'FE353'),group_width(R,'FE353'), ...
        group_width(R,'FrontendObs7'),group_width(R,'FrontendObs7')];
    names={'oldFE353','advancedFE353','after_commandFE353','advancedObs7','after_commandObs7'};
    groups={'FE353','FE353','FE353','FrontendObs7','FrontendObs7'};
    stages={'stage-input','advanced','local-after-command','advanced','local-after-command'};
    if strcmp(section,'FE_ChargeReturn'),stages{3}='UD-next-candidate';end
    taps=struct();pos=headWidth+1;
    for k=1:numel(widths)
        part=raw(:,pos:(pos+widths(k)-1));pos=pos+widths(k);
        tap=[section '_' names{k}];
        tm=outer;
        present=isfinite(h.valid)&h.valid==1&any(isfinite(part),2);
        reason=phase_reason(h.valid,part,names{k});
        tm=with_tap_meta(tm,tap,stages{k},present,reason);
        tm=add_trace_header(tm,h,'FE',R.enums);
        taps.(tap)=decode_group(R,groups{k},part,tm);
    end
    assert(pos==size(raw,2)+1,'sar20Debug:feTraceLayout','FE trace layout width mismatch.');
end

function E=fe_event_rows(section,H,enums)
    V=H.values;n=height(V);
    E=V;
    E.outer_row=H.meta.decoded_outer_row;
    E.stage_name=repmat(string(section),n,1);
    E.stage_called=isfinite(V.valid)&V.valid==1;
    E.event_name=context_event_names(V.kind_code,V.context_event,enums.frontend_context_event_code);
    E.sample_id=V.context_id;
    E.phase_ordinal=nan(n,1);
    E.phase_ordinal_reason=repmat("Not present in FE trace header; resolve exact original ordinal through saved P.groups and event order.",n,1);
    E.event_index=nan(n,1);
    E.event_index_reason=repmat("Not logged by FE trace; keep NaN until a unique original group event is matched.",n,1);
    E.event_bit=nan(n,1);
    E.event_bit_reason=repmat("Not logged by FE trace; keep NaN until a unique original group event is matched.",n,1);
end

function [taps,H]=decode_backend_trace(R,section,raw,outer)
    headWidth=group_width(R,'BackendTraceHeader4');
    H=decode_group(R,'BackendTraceHeader4',raw(:,1:headWidth), ...
        trace_meta(outer,'header',section,raw(:,1:headWidth), ...
        'Backend trace header absent at this scheduler event.'));
    h=H.values;
    widths=[group_width(R,'RA48'),group_width(R,'RA48'),group_width(R,'RA48'), ...
        group_width(R,'BackendObs8'),group_width(R,'BackendObs8')];
    names={'oldRA48','advancedRA48','after_commandRA48','predictedObs8','actualObs8'};
    groups={'RA48','RA48','RA48','BackendObs8','BackendObs8'};
    stages={'stage-input','advanced','local-after-command','predicted','local-after-command'};
    if strcmp(section,'BE_RaReset'),stages{3}='UD-next-candidate';end
    taps=struct();pos=headWidth+1;
    for k=1:numel(widths)
        part=raw(:,pos:(pos+widths(k)-1));pos=pos+widths(k);
        tap=[section '_' names{k}];
        tm=outer;
        present=isfinite(h.valid)&h.valid==1&any(isfinite(part),2);
        reason=phase_reason(h.valid,part,names{k});
        if k==2
            advancedOK=isfinite(h.advanced_valid)&h.advanced_valid==1;
            present=present&advancedOK;
            noInterval=isfinite(h.valid)&h.valid==1&isfinite(h.advanced_valid)&h.advanced_valid==0;
            reason(noInterval)="No separate interval advance occurred at this event; advanced state is not recorded.";
        end
        tm=with_tap_meta(tm,tap,stages{k},present,reason);
        tm=add_trace_header(tm,h,'Backend',R.enums);
        taps.(tap)=decode_group(R,groups{k},part,tm);
    end
    assert(pos==size(raw,2)+1,'sar20Debug:backendTraceLayout','Backend trace layout width mismatch.');
end

function E=backend_event_rows(section,H,taps)
    V=H.values;n=height(V);
    E=V;
    E.outer_row=H.meta.decoded_outer_row;
    E.stage_name=repmat(string(section),n,1);
    E.stage_called=isfinite(V.valid)&V.valid==1;
    E.event_name=repmat(string(section),n,1);
    E.phase_ordinal=nan(n,1);
    E.phase_ordinal_reason=repmat("Not present in backend trace header; resolve by saved P.groups and the source stage.",n,1);
    E.event_index=nan(n,1);
    E.event_index_reason=repmat("Not logged by backend trace; keep NaN until a unique original group event is matched.",n,1);
    E.event_bit=nan(n,1);
    E.event_bit_reason=repmat("Not logged by backend trace; keep NaN until a unique original group event is matched.",n,1);
    oldTap=[section '_oldRA48'];
    if isfield(taps,oldTap)
        state=taps.(oldTap).values;
        E.command_sample_id_at_stage_input=state.command_sample_id;
        E.command_epoch_at_stage_input=state.command_epoch;
    else
        E.command_sample_id_at_stage_input=nan(n,1);
        E.command_epoch_at_stage_input=nan(n,1);
    end
end

function [events,taps,H,Hmeta]=decode_control_trace(R,section,raw,outer)
    eventWidth=group_width(R,'ControlEvent24');stateWidth=group_width(R,'SAR51');
    slotWidth=eventWidth+stateWidth;
    slotCount=R.bundle.controller_event_slots;
    assert(size(raw,2)==slotCount*slotWidth,'sar20Debug:controlTraceLayout', ...
        'Control trace must contain %d original-order event slots.',slotCount);
    n=size(raw,1);eventRows=nan(slotCount*n,eventWidth);stateRows=nan(slotCount*n,stateWidth);
    for k=1:slotCount
        rowsK=k:slotCount:(slotCount*n);
        start=(k-1)*slotWidth;
        eventRows(rowsK,:)=raw(:,start+(1:eventWidth));
        stateRows(rowsK,:)=raw(:,start+eventWidth+(1:stateWidth));
    end
    recordValidIndex=field_index(R,'ControlEvent24','record_valid');
    ordinalIndex=field_index(R,'ControlEvent24','ordinal');
    eventCodeIndex=field_index(R,'ControlEvent24','event_code');
    recordValidWords=eventRows(:,recordValidIndex);
    assert(all(isnan(recordValidWords)|recordValidWords==1), ...
        'sar20Debug:recordSlotFlag','Control trace record_valid must be 1 for an event or NaN for an unused all-NaN slot.');
    repeated=repeat_rows(outer,slotCount);slot=repmat((1:slotCount).',n,1);
    eventMeta=with_tap_meta(repeated,[section '_event'],'local-after-command', ...
        isfinite(eventRows(:,recordValidIndex))&eventRows(:,recordValidIndex)==1, ...
        repmat("No controller event occupies this original-order slot.",slotCount*n,1));
    eventMeta=add_column(eventMeta,'decoded_slot',slot);
    eventMeta=add_column(eventMeta,'decoded_controller_stage',repmat(string(section),slotCount*n,1));
    E=decode_group(R,'ControlEvent24',eventRows,eventMeta);
    events=E.values;
    events.outer_row=repeated.decoded_outer_row;
    events.slot=slot;
    events.controller_stage=repmat(string(section),height(events),1);
    events.event_name=event_names(events.event_code,R.enums.controller_event_code);
    events.stage_name=stage_names(events.stage_code,R.enums.controller_stage_code);
    noCompare=isfinite(events.comparison_used)&events.comparison_used==0;
    compareFields={'sample_v','vres_v','vy_v','decision1','decision2','compare_valid', ...
        'compare_late','cmp_effective_v','cmp_offset_v','cmp_noise_v'};
    for k=1:numel(compareFields)
        q=events.(compareFields{k});
        assert(all(isnan(q(noCompare))), ...
            'sar20Debug:nonCompareValue','%s must remain NaN when comparison_used=0.',compareFields{k});
    end
    taps=struct();H=events;Hmeta=E.meta;
    for k=1:slotCount
        rowsK=stateRows(k:slotCount:end,:);
        eventPresent=isfinite(eventRows(k:slotCount:end,recordValidIndex))& ...
            eventRows(k:slotCount:end,recordValidIndex)==1;
        reason=repmat("Controller event slot has no state_after51 record.",n,1);
        reason(~eventPresent)="No executed controller event occupies this original-order slot.";
        tm=add_column(outer,'decoded_slot',repmat(k,n,1));
        tm=add_column(tm,'decoded_controller_stage',repmat(string(section),n,1));
        tm=add_column(tm,'decoded_event_ordinal',eventRows(k:slotCount:end,ordinalIndex));
        tm=add_column(tm,'decoded_event_code',eventRows(k:slotCount:end,eventCodeIndex));
        present=eventPresent&any(isfinite(rowsK),2);
        tm=with_tap_meta(tm,[section '_slot' num2str(k) '_after_SAR51'], ...
            'local-after-command',present,reason);
        tap=[section '_slot' num2str(k) '_after_SAR51'];
        taps.(tap)=decode_group(R,'SAR51',rowsK,tm);
    end
end

function index=field_index(R,group,signal)
    q=R.fields(strcmp({R.fields.group},group)&strcmp({R.fields.signal},signal));
    assert(isscalar(q),'sar20Debug:fieldIndex','Registry requires exactly one %s.%s.',group,signal);
    index=q.index;
end

function [D,C]=compare_outer_event_time(D,outer)
    C=table();
    if isempty(D),return;end
    V=D.values;
    n=height(V);outerTime=nan(n,1);
    if hasvar(outer,'outerSimulationTime_s')
        outerTime=double(outer.outerSimulationTime_s(:));
    end
    modelTime=V.modelEventTime_s(:);
    delta=nan(n,1);equal=nan(n,1);
    use=isfinite(outerTime)&isfinite(modelTime);
    delta(use)=modelTime(use)-outerTime(use);
    modelBits=typecast(modelTime(use),'uint64');
    outerBits=typecast(outerTime(use),'uint64');
    equal(use)=double(modelBits==outerBits);
    if hasvar(outer,'outerRow')
        originalOuterRow=outer.outerRow(:);
    elseif hasvar(outer,'outer_row')
        originalOuterRow=outer.outer_row(:);
    else
        originalOuterRow=(1:n).';
    end
    V.outerRow=originalOuterRow;
    V.outerSimulationTime_s=outerTime;
    V.modelEventTime_delta_s=delta;
    V.modelEventTime_bitwise_equal=equal;
    D.values=V;
    C=table(originalOuterRow,outerTime,modelTime,delta,equal, ...
        'VariableNames',{'outerRow','outerSimulationTime_s','modelEventTime_s', ...
        'delta_s_model_minus_outer','bitwise_equal'});
    if ~any(isfinite(outerTime))
        D.meta=add_column(D.meta,'decoded_time_check_reason', ...
            repmat("Caller did not supply the actual timeseries.Time/event_log.Time axis.",n,1));
    else
        D.meta=add_column(D.meta,'decoded_time_check_reason',repmat("",n,1));
    end
end

function E=attach_event_context(E,context)
    n=height(E);
    if hasvar(E,'outer_row')
        row=E.outer_row;
    elseif hasvar(E,'decoded_outer_row')
        row=E.decoded_outer_row;
    else
        return
    end
    for name={'outerRow','cycle_index','group_index','modelEventTime_s','outerSimulationTime_s', ...
            'modelEventTime_delta_s','modelEventTime_bitwise_equal'}
        field=name{1};
        if hasvar(context,field)
            source=context.(field);
            values=nan(n,1);
            valid=isfinite(row)&row==floor(row)&row>=1&row<=height(context);
            values(valid)=source(row(valid));
            if hasvar(E,field)
                old=E.(field);
                assert(isequaln(old(:),values(:)), ...
                    'sar20Debug:contextMismatch','Metadata %s conflicts with the aligned EventTime3 row.',field);
            else
                E=add_column(E,field,values);
            end
        end
    end
end

function M=trace_meta(outer,tap,section,part,missingText)
    present=any(isfinite(part),2);
    reason=repmat("",size(part,1),1);
    reason(~present)=string(missingText);
    M=with_tap_meta(outer,[section '_' tap],'unspecified',present,reason);
end

function M=with_tap_meta(M,tap,stage,present,reason)
    M=add_column(M,'decoded_source_tap',repmat(string(tap),height(M),1));
    M=add_column(M,'decoded_stage',repmat(string(stage),height(M),1));
    M=add_column(M,'decoded_tap_recorded',logical(present(:)));
    M=add_column(M,'decoded_reason',string(reason(:)));
end

function M=add_trace_header(M,H,prefix,enums)
    if strcmp(prefix,'FE')
        names={'valid','time_s','context_id','epoch','kind_code','context_event'};
        target={'valid','time_s','context_id','epoch','kind_code','context_event'};
    else
        names={'valid','eventTime_s','kind_code','advanced_valid'};
        target={'valid','eventTime_s','kind_code','advanced_valid'};
    end
    for k=1:numel(names)
        value=H.(names{k});
        M=add_column(M,['decoded_trace_' target{k}],value(:));
    end
    if strcmp(prefix,'FE')
        kind=M.decoded_trace_kind_code;
        event=M.decoded_trace_context_event;
        M=add_column(M,'decoded_trace_context_event_name',context_event_names(kind,event,enums.frontend_context_event_code));
    end
    M=add_column(M,'decoded_trace_kind_name',enum_names(M.decoded_trace_kind_code,enums.stage_kind_code));
end

function M=normalize_meta(meta,n)
    if isempty(meta)
        M=table();
        return
    end
    if istable(meta)
        assert(height(meta)==n,'sar20Debug:metaRows','Metadata table must have one row per source vector.');
        M=meta;return
    end
    if isstruct(meta)
        if numel(meta)>1
            assert(numel(meta)==n,'sar20Debug:metaRows','Metadata struct array must have one entry per source vector.');
            M=struct2table(meta);return
        end
        assert(isscalar(meta),'sar20Debug:meta','Metadata must be a scalar struct or row-aligned table.');
        names=fieldnames(meta);M=table();
        for k=1:numel(names)
            value=meta.(names{k});
            if ischar(value)&&isrow(value)
                value=repmat(string(value),n,1);
            elseif isstring(value)&&isscalar(value)
                value=repmat(value,n,1);
            elseif (isnumeric(value)||islogical(value))&&isscalar(value)
                value=repmat(value,n,1);
            elseif iscell(value)&&numel(value)==n
                value=value(:);
            elseif numel(value)==n
                value=reshape(value,n,1);
            else
                error('sar20Debug:metaShape','Metadata field %s cannot align to %d source rows.',names{k},n);
            end
            M.(names{k})=value;
        end
        return
    end
    error('sar20Debug:meta','meta must be a table, struct, or empty.');
end

function n=meta_height(meta)
    if istable(meta),n=height(meta);
    elseif isstruct(meta)&&~isempty(meta),n=max([numel(meta),struct_field_length(meta)]);
    else,n=0;end
end

function n=struct_field_length(meta)
    n=0;f=fieldnames(meta);
    for k=1:numel(f),n=max(n,numel(meta.(f{k})));end
end

function M=repeat_rows(M,repeats)
    if height(M)==0,return;end
    M=M(repelem((1:height(M)).',repeats),:);
end

function M=add_column(M,name,value)
    assert(~hasvar(M,name),'sar20Debug:metaCollision','Metadata collides with decoder field %s.',name);
    M.(name)=value(:);
end

function yes=hasvar(T,name)
    yes=any(strcmp(T.Properties.VariableNames,name));
end

function why=reason_for_rows(M,n,fallback)
    if hasvar(M,'reason'),why=string(M.reason(:));
    else,why=repmat(string(fallback),n,1);end
    assert(numel(why)==n,'sar20Debug:metaRows','reason must have one entry per source row.');
    blank=ismissing(why)|strlength(why)==0;why(blank)=string(fallback);
end

function T=missing_table(F,rows,present,reason)
    rowOut=[];nameOut=strings(0,1);indexOut=[];reasonOut=strings(0,1);
    for r=1:size(rows,1)
        if ~present(r)
            rowOut(end+1,1)=r;nameOut(end+1,1)="*";indexOut(end+1,1)=NaN;
            text=string(reason(r));if ismissing(text)||strlength(text)==0,text="Group row was not recorded.";end
            reasonOut(end+1,1)=text;
        else
            miss=find(isnan(rows(r,:)));
            for j=miss
                rowOut(end+1,1)=r;nameOut(end+1,1)=string(F(j).signal);indexOut(end+1,1)=F(j).index;
                reasonOut(end+1,1)="Source value is NaN; applicability: "+string(F(j).validity);
            end
        end
    end
    T=table(rowOut,nameOut,indexOut,reasonOut,'VariableNames',{'row','signal','index','reason'});
end

function M=add_if_missing(M,name,value)
    if ~hasvar(M,name),M=add_column(M,name,value);end
end

function w=group_width(R,group)
    q=R.fields(strcmp({R.fields.group},group));
    assert(~isempty(q)&&isequal([q.index],1:numel(q)), ...
        'sar20Debug:registryWidth','Missing or incomplete registry group %s.',group);
    w=numel(q);
end

function g=canonical_group(group,R)
    alias=find(strcmpi(group,{R.log_aliases.logger_name}),1);
    if ~isempty(alias)
        g=R.log_aliases(alias).group;return
    end
    known=unique({R.fields.group});
    g='';
    display=find(strcmpi(group,{R.display_aliases.label}),1);
    if isempty(display)
        display=find(strcmpi(group,{R.display_aliases.legacy_name}),1);
    end
    if ~isempty(display),g=R.display_aliases(display).group;return;end
    ix=find(strcmpi(group,known),1);
    if ~isempty(ix),g=known{ix};end
end

function why=phase_reason(headerValid,part,tap)
    n=size(part,1);why=repmat("",n,1);
    outside=~(isfinite(headerValid)&headerValid==1);
    why(outside)="Stage logger has no valid row for this scheduler event.";
    absent=~outside&~any(isfinite(part),2);
    if contains(tap,'after_command')
        why(absent)="No command/input_change produced this after-command tap; values remain unrecorded.";
    else
        why(absent)="Stage header is valid but this source tap is all NaN; value is not recorded.";
    end
end

function names=event_names(code,E)
    names=enum_names(code,E);
end

function names=stage_names(code,E)
    names=enum_names(code,E);
end

function names=enum_names(code,E)
    names=repmat("",numel(code),1);
    for k=1:numel(E)
        mask=isfinite(code)&code==E(k).code;
        names(mask)=string(E(k).label);
    end
end

function names=context_event_names(kind,code,E)
    names=repmat("",numel(code),1);
    for k=1:numel(code)
        if ~isfinite(kind(k))||~isfinite(code(k)),continue;end
        ix=find([E.kind_code]==kind(k)&[E.context_code]==code(k),1);
        if ~isempty(ix),names(k)=string(E(ix).label);end
        end
    end
end

function S=merge_struct(S,T)
    f=fieldnames(T);
    for k=1:numel(f)
        assert(~isfield(S,f{k}),'sar20Debug:tapCollision','Duplicate tap %s.',f{k});
        S.(f{k})=T.(f{k});
    end
end
