function R = sar20_debug_fields()
%SAR20_DEBUG_FIELDS Single source registry for SAR20 packed vectors and traces.
%Version: v1 (2026-11-05). Read-only metadata; no model access, state change, or RNG.
%Output R.fields is a struct array with group,signal,index,width,unit,
%        voltage_reference,meaning,owner,validity,update_stage,source.
%        index is 1-based within group; R.bundle maps the outer trace vector.
%Primary groups: FE353,RA48,SAR51,RAW6,Control13,BackendObs8,FrontendObs7.
%Trace headers/event slots are included so trace offsets and legends stay auditable.
    F = repmat(struct( ...
        'group','','signal','','index',0,'width',1,'unit','','voltage_reference','', ...
        'meaning','','owner','','validity','','update_stage','','source',''),0,1);

    % FE353: external UnitDelay owner SampleCharge.
    fePack='current/src/frontend/behavior_frontend_pack.m:11-23; current/src/frontend/behavior_frontend_unpack.m:13-24';
    feState='current/src/frontend/behavior_frontend_init.m:5-7,113-120; current/src/frontend/behavior_frontend_step.m';
    F=one(F,'FE353','time_s',1,'s','not a voltage','Last FE event time in the model execution timeline.','SampleCharge','Initialized state; has_time=1 marks that an event time has been accepted.','Each FE advance/command; packed output is a UnitDelay-next candidate.',[fePack '; ' feState]);
    F=one(F,'FE353','has_time',2,'flag','not applicable','Whether the FE owner has accepted an event time.','SampleCharge','0 only at cold initialization; 1 after first FE event.','Set by first event; retained until model reinitialization.',[fePack '; ' feState]);
    F=one(F,'FE353','input_offset_v',3,'V','P.input differential source contract; terminal Vp/Vn mapping and common mode are not separately represented','Differential input waveform DC offset.','SampleCharge','Valid while the saved input descriptor is initialized.','Changed only by input_change after advancing the old source.','config/adc_parameters.m:72-76; current/src/frontend/behavior_frontend_init.m:21,102; current/src/frontend/behavior_frontend_step.m:259-261');
    F=one(F,'FE353','input_amplitude_v',4,'V','P.input differential source contract; terminal Vp/Vn mapping and common mode are not separately represented','Differential input waveform sine amplitude.','SampleCharge','Valid while the saved input descriptor is initialized.','Changed only by input_change after advancing the old source.','config/adc_parameters.m:72-76; current/src/frontend/behavior_frontend_init.m:21,102; current/src/frontend/behavior_frontend_step.m:259-261');
    F=one(F,'FE353','input_frequency_hz',5,'Hz','not a voltage','Input waveform frequency.','SampleCharge','Valid while the saved input descriptor is initialized.','Changed only by input_change after advancing the old source.',[fePack '; ' feState]);
    F=one(F,'FE353','input_phase_rad',6,'rad','not a voltage','Input waveform phase.','SampleCharge','Valid while the saved input descriptor is initialized.','Changed only by input_change after advancing the old source.',[fePack '; ' feState]);
    F=range(F,'FE353','phase',7,18,'enum','not applicable','Per numerical segment phase: 0=park, 1=acquire, 2=convert, 3=captured. Segment index is the numeric slice, not a separate converter.','SampleCharge','Present in the state vector; interpret only using the documented phase code.','acquire_open/capture/convert_join/release/reset.',[fePack '; ' feState]);
    F=range(F,'FE353','B_c_signal_charge_C',25,18,'C','not a voltage','Stored C*bottom-voltage sum for the signal capacitor group of this numerical segment.','SampleCharge','Analog state; single-bank disconnected bias handling does not affect this signal group.','Analytic advance; capture, DAC commit, release, and reset have event-specific effects.',[fePack '; ' feState]);
    F=range(F,'FE353','B_c_tail_charge_C',43,18,'C','not a voltage','Stored C*bottom-voltage sum for the tail capacitor group of this numerical segment.','SampleCharge','Analog state; retained on runtime reset.','Analytic advance; acquire/precharge, DAC commit, and release have event-specific effects.',[fePack '; ' feState]);
    F=range(F,'FE353','B_c_bias_charge_C',61,18,'C','not a voltage','Stored C*bottom-voltage sum for the bias capacitor group of this numerical segment.','SampleCharge','May be zero for the disconnected single-bank bias group.','Analytic advance; acquire/precharge, DAC commit, and release have event-specific effects.',[fePack '; ' feState]);
    F=range(F,'FE353','B_target_signal_charge_C',79,18,'C','not a voltage','Target C*bottom-voltage sum for signal group of this numerical segment.','SampleCharge','State target; it is not the instantaneous stored charge B_c.','Set by acquire_open, convert_join, DAC commit, and release.',[fePack '; ' feState]);
    F=range(F,'FE353','B_target_tail_charge_C',97,18,'C','not a voltage','Target C*bottom-voltage sum for tail group of this numerical segment.','SampleCharge','State target; it is not the instantaneous stored charge B_c.','Set by acquire_open, convert_join, DAC commit, and release.',[fePack '; ' feState]);
    F=range(F,'FE353','B_target_bias_charge_C',115,18,'C','not a voltage','Target C*bottom-voltage sum for bias group of this numerical segment.','SampleCharge','State target; it is not the instantaneous stored charge B_c.','Set by acquire_open, convert_join, DAC commit, and release.',[fePack '; ' feState]);
    F=range(F,'FE353','q_initial_C',133,18,'C','not a voltage','Per-segment total charge captured at capture; used with current B_c to form Qres.','SampleCharge','Valid only when capture_valid for the same segment is 1.','Written by capture; retained until a later capture.',[fePack '; ' feState]);
    F=range(F,'FE353','v_capture_v',151,18,'V','P.input differential behavioral reference; terminal Vp/Vn and common mode are not separately represented','Per-segment captured differential input-equivalent voltage derived from signal charge divided by signal capacitance.','SampleCharge','Valid only when capture_valid for the same segment is 1.','Written by capture; retained until a later capture.','config/adc_parameters.m:72-76; current/src/frontend/behavior_frontend_step.m:79-84,112-115');
    F=range(F,'FE353','target_id',169,18,'sample ID','not applicable','Sample ID that owns the segment acquisition target; -1 means no target tag.','SampleCharge','Interpret with phase and target_epoch; -1 is the explicit no-owner tag.','Written by acquire_open; cleared by runtime reset.',[fePack '; ' feState]);
    F=range(F,'FE353','target_epoch',187,18,'epoch','not applicable','Epoch tag for target_id.','SampleCharge','Interpret with target_id; -1 is the explicit no-owner tag.','Written by acquire_open; cleared by runtime reset.',[fePack '; ' feState]);
    F=range(F,'FE353','capture_id',205,18,'sample ID','not applicable','Sample ID attached to the captured charge.','SampleCharge','Valid only when capture_valid=1.','Written by capture; capture_valid is cleared by release/reset.',[fePack '; ' feState]);
    F=range(F,'FE353','capture_epoch',223,18,'epoch','not applicable','Epoch attached to the captured charge.','SampleCharge','Valid only when capture_valid=1.','Written by capture; capture_valid is cleared by release/reset.',[fePack '; ' feState]);
    F=range(F,'FE353','capture_valid',241,18,'flag','not applicable','Whether captured charge tags currently own this numerical segment.','SampleCharge','0 means captured-charge fields must be treated as not valid.','Set on capture; cleared on acquire_open/release/reset.',[fePack '; ' feState]);
    F=range(F,'FE353','aperture_s',259,18,'s','not a voltage','Nominal capture command time for the numerical segment.','SampleCharge','Valid only when capture_valid=1; not the displaced aperture when jitter is enabled.','Written by capture.',[fePack '; ' feState]);
    F=one(F,'FE353','active_id',277,'sample ID','not applicable','Currently active conversion sample ID.','SampleCharge','Valid while the FE conversion owner is active; -1 denotes no active conversion.','Set by convert_join; cleared by release/reset.',[fePack '; ' feState]);
    F=one(F,'FE353','active_epoch',278,'epoch','not applicable','Epoch attached to the active conversion.','SampleCharge','Valid with active_id; -1 denotes no active conversion.','Set by convert_join; cleared by release/reset.',[fePack '; ' feState]);
    F=one(F,'FE353','d1_code',279,'code','not applicable','Most recently applied registered D1 command, integer 0..2047.','SampleCharge','Meaningful for the active conversion only after has_dac_command=1.','Written by dac_commit.',[fePack '; ' feState]);
    F=one(F,'FE353','has_dac_command',280,'flag','not applicable','Whether an explicit D1 DAC command has been applied for the active conversion.','SampleCharge','0 means d1_code is not an applied command for the current conversion.','Cleared by convert_join/release/reset; set by dac_commit.',[fePack '; ' feState]);
    F=one(F,'FE353','event_count',281,'count','not applicable','Count of FE step commands applied to this owner.','SampleCharge','Valid after initialization; this is not a SAR event counter.','Incremented once per behavior_frontend_step call.',[fePack '; ' feState]);
    F=range(F,'FE353','dem_shift',282,18,'code','not applicable','Per-segment deterministic DEM rotation shift used by the latest applied D1 command.','SampleCharge','Meaningful after a DAC command; no random draw is performed.','Written by dac_commit.',[fePack '; ' feState]);
    F=range(F,'FE353','dither_input_v',300,18,'V','FE tail/source equivalent in the differential charge model; terminal/common-mode mapping is not represented','Stored per-segment deterministic dither input associated with acquisition.','SampleCharge','Valid for a tagged acquisition; value is deterministic from saved seed and sample ID.','Written by acquire_open; not generated by the decoder.',[fePack '; ' feState]);
    F=range(F,'FE353','actual_aperture_s',318,18,'s','not a voltage','Actual signal endpoint aperture timestamp. With jitter disabled it equals nominal capture time.','SampleCharge','Valid only when capture_valid=1; initial/unrecorded values remain NaN.','Written by capture; jitter changes only this retained signal endpoint.',[fePack '; ' feState]);
    F=range(F,'FE353','acquire_open_s',336,18,'s','not a voltage','Actual physical acquisition opening time reserved for this segment.','SampleCharge','Valid when the segment has an acquisition target; do not infer from nominal event time in single-bank guard mode.','Written by acquire_open; retained as timing metadata.',[fePack '; ' feState]);

    % RA48: one shared RA/AZ/CT state owner. Multiple calls address this vector.
    raPack='current/src/physics/behavior_backend_pack.m:11-22; current/src/physics/behavior_backend_unpack.m:18-30';
    raStage='current/src/physics/behavior_backend_stage.m:18-62; current/src/physics/behavior_backend_step.m:13-19,161-190';
    F=one(F,'RA48','time_s',1,'s','not a voltage','Backend state time.','RaCtState','Valid after cold initialization.','Advance old command; commit new command at the same event time; only external UnitDelay retains final next state.',[raPack '; ' raStage]);
    F=one(F,'RA48','vx_v',2,'V','RA output differential Vp-Vn; not input-referred','Stored RA output VX state.','RaCtState','Valid after initialization.','Advanced under old command, then locally updated by endpoint CINC kick/command processing.',[raPack '; ' raStage]);
    F=range(F,'RA48','az_input_half_v',3,2,'V','AZ input-referred half state; differential is element 1 minus element 2','Two AZ internal input-referred half states, not RA output nodes.','RaCtState','AZ analog values are separate from AZ valid/pair/epoch service tags.','AZ advance under old command; AZ latch/write state updated at the current command.',[raPack '; ' raStage]);
    F=one(F,'RA48','ct_reset_vx_v',5,'V','RA output differential Vp-Vn','VX reset/off baseline retained by the RA/CT state.','RaCtState','Valid after initialization; baseline is not the current VX.','Updated on reset, RA off, or RA enable boundary.',[raPack '; ' raStage]);
    F=range(F,'RA48','main_qb_c',6,2,'C','not a voltage','Main CT/CINC branch charge state, lane order preserved from the backend ABI.','RaCtState','State vector values; not a measured node voltage.','Updated when the CT network switch state changes.',[raPack '; ' raStage]);
    F=range(F,'RA48','replica_qb_c',8,2,'C','not a voltage','Replica CT/CINC branch charge state, lane order preserved from the backend ABI.','RaCtState','State vector values; replica may be disabled by configuration.','Updated when the CT network switch state changes.',[raPack '; ' raStage]);
    F=range(F,'RA48','previous_switch_charge_c',10,2,'C','not a voltage','Previous main-plus-replica switch injected charge retained for endpoint kick differencing.','RaCtState','Valid after backend initialization.','Updated after current endpoint CINC switching.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_qres_c',12,'C','differential FE charge command; backend AZ routing may apply one polarity sign','Qres command stored at the interval start in this RA48 state.','RaCtState','Interpret with command_sample_id and the stage input time; during finite-DAC advance this can differ from the FE endpoint forcing.','Applied by backend commit; do not use this old stored word to reconstruct the finite-DAC predicted endpoint.',[raPack '; ' raStage '; current/src/physics/behavior_backend_step.m:161-167']);
    F=one(F,'RA48','command_ctop_f',13,'F','not a voltage','Total FE top-node load capacitance carried with the active command.','RaCtState','Interpret with command_qres_c from the same command.','Applied by backend commit.',[raPack '; ' raStage]);
    F=range(F,'RA48','d2_sign',14,12,'switch sign','not applicable','D2 physical feedback signs; values encode -1/0/+1 switch states, not RAW bits.','RaCtState','Current command signs; zeroed when RA is inactive/reset.','Applied by backend commit after each due feedback command.',[raPack '; ' raStage]);
    F=range(F,'RA48','tracking_sign',26,7,'switch sign','not applicable','Physical tracking feedback signs for the seven updates; comparison 8 has no eighth update.','RaCtState','Current command signs; zeroed when RA is inactive/reset.','Applied by backend commit after each of seven tracking feedback commands.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_ra_on',33,'flag','not applicable','RA enabled in latched backend command.','RaCtState','Command state; does not imply a conversion is valid.','Set by backend commit.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_az_on',34,'flag','not applicable','AZ write/service enabled in latched backend command.','RaCtState','Ordinary AZ setting is independent of CAAZ/ADI candidate experiments.','Set by backend commit.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_reset',35,'flag','not applicable','Signal reset command; it is not a global engineering reset.','RaCtState','Command state.','Set by backend commit; state owner retains specified analog storage.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_sample_id',36,'sample ID','not applicable','Sample ID carried by the latched backend command.','RaCtState','Valid with the corresponding command; -1 indicates no assigned sample.','Set by backend commit.',[raPack '; ' raStage]);
    F=one(F,'RA48','command_epoch',37,'epoch','not applicable','Epoch carried by the latched backend command.','RaCtState','Valid with the corresponding command.','Set by backend commit.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_valid',38,'flag','not applicable','Whether the shared AZ stored pair is valid for service.','RaCtState','Use with az_pair_id and az_epoch; not equivalent to RA on.','AZ service lifecycle update.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_pair_id',39,'pair ID','not applicable','Sample pair associated with the AZ storage.','RaCtState','Valid only when az_valid=1.','AZ service lifecycle update.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_epoch',40,'epoch','not applicable','Epoch associated with the AZ storage.','RaCtState','Valid only when az_valid=1.','AZ service lifecycle update.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_age_s',41,'s','not a voltage','Age of the currently valid AZ storage.','RaCtState','Valid only when az_valid=1; reset/epoch invalidation can revoke it.','AZ service lifecycle update.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_write_active',42,'flag','not applicable','Whether the shared AZ storage is currently in a write interval.','RaCtState','Valid state flag.','Updated by AZ schedule/write service.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_write_count',43,'count','not applicable','Cumulative AZ write count.','RaCtState','Cumulative count retained across signal reset.','Incremented on an AZ write.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_last_write_sample_id',44,'sample ID','not applicable','Sample ID of the last AZ write.','RaCtState','-1 means no write has been recorded.','Updated on AZ write.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_last_service_sample_id',45,'sample ID','not applicable','Sample ID last serviced by the shared AZ state.','RaCtState','-1 means no service has been recorded.','Updated by AZ service lifecycle.',[raPack '; ' raStage]);
    F=range(F,'RA48','az_write_source_half_v',46,2,'V','AZ input-referred half source; differential is element 1 minus element 2','Held input-half source used during the shared AZ write.','RaCtState','Valid while write_active or when retained source is being diagnosed.','Latched at AZ write start; may remain after write ends.',[raPack '; ' raStage]);
    F=one(F,'RA48','az_write_elapsed_s',48,'s','not a voltage','Elapsed time in the current or most recent AZ write interval.','RaCtState','Use with write_active; not a full sampling period.','Updated by AZ advance/write lifecycle.',[raPack '; ' raStage]);

    % SAR51: external UnitDelay owner SarState.
    sarPack='current/src/control/behavior_sar_pack.m:9-27; current/src/control/behavior_sar_unpack.m:11-30';
    sarStep='current/src/control/behavior_sar_step.m:23-129';
    F=one(F,'SAR51','active',1,'flag','not applicable','Whether a digital SAR conversion is active.','SarState','Valid controller state.','Updated by CNV/reset/release and conversion events.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','sample_id',2,'sample ID','not applicable','Zero-based sample ID owned by the current SAR conversion.','SarState','Valid only while a conversion is active or a completed RAW is retained.','Set by CNV; retained until next CNV/reset.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','epoch',3,'epoch','not applicable','Epoch tag owned by the current SAR conversion.','SarState','Interpret with sample_id.','Set by CNV; retained until next CNV/reset.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','bank',4,'selector','not applicable','Legacy logical bank selector; in single_bank mode the controller fixes this to zero.','SarState','Controller tag only; does not imply two physical ADC front ends.','Set by CNV.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','sample_v',5,'V','P.input differential behavioral reference; terminal Vp/Vn and common mode are not separately represented','Differential sample voltage supplied to coarse conversion at CNV.','SarState','Valid after CNV for the current sample_id/epoch.','Latched by CNV.','config/adc_parameters.m:72-76; current/src/control/behavior_sar_step.m:27-34,4-6');
    F=one(F,'SAR51','coarse',6,'code','not applicable','Six-bit coarse result.','SarState','Valid after coarse_latched=1.','Written by coarse_latch.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','coarse_latched',7,'flag','not applicable','Whether the coarse result has been captured.','SarState','0 means coarse is not yet a valid decision result.','Set by coarse_latch; cleared by CNV/reset.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','trial',8,'code','not applicable','Current D1 trial word.','SarState','Valid as a trial word while conversion is active; not necessarily the final D1 RAW.','Changed by coarse latch, fine prepare, and due feedback.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d1raw',9,'code','not applicable','Current D1 RAW word; trial and physical feedback are separate fields.','SarState','Final only after all five fine decisions are accepted.','Changed at fine decisions.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d1_feedback_word',10,'code','not applicable','D1 word whose analog feedback command has committed.','SarState','Can lag d1raw until the matching due feedback event.','Updated by fine_feedback.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','fine_count',11,'count','not applicable','Number of valid fine decisions accepted.','SarState','Range 0..5.','Incremented by valid fine_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','fine_attempt_count',12,'count','not applicable','Number of fine comparisons attempted, including invalid attempts.','SarState','Range 0..5.','Incremented by each fine_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','fine_pending',13,'flag','not applicable','A fine decision is awaiting its decision/feedback sequence.','SarState','Use with fine_bit and pending fields.','Set by fine_prepare; cleared by fine_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','fine_bit',14,'bit index','not applicable','Bit position for the current fine trial.','SarState','Valid only when fine_pending=1.','Set by fine_prepare.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2raw',15,'code','not applicable','Current 12-bit D2 RAW word.','SarState','Final only after d2_count=12 and D2 feedback completes.','Changed by each d2_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2_feedback_word',16,'code','not applicable','D2 word whose physical feedback command has committed.','SarState','May lag d2raw until due feedback.','Updated by d2_feedback.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2_trial',17,'code','not applicable','D2 trial/feedback word supplied to the physical switching network.','SarState','Interpret with d2_pending and d2_feedback_word.','Loaded by d2_prepare.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2_count',18,'count','not applicable','Number of D2 decisions accepted.','SarState','Range 0..12.','Incremented by each d2_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2_pending',19,'flag','not applicable','A D2 comparison is waiting for its decision.','SarState','Use with d2_bit.','Set by d2_prepare; cleared by d2_decide.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','d2_bit',20,'bit index','not applicable','Bit position of the current D2 comparison.','SarState','Valid only when d2_pending=1.','Set by d2_prepare.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','dtraw',21,'code','not applicable','Current 8-bit tracking RAW word.','SarState','Final after eight comparisons; only seven physical feedback updates exist.','Changed by each ta_compare.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','track_count',22,'count','not applicable','Number of tracking comparisons completed.','SarState','Range 0..8.','Incremented by each ta_compare.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','feedback_count',23,'count','not applicable','Number of physical tracking feedback updates completed.','SarState','Range 0..7; there is no eighth update.','Incremented by ta_feedback.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','ra_on',24,'flag','not applicable','Digital controller RA enable state.','SarState','Not itself a measurement of analog VX settling.','Set at ra_start; cleared at release/reset.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','overrange',25,'flag','not applicable','Whether a range, comparator-validity, or late condition has invalidated the conversion.','SarState','0 is not a guarantee of public-record alignment.','Updated by coarse/fine/D2/tracking decision checks.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','raw_latched',26,'flag','not applicable','Whether raw_latch completed.','SarState','Use with overrange and external RecordReady/RAW.valid.','Set at raw_latch; cleared by CNV/reset.',[sarPack '; ' sarStep]);
    F=range(F,'SAR51','d2_sign',27,12,'switch sign','not applicable','Physical D2 feedback sign history; entries encode -1/+1 for completed feedback decisions.','SarState','Only the first d2_count decisions and committed feedback prefix are meaningful.','Updated by d2_feedback, not by d2_decide alone.',[sarPack '; ' sarStep]);
    F=range(F,'SAR51','tracking_sign',39,7,'switch sign','not applicable','Physical tracking feedback sign history.','SarState','Only the first feedback_count entries are physically committed; 8th comparison has no entry.','Updated by seven ta_feedback events.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_type_code',46,'enum code','not applicable','Pending feedback type: 0=none, 1=fine_feedback, 2=d2_feedback, 3=ta_feedback.','SarState','Interpret with pending_index/word/decision/count/due_s.','Created by a decision; cleared by the corresponding due feedback event.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_index',47,'index','not applicable','Event index associated with the pending feedback.','SarState','Valid only when pending_type_code is nonzero.','Created by decision; consumed by matching feedback event.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_word',48,'code','not applicable','Digital word to be physically applied at due feedback.','SarState','Valid only when pending_type_code is nonzero.','Created by decision; consumed by matching feedback event.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_decision',49,'bit','not applicable','Comparator decision retained for the pending feedback.','SarState','Valid only when pending_type_code is nonzero.','Created by decision; consumed by matching feedback event.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_count',50,'count','not applicable','Decision count attached to the pending feedback.','SarState','Valid only when pending_type_code is nonzero.','Created by decision; consumed by matching feedback event.',[sarPack '; ' sarStep]);
    F=one(F,'SAR51','pending_due_s',51,'s','not a voltage','Scheduled due time for pending feedback.','SarState','Valid only when pending_type_code is nonzero.','Decision time plus the registered feedback interval; consumed at due event.',[sarPack '; ' sarStep]);

    % Existing ADC RAW and control interfaces remain ABI-compatible.
    rawSrc='current/src/model/behavior_wiring_sfun.m:41-44; current/src/control/behavior_sar_step.m:114-120';
    rawOwner='SarState -> Raw wiring';
    F=one(F,'RAW6','D1',1,'code','not applicable','Eleven-bit D1 raw word.','SarState -> Raw wiring','A current complete record requires RAW.valid=1 and aligned sample_id/epoch; otherwise the word is diagnostic/held state.','Derived from Control13 D1raw at raw wiring output.',rawSrc);
    F=one(F,'RAW6','D2',2,'code','not applicable','Twelve-bit D2 raw word.','SarState -> Raw wiring','A current complete record requires RAW.valid=1 and aligned sample_id/epoch; otherwise the word is diagnostic/held state.','Derived from Control13 D2raw at raw wiring output.',rawSrc);
    F=one(F,'RAW6','DT',3,'code','not applicable','Eight-bit tracking raw word from eight comparisons and seven physical updates.','SarState -> Raw wiring','A current complete record requires RAW.valid=1 and aligned sample_id/epoch; otherwise the word is diagnostic/held state.','Derived from Control13 DTraw at raw wiring output.',rawSrc);
    F=one(F,'RAW6','sample_id',4,'sample ID','not applicable','Sample ID carried by the raw bus.','SarState -> Raw wiring','Must match selected sample ID; row number is not sample ID.','Copied from Control13 sample_id.',rawSrc);
    F=one(F,'RAW6','epoch',5,'epoch','not applicable','Epoch carried by the raw bus.','SarState -> Raw wiring','Must match selected run epoch.','Copied from Control13 epoch.',rawSrc);
    F=one(F,'RAW6','valid',6,'flag','not applicable','ADC raw-record validity bit from the SAR controller.','SarState -> Raw wiring','This is the raw-record validity bit; do not equate it with public RecordReady or the legacy Bank CodeValid qualification.','Copied from Control13 raw_valid.',rawSrc);

    % Existing event/ready logger vectors, with their original time axes carried separately.
    eventLogSrc='current/src/analysis/behavior_sample_debug.m:70-90; current/src/model/behavior_wiring_sfun.m:46-61';
    F=one(F,'EventLog2','sample_id',1,'sample ID','not applicable','Zero-based sample/cycle identity attached to the actual event-log row.','Event logger','Use the paired actual event-log.Time; sample ID is not the vector row index.','Recorded when an event group executes.',eventLogSrc);
    F=one(F,'EventLog2','group_index',2,'group index','not applicable','1-based index into the saved event-group calendar.','Event logger','Resolve through saved P.groups; do not reorder same-time group events.','Recorded when an event group executes.',eventLogSrc);
    F=one(F,'ParentEventLog2','parent_id',1,'parent event ID','not applicable','Parent event identity used to confirm held-49 transport grouping.','Parent event logger','Interpret as parent scheduler identity, not automatically the selected ADC sample ID.','Aligned by exact event-log times in the existing sample reader.',eventLogSrc);
    F=one(F,'ParentEventLog2','group_index',2,'group index','not applicable','1-based parent event-group index.','Parent event logger','Resolve using the parent saved schedule; must align at actual event times.','Aligned by exact event-log times in the existing sample reader.',eventLogSrc);
    F=one(F,'Ready1','ADC_RawReady',1,'flag','not applicable','ADC raw-ready event pulse from the legacy ready_log.','SarState -> Raw wiring','A pulse is distinct from RAW.valid, public RecordReady, record alignment, and legacy Bank CodeValid.','Asserted at the actual raw_latch event.', ...
        'current/src/analysis/behavior_sample_debug.m:95-110; current/src/control/behavior_sar_step.m:114-120');

    % Public-record/output observations keep their own owner and qualification.
    publicSrc='current/src/analysis/behavior_record_view.m:14-29,42-77';
    F=one(F,'PublicRecord6','D1',1,'code','not applicable','D1 word on the public record path.','FPGA/Transport public record','Use only with aligned public RecordReady, sample_id, epoch, and this record valid word.','Captured from record_log after the public transport/output path.',publicSrc);
    F=one(F,'PublicRecord6','D2',2,'code','not applicable','D2 word on the public record path.','FPGA/Transport public record','Use only with the same aligned public record tags and validity.','Captured from record_log after the public transport/output path.',publicSrc);
    F=one(F,'PublicRecord6','DT',3,'code','not applicable','Tracking word on the public record path.','FPGA/Transport public record','Use only with the same aligned public record tags and validity.','Captured from record_log after the public transport/output path.',publicSrc);
    F=one(F,'PublicRecord6','sample_id',4,'sample ID','not applicable','Sample ID carried by the public record.','FPGA/Transport public record','Match by ID/epoch and actual ready time; never by row number alone.','Captured from record_log.',publicSrc);
    F=one(F,'PublicRecord6','epoch',5,'epoch','not applicable','Epoch carried by the public record.','FPGA/Transport public record','Must match the selected run epoch.','Captured from record_log.',publicSrc);
    F=one(F,'PublicRecord6','valid',6,'flag','not applicable','Validity word carried by the public record.','FPGA/Transport public record','Distinct from ADC_RawReady, Control13.raw_valid, public RecordReady pulse, and legacy Bank CodeValid.','Captured from record_log.',publicSrc);
    F=one(F,'PublicRecordReady1','RecordReady',1,'flag','not applicable','Public record-ready pulse for record_log.','FPGA/Transport public output','Align by its actual logger Time; not the ADC ready_log pulse and not RAW.valid.','Captured from record_ready_log.',publicSrc);
    F=one(F,'Code20_1','code20',1,'code','not applicable','Observed unsigned 20-bit output code from code_log.','FPGA/public output path','Align by exact actual public RecordReady time and record ID/epoch. This is an observed code, not a recomputation.','Captured from code_log.',publicSrc);
    F=one(F,'LegacyCodeValid1','CodeValid_old_BankQualification',1,'flag','not applicable','Legacy Bank output qualification flag, retained under its old CodeValid meaning.','Bank legacy output qualification','Read and display unchanged; it is distinct from ADC RAW.valid, ADC_RawReady, public RecordReady, and record_log.valid.','Captured from bank_code_valid_log when present.', ...
        'current/src/analysis/behavior_sample_debug.m:201-240; current/src/analysis/behavior_bank_record_gate.m:1-20');
    bankMetaSrc='current/src/analysis/behavior_sample_debug.m:218-234; current/src/analysis/behavior_bank_record_gate.m:12-20';
    F=one(F,'BankMeta9','meta_word_01',1,'待确认','not applicable','Bank metadata word 1; current source does not assign its meaning.','Bank','Uninterpreted and preserved as recorded.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','event_time_s',2,'s','not a voltage','Actual public record-ready timestamp carried in Bank metadata.','Bank','Must match the actual selected public record-ready time exactly.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','sample_id',3,'sample ID','not applicable','Sample ID paired with Bank metadata.','Bank','Must match PublicRecord6.sample_id.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','epoch',4,'epoch','not applicable','Epoch paired with Bank metadata.','Bank','Must match PublicRecord6.epoch.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','raw_valid',5,'flag','not applicable','RAW validity copied into Bank metadata for record matching.','Bank','Must match PublicRecord6.valid; does not replace CodeValid_old_BankQualification.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','slot',6,'slot','not applicable','Bank coefficient slot ID.','Bank','Valid only when the selected version/slot mapping is available.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','version',7,'version','not applicable','Bank coefficient version tag.','Bank','Match to the explicitly saved Bank versions.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','fault',8,'flag','not applicable','Bank fault flag.','Bank','0 is required for the existing Bank metadata integrity gate; it does not qualify the analog conversion.','Captured from bank_meta_log.',bankMetaSrc);
    F=one(F,'BankMeta9','meta_word_09',9,'待确认','not applicable','Bank metadata word 9; current source does not assign its meaning.','Bank','Uninterpreted and preserved as recorded.','Captured from bank_meta_log.',bankMetaSrc);

    ctrlSrc='current/src/control/behavior_control_stage.m:73-78';
    F=one(F,'Control13','trial',1,'code','not applicable','Current D1 trial word.','SarState','Valid controller output; may differ from D1raw and d1_feedback_word.','Emitted after all accepted controller events in this event group.',ctrlSrc);
    F=one(F,'Control13','ra_on',2,'flag','not applicable','Controller RA enable state.','SarState','Controller flag, not the analog backend measurement.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','active',3,'flag','not applicable','Controller conversion-active flag.','SarState','Controller state.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','RawReady',4,'flag','not applicable','Pulse indicating raw_latch occurred in this event group.','SarState','One-group pulse; separate from RAW.valid and public RecordReady.','Asserted only when current group executes raw_latch.',ctrlSrc);
    F=one(F,'Control13','D1raw',5,'code','not applicable','Current D1 raw word.','SarState','Not a final accepted word until the conversion path completes and validity is checked.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','D2raw',6,'code','not applicable','Current D2 raw word.','SarState','Not final until 12 D2 decisions and required feedback are complete.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','DTraw',7,'code','not applicable','Current tracking raw word.','SarState','Eight comparisons produce eight bits; only seven physical feedback updates.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','raw_valid',8,'flag','not applicable','SAR controller raw validity: raw_latched && !overrange.','SarState','ADC raw validity only; do not rename as legacy Bank CodeValid or as public RecordReady.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','sample_id',9,'sample ID','not applicable','Current controller sample ID.','SarState','Do not infer sample identity from vector row number.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','epoch',10,'epoch','not applicable','Current controller epoch.','SarState','Use with sample_id.','Emitted after current group events.',ctrlSrc);
    F=one(F,'Control13','CNV',11,'flag','not applicable','Pulse for CNV in this event group.','SarState','Group pulse, not an event count.','Set when the group contains CNV.',ctrlSrc);
    F=one(F,'Control13','release',12,'flag','not applicable','Pulse for release in this event group.','SarState','Group pulse, not evidence that FE/RA state has been committed by a full cycle.','Set when the group contains release.',ctrlSrc);
    F=one(F,'Control13','dac_changed',13,'flag','not applicable','Pulse when a controller trial or due feedback changed its DAC word.','SarState','Does not mean every physical state owner changed.','Set by trial_changed or feedback_changed in this group.',ctrlSrc);

    backSrc='current/src/physics/behavior_backend_stage.m:60-62; current/src/physics/behavior_backend_step.m:161-190,267-296';
    backOwner='RaCtState';
    F=one(F,'BackendObs8','VX',1,'V','RA output differential Vp-Vn; not input-referred','Observed RA output VX.','RaCtState','Finite only when this backend observation is recorded.','Stage tap determines predicted versus local-after-command timing.',backSrc);
    F=one(F,'BackendObs8','VY',2,'V','CT comparator differential input VY_P-VY_N; not RA VX','Observed CT/comparator input VY.','RaCtState','Finite only when the backend observation and CT path are recorded; compare at the exact event time.','Backend stage output; physical D2/TA comparisons consume comparator input.',backSrc);
    F=one(F,'BackendObs8','Vtop',3,'V','RA feedback/output boundary differential; distinct from VX and FE vtop_equiv','Observed RA top/output voltage supplied to FE release path.','RaCtState','Finite only when this backend observation is recorded.','Backend stage output; release routing can restore AZ polarity.',backSrc);
    F=one(F,'BackendObs8','target_v',4,'V','Differential target at RA command boundary; not actual VX','Target implied by the exact stage operation. On finite-DAC advance, predicted target may use the FE endpoint forcing, not command_qres_c in the advanced RA48 state.','RaCtState','Finite only when this observation is recorded; do not recompute from a different-stage Qres.','predicted uses y.predicted old-command endpoint; local observation uses that stage actual command.',backSrc);
    F=one(F,'BackendObs8','noise_gain',5,'ratio','not a voltage','RA noise gain 1+Ctop/Cf.','RaCtState','Finite only when this backend observation is recorded.','Computed by the executing stage from its exact endpoint command.',backSrc);
    F=one(F,'BackendObs8','tau_ra_s',6,'s','not a voltage','RA time constant NG/(2*pi*UGB).','RaCtState','Finite only when this backend observation is recorded.','Computed by the executing stage from its exact endpoint command.',backSrc);
    F=one(F,'BackendObs8','az_input_diff_v',7,'V','AZ input-referred differential: half-state 1 minus half-state 2; not RA VX','Differential of the two shared AZ input-referred half states.','RaCtState','Finite only when the backend observation is recorded; AZ state is separate from CAAZ/ADI experiments.','Observed after the selected backend stage.',backSrc);
    F=one(F,'BackendObs8','ct_reset_baseline_vx_v',8,'V','RA output differential Vp-Vn','Stored CT reset baseline of VX.','RaCtState','Finite only when this backend observation is recorded.','Observed after the selected backend stage.',backSrc);

    frontSrc='current/src/frontend/behavior_frontend_stage.m:68-69; current/src/frontend/behavior_frontend_step.m:274-295';
    frontOwner='SampleCharge';
    F=one(F,'FrontendObs7','coarse_input_v',1,'V','P.input differential behavioral reference; terminal Vp/Vn and common mode are not separately represented','Charge-weighted captured differential input value presented to coarse conversion.','SampleCharge','Valid only for a valid matching capture; terminal/common-mode mapping is not represented.','Frontend stage observation after its named stage.','config/adc_parameters.m:72-76; current/src/frontend/behavior_frontend_step.m:274-295; current/src/frontend/behavior_frontend_stage.m:68-69');
    F=one(F,'FrontendObs7','vres_v',2,'V','FE differential input-equivalent residual Qres/Cs; not RA output and not an established settling error','Differential charge residual referred to total FE signal capacitance.','SampleCharge','Valid only for a matching active/captured sample; source tap determines phase.','Computed from FE stored charge at the observation point.',frontSrc);
    F=one(F,'FrontendObs7','qres_c',3,'C','FE differential charge boundary before backend polarity routing','Qres delivered to backend command construction.','SampleCharge','Valid only for a matching active/captured sample.','Computed from capture charge minus current FE stored charge.',frontSrc);
    F=one(F,'FrontendObs7','cs_f',4,'F','not a voltage','Total signal-group capacitance Cs.','SampleCharge','Finite only for a valid FE observation.','Summed from selected numerical segments.',frontSrc);
    F=one(F,'FrontendObs7','ctop_f',5,'F','not a voltage','Total FE top load including the current FE group capacitances and Cp.','SampleCharge','Finite only for a valid FE observation.','Summed from selected numerical segments.',frontSrc);
    F=one(F,'FrontendObs7','vtop_equiv_v',6,'V','derived FE equivalent -Qres/Ctop; not physical RA Vtop','Equivalent FE top voltage inferred from FE charge boundary.','SampleCharge','Finite only for a valid FE observation; never relabel as BackendObs8.Vtop.','Derived in FE readout.',frontSrc);
    F=one(F,'FrontendObs7','dither_input_v',7,'V','deterministic FE dither source reference; not the differential input sample','Deterministic dither value associated with the selected sample.','SampleCharge','Valid from saved configuration/seed; no random sampling occurs during decode.','Computed by FE readout from the configured keyed dither.',frontSrc);

    % Existing logged groups: compact header and actual comparison-event slot metadata.
    feHeaderSrc='current/src/frontend/behavior_frontend_sfun.m:4-7; current/src/frontend/behavior_frontend_stage.m:4-9';
    F=one(F,'FETraceHeader6','valid',1,'flag','not applicable','Observer window marker; distinct from capture_valid or RAW.valid.','Trace observer','Finite 1 marks an actual stage call in the selected window; outside-window trace rows remain all-NaN, not zero. Individual taps may still be absent.','Recorded by the FE stage observer.',feHeaderSrc);
    F=one(F,'FETraceHeader6','time_s',2,'s','not a voltage','Actual FE event context time.','Trace observer','Valid only when observer valid=1.','Copied from Context(1); no event-time interpolation.',feHeaderSrc);
    F=one(F,'FETraceHeader6','context_id',3,'sample ID','not applicable','Sample ID from the FE stage context.','Trace observer','Context target ID; distinguish from any later RAW/public output ID.','Copied from Context(2).',feHeaderSrc);
    F=one(F,'FETraceHeader6','epoch',4,'epoch','not applicable','Epoch from the FE stage context.','Trace observer','Valid only when observer valid=1.','Copied from Context(3).',feHeaderSrc);
    F=one(F,'FETraceHeader6','kind_code',5,'enum','not applicable','Frontend stage kind code; labels are in R.enums.stage_kind_code.','Trace observer','Valid only when observer valid=1.','Copied from the executing FE stage kind.',feHeaderSrc);
    F=one(F,'FETraceHeader6','context_event',6,'enum','not applicable','Original Context(4); labels depend on kind_code and are in R.enums.frontend_context_event_code.','Trace observer','Valid only when observer valid=1; preserves the context code, not group.events ordinal.','Copied unchanged from Context(4); event ordinal remains a separate calendar value.',feHeaderSrc);

    backHeaderSrc='current/src/physics/behavior_backend_sfun.m:4-7; current/src/physics/behavior_backend_stage.m:4-12';
    F=one(F,'BackendTraceHeader4','valid',1,'flag','not applicable','Observer window marker; distinct from AZ valid and raw-record validity.','Trace observer','Finite 1 marks an actual stage call in the selected window; outside-window trace rows remain all-NaN, not zero. Individual taps may still be absent.','Recorded by the backend stage observer.',backHeaderSrc);
    F=one(F,'BackendTraceHeader4','eventTime_s',2,'s','not a voltage','Actual absolute backend event time.','Trace observer','Valid only when observer valid=1.','Copied from backend eventTime.',backHeaderSrc);
    F=one(F,'BackendTraceHeader4','kind_code',3,'enum','not applicable','Backend stage kind code; labels are in R.enums.stage_kind_code.','Trace observer','Valid only when observer valid=1.','Copied from the executing backend stage kind.',backHeaderSrc);
    F=one(F,'BackendTraceHeader4','advanced_valid',4,'flag','not applicable','Whether the advanced RA48/observation tap is available for this row. Commit dt=0 has no separate advanced tap.','Trace observer','0 requires advanced tap values to remain NaN with a reason; does not invalidate predicted/actual taps.','Set from actual backend advance availability.',backHeaderSrc);

    controllerSrc='current/src/control/behavior_sar_step.m:54-120; current/src/control/behavior_control_stage.m:47-70';
    F=one(F,'ControlEvent24','record_valid',1,'flag','not applicable','Whether this event slot contains a real controller event observation.','SarState','Finite 1 marks an actual event; unused slots remain all-NaN including record_valid. This is not a conversion-validity bit.','Captured for each executed event in original group.events order.',controllerSrc);
    F=one(F,'ControlEvent24','time_s',2,'s','not a voltage','Actual absolute time of this controller event.','SarState','Valid only when record_valid=1.','Copied from event absolute_time_s.',controllerSrc);
    F=one(F,'ControlEvent24','sample_id',3,'sample ID','not applicable','Sample ID attached to the actual controller event.','SarState','Valid only when record_valid=1; do not infer from row number.','Copied from event sample_id.',controllerSrc);
    F=one(F,'ControlEvent24','epoch',4,'epoch','not applicable','Epoch attached to the actual controller event.','SarState','Valid only when record_valid=1.','Copied from event epoch.',controllerSrc);
    F=one(F,'ControlEvent24','ordinal',5,'ordinal','not applicable','1-based original position of this event in group.events.','Trace observer','Preserve as captured; do not sort/deduplicate same-time events.','Copied from group.events ordinal.',controllerSrc);
    F=one(F,'ControlEvent24','stage_code',6,'enum','not applicable','Controller stage code; labels are in R.enums.controller_stage_code.','Trace observer','Valid only when record_valid=1.','Copied from actual executing stage.',controllerSrc);
    F=one(F,'ControlEvent24','event_code',7,'enum','not applicable','Observer event code for the actual controller event; labels are in R.enums.controller_event_code.','Trace observer','Valid only when record_valid=1.','Copied from the executed event type.',controllerSrc);
    F=one(F,'ControlEvent24','event_index',8,'index','not applicable','Original event.index; -1 is the source calendar sentinel for events without an index.','Trace observer','For recorded slots, -1 means not applicable, not missing; unused slots are all-NaN.','Copied directly from event.index.','current/src/control/behavior_calendar.m:5,14,16-36,39-41; trace_observer candidate behavior_control_stage.m:101-106');
    F=one(F,'ControlEvent24','event_bit',9,'bit index','not applicable','Original event.bit; -1 is the source calendar sentinel for events without a bit.','Trace observer','For recorded slots, -1 means not applicable, not missing; unused slots are all-NaN.','Copied directly from event.bit.','current/src/control/behavior_calendar.m:5,14,16-36,39-41; trace_observer candidate behavior_control_stage.m:101-106');
    F=one(F,'ControlEvent24','comparison_used',10,'flag','not applicable','Whether an actual comparator comparison was consumed for this event.','SarState','When zero, comparator inputs/decisions must remain NaN, not zero-filled.','Captured from the exact eventComparison passed to behavior_sar_step.',controllerSrc);
    F=one(F,'ControlEvent24','sample_v',11,'V','P.input differential behavioral reference; terminal Vp/Vn and common mode are not separately represented','Actual sample_v supplied to the controller comparison.','SarState','Recorded only when comparison_used=1.','Exact comparison struct passed to the event.','config/adc_parameters.m:72-76; current/src/control/behavior_control_stage.m:47-49; current/src/control/behavior_sar_step.m:4-6');
    F=one(F,'ControlEvent24','vres_v',12,'V','FE-side differential input-equivalent residual Qres/Cs; not RA output','Actual fine comparator residual supplied to the controller.','SarState','Recorded only when comparison_used=1 and event is a fine comparison.','Exact comparison struct passed to the event.','current/src/control/behavior_control_stage.m:47-49; current/src/control/behavior_sar_step.m:4-6');
    F=one(F,'ControlEvent24','vy_v',13,'V','CT comparator differential input VY_P-VY_N; not RA VX','Actual physical comparator input supplied to D2/tracking comparison.','RaCtState -> SarState','Recorded only when comparison_used=1 and event is a D2/tracking comparison.','Exact comparison struct passed to the event.',controllerSrc);
    F=one(F,'ControlEvent24','decision1',14,'bit','not applicable','Native D1 comparator decision supplied to this event.','Comparator -> SarState','Recorded only when comparison_used=1; preserve the exact consumed comparator output.','Exact comparison struct passed to the event.',controllerSrc);
    F=one(F,'ControlEvent24','decision2',15,'bit','not applicable','Native D2/tracking comparator decision supplied to this event.','Comparator -> SarState','Recorded only when comparison_used=1; preserve the exact consumed comparator output.','Exact comparison struct passed to the event.',controllerSrc);
    F=one(F,'ControlEvent24','compare_valid',16,'flag','not applicable','Validity flag consumed by the SAR behavior model. Current stage adapter sets this to true; native comparator-valid status is not logged.','SarState','Meaningful only when comparison_used=1; this is the behavioral input value, not native validity evidence.','Supplied in the event comparison struct.','current/src/control/behavior_control_stage.m:47-49; current/src/control/behavior_sar_step.m:162-170');
    F=one(F,'ControlEvent24','compare_late',17,'flag','not applicable','Late flag consumed by the SAR behavior model. Current stage adapter sets this to false; native comparator timeout/late status is not logged.','SarState','Meaningful only when comparison_used=1; false is the adapter default, not measured timing evidence.','Supplied in the event comparison struct.','current/src/control/behavior_control_stage.m:47-49; current/src/control/behavior_sar_step.m:162-170');
    cmpSrc='current/src/control/behavior_comparator_sample.m:10-55; trace_observer candidate behavior_control_stage.m:69-106';
    F=one(F,'ControlEvent24','cmp_effective_v',18,'V','fine_decide: FE residual reference; d2_decide/ta_compare: CT differential VY_P-VY_N','Post-perturbation comparator input actually used to determine the native decision.','Comparator -> SarState','Valid only when comparison_used=1 and the comparator diagnostic was captured.','Captured from the same comparator helper call; no second noise draw.',cmpSrc);
    F=one(F,'ControlEvent24','cmp_offset_v',19,'V','comparator input-referred perturbation reference; channel selected by event_code','Comparator offset contribution from the same diagnostic call.','Comparator','Valid only when comparison_used=1 and the diagnostic was captured.','Captured from the same comparator helper call.',cmpSrc);
    F=one(F,'ControlEvent24','cmp_noise_v',20,'V','comparator input-referred perturbation reference; channel selected by event_code','Comparator noise contribution from the same diagnostic call.','Comparator','Valid only when comparison_used=1 and the diagnostic was captured; not an independent random sample.','Captured from the same comparator helper call.',cmpSrc);
    F=one(F,'ControlEvent24','decision',21,'bit','not applicable','Decision returned by the exact executed SAR event.','SarState','NaN when the event does not perform a comparison.','Captured from behavior_sar_step output.',controllerSrc);
    F=one(F,'ControlEvent24','record_ready',22,'flag','not applicable','Pulse returned when raw_latch executes.','SarState','Event-local; not public RecordReady alignment.','Captured from behavior_sar_step output.',controllerSrc);
    F=one(F,'ControlEvent24','feedback_changed',23,'flag','not applicable','Whether this event committed a due feedback word.','SarState','Event-local; a comparison alone does not imply a feedback commit.','Captured from behavior_sar_step output.',controllerSrc);
    F=one(F,'ControlEvent24','trial_changed',24,'flag','not applicable','Whether this event changed the D1 trial/feedback output.','SarState','Event-local.','Captured from behavior_sar_step output.',controllerSrc);

    % Outer event/time context: group event identity is not the ToWorkspace time.
    eventSrc='current/src/model/behavior_wiring_sfun.m:46-61; observer_log outer bundle schema/v1';
    F=one(F,'ObserverEventTime3','cycle_index',1,'cycle index','not applicable','Zero-based event cycle/sample index from the scheduler event vector.','Trace observer','Use as scheduler context only; it is not a row number or automatically the final RAW/output ID.','Copied from the event source.',eventSrc);
    F=one(F,'ObserverEventTime3','group_index',2,'group index','not applicable','1-based index into the saved grouped event calendar.','Trace observer','Resolve through the saved P.groups/event calendar; do not replace by event name sort order.','Copied from the event source.',eventSrc);
    F=one(F,'ObserverEventTime3','modelEventTime_s',3,'s','not a voltage','Model event time calculated from cycle*Ts plus the saved group offset.','Trace observer','This is the wiring-calculated event time, not the actual ToWorkspace timeseries.Time axis. Compare both axes explicitly.','Copied from the event source time calculation.',eventSrc);

    % The registry itself is the positional and naming contract used by decode.
    required={'FE353',353;'RA48',48;'SAR51',51;'RAW6',6;'Control13',13; ...
        'BackendObs8',8;'FrontendObs7',7;'FETraceHeader6',6; ...
        'BackendTraceHeader4',4;'ControlEvent24',24;'ObserverEventTime3',3; ...
        'EventLog2',2;'ParentEventLog2',2;'Ready1',1;'PublicRecord6',6; ...
        'PublicRecordReady1',1;'Code20_1',1;'LegacyCodeValid1',1;'BankMeta9',9};
    for k=1:size(required,1)
        q=F(strcmp({F.group},required{k,1}));
        assert(numel(q)==required{k,2}&&isequal([q.index],1:required{k,2}), ...
            'sar20:debugRegistryWidth','Registry group %s is not a complete ordered ABI.',required{k,1});
        names={q.signal};
        assert(numel(unique(names))==numel(names),'sar20:debugRegistryNames','Duplicate signal name in %s.',required{k,1});
    end
    assert(all(arrayfun(@(q)~isempty(q.unit)&&~isempty(q.voltage_reference)&& ...
        ~isempty(q.meaning)&&~isempty(q.owner)&&~isempty(q.validity)&& ...
        ~isempty(q.update_stage)&&~isempty(q.source),F)), ...
        'sar20:debugRegistryMetadata','Every registry entry needs complete provenance and semantics.');
    traceWidthFE=width(F,'FETraceHeader6')+3*width(F,'FE353')+2*width(F,'FrontendObs7');
    traceWidthBE=width(F,'BackendTraceHeader4')+3*width(F,'RA48')+2*width(F,'BackendObs8');
    controllerEventSlots=2;
    traceWidthSC=controllerEventSlots*(width(F,'ControlEvent24')+width(F,'SAR51'));
    bundleSpec={
        'FE_Sample','FETrace1079',traceWidthFE,'SampleCharge','mixed vector', ...
            'FE Sample stage trace: old353, advanced353, after-command353, advanced Obs7, after-command Obs7.','actual FE stage call; unavailable taps remain NaN.','Trace old353 is this stage input, not necessarily UnitDelay Q; after-command is a local stateNext passed through the stage chain.','SarAdc.slx block SampleRaAdvance/Sample; SampleCharge owner; current/src/frontend/behavior_frontend_sfun.m:2-7; current/src/frontend/behavior_frontend_stage.m:35-49,67-69';
        'FE_DacFeedback','FETrace1079',traceWidthFE,'SampleCharge','mixed vector', ...
            'FE DacFeedback stage trace; preserves separate command-stage observations.','actual FE stage call; unavailable taps remain NaN.','D1 feedback stage input is the preceding local stateNext; after-command is an intermediate stateNext passed to the next stage, not the external UnitDelay input.','SarAdc.slx block DacCtFeedback/DacFeedback; SampleCharge owner; current/src/frontend/behavior_frontend_sfun.m:2-7; current/src/frontend/behavior_frontend_stage.m:50-65,67-69';
        'FE_DacTrial','FETrace1079',traceWidthFE,'SampleCharge','mixed vector', ...
            'FE DacTrial stage trace; preserves trial/command-stage ordering.','actual FE stage call; unavailable taps remain NaN.','D1 trial stage input is the preceding local stateNext; after-command is an intermediate stateNext passed to the next stage, not the external UnitDelay input.','SarAdc.slx block Sar1TrialRaCt/DacTrial; SampleCharge owner; current/src/frontend/behavior_frontend_sfun.m:2-7; current/src/frontend/behavior_frontend_stage.m:50-65,67-69';
        'FE_ChargeReturn','FETrace1079',traceWidthFE,'SampleCharge','mixed vector', ...
            'FE ChargeReturn stage trace; release consumes actual backend Vtop.','actual FE stage call; unavailable taps remain NaN.','Final FE charge-return stage; local after-command stateNext is the final FE UnitDelay-input candidate. It is not a proven UnitDelay commit.','SarAdc.slx block ChargeReturnRaReset/ChargeReturn; SampleCharge owner; current/src/frontend/behavior_frontend_sfun.m:2-7; current/src/frontend/behavior_frontend_stage.m:50-65';
        'BE_RaAdvance','BackendTrace164',traceWidthBE,'RaCtState','mixed vector', ...
            'RA advance stage trace: old48, advanced48, after-command48, predicted Obs8, actual Obs8.','actual backend stage call; advanced_valid=0 makes advanced taps unavailable/NaN.','Trace old48 is this stage input, not necessarily UnitDelay Q; after-command is an intermediate stateNext. Predicted is before endpoint command/CINC switch.','SarAdc.slx block SampleRaAdvance/RaAdvance; shared RaCtState owner; current/src/physics/behavior_backend_sfun.m:4-7; current/src/physics/behavior_backend_stage.m:18-62';
        'BE_CtFeedback','BackendTrace164',traceWidthBE,'RaCtState','mixed vector', ...
            'CT feedback stage trace; actual D2/tracking feedback command remains tied to its original event slot.','actual backend stage call; absent taps remain NaN.','CT/CINC feedback stage input is the preceding local stateNext; its after-command stateNext is intermediate, not the external UnitDelay input.','SarAdc.slx block DacCtFeedback/CtFeedback; shared RaCtState owner; current/src/physics/behavior_backend_sfun.m:4-7; current/src/physics/behavior_backend_stage.m:18-62';
        'BE_RaAzCt','BackendTrace164',traceWidthBE,'RaCtState','mixed vector', ...
            'Shared RA/AZ/CT stage trace; multiple RA-stage invocations share the same state owner.','actual backend stage call; absent taps remain NaN.','RA/AZ/CT stage input is the preceding local stateNext; its after-command stateNext is intermediate in the backend stage chain.','SarAdc.slx block Sar1TrialRaCt/RaAzCt; shared RaCtState owner; current/src/physics/behavior_backend_sfun.m:4-7; current/src/physics/behavior_backend_stage.m:18-62';
        'BE_RaReset','BackendTrace164',traceWidthBE,'RaCtState','mixed vector', ...
            'RA reset stage trace; signal reset is not a global reset.','actual backend stage call; absent taps remain NaN.','Final backend RA reset stage; local after-command stateNext is the RA UnitDelay-input candidate. No UnitDelay commit or global reset is inferred.','SarAdc.slx block ChargeReturnRaReset/RaReset; shared RaCtState owner; current/src/physics/behavior_backend_sfun.m:4-7; current/src/physics/behavior_backend_stage.m:18-62';
        'SC_Due','ControlTrace150',traceWidthSC,'SarState','mixed vector', ...
            'Controller due stage trace; up to two real group.events slots in original order.','record_valid identifies actual event slot; empty slots remain NaN.','Due feedback event state_after51 is a UnitDelay-next candidate, not a previously committed state.','SarAdc.slx block DacCtFeedback/DueFeedback; SarState owner; current/src/control/behavior_control_stage.m:41-70; current/src/control/behavior_sar_step.m:63-110';
        'SC_Prepare','ControlTrace150',traceWidthSC,'SarState','mixed vector', ...
            'Controller prepare stage trace; up to two real group.events slots in original order.','record_valid identifies actual event slot; empty slots remain NaN.','Prepare events record actual trial/state effects in original event order.','SarAdc.slx block Sar1TrialRaCt/PreconvertSar1; SarState owner; current/src/control/behavior_control_stage.m:41-70; current/src/control/behavior_sar_step.m:34-76';
        'SC_Decide','ControlTrace150',traceWidthSC,'SarState','mixed vector', ...
            'Controller decide stage trace; includes actual comparator inputs, perturbation diagnostics, decisions and state_after51.','record_valid identifies actual event slot; comparison_used gates comparator fields.','Decision output and state_after51 follow exact executed event order; not sorted or reconstructed.','SarAdc.slx block SarDecisionTracking/Sar2Tracking; SarState owner; current/src/control/behavior_control_stage.m:47-70; current/src/control/behavior_sar_step.m:54-120';
        'FEold353','FE353',width(F,'FE353'),'SampleCharge','mixed SI units', ...
            'Actual SampleCharge UnitDelay output before the current scheduler event.','Actual saved state when outer bundle row is valid.','UD-old; do not call predicted or event-after-command.','SarAdc.slx SampleCharge UnitDelay output; current/src/frontend/behavior_frontend_sfun.m:6-7';
        'FEnext353','FE353',width(F,'FE353'),'SampleCharge','mixed SI units', ...
            'Final SampleCharge state vector presented to UnitDelay input.','Actual saved next-state candidate when outer bundle row is valid.','UD-next candidate; not proof of a completed UnitDelay commit.','SarAdc.slx SampleCharge UnitDelay input; current/src/frontend/behavior_frontend_sfun.m:6-7';
        'RAold48','RA48',width(F,'RA48'),'RaCtState','mixed SI units', ...
            'Actual shared RaCtState UnitDelay output before the current scheduler event.','Actual saved state when outer bundle row is valid.','UD-old; all RA stage calls refer to this shared state owner.','SarAdc.slx RaCtState UnitDelay output; current/src/physics/behavior_backend_sfun.m:4-7,10';
        'RAnext48','RA48',width(F,'RA48'),'RaCtState','mixed SI units', ...
            'Final shared RaCtState vector presented to UnitDelay input.','Actual saved next-state candidate when outer bundle row is valid.','UD-next candidate; not proof of a completed UnitDelay commit.','SarAdc.slx RaCtState UnitDelay input; current/src/physics/behavior_backend_sfun.m:4-7,10';
        'SARold51','SAR51',width(F,'SAR51'),'SarState','unitless except sample_v and pending_due_s', ...
            'Actual SarState UnitDelay output before the current scheduler event.','Actual saved state when outer bundle row is valid.','UD-old; controller events may have multiple ordered transforms within the group.','SarAdc.slx SarState UnitDelay output; current/src/control/behavior_control_stage.m:8-10';
        'SARnext51','SAR51',width(F,'SAR51'),'SarState','unitless except sample_v and pending_due_s', ...
            'Final SarState vector presented to UnitDelay input.','Actual saved next-state candidate when outer bundle row is valid.','UD-next candidate; not proof of a completed UnitDelay commit.','SarAdc.slx SarState UnitDelay input; current/src/control/behavior_control_stage.m:8-10';
        'EventTime3','ObserverEventTime3',width(F,'ObserverEventTime3'),'Trace observer','mixed event indices and time', ...
            'Outer scheduler cycle, 1-based event-group index, and wiring-calculated model event time.','Present only for an observer bundle row; compare modelEventTime_s against actual timeseries.Time/event_log.Time.','Outer event identity/time; this time word never substitutes for the actual logger time axis.','observer_log outer bundle; event source current/src/model/behavior_wiring_sfun.m:46-61'};
    navSpec={
        'FE_Sample','exec:sample_ra_advance';
        'FE_DacFeedback','exec:dac_ct_feedback';
        'FE_DacTrial','exec:sar1_trial_ra_ct';
        'FE_ChargeReturn','exec:charge_return_ra_reset';
        'BE_RaAdvance','exec:sample_ra_advance';
        'BE_CtFeedback','exec:dac_ct_feedback';
        'BE_RaAzCt','exec:sar1_trial_ra_ct';
        'BE_RaReset','exec:charge_return_ra_reset';
        'SC_Due','exec:dac_ct_feedback';
        'SC_Prepare','exec:sar1_trial_ra_ct';
        'SC_Decide','exec:sar2_tracking';
        'FEold353','state:FE353';'FEnext353','state:FE353';
        'RAold48','state:RA48';'RAnext48','state:RA48';
        'SARold51','state:SAR51';'SARnext51','state:SAR51';
        'EventTime3','physical:observer_sample5'};
    bundle=repmat(struct('section','','signal','','group','','navigation_key','', ...
        'index',0,'width',0,'unit','', ...
        'meaning','','owner','','validity','','update_stage','','source',''),size(bundleSpec,1),1);
    nextIndex=1;
    for k=1:size(bundleSpec,1)
        q=bundleSpec(k,:);
        nav=find(strcmp(navSpec(:,1),q{1}),1);
        assert(~isempty(nav),'sar20:debugNavigationKey','Missing canonical navigation key for %s.',q{1});
        bundle(k)=struct('section',q{1},'signal',q{1},'group',q{2}, ...
            'navigation_key',navSpec{nav,2},'index',nextIndex, ...
            'width',q{3},'unit',q{5},'meaning',q{6},'owner',q{4}, ...
            'validity',q{7},'update_stage',q{8},'source',q{9});
        nextIndex=nextIndex+q{3};
    end
    assert(nextIndex-1==6329,'sar20:debugBundleWidth','The sample observer bundle must be 6329 doubles.');
    aliasSpec={
        'raw_log','RAW6','current/src/analysis/behavior_sample_debug.m:95-103','ADC raw record before public output alignment';
        'ready_log','Ready1','current/src/analysis/behavior_sample_debug.m:95-110','ADC RawReady event pulse';
        'front_log','FrontendObs7','current/src/analysis/behavior_sample_debug.m:95-103','FrontendObs7 at actual event groups';
        'back_log','BackendObs8','current/src/analysis/behavior_sample_debug.m:95-103','BackendObs8 at actual event groups';
        'control_log','Control13','current/src/analysis/behavior_sample_debug.m:95-103','Control13 at actual event groups';
        'event_log','EventLog2','current/src/analysis/behavior_sample_debug.m:70-90','Actual event ID/group-index pairs; actual times are timeseries.Time';
        'parent_event_log','ParentEventLog2','current/src/analysis/behavior_sample_debug.m:78-90','Parent event ID/group-index pairs for held transport joins';
        'record_log','PublicRecord6','current/src/analysis/behavior_record_view.m:14-29,42-77','Public output record words';
        'record_ready_log','PublicRecordReady1','current/src/analysis/behavior_record_view.m:14-19,55-65','Public RecordReady pulse';
        'code_log','Code20_1','current/src/analysis/behavior_record_view.m:55-65,73-77','Observed public output code20';
        'bank_code_valid_log','LegacyCodeValid1','current/src/analysis/behavior_sample_debug.m:218-240','Legacy Bank CodeValid qualification';
        'bank_meta_log','BankMeta9','current/src/analysis/behavior_sample_debug.m:218-234','Bank record metadata; unknown words remain uninterpreted'};
    logAliases=repmat(struct('logger_name','','group','','width',0,'meaning','','source',''),size(aliasSpec,1),1);
    for k=1:size(aliasSpec,1)
        logAliases(k)=struct('logger_name',aliasSpec{k,1},'group',aliasSpec{k,2}, ...
            'width',width(F,aliasSpec{k,2}),'meaning',aliasSpec{k,4},'source',aliasSpec{k,3});
    end
    displayAliases=struct('label','Bank 输出资格〔旧 CodeValid〕','legacy_name','CodeValid','group','LegacyCodeValid1', ...
        'signal','CodeValid_old_BankQualification', ...
        'meaning','Preserve legacy Bank output qualification semantics unchanged.');
    bundleInfo=struct('schema','sar20-observer-bundle/v1','logger_name','observer_log', ...
        'selection_parameter','P.debug.observer.sample_id','default_sample_id',5, ...
        'max_data_points',64,'expected_selected_sample_rows',49, ...
        'selection_window','inclusive [sample_id*Ts_s,(sample_id+1)*Ts_s]', ...
        'sections',bundle,'width',nextIndex-1);
    enumMap=struct('stage_kind_code',enum_map([1 2],{'advance','commit'}), ...
        'controller_stage_code',enum_map([1 2 3],{'due','prepare','decide'}), ...
        'controller_event_code',enum_map(1:17,{'cnv','coarse_latch','fine_prepare','fine_decide', ...
        'fine_feedback','ra_start','d2_prepare','d2_decide','d2_feedback','d2_end', ...
        'ta_compare','ta_feedback','tracking_end','raw_latch','release','reset','frame_ready'}), ...
        'frontend_context_event_code',frontend_context_map());
    bundleInfo.controller_event_slots=controllerEventSlots;
    R=struct('schema','sar20-debug-fields/v1','fields',F,'bundle',bundleInfo, ...
        'log_aliases',logAliases,'display_aliases',displayAliases, ...
        'enums',enumMap, ...
        'bundle_width',nextIndex-1,'trace_widths',struct( ...
        'FETrace1079',traceWidthFE,'BackendTrace164',traceWidthBE,'ControlTrace150',traceWidthSC), ...
        'trace_stages',{{'FE_Sample','FE_DacFeedback','FE_DacTrial','FE_ChargeReturn', ...
        'BE_RaAdvance','BE_CtFeedback','BE_RaAzCt','BE_RaReset', ...
        'SC_Due','SC_Prepare','SC_Decide'}});
end

function E=enum_map(codes,labels)
    E=repmat(struct('code',0,'label',''),numel(codes),1);
    for k=1:numel(codes),E(k)=struct('code',codes(k),'label',labels{k});end
end

function E=frontend_context_map()
    kind=[1 1 1 1 2 2 2 2];
    code=[0 1 2 3 0 1 2 3];
    label={'observe','capture_convert_join_optional_acquire','startup_acquire_open','reset', ...
        'observe','dac_commit','release_optional_acquire','reset'};
    E=repmat(struct('kind_code',0,'context_code',0,'label',''),numel(kind),1);
    for k=1:numel(kind)
        E(k)=struct('kind_code',kind(k),'context_code',code(k),'label',label{k});
    end
end

function F=one(F,group,signal,index,unit,reference,meaning,owner,validity,stage,source)
    F(end+1,1)=struct('group',group,'signal',signal,'index',index,'width',1,'unit',unit, ...
        'voltage_reference',reference,'meaning',meaning,'owner',owner, ...
        'validity',validity,'update_stage',stage,'source',source);
end

function F=range(F,group,base,firstIndex,count,unit,reference,meaning,owner,validity,stage,source)
    for k=1:count
        signal=sprintf('%s_%02d',base,k);
        F=one(F,group,signal,firstIndex+k-1,unit,reference,meaning,owner,validity,stage,source);
    end
end

function n=width(F,group)
    q=F(strcmp({F.group},group));
    assert(~isempty(q)&&isequal([q.index],1:numel(q)), ...
        'sar20:debugGroupWidth','Cannot derive width for incomplete registry group %s.',group);
    n=numel(q);
end
