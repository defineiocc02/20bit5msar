# SAR20 debug field registry / decoder patch

## Candidate boundary

- Candidate root: /tmp/sar20_debug_registry_luna/
- MATLAB source: src/sar20_debug_fields.m, src/sar20_debug_decode.m
- Unified add-file patch: REGISTRY.patch
- Intended baseline: current/models/SarAdc.slx, SHA-256 91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e
- Scope: current 9197 normal baseline only. This candidate does not enable CAAZ, ADI, new physical models, or make production-tree edits.
- The observer sidecar remains under /tmp/sar20_debug_observer_luna_20261105/. This patch consumes its 6329-word observer_log bundle schema. It does not claim a compiled Simulink port or a simulation result.

## Functions

### sar20_debug_fields

Version v1 (2026-11-05). Returns one scalar wrapper:

- R.fields: single registry for each ABI signal and trace header/event field.
- R.bundle: scalar bundle schema wrapper. It defines logger_name, max_data_points, expected_selected_sample_rows, selection_parameter, selection_window, width, and sections. R.bundle.sections is the canonical outer-section array with section, signal, group, navigation_key, index (1-based start), width, unit, meaning, owner, validity, update stage, and source. Navigation keys resolve through the independently verified model-navigation manifest; numeric SIDs are not copied here.
- R.log_aliases: actual SimulationOutput logger names mapped to registry groups, with widths, meanings, and sources. R.display_aliases maps the UI label Bank 输出资格〔旧 CodeValid〕 to LegacyCodeValid1.CodeValid_old_BankQualification without renaming or changing its value.
- R.bundle_width: 6329.
- R.bundle.controller_event_slots: 2 original-order accepted event slots per controller trace group.
- R.trace_widths: FETrace1079=1079, BackendTrace164=164, ControlTrace150=150.
- R.trace_stages: the 11 actual stage logger identities, named by stable stage key without embedding an SLX SID.
- R.enums: the single code-to-label map for stage kind, FE context event, controller stage, and controller event enums.
- Canonical ToWorkspace variable: R.bundle.logger_name = observer_log; selection is read from P.debug.observer.sample_id, default 5. The selected window expects 49 rows and has MaxDataPoints 64.

Each R.fields row carries group, signal, index (1-based within that ABI group), width, unit, voltage_reference, meaning, owner, validity, update_stage, and project-relative source. It includes FE353, RA48, SAR51, RAW6, Control13, BackendObs8, FrontendObs7, the three trace header/event groups, EventLog2, ParentEventLog2, Ready1, PublicRecord6, PublicRecordReady1, Code20_1, LegacyCodeValid1, and BankMeta9.

### sar20_debug_decode

Version v1 (2026-11-05). Main call:

D = sar20_debug_decode('observer_log', observerData, meta)

observerData is the saved real double matrix, one 6329-word outer bundle per row. meta is a table or struct aligned to those rows; it must include outerSimulationTime_s from timeseries.Time (or the legacy event_log.Time) for a real time-axis comparison.

Output:

- D.sections: exact numeric component matrices, split only by R.bundle.sections.
- D.section_meta: outer row metadata, section identity/presence, and missing reason.
- D.trace_headers, D.trace_header_meta: named header tables and aligned row metadata.
- D.events: one entry per each of the 11 trace stages; FE/BE stage rows preserve their headers and mark absent ordinal/index/bit as NaN with reason. SC entries retain both event slots in original outer-row/slot order and include the actual group ordinal, event code/index/bit, comparator values, decisions, and event-local flags. For a recorded calendar event, index/bit=-1 is the source not-applicable sentinel; an unused slot is all-NaN.
- D.taps: named per-tap structs with .values as a signal-named table, .raw as the exact source matrix, .meta as row-aligned source/tap/time/status metadata, .fields as the matching registry subset, and .missing as row/signal/index/reason.
- D.context.values: cycle_index, group_index, wiring-calculated modelEventTime_s, actual outerSimulationTime_s, modelEventTime_delta_s, bitwise-equality status, and outerRow.
- D.time_check: row-wise outer-time versus model-event-time comparison. The decoder does not replace the actual saved time axis with the wiring time word.
- D.completeness: isComplete/reason/source_row_count/expected_selected_sample_rows/max_data_points. Any row count other than 49 or more than 64 is marked incomplete; every supplied row is retained without clipping.

Direct registered-group calls are also supported, for example sar20_debug_decode('RAW6',rawRows,meta). Logger-name mapping is read from R.log_aliases; CodeValid is a display alias in R.display_aliases, not a log name.

The decoder accepts real double values and allows NaN. It rejects Inf and width mismatches instead of guessing orientation or padding missing columns. An absent direct group yields NaN rows plus a reason. Source NaN fields stay NaN and are reported with their registered validity condition. Stored doubles are not recomputed or converted before returning .raw.

## Canonical outer bundle order

| Section | Group | Start | Width | Navigation key | Source owner / stage |
|---|---|---:|---:|---|---|
| FE_Sample | FETrace1079 | 1 | 1079 | exec:sample_ra_advance | SampleCharge |
| FE_DacFeedback | FETrace1079 | 1080 | 1079 | exec:dac_ct_feedback | SampleCharge |
| FE_DacTrial | FETrace1079 | 2159 | 1079 | exec:sar1_trial_ra_ct | SampleCharge |
| FE_ChargeReturn | FETrace1079 | 3238 | 1079 | exec:charge_return_ra_reset | SampleCharge |
| BE_RaAdvance | BackendTrace164 | 4317 | 164 | exec:sample_ra_advance | shared RaCtState |
| BE_CtFeedback | BackendTrace164 | 4481 | 164 | exec:dac_ct_feedback | shared RaCtState |
| BE_RaAzCt | BackendTrace164 | 4645 | 164 | exec:sar1_trial_ra_ct | shared RaCtState |
| BE_RaReset | BackendTrace164 | 4809 | 164 | exec:charge_return_ra_reset | shared RaCtState |
| SC_Due | ControlTrace150 | 4973 | 150 | exec:dac_ct_feedback | SarState |
| SC_Prepare | ControlTrace150 | 5123 | 150 | exec:sar1_trial_ra_ct | SarState |
| SC_Decide | ControlTrace150 | 5273 | 150 | exec:sar2_tracking | SarState |
| FEold353 | FE353 | 5423 | 353 | state:FE353 | SampleCharge UnitDelay output, UD-old |
| FEnext353 | FE353 | 5776 | 353 | state:FE353 | SampleCharge UnitDelay input candidate, UD-next |
| RAold48 | RA48 | 6129 | 48 | state:RA48 | shared RaCtState UnitDelay output, UD-old |
| RAnext48 | RA48 | 6177 | 48 | state:RA48 | shared RaCtState UnitDelay input candidate, UD-next |
| SARold51 | SAR51 | 6225 | 51 | state:SAR51 | SarState UnitDelay output, UD-old |
| SARnext51 | SAR51 | 6276 | 51 | state:SAR51 | SarState UnitDelay input candidate, UD-next |
| EventTime3 | ObserverEventTime3 | 6327 | 3 | physical:observer_sample5 | [cycle,group_index,modelEventTime_s] |

The three stage trace schemas are derived from their registered header and state/observation widths: FE 6 + 3*353 + 2*7 = 1079; backend 4 + 3*48 + 2*8 = 164; controller 2*(24+51)=150. Total: 4*1079 + 4*164 + 3*150 + 2*353 + 2*48 + 2*51 + 3 = 6329 doubles.

## Time and event semantics

- The ToWorkspace logger is observer_log. Its registered MaxDataPoints is 64; the default selected sample window is expected to produce exactly 49 event rows. Missing/excess rows are marked incomplete and preserved; the decoder does not clip to 49.
- The last three bundle words contain scheduler cycle_index, 1-based group_index, and the wiring-calculated modelEventTime_s.
- The actual observer row time is the timeseries.Time metadata supplied by the caller. modelEventTime_s is compared against it; it never replaces it.
- P.input is declared differential in config/adc_parameters.m:72-76. FE/SAR use that differential behavioral coordinate; the model does not expose independent common mode or terminal voltages. Physical terminal mapping remains unrepresented.
- FETraceHeader6.context_event is copied unchanged from original Context(4) and must be interpreted jointly with kind_code using R.enums.frontend_context_event_code.
- Controller event codes are registered as 1=cnv, 2=coarse_latch, 3=fine_prepare, 4=fine_decide, 5=fine_feedback, 6=ra_start, 7=d2_prepare, 8=d2_decide, 9=d2_feedback, 10=d2_end, 11=ta_compare, 12=ta_feedback, 13=tracking_end, 14=raw_latch, 15=release, 16=reset, 17=frame_ready. stage_code is due=1, prepare=2, decide=3. Event slots are not sorted or deduplicated.
- BackendObs8.VX is RA differential output; BackendObs8.VY is CT comparator differential input. FrontendObs7.vtop_equiv_v is -Qres/Ctop and is not BackendObs8.Vtop. All voltage reference planes are in R.fields.
- The saved state vector on each FE/BE stage trace is that S-function's stage input; only the first stage input is sourced directly from the owner UnitDelay Q. Intermediate stage stateNext values feed later stages locally. Only FE_ChargeReturn and BE_RaReset final stateNext outputs are UnitDelay-input candidates; the separate FEold/FEnext/RAold/RAnext/SARold/SARnext sections are the actual external UnitDelay taps.
- ADC_RawReady (legacy ready_log), RAW6.valid, public RecordReady, PublicRecord6.valid, and CodeValid_old_BankQualification are separate signals. The legacy Bank qualification value is preserved without changing its meaning. code_log is an observed output code, not a recomputation.
- Controller event_index/event_bit preserve the source calendar's -1 not-applicable sentinel. Unused controller slots are entirely NaN. compare_valid/compare_late are the values supplied by the behavioral controller adapter (currently true/false defaults), not native comparator-valid/timeout measurements.
- predicted labels the backend old-command endpoint before endpoint command/CINC switching. local-after-command labels a locally produced observation/state after the command. UD-old is the UnitDelay output. UD-next is the UnitDelay input candidate. A candidate is not described as committed state.
- The 8 tracking comparisons and 7 physical feedback updates remain distinct in SAR51 and controller-event metadata.

## State, reset, and randomness

The registry and decoder are pure metadata/readout code. They keep no persistent state, do not call the model or physical kernels, do not add a delay, and make no random call.

- FE353 state belongs to SampleCharge. Runtime reset clears FE ownership/capture-valid tags but retains analog charge; cold initialization clears charge/tags.
- RA48 belongs to one shared RaCtState. Backend signal reset is not a global reset; AZ lifecycle tags and analog state retain the semantics specified by behavior_backend_step and behavior_backend_pack.
- SAR51 belongs to SarState. Controller reset reinitializes digital SAR state; release clears active/RA flags without clearing FE or shared RA analog charge.
- The decoder does not synthesize or refit missing records. Every missing value stays NaN with a source/validity reason.

## Source map and evidence boundary

Primary current implementation sources:

- current/src/frontend/behavior_frontend_pack.m, behavior_frontend_unpack.m, behavior_frontend_init.m, behavior_frontend_step.m, behavior_frontend_stage.m.
- current/src/physics/behavior_backend_pack.m, behavior_backend_unpack.m, behavior_backend_stage.m, behavior_backend_step.m.
- current/src/control/behavior_sar_pack.m, behavior_sar_unpack.m, behavior_sar_step.m, behavior_control_stage.m.
- current/src/model/behavior_wiring_sfun.m.
- current/src/analysis/behavior_sample_debug.m for legacy event, ready, per-sample logger widths/joins, and Bank fields.
- current/src/analysis/behavior_record_view.m for public record, public ready, and code_log widths/alignment.
- /tmp/sar20_debug_observer_luna_20261105/TRACE_CONTRACT.md for the candidate observer output schema and observer-side field capture locations.
- Model block navigation keys resolve through the read-only model-navigation manifest, which owns the current SLX paths/SIDs. This manifest does not claim that the observer candidate has been loaded or compiled.

## Static checks and hashes

- Static argument-count scan: 158 calls to the registry one() helper; all have 11 arguments in the declared order.
- Registry contains explicit runtime assertions for every required group width/index sequence and for the 6329-word bundle width.
- sar20_debug_fields.m SHA-256: cdd47f10b535eacea35df1be475cdf84e420076eaf9471e70bb2d32237ac5d98
- sar20_debug_decode.m SHA-256: 64bb3ea857136196bf53698afd8e79adf2d56b838e768440fb6508d377a2564f
- REGISTRY.patch SHA-256: 3ca21883821ff5e1206317667a2fe1d2660620079c18b79dafcc05497a7d7ba8

No MATLAB/Windows run was performed. This artifact is a source-only patch candidate, not execution, simulation equivalence, or N256 regression evidence.
