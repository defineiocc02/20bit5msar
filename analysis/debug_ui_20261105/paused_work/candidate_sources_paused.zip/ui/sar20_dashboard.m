function report=sar20_dashboard(action,varargin)
%SAR20_DASHBOARD Interactive, read-only-first R2024a debugging workspace.
% This UI reads source files, run manifests and saved sample views. It never
% evaluates a configuration factory, simulates, or edits the model by itself.
% Mutating controls call the existing public SAR20 actions explicitly.
    if nargin<1||isempty(action),action='home';end
    action=lower(char(action));
    root=project_root();
    fig=get_dashboard(root);
    switch action
        case 'home'
            payload=first_arg(varargin,[]);
            if isempty(payload),refresh_run_catalog(fig,[]);else,refresh_run_catalog(fig,payload);end
            refresh_home(fig,payload);
            select_tab(fig,'home');
        case 'results'
            payload=first_arg(varargin,[]);
            refresh_results(fig,payload);
            select_tab(fig,'results');
        case 'compare'
            payload=first_arg(varargin,[]);
            refresh_compare(fig,payload);
            select_tab(fig,'compare');
        case 'sample'
            payload=first_arg(varargin,[]);
            show_sample(fig,payload);
            select_tab(fig,'sample');
        case 'focus'
            payload=first_arg(varargin,[]);
            navigate_focus(fig,payload,varargin(2:end));
        otherwise
            error('SAR20Dashboard:Action','Unknown dashboard action: %s.',action);
    end
    report=struct('action',action,'status','dashboard_ready','project_root',root, ...
        'figure',fig);
end

function fig=get_dashboard(root)
    hits=findall(groot,'Type','figure','Tag','SAR20Dashboard');
    for k=1:numel(hits)
        if ~isvalid(hits(k)),continue;end
        state=hits(k).UserData;
        if isstruct(state)&&isfield(state,'root')&& ...
                strcmpi(canonical_path(state.root),canonical_path(root))
            fig=hits(k);return;
        end
    end
    session=read_session(root);
    fig=uifigure('Name','SAR20 | 模型 / 样本 / 对照调试台','Tag','SAR20Dashboard', ...
        'Position',session.position,'Color',[0.96 0.97 0.98]);
    top=uigridlayout(fig,[2 1]);
    top.RowHeight={48,'1x'};top.ColumnWidth={'1x'};top.Padding=[8 8 8 8];
    head=uigridlayout(top,[1 4]);head.Layout.Row=1;head.ColumnWidth={300,'1x',260,92};
    titleLabel=uilabel(head,'Text','SAR20 调试首页','FontSize',18,'FontWeight','bold');
    titleLabel.Layout.Column=1;
    statusLabel=uilabel(head,'Text','就绪','FontColor',[0.18 0.38 0.54], ...
        'HorizontalAlignment','left','WordWrap','on');statusLabel.Layout.Column=2;
    runDrop=uidropdown(head,'Items',{'(未选择历史运行)'}, ...
        'ValueChangedFcn',@(src,evt)select_run_from_dropdown(fig));runDrop.Layout.Column=3;
    browseRun=uibutton(head,'Text','选择运行…','ButtonPushedFcn', ...
        @(src,evt)browse_run(fig,'selected'));browseRun.Layout.Column=4;

    tabs=uitabgroup(top);tabs.Layout.Row=2;
    tabHome=uitab(tabs,'Title','首页');
    tabParameters=uitab(tabs,'Title','参数与派生量');
    tabSample=uitab(tabs,'Title','样本');
    tabCompare=uitab(tabs,'Title','运行对照');
    tabResults=uitab(tabs,'Title','结果');
    tabFields=uitab(tabs,'Title','字段说明');
    tabs.SelectionChangedFcn=@(src,evt)on_tab_changed(fig);

    ui=struct();ui.tabs=tabs;ui.tabHome=tabHome;ui.tabParameters=tabParameters;ui.tabSample=tabSample;
    ui.tabCompare=tabCompare;ui.tabResults=tabResults;ui.tabFields=tabFields;
    ui.statusLabel=statusLabel;ui.runDrop=runDrop;
    build_home(ui);
    build_parameters(ui);
    build_sample(ui);
    build_compare(ui);
    build_results(ui);
    build_fields(ui);
    state=struct('root',root,'ui',ui,'selectedRunPath',session.selected_run_path, ...
        'runCatalog',empty_catalog(),'sampleData',[], ...
        'sampleGroups',struct('name',{},'unit',{},'items',{}),'compareData',[], ...
        'sampleID',session.sample_id,'eventRow',session.event_row, ...
        'tabIndex',session.tab_index,'focusTarget','','selectedRunSelection',struct(), ...
        'snapshotChoices',struct('label',{},'stageName',{},'scope',{}), ...
        'restoreSampleSelection',session.tab_index==3,'runBusy',false,'homeReport',struct());
    fig.UserData=state;
    fig.CloseRequestFcn=@(src,evt)close_dashboard(fig);
    fig.SizeChangedFcn=@(src,evt)save_session_safely(fig);
    refresh_run_catalog(fig,[]);
    apply_session_to_figure(fig,session);
    refresh_home(fig);
    refresh_fields(fig);
    if session.tab_index==3,restore_sample_session(fig,session);end
end

function build_home(ui)
    g=uigridlayout(ui.tabHome,[3 2]);
    g.RowHeight={180,235,82};g.ColumnWidth={'1.1x','1x'};
    g.Padding=[8 8 8 8];g.RowSpacing=8;g.ColumnSpacing=8;

    p=uipanel(g,'Title','模型身份与导航');p.Layout.Row=1;p.Layout.Column=1;
    pg=uigridlayout(p,[2 1]);pg.RowHeight={'1x',40};pg.Padding=[6 4 6 4];
    ui.homeModel=uitextarea(pg,'Editable','off','Value',{'读取模型身份…'}, ...
        'FontSize',11);ui.homeModel.Layout.Row=1;
    b=uigridlayout(pg,[1 5]);b.Layout.Row=2;b.ColumnWidth={'1x','1.2x','1x','1.2x','1x'};
    ui.btnOpen=uibutton(b,'Text','打开模型','ButtonPushedFcn',@(s,e)call_sar20(fig_from(ui),'open'));
    ui.physicalKeys={'physical:sample_dac1','physical:residue','physical:ra_az', ...
        'physical:cinc_ct','physical:sar2_tracking','physical:digital','physical:lvds'};
    ui.physicalDrop=uidropdown(b,'Items',{'采集与 DAC1','真实电荷残差','共享 RA 与 AZ 存储', ...
        'CINC / CT 网络','SAR2 与 tracking','数字重构及输出','LVDS传输'}, ...
        'ValueChangedFcn',@(s,e)[]);
    ui.btnPhysical=uibutton(b,'Text','定位物理模块','ButtonPushedFcn', ...
        @(s,e)focus_from_dropdown(ui,'physical'));
    ui.executionKeys={'exec:sample_ra_advance','exec:dac_ct_feedback','exec:sar1_trial_ra_ct', ...
        'exec:residue_ct_compare','exec:sar_decision_tracking','exec:charge_return_ra_reset'};
    ui.executionDrop=uidropdown(b,'Items',{'SampleRaAdvance','DacCtFeedback','Sar1TrialRaCt', ...
        'ResidueCtCompare','SarDecisionTracking','ChargeReturnRaReset'});
    ui.btnExecution=uibutton(b,'Text','定位执行阶段','ButtonPushedFcn', ...
        @(s,e)focus_from_dropdown(ui,'execution'));

    p=uipanel(g,'Title','三层参数状态');p.Layout.Row=1;p.Layout.Column=2;
    pg=uigridlayout(p,[2 1]);pg.RowHeight={'1x',38};pg.Padding=[6 4 6 4];
    ui.homeConfig=uitextarea(pg,'Editable','off','Value',{'读取参数身份…'}, ...
        'FontSize',10);ui.homeConfig.Layout.Row=1;
    b=uigridlayout(pg,[1 4]);b.Layout.Row=2;b.ColumnWidth={'1x','1x','1x','1x'};
    ui.btnApplyFactory=uibutton(b,'Text','应用 factory 配置','ButtonPushedFcn', ...
        @(s,e)call_sar20(fig_from(ui),'apply'));
    ui.explicitVar=uieditfield(b,'text','Placeholder','base workspace 中的 P 变量名');
    ui.btnApplyExplicit=uibutton(b,'Text','显式应用 P','ButtonPushedFcn', ...
        @(s,e)apply_explicit(fig_from(ui)));
    ui.btnParameterDetails=uibutton(b,'Text','参数详情','ButtonPushedFcn', ...
        @(s,e)select_tab(fig_from(ui),'parameters'));

    p=uipanel(g,'Title','场景、开关与验证状态');p.Layout.Row=2;p.Layout.Column=1;
    pg=uigridlayout(p,[3 1]);pg.RowHeight={'1x',28,34};pg.Padding=[6 4 6 4];
    ui.featureTable=uitable(pg,'ColumnName',{'功能/场景','当前开关','验证状态'}, ...
        'ColumnEditable',[false false false],'RowName',{});ui.featureTable.Layout.Row=1;
    ui.scenario=uilabel(pg,'Text','场景：读取中','WordWrap','on');ui.scenario.Layout.Row=2;
    ui.coverageNote=uilabel(pg,'Text','P.ni coverage labels are not feature-level verification.','WordWrap','on','FontSize',9);
    ui.coverageNote.Layout.Row=3;

    p=uipanel(g,'Title','历史运行配置（与当前工作区分开）');p.Layout.Row=2;p.Layout.Column=2;
    pg=uigridlayout(p,[3 1]);pg.RowHeight={'1x',34,38};pg.Padding=[6 4 6 4];
    ui.homeRun=uitextarea(pg,'Editable','off','Value',{'尚未选择历史运行。'}, ...
        'FontSize',10);ui.homeRun.Layout.Row=1;
    ui.runModeNote=uilabel(pg,'Text','GUI Run 使用当前 ModelWorkspace.P，和历史 run 下拉不同。', ...
        'WordWrap','on','FontSize',9);ui.runModeNote.Layout.Row=2;
    b=uigridlayout(pg,[1 3]);b.Layout.Row=3;b.ColumnWidth={'1x','1x','1x'};
    ui.btnCheck=uibutton(b,'Text','检查当前模型','ButtonPushedFcn', ...
        @(s,e)call_sar20(fig_from(ui),'check'));
    ui.btnRun=uibutton(b,'Text','运行当前已应用配置','ButtonPushedFcn', ...
        @(s,e)call_sar20(fig_from(ui),'run'));
    ui.btnResults=uibutton(b,'Text','查看结果','ButtonPushedFcn', ...
        @(s,e)dispatch_results(fig_from(ui)));

    p=uipanel(g,'Title','实际操作入口');p.Layout.Row=3;p.Layout.Column=[1 2];
    b=uigridlayout(p,[1 5]);b.ColumnWidth={'1x','1x','1x','1x','1x'};b.Padding=[4 4 4 4];
    ui.btnSample=uibutton(b,'Text','查看所选样本','ButtonPushedFcn', ...
        @(s,e)dispatch_sample(fig_from(ui)));
    ui.btnCompare=uibutton(b,'Text','比较两次运行','ButtonPushedFcn', ...
        @(s,e)select_tab(fig_from(ui),'compare'));
    ui.btnFE=uibutton(b,'Text','FE353 保存状态','ButtonPushedFcn', ...
        @(s,e)call_focus_from_ui(ui,'state:FE353','FE353'));
    ui.btnSAR=uibutton(b,'Text','SAR51 保存状态','ButtonPushedFcn', ...
        @(s,e)call_focus_from_ui(ui,'state:SAR51','SAR51'));
    ui.btnRA=uibutton(b,'Text','RA48 保存状态','ButtonPushedFcn', ...
        @(s,e)call_focus_from_ui(ui,'state:RA48','RA48'));
end

function build_parameters(ui)
    g=uigridlayout(ui.tabParameters,[2 2]);g.RowHeight={190,'1x'};g.ColumnWidth={'1x','1x'};
    g.Padding=[8 8 8 8];g.RowSpacing=8;g.ColumnSpacing=8;
    p=uipanel(g,'Title','三层配置身份');p.Layout.Row=1;p.Layout.Column=1;
    gg=uigridlayout(p,[1 1]);ui.parameterLayers=uitable(gg,'Data',cell(0,0),'RowName',{});
    ui.parameterLayers.Layout.Row=1;ui.parameterLayers.Layout.Column=1;
    p=uipanel(g,'Title','关键参数 / Applied 与 Historical P');p.Layout.Row=1;p.Layout.Column=2;
    gg=uigridlayout(p,[2 1]);gg.RowHeight={34,'1x'};
    ui.btnFullParameters=uibutton(gg,'Text','查看完整P字段（搜索/选值）','ButtonPushedFcn', ...
        @(s,e)open_parameter_browser(fig_from(ui)));
    ui.parameterValues=uitable(gg,'Data',cell(0,0),'RowName',{});
    ui.parameterValues.Layout.Row=2;ui.parameterValues.Layout.Column=1;
    p=uipanel(g,'Title','参数修改与派生值（仅显示apply报告）');p.Layout.Row=2;p.Layout.Column=1;
    gg=uigridlayout(p,[1 1]);ui.parameterDerivation=uitextarea(gg,'Editable','off', ...
        'Value',{'变更/重算/保持字段及派生量尚未记录。'},'FontSize',10);
    ui.parameterDerivation.Layout.Row=1;ui.parameterDerivation.Layout.Column=1;
    p=uipanel(g,'Title','噪声约定');p.Layout.Row=2;p.Layout.Column=2;
    gg=uigridlayout(p,[1 1]);ui.noiseConvention=uitextarea(gg,'Editable','off', ...
        'Value',{'噪声口径未知；不根据 sigma 或 PSD 字段推断。'},'FontSize',10);
    ui.noiseConvention.Layout.Row=1;ui.noiseConvention.Layout.Column=1;
end

function build_sample(ui)
    g=uigridlayout(ui.tabSample,[2 2]);g.RowHeight={'1x',245};g.ColumnWidth={430,'1x'};
    g.Padding=[8 8 8 8];g.RowSpacing=8;g.ColumnSpacing=8;
    p=uipanel(g,'Title','真实事件表（保持原日志序；同刻事件不合并）');
    p.Layout.Row=[1 2];p.Layout.Column=1;
    pg=uigridlayout(p,[4 1]);pg.RowHeight={36,'1x',126,44};pg.Padding=[6 4 6 4];
    bar=uigridlayout(pg,[1 4]);bar.Layout.Row=1;bar.ColumnWidth={78,94,'1x',92};
    uilabel(bar,'Text','Sample ID');
    ui.sampleIDField=uieditfield(bar,'numeric','Value',5,'Limits',[0 Inf], ...
        'RoundFractionalValues','on');
    ui.sampleRunLabel=uilabel(bar,'Text','run: 未选','WordWrap','on');
    ui.btnLoadSample=uibutton(bar,'Text','载入真实样本','ButtonPushedFcn', ...
        @(s,e)dispatch_sample(fig_from(ui)));
    ui.eventTable=uitable(pg,'Data',cell(0,0),'RowName',{}, ...
        'CellSelectionCallback',@(s,e)sample_event_selected(fig_from(ui),e));
    ui.eventTable.ColumnSortable=false;
    ui.eventTable.Layout.Row=2;
    groupPanel=uipanel(pg,'Title','当前outerRow的FE/BE group-stage调用');groupPanel.Layout.Row=3;
    groupGrid=uigridlayout(groupPanel,[2 1]);groupGrid.RowHeight={24,'1x'};groupGrid.Padding=[2 2 2 2];
    ui.eventGroupNote=uilabel(groupGrid,'Text','stage group为group-scope；不映射成co-timed token ordinal。', ...
        'WordWrap','on','FontSize',8);ui.eventGroupNote.Layout.Row=1;
    ui.eventGroupTable=uitable(groupGrid,'Data',cell(0,0),'RowName',{});
    ui.eventGroupTable.ColumnSortable=false;ui.eventGroupTable.Layout.Row=2;
    foot=uigridlayout(pg,[1 2]);foot.Layout.Row=4;foot.ColumnWidth={'1x',130};
    ui.eventInfo=uilabel(foot,'Text','先选运行并载入样本。','WordWrap','on');
    ui.btnFirstD2=uibutton(foot,'Text','定位首次 D2','ButtonPushedFcn', ...
        @(s,e)select_first_d2(fig_from(ui)));

    p=uipanel(g,'Title','同一事件的实际观测（六个物理/单位分离组）');
    p.Layout.Row=1;p.Layout.Column=2;
    pg=uigridlayout(p,[2 1]);pg.RowHeight={34,'1x'};pg.Padding=[4 4 4 4];
    modeBar=uigridlayout(pg,[1 2]);modeBar.Layout.Row=1;modeBar.ColumnWidth={'1x',240};
    ui.waveformNote=uilabel(modeBar,'Text',['1 输入/held/sample[V]  2 DAC1残差[mV]/charge[fC]  3 RA VX[mV]/reference  ' ...
        '4 CT VY[mV]/噪声[µV]  5 判决bit/RAW counts  6 Code20/validity；仅画真实点、缩放只用于显示。'], ...
        'WordWrap','on','FontSize',9);
    ui.raRightMode=uidropdown(modeBar,'Items',{'AZ存储[µV]','RA target / Vtop reference[V]'}, ...
        'Value','AZ存储[µV]','ValueChangedFcn',@(s,e)sample_plot_mode_changed(fig_from(ui)));
    ag=uigridlayout(pg,[2 3]);ag.Layout.Row=2;ag.RowHeight={'1x','1x'};ag.ColumnWidth={'1x','1x','1x'};
    ag.Padding=[4 4 4 4];ag.RowSpacing=5;ag.ColumnSpacing=5;
    ui.axes=gobjects(1,6);
    for k=1:6
        ui.axes(k)=uiaxes(ag);ui.axes(k).Layout.Row=ceil(k/3);ui.axes(k).Layout.Column=mod(k-1,3)+1;
        grid(ui.axes(k),'on');ui.axes(k).Box='on';
        title(ui.axes(k),'等待样本');xlabel(ui.axes(k),'相对该样本 CNV (ns)');
    end
    p=uipanel(g,'Title','状态快照 / 有效性 / 判决');p.Layout.Row=2;p.Layout.Column=2;
    pg=uigridlayout(p,[3 1]);pg.RowHeight={36,104,'1x'};pg.Padding=[6 4 6 4];
    controls=uigridlayout(pg,[1 6]);controls.Layout.Row=1;controls.ColumnWidth={72,110,75,'1x',60,120};
    uilabel(controls,'Text','状态所有者');
    ui.snapshotOwner=uidropdown(controls,'Items',{'FE353','RA48','SAR51'}, ...
        'ValueChangedFcn',@(s,e)snapshot_owner_changed(fig_from(ui)));
    uilabel(controls,'Text','阶段/范围');
    ui.snapshotStageName=uidropdown(controls,'Items',{'请选择stage…'},'Value','请选择stage…', ...
        'ValueChangedFcn',@(s,e)refresh_snapshot(fig_from(ui)));
    uilabel(controls,'Text','快照阶段');
    ui.snapshotStage=uidropdown(controls,'Items',{'old','advanced','after_command','next'}, ...
        'Value','old','ValueChangedFcn',@(s,e)refresh_snapshot(fig_from(ui)));
    ui.validityText=uitextarea(pg,'Editable','off','Value',{'Bank 输出资格〔旧 CodeValid〕、RecordReady、RAW.valid、有效 record event 分开显示。'}, ...
        'FontSize',10);ui.validityText.Layout.Row=2;
    ui.snapshotValue=uitextarea(pg,'Editable','off','Value',{'快照未载入。'}, ...
        'FontSize',9);ui.snapshotValue.Layout.Row=3;
end

function build_compare(ui)
    g=uigridlayout(ui.tabCompare,[3 1]);g.RowHeight={72,120,'1x'};g.Padding=[8 8 8 8];g.RowSpacing=8;
    p=uipanel(g,'Title','选择两个已保存运行与对齐样本');p.Layout.Row=1;
    pg=uigridlayout(p,[1 8]);pg.ColumnWidth={48,'1x',78,48,'1x',78,78,105};pg.Padding=[4 4 4 4];
    uilabel(pg,'Text','运行 A');ui.compareA=uieditfield(pg,'text','Placeholder','run A 路径');
    ui.btnBrowseA=uibutton(pg,'Text','浏览…','ButtonPushedFcn',@(s,e)browse_run(fig_from(ui),'A'));
    uilabel(pg,'Text','运行 B');ui.compareB=uieditfield(pg,'text','Placeholder','run B 路径');
    ui.btnBrowseB=uibutton(pg,'Text','浏览…','ButtonPushedFcn',@(s,e)browse_run(fig_from(ui),'B'));
    ui.compareSampleID=uieditfield(pg,'numeric','Value',5,'Limits',[0 Inf], ...
        'RoundFractionalValues','on');
    ui.btnDoCompare=uibutton(pg,'Text','执行只读对照','ButtonPushedFcn', ...
        @(s,e)dispatch_compare(fig_from(ui)));
    p=uipanel(g,'Title','首个差异、缺字段与有效性边界');p.Layout.Row=2;
    pg=uigridlayout(p,[1 2]);pg.ColumnWidth={'1x','1x'};pg.Padding=[4 4 4 4];
    ui.compareSummary=uitextarea(pg,'Editable','off','Value',{'选择两个真实历史运行后执行对照。对照只读归档，不触发仿真。'}, ...
        'FontSize',10);
    ui.compareMissing=uitextarea(pg,'Editable','off','Value',{'未匹配/缺失字段会单独列出，不按“未发现差异”处理。'}, ...
        'FontSize',10);
    p=uipanel(g,'Title','已对齐事件 / 字段差异');p.Layout.Row=3;
    cgGrid=uigridlayout(p,[1 1]);cg=uitabgroup(cgGrid);cg.Layout.Row=1;cg.Layout.Column=1;
    ce=uitab(cg,'Title','事件 / 首个差异');cc=uitab(cg,'Title','输出码差');cn=uitab(cg,'Title','关键节点差');
    ge=uigridlayout(ce,[1 1]);ui.compareTable=uitable(ge,'Data',cell(0,0),'RowName',{});ui.compareTable.Layout.Row=1;ui.compareTable.Layout.Column=1;
    gc=uigridlayout(cc,[1 1]);ui.codeDeltaTable=uitable(gc,'Data',cell(0,0),'RowName',{});ui.codeDeltaTable.Layout.Row=1;ui.codeDeltaTable.Layout.Column=1;
    gn=uigridlayout(cn,[1 1]);ui.nodeDeltaTable=uitable(gn,'Data',cell(0,0),'RowName',{});ui.nodeDeltaTable.Layout.Row=1;ui.nodeDeltaTable.Layout.Column=1;
end

function build_results(ui)
    g=uigridlayout(ui.tabResults,[2 1]);g.RowHeight={'1x',120};g.Padding=[8 8 8 8];g.RowSpacing=8;
    p=uipanel(g,'Title','历史运行索引（读取 summary/registry；不执行模型）');p.Layout.Row=1;
    pgTable=uigridlayout(p,[1 1]);ui.resultsTable=uitable(pgTable,'Data',cell(0,0),'RowName',{}, ...
        'CellSelectionCallback',@(s,e)result_row_selected(fig_from(ui),e));
    ui.resultsTable.ColumnSortable=false;
    ui.resultsTable.Layout.Row=1;ui.resultsTable.Layout.Column=1;
    p=uipanel(g,'Title','选中运行信息');p.Layout.Row=2;
    pg=uigridlayout(p,[1 2]);pg.ColumnWidth={'1x',180};pg.Padding=[4 4 4 4];
    ui.resultsInfo=uitextarea(pg,'Editable','off','Value',{'没有找到根目录runs索引；可用顶部“选择运行…”指定已有目录。'}, ...
        'FontSize',10);
    b=uigridlayout(pg,[3 1]);b.ColumnWidth={'1x'};
    ui.btnResultsRefresh=uibutton(b,'Text','刷新索引','ButtonPushedFcn', ...
        @(s,e)dispatch_results(fig_from(ui)));
    ui.btnResultsSample=uibutton(b,'Text','查看样本 5','ButtonPushedFcn', ...
        @(s,e)dispatch_sample(fig_from(ui)));
    ui.btnResultsFolder=uibutton(b,'Text','选择运行目录…','ButtonPushedFcn', ...
        @(s,e)browse_run(fig_from(ui),'selected'));
end

function build_fields(ui)
    g=uigridlayout(ui.tabFields,[2 1]);g.RowHeight={56,'1x'};g.Padding=[8 8 8 8];g.RowSpacing=8;
    ui.fieldsNote=uilabel(g,'Text',['字段索引、单位、参考面、所有者、有效条件、更新阶段与源码位置来自统一 registry。' ...
        ' 缺失字段保留“未记录/待确认”，不补零。'],'WordWrap','on');
    p=uipanel(g,'Title','统一字段定义');p.Layout.Row=2;
    pgTable=uigridlayout(p,[1 1]);ui.fieldsTable=uitable(pgTable,'Data',cell(0,0),'RowName',{});
    ui.fieldsTable.Layout.Row=1;ui.fieldsTable.Layout.Column=1;
end

function refresh_home(fig,payload)
    if nargin<2,payload=[];end
    state=fig.UserData;ui=state.ui;root=state.root;
    selectedPath=field_any(payload,{'selected_run_path','selectedRunPath'},'');
    if isempty(selectedPath)
        selectedReport=field_any(payload,{'selected_run'},struct());
        if ~isstruct(selectedReport)||isempty(fieldnames(selectedReport))
            ps=field_any(payload,{'parameter_state'},struct());selectedReport=field_any(ps,{'selected_run'},struct());
        end
        selectedPath=field_any(selectedReport,{'run_path','runPath','path'},'');
    end
    selectedReport=field_any(payload,{'selected_run'},struct());
    if ~isstruct(selectedReport)||isempty(fieldnames(selectedReport))
        ps=field_any(payload,{'parameter_state'},struct());selectedReport=field_any(ps,{'selected_run'},struct());
    end
    if ~isempty(selectedPath),state.selectedRunPath=char(string(selectedPath));end
    if isstruct(selectedReport)&&~isempty(fieldnames(selectedReport))
        state.selectedRunSelection=selectedReport;
    end
    state.homeReport=payload;
    fig.UserData=state;
    info=project_status(root);
    baselineSha=value_text(field_any(payload,{'baseline_model_sha256','baseline_model_sha'},info.baselineSha));
    ui.homeModel.Value={sprintf('模型：%s',info.modelPath), ...
        sprintf('当前模型 SHA-256：%s',info.modelSha), ...
        sprintf('原基线 SHA：%s；当前身份按上行 SHA 核验',short_hash(baselineSha)), ...
        sprintf('版本：%s',info.modelVersion), ...
        sprintf('已加载模型：%s',info.modelLoadedStatus), ...
        '入口：SAR20.m（open/apply/check/run语义保持原样）', ...
        '物理导航只定位真实计算块/状态所有者，不复制计算核。'};
    p=info.pending;
    a=info.applied;
    live=info.live;
    selected=selected_run_descriptor(state);
    parameterState=field_any(payload,{'parameter_state'},struct());
    workspaceState=field_any(parameterState,{'workspace'},struct());
    if isempty(fieldnames(workspaceState)),workspaceState=field_any(payload,{'workspace_status'},struct());end
    appliedState=field_any(parameterState,{'applied'},struct());
    workspaceSummary=field_any(workspaceState,{'configuration_summary'},[]);
    if ~has_struct_fields(workspaceSummary),workspaceSummary=field_any(payload,{'configuration_summary'},[]);end
    appliedSummary=field_any(appliedState,{'configuration_summary'},[]);
    if has_struct_fields(appliedSummary),a.summary=parameter_summary_text(appliedSummary);end
    if has_struct_fields(workspaceSummary),live.reportedSummary=parameter_summary_text(workspaceSummary);
    else,live.reportedSummary='';end
    workspaceSource=value_text(field_any(workspaceState,{'status'},''));
    live.workspaceSource=workspaceSource;
    sourceSummary=workspaceSummary;
    if ~has_struct_fields(sourceSummary),sourceSummary=appliedSummary;end
    modified=field_any(workspaceState,{'modified_since_apply','status'},'');
    changedFields=field_any(workspaceState,{'changed_fields','workspace_changed_fields'}, ...
        field_any(payload,{'workspace_changed_fields'},[]));
    sourceStatus=field_any(payload,{'source_pending_status'},'');
    applyTx=field_any(payload,{'apply_transaction'},info.applyTransaction);
    if ~has_struct_fields(applyTx),applyTx=info.applyTransaction;end
    applyTxStatus=value_text(field_any(applyTx,{'status'},'未知'));
    applyTxInstructions=field_any(applyTx,{'recovery_instructions','recovery_message','message'},[]);
    applyPending=field_any(applyTx,{'pending'},[]);
    if isempty(applyPending),applyTxPending=contains(lower(applyTxStatus),'pending');
    elseif isscalar(applyPending),applyTxPending=logical(applyPending);
    else,applyTxPending=false;end
    operations=field_any(payload,{'operation_semantics'}, ...
        'apply准备并保存P/DecodeP；SAR20 run 使用当前模型Workspace.P；GUI Run 使用当前已加载P并绕过SAR20公开检查。');
    randomSeeds=field_any(payload,{'random_seeds','randomSeeds'}, ...
        field_any(sourceSummary,{'random_seeds'},[]));
    dirtyReport=field_any(payload,{'model_dirty_status'},[]);
    if ~isempty(sourceStatus)
        p.changeStatus=pretty_source_status(sourceStatus);
    end
    if isempty(randomSeeds),randomSeeds=live.seed;end
    ui.homeConfig.Value={ ...
        sprintf('待应用源：%s',p.summary), ...
        sprintf('待应用文件 bundle SHA-256：%s',p.hash), ...
        sprintf('自上次 apply 是否变化：%s',p.changeStatus), ...
        sprintf('已应用配置：%s',a.summary), ...
        sprintf('已应用来源：%s；记录时间：%s',a.source,a.utc), ...
        sprintf('当前 Workspace.P：%s',workspace_P_summary(live,workspaceSummary,workspaceSource)), ...
        sprintf('与 apply 记录比较：%s',workspace_modified_text(modified,live.workspaceLoaded,live.modelLoadedPath,live.compare,workspaceSource)), ...
        sprintf('Workspace 改动字段：%s',report_value(changedFields)), ...
        sprintf('P.digital 与 DecodeP 一致：%s',value_text_or_unknown(field_any(payload,{'DecodeP_matches_P_digital'},live.decodePMatches))), ...
        sprintf('模型 Dirty：%s；SimulationStatus：%s',report_value_or_local(dirtyReport,live.dirty),live.simulationStatus), ...
        sprintf('Apply事务：%s%s',applyTxStatus,conditional_text(applyTxPending, ...
            ['（pending）' conditional_text(isempty(applyTxInstructions), ...
            '；恢复需通过SAR20校验，不会自动重试', ['；' report_value(applyTxInstructions)])],'') ),...
        sprintf('随机种子分源：%s',seed_sources_text(randomSeeds,live.seed)), ...
        sprintf('apply / run 语义：%s',value_text(operations))};
    sourcePending=is_source_pending(p.changeStatus);
    modelDirty=is_model_dirty(dirtyReport,live.dirty);
    modelMismatch=~isempty(live.modelLoadedPath)&&~live.workspaceLoaded;
    simulationBusy=any(strcmpi(live.simulationStatus,{'running','paused','initializing','updating','terminating'}));
    runBusy=state.runBusy||simulationBusy;
    runBlocked=applyTxPending||modelDirty||modelMismatch||runBusy;
    runNote=workspace_modified_text(modified,live.workspaceLoaded,live.modelLoadedPath,live.compare,workspaceSource);
    if sourcePending,runNote=[runNote ' Factory源文件有未apply修改；本次仍使用当前已应用P，不自动apply。'];end
    if applyTxPending,runNote=[runNote ' Apply事务pending；请检查SID、模型clean且simulation stopped后再显式Apply。'];end
    if modelDirty,runNote=[runNote ' 模型Dirty，Run已禁用；先在Simulink中显式处理未保存修改。'];end
    if modelMismatch,runNote=[runNote ' 同名模型路径错误，Run已禁用。'];end
    if runBusy,runNote=[runNote ' 当前Simulink运行正在执行或暂停。'];end
    ui.runModeNote.Text=runNote;
    ui.btnRun.Text=run_button_text(modified,live.workspaceLoaded,live.compare,live.modelLoadedPath,sourcePending);
    if runBlocked,ui.btnRun.Enable='off';else,ui.btnRun.Enable='on';end
    if live.workspaceLoaded
        scenario=live.summary;if ~isempty(live.reportedSummary),scenario=live.reportedSummary;end
        ui.scenario.Text=sprintf('当前场景（工作区P）：%s    seed sources=%s',scenario,seed_sources_text(randomSeeds,live.seed));
    elseif strcmp(workspaceSource,'saved_apply_snapshot_model_hash_match')&&~isempty(workspaceSummary)
        ui.scenario.Text=sprintf('模型未加载；已保存且SHA匹配的apply P：%s    seed sources=%s', ...
            live.reportedSummary,seed_sources_text(randomSeeds,live.seed));
    else
        ui.scenario.Text=sprintf('模型未加载；最近 apply 记录场景：%s    seed sources=%s', ...
            live.appliedFallback,seed_sources_text(randomSeeds,live.seed));
    end
    switches=field_any(sourceSummary,{'feature_switches'},[]);
    ui.featureTable.Data=feature_rows(live,selected,a,switches,sourceSummary);
    coverage=field_any(payload,{'nonideality_flags'},field_any(sourceSummary,{'nonideality_flags'},[]));
    coverageScope=field_any(payload,{'nonideality_flag_scope'}, ...
        field_any(sourceSummary,{'nonideality_flag_scope'}, ...
        'P.ni 是保存参数中的coverage label，不是feature-level verification'));
    if isempty(coverage)
        coverageSource=live.raw;if ~live.workspaceLoaded,coverageSource=a.raw;end
        coverage=field_any(coverageSource,{'ni'},[]);
    end
    ui.coverageNote.Text=sprintf('P.ni coverage flags：%s；scope：%s', ...
        report_value(coverage),value_text(coverageScope));
    refresh_parameters(fig,payload,info);
    if isempty(selected.path)
        ui.homeRun.Value={'Selected run ID：未选择', ...
            '历史配置 P：未载入', ...
            '历史运行查看不会启动仿真或执行物理计算。'};
    else
        ui.homeRun.Value={sprintf('Selected run ID：%s',selected.id), ...
            sprintf('历史配置 P：%s',selected.config), ...
            sprintf('运行状态：%s；样本数：%s',selected.status,selected.records), ...
            sprintf('源模型 SHA：%s',selected.modelSha), ...
            sprintf('P SHA：%s；DecodeP SHA：%s；P身份：%s',selected.Psha,selected.DecodePsha,selected.identityStatus), ...
            sprintf('parameters.mat SHA：%s；选择来源：%s',selected.matSha,selected.selectionSource), ...
            sprintf('该run Workspace状态：%s；改动字段：%s',selected.workspaceChangeStatus, ...
                report_value(selected.workspaceChangedFields)), ...
            sprintf('observer contract：%s；SHA=%s；path=%s',selected.observerContractStatus, ...
                selected.observerContractSha,selected.observerContractPath), ...
            '此处配置来自所选 run 的 parameters.mat，和当前已应用 Workspace.P 分开。'};
    end
    set_status(fig,'首页已刷新；源配置文件只读，不会自动执行 factory。');
end

function refresh_results(fig,payload)
    state=fig.UserData;
    selectedPath=field_any(payload,{'selected_run_path','selectedRunPath'},'');
    if isempty(selectedPath)
        selectedReport=field_any(payload,{'selected_run'},struct());
        selectedPath=field_any(selectedReport,{'run_path','runPath','path'},'');
    end
    if ~isempty(selectedPath),state.selectedRunPath=char(string(selectedPath));end
    selectedReport=field_any(payload,{'selected_run'},struct());
    if isstruct(selectedReport)&&~isempty(fieldnames(selectedReport)),state.selectedRunSelection=selectedReport;end
    catalog=discover_runs(state.root,payload);
    state.runCatalog=catalog;
    fig.UserData=state;
    rebuild_run_dropdown(fig);
    if isempty(catalog)
        fig.UserData.ui.resultsTable.Data=cell(0,0);
        fig.UserData.ui.resultsInfo.Value={ ...
            '当前未在项目根 runs/ 下发现可索引运行。', ...
            '使用“选择运行…”加载外部归档 run。只读取 summary.json / parameters.mat；不启动仿真。'};
    else
        rows=cell(numel(catalog),7);
        for k=1:numel(catalog)
            rows(k,:)={catalog(k).id,catalog(k).status,catalog(k).records, ...
                catalog(k).config,catalog(k).modelSha,catalog(k).observerContractStatus,catalog(k).path};
        end
        fig.UserData.ui.resultsTable.ColumnName={'run ID','status','records','config','model SHA','observer contract','run path'};
        fig.UserData.ui.resultsTable.Data=rows;
        fig.UserData.ui.resultsInfo.Value={'历史 run 元数据只读；载入样本时再读取指定 parameters.mat 与 simout.mat。', ...
            '完整运行配置只显示为所选 run 的第三层 P，不回写当前模型工作区。'};
    end
    set_status(fig,sprintf('结果索引：%d 个可用运行。',numel(catalog)));
end

function refresh_compare(fig,payload)
    state=fig.UserData;ui=state.ui;
    if nargin>=2&&~isempty(payload)
        state.compareData=payload;fig.UserData=state;
        render_compare_data(fig,payload);
        return;
    end
    if isempty(ui.compareA.Value)&&~isempty(state.selectedRunPath),ui.compareA.Value=state.selectedRunPath;end
    if isempty(ui.compareB.Value)&&numel(state.runCatalog)>=2
        idx=find(~strcmp({state.runCatalog.path},state.selectedRunPath),1);
        if isempty(idx),idx=2;end
        ui.compareB.Value=state.runCatalog(idx).path;
    end
    set_status(fig,'对照准备就绪。选择两个归档运行后点击“执行只读对照”。');
end

function render_compare_data(fig,C)
    state=fig.UserData;ui=state.ui;
    first=field_any(C,{'first_difference','firstDifference','first_mismatch','firstMismatch'},[]);
    missing=field_any(C,{'missing_signals','missing_fields','missingFields','unmatched_fields','unmatchedFields'},[]);
    runA=field_any(C,{'run_a','runA'},[]);runB=field_any(C,{'run_b','runB'},[]);
    sample=field_any(C,{'sample_id','sampleID'},[]);
    status=field_any(C,{'status'},'未返回');statusText=value_text(status);
    if ~isempty(missing)&&contains(lower(statusText),'pass')
        statusText='不可判为通过：report同时含有未匹配/缺失字段';
    end
    header={['对照状态：' statusText], ...
        ['运行 A：' describe_run(runA)],['运行 B：' describe_run(runB)], ...
        '跨运行只读语义对照。未匹配信号独立列出；缺字段不视为通过。'};
    if ~isempty(sample),header{end+1}=sprintf('sample ID：%s',value_text(sample));end
    alignment=field_any(C,{'alignment_key','alignmentKey'},[]);
    if ~isempty(alignment),header{end+1}=['对齐键：' value_text(alignment)];end
    if isempty(first),header{end+1}='首个差异：没有返回/没有记录';
    else,header{end+1}=['首个差异：' first_difference_text(first)];end
    ui.compareSummary.Value=header;
    if isempty(missing),ui.compareMissing.Value={'缺字段：未返回列表（不能据此称为零缺失）。'};
    else,ui.compareMissing.Value=describe_missing(missing);end
    diffs=field_any(C,{'differences','diffs','aligned_events','alignedEvents'},[]);
    if isempty(diffs),diffs=first;end
    set_compare_table(ui.compareTable,diffs);
    set_compare_table(ui.codeDeltaTable,field_any(C,{'code_delta','codeDelta','output_code_delta'},[]));
    set_compare_table(ui.nodeDeltaTable,field_any(C,{'node_deltas','nodeDeltas','key_node_deltas'},[]));
    set_status(fig,'已显示归档运行对照；当前未启动任何仿真。');
end

function txt=describe_run(run)
    if isempty(run),txt='身份未记录';return;end
    if ischar(run)||isstring(run),txt=value_text(run);return;end
    id=field_any(run,{'run_id','runID','id'},'未知');
    path=field_any(run,{'run_path','runPath','path'},'未知');
    cfg=field_any(run,{'configuration_summary','config_summary','config_sha256'},'未知');
    model=field_any(run,{'model_sha256','modelSha256'},'未知');
    txt=sprintf('id=%s; config=%s; modelSHA=%s; path=%s', ...
        value_text(id),value_text(cfg),short_hash(value_text(model)),value_text(path));
end

function txt=first_difference_text(first)
    if isstruct(first)&&numel(first)>1,first=first(1);end
    if ~isstruct(first),txt=value_text(first);return;end
    fields={'sample_id','epoch','event_ordinal','phase','semantic_field','unit','value_a','value_b','delta'};
    parts={};
    for k=1:numel(fields)
        v=field_any(first,fields{k},[]);if ~isempty(v),parts{end+1}=[fields{k} '=' value_text(v)];end %#ok<AGROW>
    end
    if isempty(parts),txt=value_text(first);else,txt=strjoin(parts,' | ');end
end

function lines=describe_missing(missing)
    if istable(missing)
        rows=table2struct(missing);lines=describe_missing(rows);return;
    elseif isstruct(missing)
        lines=cell(numel(missing),1);
        for k=1:numel(missing)
            field=field_any(missing(k),{'semantic_field','field','signal'},'字段未命名');
            ra=field_any(missing(k),{'runA','run_a','reasonA'},'未记录');
            rb=field_any(missing(k),{'runB','run_b','reasonB'},'未记录');
            lines{k}=sprintf('%s | A:%s | B:%s',value_text(field),value_text(ra),value_text(rb));
        end
    else
        lines=lines_for_value(missing);
    end
    if isempty(lines),lines={'缺字段列表为空'};end
end

function set_compare_table(control,data)
    if istable(data)
        names=data.Properties.VariableNames;cells=table2cell(data);
    elseif isstruct(data)&&~isempty(data)
        t=struct2table(data);names=t.Properties.VariableNames;cells=table2cell(t);
    elseif iscell(data)
        names={};cells=data;
    else
        control.Data=cell(0,0);return;
    end
    for r=1:size(cells,1)
        for c=1:size(cells,2),cells{r,c}=value_text(cells{r,c});end
    end
    control.ColumnName=names;control.Data=cells;
end

function show_sample(fig,D)
    state=fig.UserData;ui=state.ui;
    if isempty(D)||~isstruct(D)
        set_status(fig,'样本尚未加载。请先选择真实运行，并点击“载入真实样本”。');
        return;
    end
    state.sampleData=D;
    state.sampleGroups=waveform_groups(D);
    sid=field_any(D,{'sample_id','sampleID','id'},[]);
    if isempty(sid)&&isfield(D,'sample')&&isstruct(D.sample),sid=field_any(D.sample,{'id','sample_id'},[]);end
    if isempty(sid),sid=state.sampleID;end
    state.sampleID=double(sid);
    runPath=field_any(D,{'run_path','runPath'},'');
    if ~isempty(runPath)
        if ~strcmpi(canonical_path(state.selectedRunPath),canonical_path(char(string(runPath))))
            state.selectedRunSelection=struct();
        end
        state.selectedRunPath=char(string(runPath));
    end
    events=field_any(D,{'events','event_table'},table());
    n=height_safe(events);
    firstD2=first_d2_row(D);
    if state.restoreSampleSelection&&state.eventRow>=1&&state.eventRow<=n
        % Restore only the saved event-table row identity; no physical state is restored.
    elseif isfinite(firstD2)&&firstD2>=1&&firstD2<=n,state.eventRow=firstD2;
    elseif state.eventRow<1||state.eventRow>n,state.eventRow=1;end
    state.restoreSampleSelection=false;
    fig.UserData=state;
    if ~isempty(runPath)&&isfolder(char(string(runPath)))
        refresh_run_catalog(fig,struct('run_path',char(string(runPath))));
        state=fig.UserData;ui=state.ui;
    end
    ui.sampleIDField.Value=state.sampleID;
    ui.eventTable.Data=events;
    if isempty(state.selectedRunPath),runLabel='run: view已加载';
    else,runLabel=['run: ' run_id_from_path(state.selectedRunPath)];end
    ui.sampleRunLabel.Text=[runLabel ' | ' sample_keys_text(D)];
    refresh_sample(fig);
    set_status(fig,sprintf('样本 ID %g 已从归档读取；切换样本/重画不会运行模型。',state.sampleID));
end

function restore_sample_session(fig,session)
    if isempty(session.selected_run_path)||~isfolder(session.selected_run_path)
        set_status(fig,'已恢复样本页位置；历史 run 路径不可用，请重新选择运行目录。');return;
    end
    if exist('sar20_debug_sample','file')~=2
        set_status(fig,'已恢复run/sample/event选择；样本读取器未载入，点击“载入真实样本”重试。');return;
    end
    try
        D=sar20_debug_sample(session.selected_run_path,session.sample_id);
        show_sample(fig,D);
        state=fig.UserData;
        refresh_sample(fig);
        set_status(fig,sprintf('已从归档恢复 run/sample/event：%s / %g / row %d；未运行模型。', ...
            run_id_from_path(session.selected_run_path),session.sample_id,state.eventRow));
    catch ex
        set_status(fig,['样本会话恢复失败（未启动仿真）：' ex.message]);
    end
end

function refresh_sample(fig)
    state=fig.UserData;ui=state.ui;D=state.sampleData;
    if isempty(D)
        for k=1:numel(ui.axes),cla(ui.axes(k));title(ui.axes(k),'等待样本');grid(ui.axes(k),'on');end
        ui.validityText.Value={'Bank 输出资格〔旧 CodeValid〕：未加载', ...
            'RecordReady：未加载', 'RAW.valid：未加载', '有效 record event：未加载', ...
            '契约：同一条记录使用 RecordReady && RAW.valid；不改变旧 CodeValid 语义。'};
        return;
    end
    events=field_any(D,{'events','event_table'},table());
    n=height_safe(events);row=state.eventRow;
    if n>0&&row>=1&&row<=n
        selected=table_row(events,row);
        ui.eventInfo.Text=sprintf('日志原序行 %d / %d | %s | %s',row,n, ...
            event_summary(selected),decision_summary(D,selected,row));
        plot_sample_traces(ui.axes,state.sampleGroups,events,row,ui.raRightMode.Value);
        update_validity(ui.validityText,D,selected);
        update_event_group_view(ui,D,row);
    else
        ui.eventInfo.Text='当前样本没有事件记录。';
        for k=1:numel(ui.axes),cla(ui.axes(k));title(ui.axes(k),'未记录');end
        update_validity(ui.validityText,D,struct());
        update_event_group_view(ui,D,NaN);
    end
    update_snapshot_controls(fig,D,row);
    refresh_snapshot(fig);
    save_session_safely(fig);
end

function update_event_group_view(ui,D,eventRow)
    groups=field_any(D,{'eventGroups','event_groups'},[]);
    if ~istable(groups)||height(groups)==0||~isfinite(eventRow)
        ui.eventGroupTable.Data=cell(0,0);
        ui.eventGroupNote.Text='group-stage调用未记录；不把FE/BE stage伪造成event token。';return;
    end
    events=field_any(D,{'events','event_table'},table());
    selected=table_row(events,eventRow);
    sampleID=field_any(selected,{'sampleID','sample_id'},NaN);
    epoch=field_any(selected,{'epoch'},NaN);
    groupIndex=field_any(selected,{'groupIndex','group_index'},NaN);
    eventGroupRow=field_any(selected,{'eventGroupRow','event_group_row'},NaN);
    mask=false(height(groups),1);
    vars=groups.Properties.VariableNames;
    eventRowsColumn=field_name(groups,{'eventRows','event_rows'});
    sampleColumn=field_name(groups,{'sampleID','selectedSampleID','sample_id'});
    epochColumn=field_name(groups,{'epoch'});
    groupColumn=field_name(groups,{'groupIndex','group_index'});
    sourceRowColumn=field_name(groups,{'eventGroupRow','event_group_row'});
    if ~isempty(sampleColumn),sampleValues=groups.(sampleColumn);else,sampleValues=[];end
    if ~isempty(epochColumn),epochValues=groups.(epochColumn);else,epochValues=[];end
    if ~isempty(groupColumn),groupValues=groups.(groupColumn);else,groupValues=[];end
    if ~isempty(sourceRowColumn),sourceValues=groups.(sourceRowColumn);else,sourceValues=[];end
    for k=1:height(groups)
        linked=false;
        if ~isempty(eventRowsColumn)
            links=table_cell(groups.(eventRowsColumn),k);
            if isnumeric(links),linked=any(double(links(:))==eventRow);end
        end
        tupleMatch=true;hasTuple=false;
        if ~isempty(sampleColumn)&&isfinite(double(sampleID))
            tupleMatch=tupleMatch&&isequaln(sampleValues(k),sampleID);hasTuple=true;
        end
        if ~isempty(epochColumn)&&isfinite(double(epoch))
            tupleMatch=tupleMatch&&isequaln(epochValues(k),epoch);hasTuple=true;
        end
        if ~isempty(groupColumn)&&isfinite(double(groupIndex))
            tupleMatch=tupleMatch&&isequaln(groupValues(k),groupIndex);hasTuple=true;
        end
        if ~isempty(sourceRowColumn)&&isfinite(double(eventGroupRow))
            tupleMatch=tupleMatch&&isequaln(sourceValues(k),eventGroupRow);hasTuple=true;
        end
        tupleMatch=tupleMatch&&hasTuple;
        mask(k)=linked||tupleMatch;
    end
    selectedGroups=groups(mask,:);
    if isempty(selectedGroups)
        ui.eventGroupTable.Data=cell(0,0);
        ui.eventGroupNote.Text='该outerRow/group未记录stage calls；同刻token不合并、不推定执行。';return;
    end
    ui.eventGroupTable.Data=selectedGroups;
    ui.eventGroupTable.ColumnName=vars;
    ui.eventGroupNote.Text=sprintf('groupIndex=%g / eventGroupRow=%g：group-scope阶段调用；FE/BE没有token ordinal时不归属单个co-timed event。', ...
        groupIndex,eventGroupRow);
end

function plot_sample_traces(axs,groups,events,eventRow,raRightMode)
    for k=1:numel(axs),cla(axs(k));hold(axs(k),'on');grid(axs(k),'on');box(axs(k),'on');end
    cnv=cnv_time(events);
    for k=1:numel(axs)
        if isempty(groups)||numel(groups)<k
            title(axs(k),'未记录');hold(axs(k),'off');continue;
        end
        g=groups(k);items=g.items;leftPlotted=false;rightPlotted=false;
        if k==3&&isstruct(items)&&~isempty(items)&&isfield(items,'side')&&isfield(items,'rightMode')
            if strcmp(raRightMode,'RA target / Vtop reference[V]')
                items=items(strcmp({items.side},'left')|strcmp({items.rightMode},'ra_reference'));
                g.rightLabel='V (RA target / Vtop reference; separate plane)';
            else
                items=items(strcmp({items.side},'left')|strcmp({items.rightMode},'az'));
                g.rightLabel='µV (AZ input-reference storage)';
            end
        end
        eventPointFound=false;missingNotes={};
        for j=1:numel(items)
            t=field_any(items(j),{'time_s','time'},[]);
            y=field_any(items(j),{'value'},[]);
            if isempty(t)||isempty(y)||~isnumeric(t)||~isnumeric(y),continue;end
            t=double(t(:));y=double(y(:));
            if numel(t)~=numel(y),continue;end
            x=(t-cnV_or_zero(cnv))*1e9;
            side=field_any(items(j),{'side'},'left');
            if strcmp(side,'right'),yyaxis(axs(k),'right');rightPlotted=true;
            else,yyaxis(axs(k),'left');leftPlotted=true;end
            scale=field_any(items(j),{'displayScale'},1);
            if isempty(scale)||~isscalar(scale)||~isfinite(scale),scale=1;end
            yDisplay=y*double(scale);
            signal=field_any(items(j),{'signal','name'},sprintf('signal_%d',j));
            tap=field_any(items(j),{'sourceTap','source_tap'},'来源未记录');
            logger=field_any(items(j),{'sourceLogger','logger'},'');
            reference=field_any(items(j),{'voltageReference','voltage_reference'},'');
            meaning=field_any(items(j),{'meaning','observationKind'},'');
            displayUnit=field_any(items(j),{'displayUnit'},field_any(items(j),{'unit'},'待确认'));
            label=sprintf('%s | ref=%s | tap=%s | logger=%s | %s', ...
                value_text(signal),value_text(reference),value_text(tap),value_text(logger),value_text(meaning));
            label=[label sprintf(' | display ×%g %s',double(scale),value_text(displayUnit))];
            plot(axs(k),x,yDisplay,'.','MarkerSize',9,'DisplayName',label);
            eventRows=field_any(items(j),{'eventRows','event_rows'},[]);
            exactRows=field_any(items(j),{'exactEventRow','eventRow','event_row'},[]);
            recorded=field_any(items(j),{'decodedTapRecorded','decoded_tap_recorded','recorded'},[]);
            rowReason=field_any(items(j),{'decodedReason','decoded_reason','reason'},'');
            available=field_any(items(j),{'available'},true);
            tapReason=field_any(items(j),{'tapReason','tap_reason'},'');
            [selectedPoints,pointReason]=trace_selected_event(eventRows,exactRows,recorded, ...
                rowReason,available,tapReason,y,eventRow,numel(t));
            sel=find(selectedPoints);
            if ~isempty(sel)
                eventPointFound=true;
                scatter(axs(k),x(sel),yDisplay(sel),36,'o','LineWidth',1.6, ...
                    'MarkerEdgeColor',[0.85 0.2 0.1],'DisplayName','当前事件');
            elseif ~isempty(pointReason)
                missingNotes{end+1}=sprintf('%s: %s',value_text(signal),pointReason); %#ok<AGROW>
            end
        end
        if isfinite(cnv)
            selected=table_row(events,eventRow);evT=field_any(selected,{'time_s','time'},NaN);
            if isfinite(evT),xline(axs(k),(double(evT)-cnv)*1e9,'--','Color',[0.85 0.2 0.1], ...
                    'HandleVisibility','off');end
        end
        panelTitle=g.name;
        if k==3&&strcmp(raRightMode,'RA target / Vtop reference[V]')
            panelTitle='RA VX / RA target and Vtop reference';
        end
        title(axs(k),panelTitle,'Interpreter','none');
        yyaxis(axs(k),'left');ylabel(axs(k),g.leftLabel,'Interpreter','none');
        if ~isempty(g.rightLabel),yyaxis(axs(k),'right');ylabel(axs(k),g.rightLabel,'Interpreter','none');end
        if isfinite(cnv),xlabel(axs(k),'相对该样本 CNV (ns)');
        else,xlabel(axs(k),'仿真时间 (ns；CNV未记录)');end
        if leftPlotted||rightPlotted,legend(axs(k),'Location','best','Interpreter','none');
        else,title(axs(k),[g.name '：未记录']);end
        if ~eventPointFound||~isempty(missingNotes)
            if ~isempty(missingNotes)
                missingNotes=unique(missingNotes,'stable');shown=missingNotes(1:min(3,numel(missingNotes)));
                missingText=['未记录/未执行：' strjoin(shown,'；')];
                if numel(missingNotes)>numel(shown),missingText=[missingText sprintf('；另有%d字段未记录',numel(missingNotes)-numel(shown))];end
            else
                missingText='当前事件：无精确logger row关联';
            end
            text(axs(k),0.01,0.98,missingText,'Units','normalized','VerticalAlignment','top', ...
                'Color',[0.68 0.23 0.13],'FontSize',8,'Interpreter','none');
        end
        hold(axs(k),'off');
    end
end

function groups=waveform_groups(D)
    raw=field_any(D,{'traces','waveforms','taps'},[]);
    groups=struct('name',{},'panel',{},'leftLabel',{},'rightLabel',{},'items',{});
    if isempty(raw),return;end
    if isstruct(raw)&&isfield(raw,'values')
        groups=waveform_groups_from_taps(raw);
        return;
    end
    if isstruct(raw)&&isfield(raw,'group')
        keys=cell(1,numel(raw));names=cell(1,numel(raw));units=cell(1,numel(raw));
        for k=1:numel(raw)
            names{k}=value_text(field_any(raw(k),{'group'},'未命名组'));
            units{k}=value_text(field_any(raw(k),{'unit','units'},'待确认'));
            keys{k}=[names{k} char(0) units{k}];
        end
        [uniqueKeys,first]=unique(keys,'stable');
        for k=1:numel(uniqueKeys)
            mask=strcmp(keys,uniqueKeys{k});
            groups(end+1)=struct('name',names{first(k)},'panel',k,'leftLabel',units{first(k)}, ...
                'rightLabel','','items',raw(mask)); %#ok<AGROW>
        end
    elseif isstruct(raw)&&isscalar(raw)
        names=fieldnames(raw);
        order={'input','capture','dac1','residue','residual','ra','az','cinc','ct','vy','sar','decision','raw','output'};
        rank=ones(size(names))*100;
        for k=1:numel(names)
            q=find(contains(lower(names{k}),order),1);if ~isempty(q),rank(k)=q;end
        end
        [~,ix]=sort(rank);names=names(ix);
        for k=1:numel(names)
            groups(end+1)=struct('name',names{k},'panel',k,'leftLabel', ...
                value_text(field_any(raw.(names{k}),{'unit','units'},'待确认')), ...
                'rightLabel','','items',raw.(names{k})); %#ok<AGROW>
        end
    elseif isstruct(raw)
        for k=1:numel(raw)
            nm=field_any(raw(k),{'name','group','physical_group'},sprintf('group_%d',k));
            groups(end+1)=struct('name',char(value_text(nm)),'panel',k,'leftLabel', ...
                value_text(field_any(raw(k),{'unit','units'},'待确认')),'rightLabel','','items',raw(k)); %#ok<AGROW>
        end
    end
end

function groups=waveform_groups_from_taps(taps)
    groups=struct('name',{},'panel',{},'leftLabel',{},'rightLabel',{},'items',{});
    template=struct('time_s',[],'value',[],'eventRows',[],'exactEventRow',[], ...
        'decodedTapRecorded',[],'decodedReason',[],'available',true,'tapReason','', ...
        'signal','','sourceTap','','sourceLogger','','observationKind','','unit','待确认', ...
        'voltageReference','','meaning','','group','','panel',0,'side','left','rightMode','', ...
        'displayScale',1,'displayUnit','');
    groupTemplate=struct('name','','panel',0,'leftLabel','','rightLabel','','items',repmat(template,0,1));
    names={'Input / held / voltage-level sample [V]','DAC1 residual / Qres','RA VX / AZ storage', ...
        'CT VY / comparator','SAR decision / RAW words','Code20 / readiness'};
    leftLabels={'V (input/source plane)','mV (DAC1 residual)','mV (RA VX reference)', ...
        'mV (VY physical/effective)','bits (SAR decision)','counts (Code20)'};
    rightLabels={'','fC (Qres)','µV (AZ storage)','µV (cmp offset/noise)', ...
        'counts (RAW D1/D2/DT)','bits (Ready / RAW.valid / BankQual)'};
    groups=repmat(groupTemplate,1,6);
    for panel=1:6
        groups(panel).name=names{panel};groups(panel).panel=panel;
        groups(panel).leftLabel=leftLabels{panel};groups(panel).rightLabel=rightLabels{panel};
    end
    series=repmat(template,0,1);
    for k=1:numel(taps)
        values=field_any(taps(k),{'values'},[]);
        if ~istable(values),continue;end
        t=field_any(taps(k),{'time_s','time'},[]);
        if isempty(t),t=table_column(values,{'time_s','time'});end
        if isempty(t),t=table_column(field_any(taps(k),{'metadata'},table()),{'time_s','time'});end
        if isempty(t),continue;end
        rows=field_any(taps(k),{'eventRows','event_rows'},[]);
        exactRows=field_any(taps(k),{'eventRow','event_row'},[]);
        if isempty(rows)
            meta=field_any(taps(k),{'metadata'},[]);
            rows=table_column(meta,{'eventRows','event_rows'});
            if isempty(rows),rows=table_column(meta,{'eventRow','event_row'});end
        end
        if isempty(exactRows),exactRows=table_column(field_any(taps(k),{'metadata'},[]),{'eventRow','event_row'});end
        meta=field_any(taps(k),{'metadata'},[]);
        recorded=field_any(taps(k),{'decoded_tap_recorded','decodedTapRecorded'},[]);
        if isempty(recorded),recorded=table_column(meta,{'decoded_tap_recorded','decodedTapRecorded'});end
        reasons=field_any(taps(k),{'decoded_reason','decodedReason'},[]);
        if isempty(reasons),reasons=table_column(meta,{'decoded_reason','decodedReason'});end
        defs=field_any(taps(k),{'fields','definitions'},[]);
        tapsource=field_any(taps(k),{'sourceTap','source_tap'},'');
        logger=field_any(taps(k),{'sourceLogger','logger'},'');
        obs=field_any(taps(k),{'observationKind','observation_kind'},'');
        group=field_any(taps(k),{'group'},'');
        vars=values.Properties.VariableNames;
        for j=1:numel(vars)
            signal=vars{j};
            if any(strcmpi(signal,{'time','time_s','eventRow','eventGroupRow','groupIndex', ...
                    'sampleID','epoch','phaseOrdinal','eventName','index','bit'})),continue;end
            y=values.(signal);if ~isnumeric(y)&&~islogical(y),continue;end
            def=field_definition(defs,signal);
            unit=value_text(field_any(def,{'unit','units'},'待确认'));
            meaning=value_text(field_any(def,{'meaning','semantics'},''));
            grp=value_text(field_any(def,{'group'},group));
            reference=value_text(field_any(def,{'voltage_reference','voltageReference','reference_plane'},''));
            [panel,side,scale,displayUnit,rightMode]=map_waveform_panel(grp,signal,unit,reference,meaning);
            if panel==0,continue;end
            s=template;s.time_s=double(t(:));s.value=double(y(:));s.eventRows=rows;s.exactEventRow=exactRows;
            s.decodedTapRecorded=recorded;s.decodedReason=reasons;
            s.available=field_any(taps(k),{'available'},true);s.tapReason=value_text(field_any(taps(k),{'reason'},''));
            s.signal=signal;s.sourceTap=value_text(tapsource);s.sourceLogger=value_text(logger);
            s.observationKind=value_text(obs);s.unit=unit;s.meaning=meaning;s.group=grp;
            s.voltageReference=reference;s.panel=panel;s.side=side;s.rightMode=rightMode;
            s.displayScale=scale;s.displayUnit=displayUnit;
            if numel(s.time_s)~=numel(s.value),continue;end
            series(end+1)=s; %#ok<AGROW>
        end
    end
    for panel=1:6
        items=series([series.panel]==panel);
        if isempty(items),continue;end
        if panel==5
            left=prioritize_panel_signals(items(strcmp({items.side},'left')),5);
            right=prioritize_panel_signals(items(strcmp({items.side},'right')),5);
            groups(panel).items=[left(:);right(:)];
        else
            left=prioritize_panel_signals(items(strcmp({items.side},'left')),5);
            right=prioritize_panel_signals(items(strcmp({items.side},'right')),5);
            groups(panel).items=[left(:);right(:)];
        end
    end
end

function [panel,side,scale,displayUnit,rightMode]=map_waveform_panel(group,signal,unit,reference,meaning)
    panel=0;side='left';scale=1;displayUnit=unit;rightMode='';
    s=lower(signal);m=lower(meaning);u=lower(unit);r=lower(reference);g=lower(group);
    descriptor=any(contains(s,{'input_offset','input_amplitude','input_frequency', ...
        'input_phase','dither_input','phase_rad','seed'}));
    if descriptor,return;end

    if any(contains(s,{'recordready','raw_valid','validrecord_event','oldcodevalidbank','bankqual','codevalid'}))|| ...
            (contains(g,'ready1')&&contains(s,'adc_rawready'))|| ...
            ((contains(g,'raw6')||contains(g,'publicrecord6'))&&strcmp(s,'valid'))|| ...
            (contains(g,'legacycodevalid1')&&strcmp(s,'codevalid'))|| ...
            (contains(g,'control13')&&contains(s,'raw_valid'))|| ...
            contains(m,'record readiness')||contains(m,'bank output qualification')
        panel=6;side='right';displayUnit='bit';return;
    end
    if any(contains(s,{'code20','public_code','output_code'}))
        panel=6;side='left';displayUnit='count';return;
    end
    if any(strcmp(g,{'raw6','publicrecord6'}))&&any(ismember(s,{'d1','d2','dt'}))
        panel=5;side='right';displayUnit='count';return;
    end
    if any(contains(s,{'decision','d1raw','d2raw','dtraw','sar_trial'}))||contains(m,'sar decision')
        panel=5;side='left';displayUnit='bit';return;
    end

    if contains(s,'qres')||contains(s,'residual_charge')||contains(m,'residual charge')|| ...
            contains(m,'signal charge')||any(strcmp(u,{'c','fc','pc'}))
        [scale,ok]=display_scale(unit,'fC');if ~ok,return;end
        panel=2;side='right';displayUnit='fC';return;
    end
    if any(contains(s,{'vres','resid','residue','vtop_equiv'}))||contains(m,'residual voltage')
        [scale,ok]=display_scale(unit,'mV');if ~ok,return;end
        panel=2;side='left';displayUnit='mV';return;
    end
    if any(contains(s,{'az_input','az_storage','az_half'}))||contains(r,'az storage')||contains(m,'az storage')
        [scale,ok]=display_scale(unit,'µV');if ~ok,return;end
        panel=3;side='right';rightMode='az';displayUnit='µV';return;
    end
    if any(strcmp(s,{'target_v','vtop'}))||contains(r,'ra command boundary')||contains(m,'ideal target')
        panel=3;side='right';rightMode='ra_reference';displayUnit=unit;return;
    end
    if any(contains(s,{'cmp_noise','comparator_noise','cmp_offset','comparator_offset'}))|| ...
            contains(m,'comparator noise')||contains(m,'comparator offset')
        [scale,ok]=display_scale(unit,'µV');if ~ok,return;end
        panel=4;side='right';displayUnit='µV';return;
    end
    if any(strcmp(s,{'vx','vx_v','ct_reset_baseline_vx_v'}))|| ...
            contains(m,'ra output differential vx')
        [scale,ok]=display_scale(unit,'mV');if ~ok,return;end
        panel=3;side='left';displayUnit='mV';return;
    end
    if any(contains(s,{'vy','cmp_effective_v','cmp_input_v','comparator_input_v'}))|| ...
            contains(m,'effective comparator input')
        [scale,ok]=display_scale(unit,'mV');if ~ok,return;end
        panel=4;side='left';displayUnit='mV';return;
    end
    if any(contains(s,{'coarse_input_v','held_v','sample_v','source_v','capture_v','input_v'}))|| ...
            contains(m,'held input')||contains(r,'differential input')||contains(r,'source input')|| ...
            contains(m,'sampled input')
        panel=1;side='left';displayUnit='V';return;
    end
end

function [scale,ok]=display_scale(unit,target)
    u=lower(strrep(value_text(unit),'μ','µ'));ok=true;scale=1;
    switch lower(target)
        case 'mv'
            if any(strcmp(u,{'v','volt','volts'})),scale=1e3;
            elseif any(strcmp(u,{'mv'})),scale=1;
            elseif any(strcmp(u,{'uv','µv'})),scale=1e-3;
            else,ok=false;end
        case 'µv'
            if any(strcmp(u,{'v','volt','volts'})),scale=1e6;
            elseif strcmp(u,'mv'),scale=1e3;
            elseif any(strcmp(u,{'uv','µv'})),scale=1;
            else,ok=false;end
        case 'fc'
            if strcmp(u,'c'),scale=1e15;
            elseif strcmp(u,'pc'),scale=1e3;
            elseif strcmp(u,'fc'),scale=1;
            else,ok=false;end
    end
end

function items=prioritize_panel_signals(items,limit)
    priority=zeros(1,numel(items));
    for k=1:numel(items)
        n=lower(items(k).signal);
        if contains(n,'coarse_input')||contains(n,'vtop_equiv')||contains(n,'cmp_effective'),priority(k)=1;
        elseif contains(n,'vres')||contains(n,'qres')||contains(n,'vx')||contains(n,'vy'),priority(k)=2;
        elseif contains(n,'decision')||contains(n,'d1')||contains(n,'d2')||contains(n,'dt'),priority(k)=3;
        else,priority(k)=10;end
    end
    [~,ix]=sortrows([priority(:),(1:numel(priority)).'],[1 2]);
    ix=ix(1:min(limit,numel(ix)));items=items(ix);
end

function txt=sample_keys_text(D)
    keys=field_any(D,{'keys','ids','identity'},struct());
    if isempty(keys)||~isstruct(keys),txt='sample/record ID关系未记录';return;end
    labels={'采集ID','采集目标ID','当前转换ID','RAW ID','输出记录ID','epoch'};parts={};
    aliases={{'acquisitionID','acquisition_id','captureID','capture_id'}, ...
        {'targetID','target_id','acquisitionTargetID','acquisition_target_id'}, ...
        {'currentConversionID','current_conversion_id','conversionID','conversion_id'}, ...
        {'rawID','raw_id','RAW_ID'}, ...
        {'outputRecordID','output_record_id','finalOutputID','final_output_id','recordID'}, {'epoch'}};
    for k=1:numel(aliases)
        v=field_any(keys,aliases{k},[]);if ~isempty(v),parts{end+1}=[labels{k} '=' value_text(v)];end %#ok<AGROW>
    end
    if isempty(parts),txt='sample/record ID关系未记录';else,txt=strjoin(parts,' ');end
end

function def=field_definition(defs,signal)
    def=struct();
    if istable(defs)
        key=field_name(defs,{'signal','name'});
        if ~isempty(key)
            ix=find(strcmpi(string(defs.(key)),string(signal)),1);
            if ~isempty(ix),def=table2struct(defs(ix,:));end
        end
    elseif isstruct(defs)
        for k=1:numel(defs)
            n=field_any(defs(k),{'signal','name'},'');
            if strcmpi(char(string(n)),signal),def=defs(k);return;end
        end
    end
end

function col=table_column(t,names)
    col=[];
    if istable(t)
        name=field_name(t,names);if ~isempty(name),col=t.(name);end
    elseif isstruct(t)
        if isscalar(t),col=field_any(t,names,[]);
        elseif ~isempty(t)
            name='';
            for k=1:numel(names),if isfield(t,names{k}),name=names{k};break;end,end
            if ~isempty(name),col={t.(name)}.';end
        end
    end
end

function mask=trace_event_mask(eventRows,exactRows,eventRow,n)
    mask=false(n,1);
    if isnumeric(exactRows)
        q=double(exactRows(:));
        if numel(q)==n,mask=isfinite(q)&q==eventRow;if any(mask),return;end,end
        if isscalar(q)&&n==1,mask=isfinite(q)&&q==eventRow;if any(mask),return;end,end
    end
    % When no explicit exact row exists, only a singleton event link is unique.
    if iscell(eventRows)
        if numel(eventRows)==n
            for k=1:n
                q=eventRows{k};if isnumeric(q)&&isscalar(q)&&isfinite(q),mask(k)=double(q)==eventRow;end
            end
        end
    elseif isnumeric(eventRows)
        q=double(eventRows(:));
        if numel(q)==n,mask=isfinite(q)&q==eventRow;end
    end
end

function [mask,reason]=trace_selected_event(eventRows,exactRows,recorded,rowReason,available,tapReason,values,eventRow,n)
    mask=false(n,1);reason='';
    if isscalar(available)&&~isempty(available)&&~logical(available)
        reason=value_text_or_unknown(tapReason);
        if strcmp(reason,'未记录'),reason='observer/logger tap标记为unavailable';end
        return;
    end
    exactMask=trace_event_mask(eventRows,exactRows,eventRow,n);
    indices=find(exactMask);
    if numel(indices)>1
        reason='多个logger row对应同一eventRow；未擅选';return;
    elseif numel(indices)==1
        q=indices(1);flag=per_row_value(recorded,q,n);
        if flag_is_false(flag)
            reason=reason_at_row(rowReason,q,n,'decoded_tap_recorded=false');return;
        end
        if ~isfinite(double(values(q)))
            reason=reason_at_row(rowReason,q,n,'该tap的实际观测值未记录/为NaN；未填充');return;
        end
        mask(q)=true;return;
    end
    [linked,ambiguous]=event_link_status(eventRows,eventRow,n);
    if ~isempty(linked)
        q=linked(1);reason=reason_at_row(rowReason,q,n,'同一仿真时刻多个token，tap未唯一关联到此phase');
    elseif ambiguous
        reason='同组logger row关联多个co-timed event token；没有精确phase映射';
    elseif ~isempty(tapReason)&&~strcmp(value_text(tapReason),'')
        reason=value_text(tapReason);
    else
        reason='本tap没有与此eventRow的精确关联记录';
    end
end

function [indices,ambiguous]=event_link_status(eventRows,eventRow,n)
    indices=[];ambiguous=false;
    if iscell(eventRows)&&numel(eventRows)==n
        for k=1:n
            q=eventRows{k};
            if ~isnumeric(q)||~any(double(q(:))==eventRow),continue;end
            if isscalar(q),indices(end+1)=k;else,ambiguous=true;end %#ok<AGROW>
        end
    elseif isnumeric(eventRows)&&numel(eventRows)==n
        q=double(eventRows(:));indices=find(q==eventRow);
    end
end

function value=per_row_value(values,index,n)
    value=[];
    if isempty(values),return;end
    if iscell(values)&&numel(values)==n,value=values{index};
    elseif (isnumeric(values)||islogical(values)||isstring(values))&&numel(values)==n,value=values(index);
    elseif isscalar(values),value=values;
    end
end

function tf=flag_is_false(value)
    tf=false;
    if isempty(value),return;end
    if islogical(value)||isnumeric(value),tf=isscalar(value)&&isfinite(double(value))&&double(value)==0;
    elseif ischar(value)||isstring(value)
        tf=any(strcmpi(char(string(value)),{'false','no','not_recorded','unavailable'}));
    end
end

function textOut=reason_at_row(reasons,index,n,fallback)
    q=per_row_value(reasons,index,n);
    if isempty(q)||strcmp(value_text(q),'')||strcmp(value_text(q),'null')
        textOut=fallback;
    else
        textOut=value_text(q);
    end
end

function update_validity(target,D,event)
    validity=field_any(D,{'validity'},struct());
    validityRecord=field_any(validity,{'selected'},struct());
    bank=field_any(event,{'oldCodeValidBank','old_code_valid_bank','bankCodeValid','CodeValid'}, ...
        field_any(validity,{'oldCodeValidBank','bank_output_qualification','bankCodeValid'}, ...
        field_any(validityRecord,{'oldCodeValidBank','bank_output_qualification','bankCodeValid'},[])));
    ready=field_any(event,{'RecordReady','recordReady','record_ready'}, ...
        field_any(validity,{'RecordReady','record_ready'},field_any(validityRecord,{'RecordReady','record_ready'},[])));
    raw=field_any(event,{'RAW_valid','RAW_valid_flag','raw_valid','RAWvalid'}, ...
        field_any(validity,{'RAW_valid','raw_valid'},field_any(validityRecord,{'RAW_valid','raw_valid'},[])));
    validRecord=field_any(event,{'validRecord','valid_record','validRecordEvent','validRecord_event'}, ...
        field_any(validity,{'validRecord','valid_record_event','validRecord_event'}, ...
        field_any(validityRecord,{'validRecord','valid_record_event','validRecord_event'},[])));
    recordID=field_any(validity,{'recordID','record_id','outputRecordID'}, ...
        field_any(validityRecord,{'recordID','record_id','outputRecordID'},[]));
    recordEpoch=field_any(validity,{'epoch','record_epoch'},field_any(validityRecord,{'epoch','record_epoch'},[]));
    recordTime=field_any(validity,{'time_s','record_time_s'},field_any(validityRecord,{'time_s','record_time_s'},[]));
    recordSource=field_any(validity,{'source','record_source'},field_any(validityRecord,{'source','record_source'},[]));
    readySource=field_any(validity,{'recordReadySignal','record_ready_signal','readySignal'}, ...
        field_any(validityRecord,{'recordReadySignal','record_ready_signal','readySignal'},[]));
    requestedID=field_any(validityRecord,{'selectedRequestedID','requestedID','requested_id'}, ...
        field_any(validity,{'selectedRequestedID','requestedID','requested_id'},[]));
    rawAligned=field_any(validityRecord,{'rawAligned','raw_aligned'},field_any(validity,{'rawAligned','raw_aligned'},[]));
    codeAligned=field_any(validityRecord,{'codeAligned','code_aligned'},field_any(validity,{'codeAligned','code_aligned'},[]));
    reason=field_any(validityRecord,{'reason'},field_any(validity,{'reason'},''));
    target.Value={ ...
        ['Bank 输出资格〔旧 CodeValid〕：' value_text_or_unknown(bank)], ...
        ['RecordReady：' value_text_or_unknown(ready)], ...
        ['RecordReady signal/source：' value_text_or_unknown(readySource)], ...
        ['RAW.valid：' value_text_or_unknown(raw)], ...
        ['对齐后有效 record event：' value_text_or_unknown(validRecord)], ...
        ['记录ID/epoch/time/source：' value_text_or_unknown(recordID) '/' ...
            value_text_or_unknown(recordEpoch) '/' value_text_or_unknown(recordTime) '/' ...
            value_text_or_unknown(recordSource)], ...
        ['requestedID/rawAligned/codeAligned：' value_text_or_unknown(requestedID) '/' ...
            value_text_or_unknown(rawAligned) '/' value_text_or_unknown(codeAligned)], ...
        '有效记录契约：同一条记录的 RecordReady && RAW.valid。旧 CodeValid 语义保持不变。', ...
        ['记录原因：' value_text_or_unknown(reason)],validity_explanation(bank,ready,raw,validity)};
end

function update_snapshot_controls(fig,D,row)
    state=fig.UserData;ui=state.ui;owners=snapshot_owner_names(D,row);
    if isempty(owners),owners={'FE353','RA48','SAR51'};end
    owner=ui.snapshotOwner.Value;
    if ~any(strcmp(owners,owner)),owner=owners{1};end
    state.snapshotChoices=snapshot_stage_choices(D,row,owner);fig.UserData=state;
    ui.snapshotOwner.Items=owners;
    ui.snapshotOwner.Value=owner;
    labels={'请选择stage…'};
    if ~isempty(state.snapshotChoices),labels=[labels {state.snapshotChoices.label}];end
    old=ui.snapshotStageName.Value;ui.snapshotStageName.Items=labels;
    exact=find(strcmp({state.snapshotChoices.scope},'exact-event'));
    if numel(exact)==1
        ui.snapshotStageName.Value=state.snapshotChoices(exact).label;
    elseif any(strcmp(labels,old))
        ui.snapshotStageName.Value=old;
    else
        ui.snapshotStageName.Value=labels{1};
    end
end

function snapshot_owner_changed(fig)
    state=fig.UserData;
    if isempty(state.sampleData),refresh_snapshot(fig);return;end
    update_snapshot_controls(fig,state.sampleData,state.eventRow);
    refresh_snapshot(fig);
end

function refresh_snapshot(fig)
    state=fig.UserData;ui=state.ui;D=state.sampleData;
    if isempty(D),ui.snapshotValue.Value={'快照未载入。'};return;end
    row=state.eventRow;owner=ui.snapshotOwner.Value;stage=ui.snapshotStage.Value;
    choiceIndex=find(strcmp({state.snapshotChoices.label},ui.snapshotStageName.Value),1);
    if isempty(choiceIndex)
        ui.snapshotValue.Value={sprintf('%s：请选择group/stage；此owner下没有唯一关联阶段。',owner), ...
            'FE/BE与UnitDelay group-scope状态不归属单个co-timed event。'};return;
    end
    choice=state.snapshotChoices(choiceIndex);
    snap=snapshot_record(D,row,owner,choice.stageName,choice.scope,stage);
    lines={sprintf('%s | %s | %s',owner,choice.stageName,stage)};
    lines{end+1}=['状态范围：' value_text(field_any(snap,{'scope'},choice.scope))];
    lines{end+1}=sprintf('可用：%s',value_text_or_unknown(field_any(snap,{'available'},[])));
    lines{end+1}=sprintf('来源位置：%s',value_text_or_unknown(field_any(snap,{'sourceTap','source_tap','source'},[])));
    reason=field_any(snap,{'reason'},'');if ~isempty(reason),lines{end+1}=['规则/缺失原因：' value_text(reason)];end
    alias=field_any(snap,{'aliasOf','alias_of'},'');if ~isempty(alias),lines{end+1}=['别名关系：' value_text(alias)];end
    value=field_any(snap,{'value'},[]);
    if isempty(value)
        lines{end+1}='数值：未记录（未复制其它阶段向量填充）。';
    elseif isnumeric(value)
        lines{end+1}=sprintf('数值形状：%s',mat2str(size(value)));
        lines{end+1}=['完整数值：' mat2str(value,8)];
    else
        lines{end+1}=['数值：' value_text(value)];
    end
    handoff=handoff_for_event(D,row,owner);
    if isempty(handoff)
        lines{end+1}='相邻有效执行 next → old：该事件未记录对应交接。';
    else
        lines{end+1}=['相邻有效执行 next → old：' value_text(handoff)];
    end
    ui.snapshotValue.Value=lines;
end

function snap=snapshot_record(D,row,owner,stageName,scope,phase)
    snap=struct('available',false,'scope',scope,'reason','未记录此阶段','sourceTap','未记录','value',[]);
    snapshots=field_any(D,{'snapshots'},[]);
    if isempty(snapshots),return;end
    if istable(snapshots),snapshots=table2struct(snapshots);end
    if isstruct(snapshots)
        candidates=[];
        event=table_row(field_any(D,{'events','event_table'},table()),row);
        group=event_group_identity(D,row);
        for k=1:numel(snapshots)
            own=field_any(snapshots(k),{'owner','stateOwner'},'');
            if ~owner_matches(own,owner),continue;end
            name=field_any(snapshots(k),{'stageName','stage_name','stageKey','stage_key'},'');
            if ~strcmp(char(string(name)),stageName),continue;end
            exact=field_any(snapshots(k),{'exactEvent','exact_event'},false);
            linked=event_row_linked(field_any(snapshots(k),{'eventRows','event_rows'},[]),row);
            if strcmp(scope,'exact-event')&&~isempty(exact)&&logical(exact(1))&&linked
                candidates(end+1)=k; %#ok<AGROW>
            elseif strcmp(scope,'group-stage')&&~isempty(exact)&&~logical(exact(1))&&snapshot_group_matches(snapshots(k),group)
                candidates(end+1)=k; %#ok<AGROW>
            end
        end
        if numel(candidates)>1
            snap=struct('available',false,'scope',scope,'reason','多个快照候选匹配owner/outerRow/stage；未擅选', ...
                'sourceTap','歧义','value',[]);
        elseif numel(candidates)==1
            eventSnap=snapshots(candidates(1));
            if isfield(eventSnap,phase)
                snap=eventSnap.(phase);
                if isstruct(snap),snap.scope=scope;end
            end
        end
    end
end

function choices=snapshot_stage_choices(D,row,owner)
    choices=struct('label',{},'stageName',{},'scope',{});
    snapshots=field_any(D,{'snapshots'},[]);if isempty(snapshots)||~isfinite(row),return;end
    if istable(snapshots),snapshots=table2struct(snapshots);end
    group=event_group_identity(D,row);
    for k=1:numel(snapshots)
        if ~owner_matches(field_any(snapshots(k),{'owner','stateOwner'},''),owner),continue;end
        name=value_text(field_any(snapshots(k),{'stageName','stage_name','stageKey','stage_key'},''));
        if isempty(name),continue;end
        exact=field_any(snapshots(k),{'exactEvent','exact_event'},false);
        if ~isempty(exact)&&logical(exact(1))&&event_row_linked(field_any(snapshots(k),{'eventRows','event_rows'},[]),row)
            scope='exact-event';
        elseif ~isempty(exact)&&~logical(exact(1))&&snapshot_group_matches(snapshots(k),group)
            scope='group-stage';
        else
            continue;
        end
        label=sprintf('%s [%s]',name,scope);
        if ~any(strcmp({choices.label},label))
            choices(end+1)=struct('label',label,'stageName',name,'scope',scope); %#ok<AGROW>
        end
    end
end

function group=event_group_identity(D,row)
    event=table_row(field_any(D,{'events','event_table'},table()),row);
    group=struct('sampleID',field_any(event,{'sampleID','sample_id'},[]), ...
        'epoch',field_any(event,{'epoch'},[]), ...
        'groupIndex',field_any(event,{'groupIndex','group_index'},[]), ...
        'eventGroupRow',field_any(event,{'eventGroupRow','event_group_row'},[]), ...
        'outerRow',[]);
    groups=field_any(D,{'eventGroups','event_groups'},[]);
    if ~istable(groups)||height(groups)==0,return;end
    matches=event_group_rows(D,row);
    if isempty(matches),return;end
    col=field_name(groups,{'outerRow','outer_row'});
    if isempty(col),return;end
    outerRows=groups.(col);values=unique(double(outerRows(matches)));
    if numel(values)==1&&isfinite(values(1)),group.outerRow=values(1);end
end

function matches=event_group_rows(D,eventRow)
    matches=[];groups=field_any(D,{'eventGroups','event_groups'},[]);
    if ~istable(groups)||height(groups)==0,return;end
    event=table_row(field_any(D,{'events','event_table'},table()),eventRow);
    sampleID=field_any(event,{'sampleID','sample_id'},[]);
    epoch=field_any(event,{'epoch'},[]);
    groupIndex=field_any(event,{'groupIndex','group_index'},[]);
    eventGroupRow=field_any(event,{'eventGroupRow','event_group_row'},[]);
    linksColumn=field_name(groups,{'eventRows','event_rows'});
    sampleColumn=field_name(groups,{'sampleID','selectedSampleID','sample_id'});
    epochColumn=field_name(groups,{'epoch'});
    groupColumn=field_name(groups,{'groupIndex','group_index'});
    sourceRowColumn=field_name(groups,{'eventGroupRow','event_group_row'});
    links=[];samples=[];epochs=[];groupValues=[];sourceRows=[];
    if ~isempty(linksColumn),links=groups.(linksColumn);end
    if ~isempty(sampleColumn),samples=groups.(sampleColumn);end
    if ~isempty(epochColumn),epochs=groups.(epochColumn);end
    if ~isempty(groupColumn),groupValues=groups.(groupColumn);end
    if ~isempty(sourceRowColumn),sourceRows=groups.(sourceRowColumn);end
    for k=1:height(groups)
        linked=false;
        if ~isempty(links)
            q=table_cell(links,k);if isnumeric(q),linked=any(double(q(:))==eventRow);end
        end
        tuple=true;hasTuple=false;
        if ~isempty(samples)&&~isempty(sampleID),tuple=tuple&&isequaln(samples(k),sampleID);hasTuple=true;end
        if ~isempty(epochs)&&~isempty(epoch),tuple=tuple&&isequaln(epochs(k),epoch);hasTuple=true;end
        if ~isempty(groupValues)&&~isempty(groupIndex),tuple=tuple&&isequaln(groupValues(k),groupIndex);hasTuple=true;end
        if ~isempty(sourceRows)&&~isempty(eventGroupRow)&&isfinite(double(eventGroupRow))
            tuple=tuple&&isequaln(sourceRows(k),eventGroupRow);hasTuple=true;
        end
        if linked||(hasTuple&&tuple),matches(end+1)=k;end %#ok<AGROW>
    end
end

function tf=snapshot_group_matches(snapshot,group)
    tf=false;
    outer=field_any(group,{'outerRow'},[]);snapshotOuter=field_any(snapshot,{'outerRow','observerOuterRow','outer_row'},[]);
    if isempty(outer)||isempty(snapshotOuter)||~isscalar(outer)||~isscalar(snapshotOuter)|| ...
            ~isequaln(double(outer),double(snapshotOuter)),return;end
    for pair={{'sampleID','sampleID'},{'epoch','epoch'},{'groupIndex','groupIndex'}}
        names=pair{1};expected=field_any(group,{names{2}},[]);actual=field_any(snapshot,{names{1}},[]);
        if ~isempty(expected)&&~isempty(actual)&&~isequaln(expected,actual),return;end
    end
    tf=true;
end

function tf=event_row_linked(eventRows,row)
    tf=false;
    if iscell(eventRows)
        for k=1:numel(eventRows),q=eventRows{k};if isnumeric(q)&&any(double(q(:))==row),tf=true;return;end,end
    elseif isnumeric(eventRows)
        tf=any(double(eventRows(:))==row);
    end
end

function tf=snapshot_group_matches(snapshot,group)
    tf=false;
    for pair={{'sampleID','sampleID'},{'epoch','epoch'},{'groupIndex','groupIndex'},{'eventGroupRow','eventGroupRow'},{'outerRow','outerRow'}}
        left=pair{1}{1};right=pair{1}{2};expected=field_any(group,{right},[]);
        actual=field_any(snapshot,{left},[]);
        if ~isempty(expected)&&~isempty(actual)
            if ~isequaln(actual,expected),return;end
            tf=true;
        end
    end
end

function names=snapshot_owner_names(D,row)
    names={};s=field_any(D,{'snapshots'},[]);
    if istable(s),s=table2struct(s);end
    if isstruct(s)&&numel(s)>0&&isfield(s,'owner')
        owners=cell(1,numel(s));for k=1:numel(s),owners{k}=display_owner(char(string(s(k).owner)));end
        names=unique(owners,'stable');
    elseif isstruct(s)&&isscalar(s)
        names=intersect(fieldnames(s),{'FE353','RA48','SAR51'},'stable');
        if isfield(s,'owners')&&iscell(s.owners),names=s.owners;end
    elseif isstruct(s)&&numel(s)>=row&&row>=1
        names=intersect(fieldnames(s(row)),{'FE353','RA48','SAR51'},'stable');
    end
end

function name=display_owner(name)
    switch lower(name)
        case {'samplecharge','fe353'},name='FE353';
        case {'ractstate','ra48'},name='RA48';
        case {'sarstate','sar51'},name='SAR51';
    end
end

function tf=owner_matches(actual,shown)
    if iscell(actual)&&isscalar(actual),actual=actual{1};end
    aliases={shown};
    switch upper(shown)
        case 'FE353',aliases={'FE353','SampleCharge'};
        case 'RA48',aliases={'RA48','RaCtState'};
        case 'SAR51',aliases={'SAR51','SarState'};
    end
    tf=any(strcmpi(char(string(actual)),aliases));
end

function h=handoff_for_event(D,row,owner)
    h=[];data=field_any(D,{'handoffs'},[]);
    targets=double(row);
    if istable(data)
        vars=data.Properties.VariableNames;
        ownerCol=field_name(data,{'owner','stateOwner'});
        if ~isempty(ownerCol)
            owners=data.(ownerCol);
            ownerMask=false(height(data),1);
            for r=1:height(data),ownerMask(r)=owner_matches(owners(r),owner);end
            rowMask=false(height(data),1);
            for k=1:numel(vars)
                nm=lower(vars{k});
                if ~contains(nm,'row')||contains(nm,'grouprow'),continue;end
                col=data.(vars{k});
                for r=1:height(data)
                    if value_contains_targets(table_cell(col,r),targets),rowMask(r)=true;end
                end
            end
            ix=find(ownerMask&rowMask);
            if numel(ix)==1,h=table2struct(data(ix,:));
            elseif numel(ix)>1,h=struct('available',false,'reason','多条next→old候选匹配此owner/event；未擅选');end
        end
    elseif isstruct(data)
        matches=[];
        for k=1:numel(data)
            own=field_any(data(k),{'owner','stateOwner'},'');
            if ~owner_matches(own,owner),continue;end
            fn=fieldnames(data(k));matched=false;
            for f=1:numel(fn)
                nm=lower(fn{f});
                if contains(nm,'row')&&~contains(nm,'grouprow')
                    if value_contains_targets(data(k).(fn{f}),targets),matched=true;break;end
                end
            end
            if matched,matches(end+1)=k;end %#ok<AGROW>
        end
        if numel(matches)==1,h=data(matches(1));
        elseif numel(matches)>1,h=struct('available',false,'reason','多条next→old候选匹配此owner/event；未擅选');end
    end
end

function v=table_cell(column,row)
    if iscell(column),v=column{row};else,v=column(row,:);end
end

function tf=value_contains_targets(value,targets)
    tf=false;
    if isnumeric(value)||islogical(value),tf=any(ismember(double(value(:)),targets));
    elseif iscell(value)
        for k=1:numel(value),if value_contains_targets(value{k},targets),tf=true;return;end,end
    elseif isstruct(value)
        for k=1:numel(value)
            fn=fieldnames(value(k));
            for j=1:numel(fn)
                if value_contains_targets(value(k).(fn{j}),targets),tf=true;return;end
            end
        end
    end
end

function select_first_d2(fig)
    state=fig.UserData;D=state.sampleData;
    if isempty(D),set_status(fig,'先载入真实样本。');return;end
    row=first_d2_row(D);n=height_safe(field_any(D,{'events','event_table'},table()));
    if ~isfinite(row)||row<1||row>n,set_status(fig,'首次 D2 没有对应已记录事件；不生成占位行。');return;end
    state.eventRow=row;fig.UserData=state;
    try,fig.UserData.ui.eventTable.Selection=[row 1];catch,end
    refresh_sample(fig);
    set_status(fig,sprintf('已定位真实事件表第 %d 行的首次 D2。',row));
end

function row=first_d2_row(D)
    row=NaN;v=field_any(D,{'firstD2','first_d2'},[]);
    if isnumeric(v)&&isscalar(v),row=double(v);return;end
    if isstruct(v)
        q=field_any(v,{'eventRow','event_row','row','eventIndex','event_index'},[]);
        if isnumeric(q)&&isscalar(q),row=double(q);return;end
    end
end

function sample_event_selected(fig,event)
    if isempty(event.Indices),return;end
    state=fig.UserData;state.eventRow=event.Indices(1,1);fig.UserData=state;
    refresh_sample(fig);
end

function sample_plot_mode_changed(fig)
    if ~isvalid(fig),return;end
    state=fig.UserData;
    if isempty(state.sampleData),return;end
    refresh_sample(fig);
    set_status(fig,['RA VX和第六图右轴参考切换为：' state.ui.raRightMode.Value]);
end

function dispatch_sample(fig)
    state=fig.UserData;ui=state.ui;
    sid=ui.sampleIDField.Value;
    if ~isfinite(sid)||sid<0||sid~=floor(sid),uialert(fig,'Sample ID 必须是非负整数。','样本 ID');return;end
    runPath=state.selectedRunPath;
    if isempty(runPath)||~isfolder(runPath)
        uialert(fig,'请先用顶部“选择运行…”指定包含真实日志的 run 目录。','缺少历史运行');return;
    end
    call_sar20(fig,'sample',sid,runPath);
end

function dispatch_compare(fig)
    state=fig.UserData;ui=state.ui;
    a=strtrim(ui.compareA.Value);b=strtrim(ui.compareB.Value);sid=ui.compareSampleID.Value;
    if isempty(a)||isempty(b)||~isfolder(a)||~isfolder(b)
        uialert(fig,'请指定两个存在的历史运行目录。','对照输入');return;
    end
    if strcmpi(canonical_path(a),canonical_path(b))
        uialert(fig,'运行 A 与运行 B 必须是不同目录。','对照输入');return;
    end
    if ~isfinite(sid)||sid<0||sid~=floor(sid),uialert(fig,'Sample ID 必须是非负整数。','对照输入');return;end
    call_sar20(fig,'compare',a,b,sid);
end

function dispatch_results(fig)
    state=fig.UserData;
    if isempty(state.selectedRunPath),call_sar20(fig,'results');
    else,call_sar20(fig,'results',state.selectedRunPath);end
end

function call_sar20(fig,action,varargin)
    running=strcmp(action,'run');
    if running
        state=fig.UserData;state.runBusy=true;fig.UserData=state;
        state.ui.btnRun.Enable='off';set_status(fig,'正在运行当前已应用/当前Workspace配置…');drawnow;
    end
    try
        set_status(fig,['正在执行 SAR20(''' action ''')…']);
        result=feval('SAR20',action,varargin{:});
        if strcmp(action,'run')&&isstruct(result)&&isfield(result,'run_path')
            state=fig.UserData;state.selectedRunPath=result.run_path;fig.UserData=state;
            refresh_results(fig,result);
        elseif strcmp(action,'apply')||strcmp(action,'check')||strcmp(action,'open')
            refresh_home(fig,result);
        end
        set_status(fig,sprintf('SAR20(%s) 已返回。',action));
    catch ex
        set_status(fig,sprintf('SAR20(%s) 失败：%s',action,ex.message));
        uialert(fig,ex.message,['SAR20 ' action ' 失败'],'Icon','error');
    end
    if running
        try
            state=fig.UserData;state.runBusy=false;fig.UserData=state;
            refresh_home(fig);
        catch ex
            set_status(fig,['Run已结束，但首页状态刷新失败：' ex.message]);
        end
    end
end

function apply_explicit(fig)
    ui=fig.UserData.ui;name=strtrim(ui.explicitVar.Value);
    if isempty(name)||~isvarname(name)
        uialert(fig,'请输入 base workspace 中已有的标量结构体变量名 P。不会自动构造或执行 factory。','显式 apply');return;
    end
    try
        if ~evalin('base',sprintf('exist(''%s'',''var'')',name))
            error('SAR20Dashboard:MissingWorkspaceP','base workspace 中不存在变量 %s。',name);
        end
        P=evalin('base',name);
        if ~isstruct(P)||~isscalar(P),error('SAR20Dashboard:ExplicitP','变量 %s 必须是标量结构体。',name);end
        call_sar20(fig,'apply',P);
    catch ex
        uialert(fig,ex.message,'显式 apply 失败','Icon','error');
    end
end

function browse_run(fig,whichField)
    state=fig.UserData;start=state.root;
    if isfolder(fullfile(state.root,'runs')),start=fullfile(state.root,'runs');end
    chosen=uigetdir(start,'选择含 summary.json / parameters.mat / simout.mat 的历史 run 目录');
    if isequal(chosen,0),return;end
    state.selectedRunPath=chosen;
    state.selectedRunSelection=struct();
    fig.UserData=state;
    if strcmpi(whichField,'A'),state.ui.compareA.Value=chosen;
    elseif strcmpi(whichField,'B'),state.ui.compareB.Value=chosen;end
    refresh_run_catalog(fig,[]);refresh_home(fig);save_session_safely(fig);
end

function select_run_from_dropdown(fig)
    state=fig.UserData;ui=state.ui;idx=find(strcmp(ui.runDrop.Items,ui.runDrop.Value),1);
    if isempty(state.runCatalog)||isempty(idx)||idx<1||idx>numel(state.runCatalog),return;end
    state.selectedRunPath=state.runCatalog(idx).path;
    state.selectedRunSelection=struct();fig.UserData=state;
    if isempty(ui.compareA.Value),ui.compareA.Value=state.selectedRunPath;end
    refresh_home(fig);save_session_safely(fig);
end

function result_row_selected(fig,event)
    if isempty(event.Indices),return;end
    row=event.Indices(1,1);state=fig.UserData;
    if row<1||row>numel(state.runCatalog),return;end
    state.selectedRunPath=state.runCatalog(row).path;
    state.selectedRunSelection=struct();fig.UserData=state;
    state.ui.runDrop.Value=state.ui.runDrop.Items{row};
    refresh_home(fig);save_session_safely(fig);
end

function refresh_run_catalog(fig,payload)
    state=fig.UserData;
    if isempty(payload)&&~isempty(state.selectedRunPath),payload=struct('run_path',state.selectedRunPath);end
    state.runCatalog=discover_runs(state.root,payload);fig.UserData=state;
    rebuild_run_dropdown(fig);
end

function rebuild_run_dropdown(fig)
    state=fig.UserData;ui=state.ui;c=state.runCatalog;
    if isempty(c)
        ui.runDrop.Items={'(未选择历史运行)'};ui.runDrop.Value=ui.runDrop.Items{1};return;
    end
    labels=cell(1,numel(c));
    for k=1:numel(c),labels{k}=sprintf('%s | %s | %s',c(k).id,c(k).status,c(k).config);end
    ui.runDrop.Items=labels;
    ix=find(strcmp({c.path},state.selectedRunPath),1);if isempty(ix),ix=1;end
    ui.runDrop.Value=labels{ix};state.selectedRunPath=c(ix).path;fig.UserData=state;
end

function catalog=discover_runs(root,payload)
    catalog=empty_catalog();paths={};entries=[];
    if isstruct(payload)
        p=field_any(payload,{'run_path','runPath','selected_run_path','selectedRunPath','path'},'');
        if ischar(p)||isstring(p),paths{end+1}=char(p);end
        selected=field_any(payload,{'selected_run'},struct());
        if ~isstruct(selected)||isempty(fieldnames(selected))
            ps=field_any(payload,{'parameter_state'},struct());selected=field_any(ps,{'selected_run'},struct());
        end
        p=field_any(selected,{'run_path','runPath','path'},'');
        if ischar(p)||isstring(p),paths{end+1}=char(p);end
        entries=field_any(payload,{'runs','catalog','run_catalog'},[]);
        if istable(entries)
            nm=field_name(entries,{'run_path','runPath','path'});
            if ~isempty(nm),paths=[paths;cellstr(string(entries.(nm)))];end
        elseif isstruct(entries)
            for k=1:numel(entries)
                p=field_any(entries(k),{'run_path','runPath','path'},'');
                if ~isempty(p),paths{end+1}=char(string(p));end %#ok<AGROW>
            end
        end
        if ~isempty(paths),paths=paths(:);end
    end
    base=value_text(field_any(payload,{'runs_root','runsRoot'},fullfile(root,'runs')));
    if isempty(base),base=fullfile(root,'runs');end
    if isfolder(base)
        d=dir(base);d=d([d.isdir]);
        for k=1:numel(d)
            if ismember(d(k).name,{'.','..'}),continue;end
            paths{end+1}=fullfile(base,d(k).name); %#ok<AGROW>
        end
    end
    paths=unique(paths,'stable');
    for k=1:numel(paths)
        path=paths{k};if ~isfolder(path),continue;end
        meta=read_run_summary(path);if isempty(meta),continue;end
        c=struct('id',run_id_from_path(path),'path',path,'status','unknown', ...
            'config','P未读','records','未记录','modelSha','未知','summary',meta, ...
            'Psha','未知','DecodePsha','未知','identityStatus','未知', ...
            'matSha','未知','selectionSource','未知','observerIdentity','未知', ...
            'observerContractStatus','未知','observerContractSha','未知','observerContractPath','未知');
        c.status=value_text(field_any(meta,{'status'},'unknown'));
        c.records=value_text(field_any(meta,{'records','N'},'未记录'));
        c.modelSha=short_hash(value_text(field_any(meta,{'model_sha256','modelSha256'},'未知')));
        c.config=summary_config(meta,path);
        c.Psha=value_text(field_any(meta,{'P_sha256','p_sha256'},'未知'));
        c.DecodePsha=value_text(field_any(meta,{'DecodeP_sha256','decodeP_sha256'},'未知'));
        c.identityStatus=value_text(field_any(meta,{'parameter_identity_status'},'未知'));
        c.matSha=value_text(field_any(meta,{'parameters_mat_sha256','config_sha256'},'未知'));
        c.selectionSource=value_text(field_any(meta,{'selection_source'},'未知'));
        c.observerIdentity=value_text(field_any(meta,{'observer_identity'},'未知'));
        c.observerContractStatus=value_text(field_any(meta,{'observer_contract_status'},'未知'));
        c.observerContractSha=value_text(field_any(meta,{'observer_contract_sha256','observer_contract_sha'},'未知'));
        c.observerContractPath=value_text(field_any(meta,{'observer_contract_path'},'未知'));
        entry=registry_entry_for_path(entries,path);
        if ~isempty(entry)
            c.id=value_text(field_any(entry,{'run_id','runID'},c.id));
            c.status=value_text(field_any(entry,{'status'},c.status));
            c.modelSha=short_hash(value_text(field_any(entry,{'model_sha256'},c.modelSha)));
            c.config=value_text(field_any(entry,{'configuration_summary'},c.config));
            c.records=value_text(field_any(entry,{'N','records'},c.records));
            c.Psha=value_text(field_any(entry,{'P_sha256'},c.Psha));
            c.DecodePsha=value_text(field_any(entry,{'DecodeP_sha256'},c.DecodePsha));
            c.identityStatus=value_text(field_any(entry,{'parameter_identity_status'},c.identityStatus));
            c.matSha=value_text(field_any(entry,{'parameters_mat_sha256'},c.matSha));
            c.selectionSource=value_text(field_any(entry,{'selection_source'},c.selectionSource));
            c.observerIdentity=value_text(field_any(entry,{'observer_identity'},c.observerIdentity));
            c.observerContractStatus=value_text(field_any(entry,{'observer_contract_status'},c.observerContractStatus));
            c.observerContractSha=value_text(field_any(entry,{'observer_contract_sha256','observer_contract_sha'},c.observerContractSha));
            c.observerContractPath=value_text(field_any(entry,{'observer_contract_path'},c.observerContractPath));
        end
        catalog(end+1)=c; %#ok<AGROW>
    end
end

function c=empty_catalog()
    c=struct('id',{},'path',{},'status',{},'config',{},'records',{},'modelSha',{},'summary',{}, ...
        'Psha',{},'DecodePsha',{},'identityStatus',{},'matSha',{},'selectionSource',{},'observerIdentity',{}, ...
        'observerContractStatus',{},'observerContractSha',{},'observerContractPath',{});
end

function entry=registry_entry_for_path(entries,path)
    entry=[];
    if istable(entries),entries=table2struct(entries);end
    if ~isstruct(entries),return;end
    for k=1:numel(entries)
        candidate=value_text(field_any(entries(k),{'run_path','runPath','path'},''));
        if ~isempty(candidate)&&strcmpi(canonical_path(candidate),canonical_path(path))
            entry=entries(k);return;
        end
    end
end

function info=selected_run_descriptor(state)
    info=struct('path','','id','未选择','status','未载入','records','未记录', ...
        'config','未载入','modelSha','未知','summary',struct(),'rawP',struct(), ...
        'Psha','未知','DecodePsha','未知','identityStatus','未知', ...
        'matSha','未知','selectionSource','未知','observerIdentity','未知', ...
        'observerContractStatus','未知','observerContractSha','未知','observerContractPath','未知', ...
        'workspaceChangeStatus','未知','workspaceChangedFields',[]);
    path=state.selectedRunPath;
    if isempty(path)||~isfolder(path),return;end
    info.path=path;info.id=run_id_from_path(path);
    ix=find(strcmp({state.runCatalog.path},path),1);
    if ~isempty(ix)
        info.status=state.runCatalog(ix).status;info.records=state.runCatalog(ix).records;
        info.config=state.runCatalog(ix).config;info.modelSha=state.runCatalog(ix).modelSha;
        info.summary=state.runCatalog(ix).summary;
        info.Psha=state.runCatalog(ix).Psha;info.DecodePsha=state.runCatalog(ix).DecodePsha;
        info.identityStatus=state.runCatalog(ix).identityStatus;info.matSha=state.runCatalog(ix).matSha;
        info.selectionSource=state.runCatalog(ix).selectionSource;info.observerIdentity=state.runCatalog(ix).observerIdentity;
    end
    if ~isstruct(info.summary)||isempty(fieldnames(info.summary)),info.summary=read_run_summary(path);end
    q=field_any(info.summary,{'P_sha256','p_sha256'},[]);if ~isempty(q),info.Psha=value_text(q);end
    q=field_any(info.summary,{'DecodeP_sha256','decodeP_sha256'},[]);if ~isempty(q),info.DecodePsha=value_text(q);end
    q=field_any(info.summary,{'parameter_identity_status'},[]);if ~isempty(q),info.identityStatus=value_text(q);end
    q=field_any(info.summary,{'parameters_mat_sha256','config_sha256'},[]);if ~isempty(q),info.matSha=value_text(q);end
    q=field_any(info.summary,{'selection_source'},[]);if ~isempty(q),info.selectionSource=value_text(q);end
    q=field_any(info.summary,{'observer_identity'},[]);if ~isempty(q),info.observerIdentity=value_text(q);end
    q=field_any(info.summary,{'observer_contract_status'},[]);if ~isempty(q),info.observerContractStatus=value_text(q);end
    q=field_any(info.summary,{'observer_contract_sha256','observer_contract_sha'},[]);if ~isempty(q),info.observerContractSha=value_text(q);end
    q=field_any(info.summary,{'observer_contract_path'},[]);if ~isempty(q),info.observerContractPath=value_text(q);end
    q=field_any(info.summary,{'workspace_change_status'},[]);if ~isempty(q),info.workspaceChangeStatus=value_text(q);end
    q=field_any(info.summary,{'workspace_changed_fields'},[]);if ~isempty(q),info.workspaceChangedFields=q;end
    selection=state.selectedRunSelection;
    selectionPath=value_text(field_any(selection,{'run_path','runPath','path'},''));
    if isstruct(selection)&&~isempty(fieldnames(selection))&& ...
            (isempty(selectionPath)||strcmpi(canonical_path(selectionPath),canonical_path(path)))
        info.Psha=value_text(field_any(selection,{'P_sha256','p_sha256'},info.Psha));
        info.DecodePsha=value_text(field_any(selection,{'DecodeP_sha256','decodeP_sha256'},info.DecodePsha));
        info.identityStatus=value_text(field_any(selection,{'parameter_identity_status'},info.identityStatus));
        info.matSha=value_text(field_any(selection,{'parameters_mat_sha256'},info.matSha));
        info.selectionSource=value_text(field_any(selection,{'selection_source'},info.selectionSource));
        info.observerIdentity=value_text(field_any(selection,{'observer_identity'},info.observerIdentity));
        info.observerContractStatus=value_text(field_any(selection,{'observer_contract_status'},info.observerContractStatus));
        info.observerContractSha=value_text(field_any(selection,{'observer_contract_sha256','observer_contract_sha'},info.observerContractSha));
        info.observerContractPath=value_text(field_any(selection,{'observer_contract_path'},info.observerContractPath));
        info.workspaceChangeStatus=value_text(field_any(selection,{'workspace_change_status'},info.workspaceChangeStatus));
        info.workspaceChangedFields=field_any(selection,{'workspace_changed_fields'},info.workspaceChangedFields);
    end
    pf=fullfile(path,'parameters.mat');d=dir(pf);
    if isempty(d)||d.bytes>300e6,info.config='parameters.mat 缺失或超过 300 MB，未读取';return;end
    try
        expectedMat=field_any(info.summary,{'parameters_mat_sha256','config_sha256'},'');
        if ~isempty(expectedMat)&&~any(strcmpi(value_text(expectedMat),{'unknown','未知'}))
            actualMat=sha256_file(pf);
            if ~strcmpi(actualMat,value_text(expectedMat))
                info.config='parameters.mat SHA-256 mismatch；拒绝将其标为精确历史 P';
                info.identityStatus='parameters_mat_sha256_mismatch';return;
            end
            info.matSha=value_text(expectedMat);
            info.identityStatus='parameters_mat_sha256_match';
        else
            info.identityStatus='unknown_no_parameters_mat_sha256';
        end
        saved=load(pf,'P');if isfield(saved,'P'),summary=summarize_P(saved.P);info.config=summary.summary;info.rawP=saved.P;end
    catch ex
        info.config=['parameters.mat 读取失败：' ex.message];
    end
end

function meta=read_run_summary(path)
    meta=[];f=fullfile(path,'summary.json');d=dir(f);
    if isempty(d)||d.isdir||d.bytes>300e6,return;end
    try,meta=jsondecode(fileread(f));catch,meta=[];end
end

function data=read_json_bounded(path)
    data=struct();d=dir(path);
    if isempty(d)||d.isdir||d.bytes>300e6,return;end
    try,data=jsondecode(fileread(path));catch,data=struct();end
end

function txt=summary_config(meta,path)
    txt='P未读取';
    direct=field_any(meta,{'configuration_summary','config_summary'},'');
    if ~isempty(direct),txt=value_text(direct);return;end
    p=field_any(meta,{'config','parameters','P'},[]);
    if isstruct(p),s=summarize_P(p);txt=s.summary;return;end
    params=fullfile(path,'parameters.json');d=dir(params);
    if ~isempty(d)&&~d.isdir&&d.bytes<=300e6
        try,j=jsondecode(fileread(params));s=summarize_P(j);txt=s.summary;catch,end
    end
end

function info=project_status(root)
    modelFile=fullfile(root,'current','models','SarAdc.slx');
    info=struct();info.modelPath=modelFile;
    if isfile(modelFile),info.modelSha=sha256_file(modelFile);else,info.modelSha='缺失';end
    info.baselineSha='91973cf76507';
    info.modelVersion='SarAdc.slx';
    appliedFile=fullfile(root,'state','applied_config.json');
    applied=struct();
    if isfile(appliedFile)
        d=dir(appliedFile);
        if d.bytes<=300e6
            try,applied=jsondecode(fileread(appliedFile));catch,applied=struct();end
        end
    end
    info.appliedRecord=applied;
    info.applyTransaction=read_json_bounded(fullfile(root,'state','apply_transaction.json'));
    info.pending=read_pending_sources(root,applied);
    p=field_any(applied,{'config'},struct());
    info.applied=summarize_P(p);
    info.applied.source=value_text(field_any(applied,{'configuration_source','source'},'未知'));
    info.applied.utc=value_text(field_any(applied,{'utc'},'未知'));
    [liveP,loaded,dirty,decodeP,loadedPath,simulationStatus]=live_workspace_P(modelFile);
    info.live=summarize_P(liveP);
    info.live.workspaceLoaded=loaded;
    info.live.modelLoadedPath=loadedPath;
    info.live.workspaceSource='model_not_loaded';
    if loaded,info.live.workspaceSource='loaded_model_workspace';
    elseif ~isempty(loadedPath),info.live.workspaceSource='different_same_name_model_loaded';end
    info.live.simulationStatus=simulationStatus;
    info.live.appliedFallback=info.applied.summary;
    info.live.decodePMatches=[];
    if loaded
        info.modelLoadedStatus=['目标模型已加载：' canonical_path(modelFile)];
    elseif ~isempty(loadedPath)
        info.modelLoadedStatus=['同名 SarAdc 来自其他路径；未读取其 Workspace.P：' loadedPath];
        info.live.summary=['检测到同名模型来自其他路径：' loadedPath];
        info.live.compare='不是本工程模型；未读取其 Workspace.P';
        info.live.dirty='非目标模型';
    else
        info.modelLoadedStatus='本工程模型未加载；只显示上次 apply 记录';
    end
    if ~loaded
        info.live.summary='模型未加载，当前 Workspace.P 未读取';
        if ~isempty(loadedPath),info.live.summary=['同名模型不是本工程模型：' loadedPath];end
        if ~isstruct(p)||isempty(fieldnames(p)),info.live.appliedFallback='无法读取 apply 记录';end
        if isempty(loadedPath)
            info.live.compare='模型未加载；live Workspace 状态未知';
            info.live.dirty='模型未加载';
        end
    else
        info.live.dirty=dirty;
        if isstruct(liveP)&&isfield(liveP,'digital')&&~isempty(decodeP)
            info.live.decodePMatches=isequaln(liveP.digital,decodeP);
        else
            info.live.decodePMatches=[];
        end
        if isstruct(p)&&~isempty(fieldnames(p))
            info.live.compare=compare_json_signature(liveP,p);
        else
            info.live.compare='apply记录缺少配置；未知';
        end
    end
    info.live.scenario=info.live.summary;
    if ~loaded,info.live.seed=[info.applied.seed '（apply记录）'];end
end

function p=read_pending_sources(root,applied)
    files={fullfile(root,'config','adc_parameters.m'),fullfile(root,'config','normal_parameters.m'), ...
        fullfile(root,'config','normal_10v_configuration.m'),fullfile(root,'config','nominal.mat')};
    rels={'config/adc_parameters.m','config/normal_parameters.m', ...
        'config/normal_10v_configuration.m','config/nominal.mat'};
    keys={'adc_parameters_m','normal_parameters_m','normal_10v_configuration_m','nominal_mat'};
    [hash,exists,currentFiles]=source_bundle_hash(files,rels,keys);
    desc=cell(1,numel(files));for k=1:numel(files),[~,n,e]=fileparts(files{k});desc{k}=[n e];end
    p=struct('hash',hash,'summary',strjoin(desc,' + '),'changeStatus','未知');
    previous=field_any(applied,{'source_sha256','source_hash','config_source_sha256'},'');
    previousFiles=field_any(applied,{'source_files'},struct());
    appliedSource=lower(value_text(field_any(applied,{'configuration_source','source'},'')));
    if strcmp(appliedSource,'explicit')
        p.changeStatus='不适用：上次 apply 使用显式 P；当前显示的 factory 源文件没有用于该次 apply';
    elseif isempty(previous)
        p.changeStatus='未知（上次 apply 记录没有 source hash；只读计算当前文件 SHA-256）';
    elseif ~exists
        p.changeStatus='无法判断（源文件缺失）';
    elseif isstruct(previousFiles)&&all(isfield(previousFiles,keys))&& ...
            all(cellfun(@(k)strcmpi(char(string(previousFiles.(k))),currentFiles.(k)),keys))
        p.changeStatus='未变化（与上次 apply source hash 一致）';
    else
        if strcmpi(char(string(previous)),hash)
            p.changeStatus='未变化（bundle source SHA-256 一致）';
        else
            p.changeStatus='已变化（当前源 hash 与上次 apply source hash 不同）';
        end
    end
    P=read_source_literals(files(1:2));
    if ~isempty(P)
        p.summary=sprintf('待应用文字配置：N=%s, f=%s Hz, AZ=%s, source-only', ...
            P.N,P.frequency,P.azMode);
    else
        p.summary=['待读配置源：' strjoin(desc,' + ')];
    end
end

function P=read_source_literals(files)
    P=[];if ~all(cellfun(@isfile,files)),return;end
    a=fileread(files{1});b=fileread(files{2});
    P=struct('N',regex_literal(a,'(?m)^\s*N\s*=\s*(\d+)\s*;'), ...
        'frequency',regex_literal(a,'(?m)^\s*input_frequency_hz\s*=\s*([0-9.eE+-]+)\s*;'), ...
        'azMode',regex_string(b,'(?m)^\s*azMode\s*=\s*''([^'']+)''\s*;'));
    if any(cellfun(@isempty,struct2cell(P))),P=[];return;end
end

function v=regex_literal(text,pat)
    t=regexp(text,pat,'tokens','once');if isempty(t),v='待确认';else,v=t{1};end
end

function v=regex_string(text,pat)
    t=regexp(text,pat,'tokens','once');if isempty(t),v='待确认';else,v=t{1};end
end

function [P,loaded,dirty,DecodeP,loadedPath,simulationStatus]=live_workspace_P(expectedModelFile)
    P=struct();DecodeP=[];loaded=false;dirty='未知';loadedPath='';simulationStatus='not_loaded';
    model='SarAdc';
    try
        if ~bdIsLoaded(model),return;end
        actualPath=get_param(model,'FileName');
        if isempty(actualPath)
            loadedPath='同名模型FileName未知';dirty='非目标模型';return;
        end
        if ~strcmpi(canonical_path(actualPath),canonical_path(expectedModelFile))
            loadedPath=char(actualPath);dirty='非目标模型';return;
        end
        loaded=true;loadedPath=char(actualPath);dirty=get_param(model,'Dirty');
        simulationStatus=get_param(model,'SimulationStatus');
        ws=get_param(model,'ModelWorkspace');P=ws.getVariable('P');
        try,DecodeP=ws.getVariable('DecodeP');catch,DecodeP=[];end
    catch
        P=struct();
    end
end

function s=summarize_P(P)
    s=struct('summary','未记录','scenario','未记录','seed','未记录','raw',P,'observer','未记录');
    if ~isstruct(P)||~isscalar(P)||isempty(fieldnames(P)),return;end
    N=field_any(P,{'N'},'未记录');fs=field_any(P,{'fs_hz'},[]);
    if isempty(fs),Ts=field_any(P,{'Ts_s'},[]);if isnumeric(Ts)&&isscalar(Ts)&&Ts>0,fs=1/Ts;end,end
    if isempty(fs),fsText='未记录';else,fsText=sprintf('%g MS/s',double(fs)/1e6);end
    az=field_any(P,{'backend'},struct());az=field_any(az,{'az'},struct());az=value_text(field_any(az,{'mode'},'未记录'));
    input=field_any(P,{'input'},struct());fin=field_any(input,{'frequency_hz'},[]);
    if isempty(fin),finText='f_in未记录';else,finText=sprintf('f_in=%g kHz',double(fin)/1e3);end
    seed=seed_summary(P);
    observer=observer_summary(P);
    bank=field_any(field_any(P,{'bank'},struct()),{'enabled'},false);
    transport=field_any(field_any(P,{'transport'},struct()),{'enabled'},false);
    training=field_any(field_any(P,{'training'},struct()),{'enabled'},false);
    summary=sprintf('SAR20 | N=%s | Fs=%s | %s | AZ=%s | Bank=%s | Transport=%s | Training=%s | observer=%s', ...
        value_text(N),fsText,finText,az,onoff(bank),onoff(transport),onoff(training),observer);
    s=struct('summary',summary,'scenario',summary,'seed',seed,'raw',P,'observer',observer);
end

function txt=seed_summary(P)
    parts={};label=field_any(P,{'seed'},[]);
    if ~isempty(label),parts{end+1}=['P.seed label=' value_text(label)];end
    front=field_any(P,{'front'},struct());
    if flag_on(field_any(front,{'ktc_enabled'},false))
        parts{end+1}=['kTC=' value_text(field_any(front,{'ktc_seed'},'未记录'))];
    end
    if flag_on(nested_value(P,{'backend','ni','ra_noise'},false))
        rn=nested_value(P,{'backend','ra_noise','seed_u64'},'未记录');parts{end+1}=['RAOU=' value_text(rn)];
    end
    cmp=field_any(field_any(P,{'control'},struct()),{'comparator'},struct());
    if flag_on(field_any(cmp,{'enabled'},false))
        parts{end+1}=['cmp=' value_text(field_any(cmp,{'seed_u64'},'未记录'))];
    end
    if flag_on(field_any(front,{'dither_enabled'},false))
        parts{end+1}=['dither=' value_text(field_any(front,{'dither_seed'},'未记录'))];
    end
    if isempty(parts),txt='未记录';else,txt=strjoin(parts,'; ');end
end

function tf=flag_on(value)
    tf=~isempty(value)&&isscalar(value)&&logical(value);
end

function txt=observer_summary(P)
    debug=field_any(P,{'debug'},struct());observer=field_any(debug,{'observer'},[]);
    if isempty(observer),txt='未记录';return;end
    if isstruct(observer)
        enabled=onoff(field_any(observer,{'enabled'},[]));sid=value_text(field_any(observer,{'sample_id','sampleID'},'未记录'));
        Ts=field_any(observer,{'Ts_s'},field_any(P,{'Ts_s'},[]));
        if isempty(Ts),tsText='Ts未记录';else,tsText=sprintf('Ts=%g ns',double(Ts)*1e9);end
        txt=sprintf('%s, sample_id=%s, %s（被动日志窗）',enabled,sid,tsText);
    else
        txt=onoff(observer);
    end
end

function rows=feature_rows(live,selected,applied,switches,summary)
    P=live.raw;
    sourceNote='';
    if ~live.workspaceLoaded
        P=applied.raw;
        if ~isempty(live.modelLoadedPath),sourceNote='（最近apply记录；同名其他模型的P未读取）';
        else,sourceNote='（最近apply记录；live Workspace未加载）';end
    end
    items={'sampling mismatch','front.ktc','DAC finite settling','RA finite gain/bandwidth', ...
        'RA OU noise','SAR2 comparator noise','AZ mode','DEM','dither','CINC kick','Bank','Transport','Training', ...
        'CAAZ N8 trial','FrameAvg paired average','ADI v2'};
    enabled=cell(numel(items),1);
    enabled{1}=projected_flag(switches,{'frontend_mismatch_enabled'},nested_flag(P,{'front','mismatch_enabled'}));
    enabled{2}=projected_flag(switches,{'frontend_ktc_enabled'},nested_flag(P,{'front','ktc_enabled'}));
    enabled{3}=projected_flag(switches,{'dac_finite_settling_enabled'},dac_settling_switch(P));
    a0=nested_value(P,{'backend','ra','A0'},[]);ugb=nested_value(P,{'backend','ra','UGB_hz'},[]);
    if has_struct_fields(switches)&& ...
            (~isempty(field_any(switches,{'ra_finite_gain_effect'},[]))|| ...
            ~isempty(field_any(switches,{'ra_finite_bandwidth_effect'},[])))
        enabled{4}=sprintf('finite gain=%s; bandwidth=%s', ...
            report_value(field_any(switches,{'ra_finite_gain_effect'},[])), ...
            report_value(field_any(switches,{'ra_finite_bandwidth_effect'},[])));
    elseif isempty(a0)&&isempty(ugb),enabled{4}='未记录';
    elseif (~isempty(a0)&&any(isfinite(double(a0(:)))))||(~isempty(ugb)&&any(isfinite(double(ugb(:)))))
        enabled{4}='开启';
    else,enabled{4}='关闭';end
    enabled{5}=projected_flag(switches,{'ra_noise'},nested_flag(P,{'backend','ni','ra_noise'}));
    enabled{6}=projected_flag(switches,{'comparator_noise_enabled'},nested_flag(P,{'control','comparator','enabled'}));
    enabled{7}=value_text(nested_value(P,{'backend','az','mode'}, ...
        field_any(summary,{'az_mode'},'未记录')));
    if strcmp(enabled{7},'未记录'),enabled{7}=projected_flag(switches,{'az'},'未记录');end
    enabled{8}=projected_flag(switches,{'frontend_dem_enabled'},nested_flag(P,{'front','dem_enabled'}));
    enabled{9}=projected_flag(switches,{'frontend_dither_enabled'},nested_flag(P,{'front','dither_enabled'}));
    enabled{10}=projected_flag(switches,{'cinc_kick'},nested_flag(P,{'backend','ni','cinc_kick'}));
    enabled{11}=projected_flag(switches,{'bank_enabled'},nested_flag(P,{'bank','enabled'}));
    enabled{12}=projected_flag(switches,{'transport_enabled'},nested_flag(P,{'transport','enabled'}));
    enabled{13}=projected_flag(switches,{'training_enabled'},nested_flag(P,{'training','enabled'}));
    enabled{14}='关闭；独立N8试验身份';
    enabled{15}='未集成；partial-712';
    enabled{16}='候选；未集成';
    rows=cell(numel(items),3);
    for k=1:numel(items)
        itemName=items{k};
        if k<=13,evidence=feature_evidence(selected,itemName);
        elseif k==14,evidence='现有证据仅属独立N8试验；不代表当前N256默认验证';
        elseif k==15,evidence='配对平均partial-712未完成整图集成/回归';
        else,evidence='ADI v2 为候选；当前默认模型未集成/未验证';end
        if ~live.workspaceLoaded&&k<=13,itemName=[itemName sourceNote];end
        rows(k,:)={itemName,enabled{k},evidence};
    end
end

function result=projected_flag(projection,names,fallback)
    value=field_any(projection,names,[]);
    if isempty(value),result=fallback;
    else,result=onoff(value);end
end

function result=dac_settling_switch(P)
    coupled=nested_value(P,{'backend','dac_coupling','enabled'},[]);
    tau=nested_value(P,{'front','tau_dac_s'},[]);
    if isempty(coupled)||isempty(tau),result='未记录';
    elseif flag_on(coupled)&&any(isfinite(double(tau(:)))&double(tau(:))>0),result='开启';
    else,result='关闭';end
end

function evidence=feature_evidence(selected,item)
    if isempty(selected.path),evidence='专项验证：未知（没有所选 run）';return;end
    report=selected.summary;
    verification=field_any(report,{'feature_verification','feature_validation'},[]);
    key=lower(regexprep(item,'[^A-Za-z0-9]+','_'));
    q=field_any(verification,{key},[]);
    if ~isempty(q)
        evidence=['专项验证：' value_text(q)];return;
    end
    status=value_text(field_any(report,{'status'},selected.status));
    sim=value_text_or_unknown(field_any(report,{'simulation_completed'},[]));
    evidence=sprintf('专项验证：未登记；run=%s, simulation_completed=%s（整体运行状态不代表本功能专项通过）',status,sim);
end

function txt=workspace_P_summary(live,summary,source)
    if live.workspaceLoaded,txt=live.summary;
    elseif ~isempty(live.modelLoadedPath),txt=['同名其他模型未读取P：' live.modelLoadedPath];
    elseif strcmp(source,'saved_apply_snapshot_model_hash_match')&&~isempty(summary)
        if ischar(summary)||isstring(summary),summaryText=value_text(summary);
        else,summaryText=parameter_summary_text(summary);end
        txt=['模型未加载；SHA匹配的已保存apply P：' summaryText];
    else,txt='模型未加载，当前 Workspace.P 未读取';end
end

function txt=parameter_summary_text(S)
    if ~has_struct_fields(S),txt='未记录';return;end
    N=value_text(field_any(S,{'N'},'未记录'));
    fs=field_any(S,{'sample_rate_hz','fs_hz'},[]);
    if isempty(fs),fsText='Fs未记录';else,fsText=sprintf('Fs=%g MS/s',double(fs)/1e6);end
    input=field_any(S,{'input'},struct());
    fin=value_text(field_any(input,{'frequency_hz'},'未记录'));
    amp=value_text(field_any(input,{'amplitude_v'},'未记录'));
    az=value_text(field_any(S,{'az_mode'},'未记录'));
    A0=value_text(field_any(S,{'A0'},'未记录'));
    UGB=field_any(S,{'UGB_hz'},[]);
    if isempty(UGB),ugbText='UGB未记录';else,ugbText=sprintf('UGB=%g MHz',double(UGB)/1e6);end
    transport=value_text(field_any(S,{'transport_enabled'},'未记录'));
    observer=field_any(S,{'observer_identity'},struct());
    obs='未记录';
    if isstruct(observer)
        obs=sprintf('%s/sample=%s/Ts=%s s',value_text(field_any(observer,{'enabled'},'未知')), ...
            value_text(field_any(observer,{'sample_id'},'未记录')), ...
            value_text(field_any(observer,{'Ts_s'},'未记录')));
    end
    txt=sprintf('N=%s | %s | fin=%s Hz | amp=%s V | AZ=%s | A0=%s | %s | transport=%s | observer=%s', ...
        N,fsText,fin,amp,az,A0,ugbText,transport,obs);
end

function tf=has_struct_fields(value)
    tf=isstruct(value)&&isscalar(value)&&~isempty(fieldnames(value));
end

function v=nested_value(P,path,default)
    v=P;
    for k=1:numel(path)
        if ~isstruct(v)||~isfield(v,path{k}),v=default;return;end
        v=v.(path{k});
    end
end
function v=nested_flag(P,path)
    q=nested_value(P,path,[]);if isempty(q),v='未记录';else,v=onoff(q);end
end
function v=nested_positive(P,path)
    q=nested_value(P,path,[]);if isempty(q),v='未记录';elseif any(isfinite(double(q(:)))&double(q(:))>0),v='开启';else,v='关闭';end
end
function txt=compare_json_signature(a,b)
    try
        sa=jsonencode(a);sb=jsonencode(b);
        if strcmp(sa,sb),txt='与 apply 记录一致';else,txt='与 apply 记录不同；检查 GUI workspace 与模型 Dirty 状态';end
    catch
        txt='无法稳定比较（数据类型/非有限值编码）；未知';
    end
end

function txt=workspace_modified_text(value,loaded,loadedPath,fallback,workspaceSource)
    if nargin<5,workspaceSource='';end
    if ~isempty(loadedPath)&&~loaded
        txt=['同名 SarAdc 但路径不匹配；未读取其 Workspace.P。' value_text(fallback)];return;
    end
    if ~loaded
        if strcmp(workspaceSource,'saved_apply_snapshot_model_hash_match')
            status=workspace_status_code(value,fallback);
            if strcmp(status,'no')
                txt='目标模型未加载；只读快照确认已保存P与apply身份一致。SAR20 run会用该保存P，不读取历史所选P。';
            else
                txt='目标模型未加载；应用快照身份未知。SAR20 run会用模型保存P，不读取历史所选P。';
            end
        else
            txt='本工程模型未加载；SAR20 run 会使用模型保存的 Workspace.P。选中历史 run 不会改变本次运行配置。';
        end
        return;
    end
    status=workspace_status_code(value,fallback);
    switch status
        case 'yes'
            txt='警示：Workspace.P 与上次 apply 记录不同。GUI Run 将用当前手改 Workspace.P；先确认是否要 Apply。';
        case 'no'
            txt='Workspace.P 与上次 apply 记录一致。GUI Run 用当前已应用 Workspace.P，不运行历史所选 P。';
        otherwise
            txt='Workspace/apply 关系未知（旧记录缺少身份字段或无法比较）。GUI Run 将用当前 Workspace.P。';
    end
end

function status=workspace_status_code(value,fallback)
    v=lower(char(string(value)));
    if any(strcmp(v,{'yes','true','modified','1'})),status='yes';return;end
    if any(strcmp(v,{'no','false','unchanged','0'})),status='no';return;end
    if ~isempty(v),status='unknown';return;end
    f=lower(char(string(fallback)));
    if contains(f,'不同'),status='yes';
    elseif contains(f,'一致'),status='no';
    else,status='unknown';end
end

function txt=run_button_text(value,loaded,compare,loadedPath,sourcePending)
    status=workspace_status_code(value,compare);
    if ~isempty(loadedPath)&&~loaded
        txt='运行 Workspace.P（存在同名模型冲突）';
    elseif ~loaded&&strcmp(status,'no')
        if sourcePending,txt='运行模型保存的已应用P（源修改尚未apply）';
        else,txt='运行模型保存的已应用配置';end
    elseif ~loaded
        txt='运行模型保存的 P（apply 关系未知）';
    elseif strcmp(status,'yes')
        if sourcePending,txt='运行手改P（源修改未apply）';
        else,txt='运行手改 Workspace.P（未与apply一致）';end
    elseif strcmp(status,'no')&&loaded
        if sourcePending,txt='运行当前已应用P（源修改尚未apply）';
        else,txt='运行当前已应用配置';end
    elseif strcmp(status,'no')
        txt='运行模型保存的应用配置';
    else
        txt='运行当前 Workspace.P（应用状态未知）';
    end
end

function tf=is_source_pending(status)
    v=lower(value_text(status));
    tf=contains(v,'changed_since_apply')||contains(v,'已变化')||contains(v,'source changed');
end

function tf=is_model_dirty(report,localStatus)
    tf=strcmpi(char(string(localStatus)),'on');
    if isstruct(report)
        flag=field_any(report,{'is_dirty','dirty'},[]);
        if ~isempty(flag)&&isscalar(flag),tf=tf||logical(flag);end
        status=lower(value_text(field_any(report,{'status'},'')));
        tf=tf||contains(status,'dirty')||contains(status,'uncommitted')||contains(status,'unsaved');
    elseif ischar(report)||isstring(report)
        status=lower(char(string(report)));
        tf=tf||contains(status,'dirty')||strcmp(status,'on')||contains(status,'uncommitted')||contains(status,'unsaved');
    end
end

function txt=report_value_or_local(value,fallback)
    if isempty(value),txt=value_text(fallback);else,txt=report_value(value);end
end

function txt=conditional_text(condition,whenTrue,whenFalse)
    if condition,txt=whenTrue;else,txt=whenFalse;end
end

function txt=seed_sources_text(seeds,fallback)
    if isempty(seeds),txt=fallback;return;end
    if isstruct(seeds)&&isscalar(seeds)
        names=fieldnames(seeds);parts=cell(1,numel(names));
        for k=1:numel(names),parts{k}=[names{k} '=' value_text(seeds.(names{k}))];end
        txt=strjoin(parts,'; ');
    else
        txt=value_text(seeds);
    end
end

function txt=pretty_source_status(value)
    v=lower(char(string(value)));
    switch v
        case {'changed_since_apply','changed'},txt='已变化（当前源文件与上次 apply 不同）';
        case {'unchanged_since_apply','unchanged'},txt='未变化（当前源文件与上次 apply 一致）';
        case {'unknown_legacy_apply','unknown'},txt='未知（旧 apply 记录没有 source hash）';
        otherwise,txt=value_text(value);
    end
end

function refresh_fields(fig)
    ui=fig.UserData.ui;
    if exist('sar20_debug_fields','file')~=2
        ui.fieldsTable.Data=cell(0,0);ui.fieldsNote.Text=[ui.fieldsNote.Text ' Registry函数尚未出现在当前路径。'];return;
    end
    try
        R=sar20_debug_fields();defs=field_any(R,{'fields'},R);
        bundle=field_any(R,{'bundle'},struct());
        ui.fieldsNote.Text=sprintf(['字段索引、单位、参考面、所有者、有效条件、更新阶段与源码位置来自统一 registry。' ...
            ' observer variable=%s；row cap=%s；expected sample rows=%s；bundle width=%s。' ...
            '缺失字段保留“未记录/待确认”，不补零。'], ...
            value_text(field_any(bundle,{'logger_name'},'未记录')), ...
            value_text(field_any(bundle,{'max_data_points'},'未记录')), ...
            value_text(field_any(bundle,{'expected_selected_sample_rows'},'未记录')), ...
            value_text(field_any(R,{'bundle_width'},'未记录')));
        if istable(defs),ui.fieldsTable.Data=defs;ui.fieldsTable.ColumnName=defs.Properties.VariableNames;
        elseif isstruct(defs)&&~isempty(defs)
            ui.fieldsTable.Data=struct2table(defs);ui.fieldsTable.ColumnName=ui.fieldsTable.Data.Properties.VariableNames;
        end
    catch ex
        ui.fieldsNote.Text=['字段registry读取失败：' ex.message];
    end
end

function refresh_parameters(fig,payload,info)
    if nargin<2,payload=[];end
    if nargin<3,info=project_status(fig.UserData.root);end
    state=fig.UserData;ui=state.ui;selected=selected_run_descriptor(state);
    parameterState=field_any(payload,{'parameter_state'},struct());
    workspaceState=field_any(parameterState,{'workspace'},struct());
    modifiedState=field_any(workspaceState,{'modified_since_apply'},'');
    appliedState=field_any(parameterState,{'applied'},struct());
    workspaceSummary=field_any(workspaceState,{'configuration_summary'},[]);
    if ~has_struct_fields(workspaceSummary),workspaceSummary=field_any(payload,{'configuration_summary'},[]);end
    appliedSummary=field_any(appliedState,{'configuration_summary'},[]);
    if ~has_struct_fields(appliedSummary),appliedSummary=field_any(info.appliedRecord,{'configuration_summary'},[]);end
    workspaceSource=value_text(field_any(workspaceState,{'status'},info.live.workspaceSource));
    if ~has_struct_fields(workspaceSummary)&&isfield(info.live,'reportedSummary'),workspaceSummary=info.live.reportedSummary;end
    if ~has_struct_fields(appliedSummary),appliedDisplay=info.applied.summary;
    else,appliedDisplay=parameter_summary_text(appliedSummary);end
    rows={ ...
        '待应用源文件',info.pending.summary, ...
        ['SHA-256=' info.pending.hash ' | ' info.pending.changeStatus], ...
        '已应用记录 P',appliedDisplay, ...
        ['source=' info.applied.source ' | utc=' info.applied.utc], ...
        '当前 Workspace.P',workspace_P_summary(info.live,workspaceSummary,workspaceSource), ...
        ['identity=' workspace_modified_text(modifiedState,info.live.workspaceLoaded, ...
            info.live.modelLoadedPath,info.live.compare,workspaceSource) ' | changed=' report_value(selected.workspaceChangedFields)], ...
        '所选历史 run P',selected.config, ...
        ['run_id=' selected.id ' | modelSHA=' selected.modelSha ' | P SHA=' selected.Psha ...
            ' | DecodeP SHA=' selected.DecodePsha ' | P identity=' selected.identityStatus ...
            ' | matSHA=' selected.matSha ' | source=' selected.selectionSource ...
            ' | observer=' selected.observerIdentity ' | workspace=' selected.workspaceChangeStatus ...
            ' | changed=' report_value(selected.workspaceChangedFields)]};
    ui.parameterLayers.ColumnName={'层','配置摘要','身份 / 状态'};
    ui.parameterLayers.Data=reshape(rows,3,[]).';
    keyRows=parameter_value_rows('当前 Workspace.P',info.live.raw);
    if ~info.live.workspaceLoaded,keyRows=parameter_value_rows('最近 apply P',info.applied.raw);end
    if ~isempty(selected.path)&&isstruct(selected.rawP)&&~isempty(fieldnames(selected.rawP))
        keyRows=[keyRows;parameter_value_rows(['历史 run ' selected.id],selected.rawP)];
    end
    ui.parameterValues.ColumnName={'参数','值 / 单位','配置层'};
    ui.parameterValues.Data=keyRows;

    reportObject=field_any(payload,{'report'},struct());
    parameterState=field_any(payload,{'parameter_state'},struct());
    derivation=field_any(payload,{'parameter_derivation','derived_report'},[]);
    if isempty(derivation)
        derivation=field_any(reportObject,{'parameter_derivation','derived_report'},[]);
    end
    if isempty(derivation),derivation=field_any(parameterState,{'parameter_derivation','derived_report'},[]);end
    if isempty(derivation)
        derivation=field_any(info.appliedRecord,{'parameter_derivation','derived_report'},[]);
    end
    derivedProjection=field_any(workspaceSummary,{'derived'},[]);
    if isempty(derivedProjection),derivedProjection=field_any(appliedSummary,{'derived'},[]);end
    ui.parameterDerivation.Value=derivation_lines(derivation,derivedProjection);
    noise=field_any(derivation,{'noise_convention'},[]);
    if isempty(noise),noise=field_any(payload,{'noise_convention'},[]);end
    if isempty(noise),noise=field_any(reportObject,{'noise_convention'},[]);end
    if isempty(noise),noise=field_any(parameterState,{'noise_convention'},[]);end
    if isempty(noise),noise=field_any(appliedState,{'noise_convention'},[]);end
    if isempty(noise),noise=field_any(info.appliedRecord,{'noise_convention'},[]);end
    ui.noiseConvention.Value=noise_lines(noise);
end

function rows=parameter_value_rows(tier,P)
    paths={ ...
        'P.N',{'N'}; 'P.Ts_s',{'Ts_s'}; 'P.fs_hz',{'fs_hz'}; ...
        'P.input.frequency_hz',{'input','frequency_hz'}; ...
        'P.input.amplitude_v',{'input','amplitude_v'}; ...
        'P.backend.az.mode',{'backend','az','mode'}; ...
        'P.backend.ra.A0',{'backend','ra','A0'}; ...
        'P.backend.ra.UGB_hz',{'backend','ra','UGB_hz'}; ...
        'P.backend.ra.Cf_f',{'backend','ra','Cf_f'}; ...
        'P.front.tau_sample_s',{'front','tau_sample_s'}; ...
        'P.front.tau_dac_s',{'front','tau_dac_s'}; ...
        'P.front.ktc_enabled / temperature_K / seed',{'front','ktc_enabled'}; ...
        'P.backend.ra_noise.sigma_vx_rms / seed_u64',{'backend','ra_noise','sigma_vx_rms'}; ...
        'P.control.comparator.enabled / sigma_vy_rms / seed_u64',{'control','comparator','enabled'}; ...
        'P.debug.observer.enabled / sample_id / Ts_s',{'debug','observer'}; ...
        'P.bank.enabled',{'bank','enabled'}; 'P.transport.enabled',{'transport','enabled'}; ...
        'P.training.enabled',{'training','enabled'}; 'P.seed (run label)',{'seed'}};
    rows=cell(size(paths,1),3);
    for k=1:size(paths,1)
        value=nested_value(P,paths{k,2},[]);
        if strcmp(paths{k,1},'P.front.ktc_enabled / temperature_K / seed')&&has_struct_fields(P)
            f=field_any(P,{'front'},struct());value=struct('enabled',field_any(f,{'ktc_enabled'},[]), ...
                'temperature_K',field_any(f,{'temperature_K'},[]),'seed',field_any(f,{'ktc_seed'},[]));
        elseif strcmp(paths{k,1},'P.backend.ra_noise.sigma_vx_rms / seed_u64')&&has_struct_fields(value)
            value=struct('sigma_vx_rms',field_any(value,{'sigma_vx_rms'},[]), ...
                'seed_u64',field_any(value,{'seed_u64'},[]));
        elseif strcmp(paths{k,1},'P.control.comparator.enabled / sigma_vy_rms / seed_u64')&&has_struct_fields(value)
            value=struct('enabled',field_any(value,{'enabled'},[]), ...
                'sigma_vy_rms',field_any(value,{'sar2_noise_rms_v'},[]), ...
                'seed_u64',field_any(value,{'seed_u64'},[]));
        end
        if isempty(value),value='未记录';else,value=value_text(value);end
        rows(k,:)={paths{k,1},value,tier};
    end
end

function open_parameter_browser(fig)
    state=fig.UserData;root=state.root;info=project_status(root);
    sources=struct('name',{},'P',{},'status',{},'path',{});
    if info.live.workspaceLoaded&&has_struct_fields(info.live.raw)
        sources(end+1)=struct('name','当前 ModelWorkspace.P','P',info.live.raw, ...
            'status',['读取目标模型Workspace；Dirty=' info.live.dirty], ...
            'path',fullfile(root,'current','models','SarAdc.slx')); %#ok<AGROW>
    end
    [exactP,exactStatus,exactPath]=load_applied_exact_p(root,info.appliedRecord);
    if has_struct_fields(exactP)
        sources(end+1)=struct('name','最近已应用精确P snapshot','P',exactP, ...
            'status',exactStatus,'path',exactPath); %#ok<AGROW>
    elseif has_struct_fields(info.applied.raw)
        sources(end+1)=struct('name','applied_config.json P投影（非exact MAT）', ...
            'P',info.applied.raw,'status',['非exact投影：' exactStatus], ...
            'path',fullfile(root,'state','applied_config.json')); %#ok<AGROW>
    end
    selected=selected_run_descriptor(state);
    if has_struct_fields(selected.rawP)
        sources(end+1)=struct('name',['历史run P: ' selected.id],'P',selected.rawP, ...
            'status',['P_sha=' selected.Psha ' DecodeP_sha=' selected.DecodePsha ...
            ' identity=' selected.identityStatus ' MAT_SHA=' selected.matSha], ...
            'path',fullfile(selected.path,'parameters.mat')); %#ok<AGROW>
    end
    if isempty(sources),uialert(fig,'当前没有可浏览的P结构。','完整P浏览');return;end
    bfig=uifigure('Name','SAR20 | 完整P字段浏览器','Tag','SAR20FullPBrowser', ...
        'Position',[100 80 1180 780]);
    g=uigridlayout(bfig,[3 1]);g.RowHeight={42,'1x',190};g.Padding=[8 8 8 8];g.RowSpacing=8;
    bar=uigridlayout(g,[1 4]);bar.Layout.Row=1;bar.ColumnWidth={220,'1x',280,110};
    uilabel(bar,'Text','参数来源');
    sourceDrop=uidropdown(bar,'Items',{sources.name},'Value',sources(1).name, ...
        'ValueChangedFcn',@(s,e)load_parameter_browser_source(bfig));
    search=uieditfield(bar,'text','Placeholder','搜索字段路径 / 值', ...
        'ValueChangedFcn',@(s,e)filter_parameter_browser(bfig));
    statusLabel=uilabel(bar,'Text','','WordWrap','on');
    tableGrid=uigridlayout(g,[1 1]);tableGrid.Layout.Row=2;
    fieldTable=uitable(tableGrid,'Data',cell(0,4),'RowName',{}, ...
        'CellSelectionCallback',@(s,e)parameter_browser_row_selected(bfig,e));
    fieldTable.ColumnSortable=false;fieldTable.ColumnName={'完整字段路径','类型','维度','预览'};
    fieldTable.Layout.Row=1;fieldTable.Layout.Column=1;
    detail=uitextarea(g,'Editable','off','Value',{'选择一个字段查看完整值。'},'FontSize',10);
    detail.Layout.Row=3;
    browser=struct('sources',sources,'sourceDrop',sourceDrop,'search',search, ...
        'status',statusLabel,'table',fieldTable,'detail',detail,'entries',[], ...
        'filteredIndex',[],'root',root);
    bfig.UserData=browser;
    load_parameter_browser_source(bfig);
end

function [P,status,path]=load_applied_exact_p(root,record)
    P=struct();status='没有已提交的exact parameters.mat';path='';
    rel=value_text(field_any(record,{'parameters_mat'},''));
    expected=value_text(field_any(record,{'parameters_mat_sha256'},''));
    if isempty(rel)||strcmp(rel,'未知'),return;end
    path=fullfile(root,rel);d=dir(path);
    if isempty(d)||d.isdir,status='应用快照路径不存在';return;end
    if d.bytes>300e6,status='应用快照超过300 MB，未读取';return;end
    rootPath=canonical_path(root);filePath=canonical_path(path);
    prefix=[rootPath filesep];
    if ~startsWith(lower(filePath),lower(prefix)),status='应用快照路径不在项目根下，拒绝读取';return;end
    if isempty(expected)||any(strcmpi(expected,{'未知','unknown'})),status='apply记录缺少MAT SHA，未读取';return;end
    actual=sha256_file(path);
    if ~strcmpi(actual,expected),status='应用快照MAT SHA不匹配，拒绝读取';return;end
    try
        loaded=load(path,'P','DecodeP','identity');
        if ~all(isfield(loaded,{'P','DecodeP','identity'}))
            status='MAT缺少P/DecodeP/identity，未读取';return;
        end
        identity=loaded.identity;
        checks={ ...
            {'model_sha256',field_any(record,{'model_sha256'},'')}, ...
            {'P_sha256',field_any(record,{'P_sha256'},'')}, ...
            {'DecodeP_sha256',field_any(record,{'DecodeP_sha256'},'')}};
        for k=1:numel(checks)
            check=checks{k};key=check{1};want=value_text(check{2});got=value_text(field_any(identity,{key},''));
            if isempty(want)||any(strcmpi(want,{'unknown','未记录'}))
                status=['apply记录缺少必需identity hash：' key];return;
            end
            if isempty(got)||any(strcmpi(got,{'unknown','未记录'}))
                status=['MAT identity缺少必需hash：' key];return;
            end
            if ~strcmpi(want,got)
                status=['apply身份不匹配：' key];return;
            end
        end
        P=loaded.P;status=['exact snapshot verified; MAT SHA=' short_hash(actual)];
    catch ex
        P=struct();status=['应用快照读取失败：' ex.message];
    end
end

function load_parameter_browser_source(fig)
    browser=fig.UserData;index=find(strcmp({browser.sources.name},browser.sourceDrop.Value),1);
    if isempty(index),return;end
    P=browser.sources(index).P;
    browser.entries=flatten_parameter_values(P,'P',struct('path',{},'class',{},'size',{},'preview',{},'value',{}));
    browser.status.Text=[browser.sources(index).status ' | ' browser.sources(index).path];
    fig.UserData=browser;
    filter_parameter_browser(fig);
end

function entries=flatten_parameter_values(value,prefix,entries)
    if isstruct(value)
        if isscalar(value)
            names=fieldnames(value);
            for k=1:numel(names),entries=flatten_parameter_values(value.(names{k}),[prefix '.' names{k}],entries);end
        else
            for k=1:numel(value),entries=flatten_parameter_values(value(k),sprintf('%s(%d)',prefix,k),entries);end
        end
    elseif iscell(value)&&numel(value)<=500
        for k=1:numel(value),entries=flatten_parameter_values(value{k},sprintf('%s{%d}',prefix,k),entries);end
    else
        entry=struct('path',prefix,'class',class(value),'size',mat2str(size(value)), ...
            'preview',parameter_preview(value),'value',value);
        entries(end+1)=entry;
    end
end

function txt=parameter_preview(value)
    if isnumeric(value)||islogical(value)
        if numel(value)<=24,txt=mat2str(value,6);
        else
            flat=value(:);txt=sprintf('%s head=%s ... tail=%s',mat2str(size(value)), ...
                mat2str(flat(1:min(8,end)).',6),mat2str(flat(max(1,end-7):end).',6));
        end
    elseif ischar(value)||isstring(value)
        txt=value_text(value);
    elseif iscell(value)
        txt=sprintf('cell %s; values expanded in child fields when <=500',mat2str(size(value)));
    else
        txt=sprintf('%s %s',class(value),mat2str(size(value)));
    end
end

function filter_parameter_browser(fig)
    browser=fig.UserData;entries=browser.entries;query=lower(strtrim(browser.search.Value));
    keep=false(1,numel(entries));
    for k=1:numel(entries)
        hay=lower([entries(k).path ' ' entries(k).class ' ' entries(k).size ' ' entries(k).preview]);
        keep(k)=isempty(query)||contains(hay,query);
    end
    browser.filteredIndex=find(keep);
    rows=cell(numel(browser.filteredIndex),4);
    for k=1:numel(browser.filteredIndex)
        e=entries(browser.filteredIndex(k));rows(k,:)={e.path,e.class,e.size,e.preview};
    end
    browser.table.Data=rows;fig.UserData=browser;
end

function parameter_browser_row_selected(fig,event)
    if isempty(event.Indices),return;end
    browser=fig.UserData;row=event.Indices(1,1);
    if row<1||row>numel(browser.filteredIndex),return;end
    entry=browser.entries(browser.filteredIndex(row));value=entry.value;
    if (isnumeric(value)||islogical(value))&&numel(value)>20000
        detail=['完整值过大，未展开。size=' entry.size ' preview=' parameter_preview(value) ...
            ' | exact值仍在来源MAT中：' browser.sources(find(strcmp({browser.sources.name},browser.sourceDrop.Value),1)).path];
    else
        detail=sprintf('%s\nclass=%s\nsize=%s\nvalue=%s',entry.path,entry.class,entry.size,parameter_full_value(value));
    end
    browser.detail.Value=splitlines(string(detail));
end

function txt=parameter_full_value(value)
    if isnumeric(value)||islogical(value)
        txt=mat2str(value,10);
    elseif ischar(value)||isstring(value)
        txt=value_text(value);
    elseif iscell(value)
        txt=report_value(value);
    elseif isstruct(value)
        txt=report_value(value);
    else
        txt=parameter_preview(value);
    end
end

function lines=derivation_lines(report,derivedProjection)
    if isempty(report)||~isstruct(report)
        lines={'参数差异/派生量报告：未记录或旧 apply 不含此报告。', ...
            '变更字段、重算字段、保持字段未知；不能根据当前P推断上次apply执行了什么。'};
    else
        lines={ ...
            ['输入变化状态：' report_value(field_any(report,{'input_change_status'},[]))], ...
            ['变化字段：' report_value(field_any(report,{'changed_fields'},[]))], ...
            ['factory重算字段：' report_value(field_any(report,{'factory_recomputed_fields'},[]))], ...
            ['prepare重算字段：' report_value(field_any(report,{'prepare_recomputed_fields'},[]))], ...
            ['总重算字段：' report_value(field_any(report,{'recomputed_fields'},[]))], ...
            ['保持字段：' report_value(field_any(report,{'preserved_fields'},[]))], ...
            ['派生报告值（不在UI重算）：' report_value(field_any(report,{'derived_values'},[]))]};
    end
    if ~isempty(derivedProjection)
        lines{end+1}=['Resolved P派生投影（仅展示保存值）：' report_value(derivedProjection)];
        copied=field_any(derivedProjection,{'sigma_vx_recomputed_for_display'},[]);
        if ~isempty(copied)&&~logical(copied)
            lines{end+1}='sigma_vx_rms直接复制P.backend.ra_noise.sigma_vx_rms；UI未重算。';
        end
    end
end

function lines=noise_lines(noise)
    if isempty(noise)||~isstruct(noise)
        lines={'噪声口径：未记录；无法判断保存的是PSD、输出RMS或固定sigma。', ...
            'UI不改变噪声口径，也不由sigma字段推断其来源。'};return;
    end
    fields={'kind','field','value','unit','rule'};lines=cell(1,numel(fields));
    for k=1:numel(fields)
        lines{k}=[fields{k} '=' report_value(field_any(noise,fields{k},[]))];
    end
end

function txt=report_value(value)
    if isempty(value),txt='未记录';
    elseif iscell(value),parts=cellfun(@value_text,value,'UniformOutput',false);txt=strjoin(parts,'; ');
    elseif istable(value)
        parts=cell(size(value,1),1);
        for r=1:size(value,1),parts{r}=strjoin(cellfun(@value_text,table2cell(value(r,:)),'UniformOutput',false),' | ');end
        txt=strjoin(parts,'; ');
    elseif isstruct(value)&&isscalar(value)
        names=fieldnames(value);parts=cell(1,numel(names));
        for k=1:numel(names),parts{k}=[names{k} '=' value_text(value.(names{k}))];end
        txt=strjoin(parts,'; ');
    elseif isstruct(value)
        parts=cell(1,numel(value));for k=1:numel(value),parts{k}=report_value(value(k));end
        txt=strjoin(parts,'; ');
    else,txt=value_text(value);end
end

function navigate_focus(fig,payload,extra)
    target='';owner='';sid='';navigationOnly=false;sourcepoint='';
    if isstruct(payload)
        resolvedStatus=lower(value_text(field_any(payload,{'status'},'')));
        if contains(resolvedStatus,'ambiguous')||contains(resolvedStatus,'not_found')||contains(resolvedStatus,'error')
            detail=field_any(payload,{'message','reason','diagnostic'},resolvedStatus);
            set_status(fig,['导航未解析：' value_text(detail)]);
            uialert(fig,value_text(detail),'导航目标未唯一解析','Icon','warning');return;
        end
        target=value_text(field_any(payload,{'key','semantic_key','semanticKey','target'},''));
        owner=value_text(field_any(payload,{'owner','state_owner','stateOwner'},''));
        sid=value_text(field_any(payload,{'focus_sid','focusSid','sid'},''));
        navigationOnly=logical(field_any(payload,{'navigation_only','navigationOnly'},false));
        sourcepoint=value_text(field_any(payload,{'sourcepoint','sourcepoints','source_point'},''));
    else
        target=value_text(payload);
        if ~isempty(extra),owner=value_text(extra{1});end
    end
    if isempty(target)&&isempty(sid),set_status(fig,'导航目标缺失；未定位模型块。');return;end
    state=fig.UserData;modelFile=fullfile(state.root,'current','models','SarAdc.slx');
    manifestFile=fullfile(state.root,'state','model_navigation.json');manifest=struct();
    if isfile(manifestFile)
        d=dir(manifestFile);
        if d.bytes<=300e6,try,manifest=jsondecode(fileread(manifestFile));catch,manifest=struct();end,end
    end
    if isempty(sid)
        [entry,manifest,ambiguous]=navigation_target(manifest,target,owner);
        if ambiguous
            msg=['manifest含多个语义目标；请指定owner或阶段，不使用第一个SID：' target];
            set_status(fig,msg);uialert(fig,msg,'导航目标不唯一','Icon','warning');return;
        end
        if isempty(entry)
            set_status(fig,['manifest未找到语义目标：' target '；不猜测SID。']);
            return;
        end
        sid=value_text(field_any(entry,{'focus_sid','focusSid','sid'},''));
        navigationOnly=logical(field_any(entry,{'navigation_only','navigationOnly'},false));
        sourcepoint=value_text(field_any(entry,{'sourcepoint'},''));
        if isempty(owner),owner=value_text(field_any(entry,{'owner'},''));end
    end
    if isempty(sid),set_status(fig,['目标没有focus SID：' target]);return;end
    manifestSha=value_text(field_any(manifest,{'model_sha256','modelSha256'},''));
    currentSha=sha256_file(modelFile);
    reportSha='';if isstruct(payload),reportSha=value_text(field_any(payload,{'model_sha256','modelSha256'},''));end
    if isempty(manifestSha)&&isempty(reportSha)
        set_status(fig,'导航报告与model_navigation.json都没有绑定model SHA；拒绝使用未校验SID。');return;
    end
    if ~isempty(reportSha)&&~strcmpi(reportSha,currentSha)
        msg=sprintf('导航报告绑定SHA与当前模型不一致。report=%s; current=%s。拒绝使用过期SID。', ...
            short_hash(reportSha),short_hash(currentSha));
        set_status(fig,msg);uialert(fig,msg,'导航报告过期','Icon','warning');return;
    end
    if ~isempty(manifestSha)&&~strcmpi(manifestSha,currentSha)
        msg=sprintf('导航manifest绑定SHA与当前模型不一致。manifest=%s; current=%s。拒绝使用过期SID。', ...
            short_hash(manifestSha),short_hash(currentSha));
        set_status(fig,msg);uialert(fig,msg,'导航manifest过期','Icon','warning');return;
    end
    try
        if bdIsLoaded('SarAdc')
            loadedPath=get_param('SarAdc','FileName');
            if isempty(loadedPath)||~strcmpi(canonical_path(loadedPath),canonical_path(modelFile))
                error('SAR20Dashboard:OtherModelLoaded', ...
                    '同名模型 SarAdc 已从其他路径加载；为避免用错 SID，本次不导航也不关闭该模型。');
            end
        else
            load_system(modelFile);
        end
        blockPath=Simulink.ID.getFullName(sid);
        if isempty(blockPath),error('SAR20Dashboard:SID','SID %s 未解析到当前模型块。',sid);end
        open_system(blockPath);
        hilite_system(blockPath,'find');
        if navigationOnly,kind='（仅导航；不新增计算）';else,kind='';end
        msg=sprintf('已定位 %s | owner=%s | SID=%s %s',target,owner,sid,kind);
        if ~isempty(sourcepoint),msg=[msg ' | source=' sourcepoint];end
        state.focusTarget=target;fig.UserData=state;set_status(fig,msg);
    catch ex
        set_status(fig,['导航失败：' ex.message]);
        uialert(fig,ex.message,'模型导航失败','Icon','error');
    end
end

function [entry,manifest,ambiguous]=navigation_target(manifest,key,owner)
    entry=[];ambiguous=false;targets=field_any(manifest,{'targets'},[]);
    if ~isstruct(targets),return;end
    matches=[];
    for k=1:numel(targets)
        candidateKey=value_text(field_any(targets(k),{'key','semantic_key'},''));
        candidateOwner=value_text(field_any(targets(k),{'owner'},''));
        if strcmp(candidateKey,key)&&(isempty(owner)||isempty(candidateOwner)||strcmp(candidateOwner,owner))
            matches(end+1)=k; %#ok<AGROW>
        end
    end
    if numel(matches)==1,entry=targets(matches(1));
    elseif numel(matches)>1,ambiguous=true;end
end

function call_focus_from_ui(ui,key,owner)
    fig=fig_from(ui);call_sar20(fig,'focus',key,owner);
end

function focus_from_dropdown(ui,kind)
    if strcmp(kind,'physical')
        drop=ui.physicalDrop;keys=ui.physicalKeys;owner='';
    else
        drop=ui.executionDrop;keys=ui.executionKeys;owner='';
    end
    index=find(strcmp(drop.Items,drop.Value),1);
    if isempty(index)||index>numel(keys),return;end
    call_focus_from_ui(ui,keys{index},owner);
end

function f=fig_from(ui)
    f=ancestor(ui.tabHome,'figure');
end

function select_tab(fig,name)
    state=fig.UserData;ui=state.ui;
    switch name
        case 'home',ui.tabs.SelectedTab=ui.tabHome;
        case 'parameters',ui.tabs.SelectedTab=ui.tabParameters;refresh_parameters(fig,state.homeReport);
        case 'sample',ui.tabs.SelectedTab=ui.tabSample;
        case 'compare',ui.tabs.SelectedTab=ui.tabCompare;refresh_compare(fig,[]);
        case 'results',ui.tabs.SelectedTab=ui.tabResults;
        case 'fields',ui.tabs.SelectedTab=ui.tabFields;refresh_fields(fig);
    end
    save_session_safely(fig);
end

function on_tab_changed(fig)
    try
        state=fig.UserData;
        if isequal(state.ui.tabs.SelectedTab,state.ui.tabParameters),refresh_parameters(fig,state.homeReport);end
        if isequal(state.ui.tabs.SelectedTab,state.ui.tabFields),refresh_fields(fig);end
    catch
    end
    save_session_safely(fig);
end

function set_status(fig,message)
    if ~isvalid(fig),return;end
    state=fig.UserData;state.ui.statusLabel.Text=char(string(message));
end

function close_dashboard(fig)
    save_session_safely(fig);
    delete(fig);
end

function save_session_safely(fig)
    if ~isvalid(fig),return;end
    try
        state=fig.UserData;tab=1;
        tabs=state.ui.tabs;
        names={state.ui.tabHome,state.ui.tabParameters,state.ui.tabSample,state.ui.tabCompare,state.ui.tabResults,state.ui.tabFields};
        for k=1:numel(names),if isequal(tabs.SelectedTab,names{k}),tab=k;break;end,end
        runPath=state.selectedRunPath;sampleID=state.sampleID;eventRow=state.eventRow;
        session=struct('schema','sar20-ui-session/v1','selected_run_path',runPath, ...
            'sample_id',sampleID,'event_row',eventRow,'tab_index',tab, ...
            'position',double(fig.Position));
        f=fullfile(state.root,'state','ui_session.json');
        if ~isfolder(fileparts(f)),return;end
        tmp=[f '.tmp'];fid=fopen(tmp,'w');if fid<0,return;end
        cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
        fwrite(fid,jsonencode(session),'char');clear cleanup;
        movefile(tmp,f,'f');
    catch
        % UI preference persistence is best effort; no model/run state is written.
    end
end

function session=read_session(root)
    session=struct('selected_run_path','','sample_id',5,'event_row',1,'tab_index',1, ...
        'position',[80 60 1500 940]);
    f=fullfile(root,'state','ui_session.json');if ~isfile(f),return;end
    d=dir(f);if d.bytes>1e6,return;end
    try
        s=jsondecode(fileread(f));
        session.selected_run_path=char(string(field_any(s,{'selected_run_path'},'')));
        session.sample_id=double(field_any(s,{'sample_id'},5));
        session.event_row=double(field_any(s,{'event_row'},1));
        session.tab_index=double(field_any(s,{'tab_index'},1));
        q=field_any(s,{'position'},session.position);if isnumeric(q)&&numel(q)==4,session.position=double(q(:).');end
    catch
    end
end

function apply_session_to_figure(fig,session)
    state=fig.UserData;
    if session.tab_index>=1&&session.tab_index<=6
        tabs={state.ui.tabHome,state.ui.tabParameters,state.ui.tabSample,state.ui.tabCompare,state.ui.tabResults,state.ui.tabFields};
        state.ui.tabs.SelectedTab=tabs{session.tab_index};
    end
    state.sampleID=session.sample_id;state.eventRow=session.event_row;
    fig.UserData=state;
    state.ui.sampleIDField.Value=session.sample_id;
end

function root=project_root()
    entry=which('SAR20');
    if isempty(entry)
        error('SAR20Dashboard:Entry','SAR20.m is not on the MATLAB path. Open the project through its public entry first.');
    end
    root=fileparts(entry);
end

function y=first_arg(args,default)
    if isempty(args),y=default;else,y=args{1};end
end

function y=field_any(s,names,default)
    y=default;
    if ischar(names),names={names};elseif isstring(names),names=cellstr(names);end
    if isempty(s),return;end
    if istable(s)
        v=s.Properties.VariableNames;
    elseif isstruct(s)
        v=fieldnames(s);
    else
        return;
    end
    for k=1:numel(names)
        ix=find(strcmpi(v,names{k}),1);
        if ~isempty(ix)
            name=v{ix};
            if istable(s),if height(s)>0,y=s.(name);end
            elseif isscalar(s),y=s.(name);
            end
            return;
        end
    end
end

function name=field_name(t,names)
    name='';if ~istable(t),return;end
    v=t.Properties.VariableNames;
    for k=1:numel(names),ix=find(strcmpi(v,names{k}),1);if ~isempty(ix),name=v{ix};return;end,end
end

function n=height_safe(t)
    if istable(t),n=height(t);elseif isstruct(t),n=numel(t);else,n=0;end
end

function row=table_row(t,k)
    if istable(t),row=table2struct(t(k,:));elseif isstruct(t)&&numel(t)>=k,row=t(k);else,row=struct();end
end

function t=cnv_time(events)
    t=NaN;if ~istable(events)||height(events)==0,return;end
    names=events.Properties.VariableNames;timeName=field_name(events,{'time_s','time'});
    eventName=field_name(events,{'eventName','event_name','event','eventType'});
    if isempty(timeName),return;end
    if ~isempty(eventName)
        ev=lower(string(events.(eventName)));ix=find(contains(ev,'cnv'),1);
        if ~isempty(ix),t=double(events.(timeName)(ix));return;end
    end
end

function t=cnv_or_zero(cnv)
    if isfinite(cnv),t=cnv;else,t=0;end
end

function txt=event_summary(row)
    names={'sampleID','epoch','eventRow','eventGroupRow','phaseOrdinal','eventName','phaseName', ...
        'event','phase','time_s','timeFromCnv_s','dtFromCnv_s','actualGroupObserved', ...
        'phaseTimeScope','sample_v','target_v','Vtop','vtop_v','VY_phys','vy_v','cmp_effective_v', ...
        'wasExecuted','valid','late','RecordReady','RAW_valid','validRecord_event'};parts={};
    for k=1:numel(names)
        v=field_any(row,names{k},[]);if ~isempty(v),parts{end+1}=[names{k} '=' value_text(v)];end %#ok<AGROW>
    end
    txt=strjoin(parts,' | ');
end

function txt=decision_summary(D,event,eventRow)
    parts={};
    v=field_any(event,{'vres_v','fine_vres_v'},[]);
    if ~isempty(v),parts{end+1}=['fine Vres=' value_text(v) ' V'];end %#ok<AGROW>
    v=field_any(event,{'VY_phys','VY','vy_v','physical_vy_v'},[]);
    if ~isempty(v),parts{end+1}=['D2/TA VY_phys=' value_text(v) ' V'];end %#ok<AGROW>
    v=field_any(event,{'cmp_effective_v','comparison_used','comparatorInput','comparator_input'},[]);
    if ~isempty(v),parts{end+1}=['comparison used=' value_text(v)];end %#ok<AGROW>
    v=field_any(event,{'cmp_offset_v'},[]);
    if ~isempty(v),parts{end+1}=['cmp offset=' value_text(v) ' V'];end %#ok<AGROW>
    v=field_any(event,{'cmp_noise_v'},[]);
    if ~isempty(v),parts{end+1}=['cmp noise=' value_text(v) ' V'];end %#ok<AGROW>
    names={'decision','decision1','decision2','decisionResult','decision_result','bit','valid','late'};
    for k=1:numel(names)
        v=field_any(event,names{k},[]);
        if ~isempty(v),parts{end+1}=[names{k} '=' value_text(v)];end %#ok<AGROW>
    end
    d2=field_any(D,{'firstD2','first_d2'},[]);
    if isstruct(d2)
        d2row=field_any(d2,{'eventRow','event_row'},[]);
        if isequal(double(d2row),double(eventRow))
            phase=field_any(d2,{'phase','phaseName','phase_name','eventName'},[]);
            if ~isempty(phase),parts{end+1}=['首次D2阶段=' value_text(phase)];end %#ok<AGROW>
            v=field_any(d2,{'comparatorInput','comparator_input','comparison_used'},[]);
            if ~isempty(v),parts{end+1}=['首次D2实际输入=' value_text(v)];end %#ok<AGROW>
        end
    end
    if isempty(parts),txt='判决输入/结果：该事件未记录';else,txt=strjoin(parts,'; ');end
end

function txt=validity_explanation(bank,ready,raw,validity)
    bankEnabled=field_any(validity,{'bank_enabled','bankEnabled'},[]);
    if ~isempty(bankEnabled)&&isscalar(bankEnabled)&&~logical(bankEnabled)
        txt='Bank关闭：旧 CodeValid=0 表示Bank输出资格没有发布，不代表RAW记录无效。';
    elseif isscalar(bank)&&isnumeric(bank)&&bank==0&&(~isempty(ready)||~isempty(raw))
        txt='旧 CodeValid=0 表示Bank输出资格未发布；不能据此否定RAW记录有效性。';
    else
        txt='未用旧 CodeValid 替代 RecordReady / RAW.valid / 对齐后的有效记录。';
    end
end

function textOut=lines_for_value(v)
    if iscell(v),textOut=cellfun(@value_text,v,'UniformOutput',false);
    elseif isstring(v),textOut=cellstr(v(:));
    elseif istable(v),textOut=table2cell(v);textOut=cellfun(@value_text,textOut,'UniformOutput',false);textOut=textOut(:);
    elseif isstruct(v)
        textOut=cell(numel(v),1);for k=1:numel(v),textOut{k}=value_text(v(k));end
    else,textOut={value_text(v)};end
    if isempty(textOut),textOut={'未记录'};end
end

function txt=value_text_or_unknown(v)
    if isempty(v),txt='未记录';else,txt=value_text(v);end
end

function txt=value_text(v)
    if isempty(v),txt='';
    elseif ischar(v),txt=v;
    elseif isstring(v),txt=strjoin(cellstr(v(:)),'; ');
    elseif islogical(v),txt=mat2str(v);
    elseif isnumeric(v),txt=mat2str(v,8);
    elseif iscell(v),parts=cellfun(@value_text,v,'UniformOutput',false);txt=strjoin(parts,', ');
    elseif istable(v)
        txt=sprintf('table[%d x %d]: %s',height(v),width(v),strjoin(v.Properties.VariableNames,','));
    elseif isstruct(v)
        if ~isscalar(v)
            parts=cell(1,numel(v));for k=1:numel(v),parts{k}=value_text(v(k));end
            txt=strjoin(parts,' | ');
        else
            fn=fieldnames(v);parts=cell(1,min(8,numel(fn)));
            for k=1:numel(parts),parts{k}=[fn{k} '=' value_text(v.(fn{k}))];end
            txt=strjoin(parts,'; ');if numel(fn)>8,txt=[txt '; …'];end
        end
    else,txt=char(string(v));end
end

function label=onoff(v)
    if isempty(v),label='未记录';elseif islogical(v)||isnumeric(v)
        if all(double(v(:))==0),label='关闭';elseif all(double(v(:))==1),label='开启';else,label=value_text(v);end
    elseif ischar(v)||isstring(v)
        q=lower(strtrim(char(string(v))));
        if any(strcmp(q,{'true','on','yes','enabled','1'})),label='开启';
        elseif any(strcmp(q,{'false','off','no','disabled','0'})),label='关闭';
        else,label=value_text(v);end
    else,label=value_text(v);end
end

function path=canonical_path(path)
    try,path=char(java.io.File(path).getCanonicalPath());catch,end
end

function id=run_id_from_path(path)
    [~,id]=fileparts(char(path));
end

function hash=short_hash(hash)
    if isempty(hash),hash='未知';elseif numel(hash)>16,hash=[hash(1:12) '…'];end
end

function [hash,ok,fileHashes]=source_bundle_hash(files,relativePaths,keys)
    ok=true;fileHashes=struct();bytes=uint8([]);
    for k=1:numel(files)
        if ~isfile(files{k}),ok=false;hash='源文件缺失';return;end
        meta=dir(files{k});
        if meta.bytes>300e6,ok=false;hash='源文件超过300 MB，未读取';return;end
        fhash=sha256_file(files{k});
        fileHashes.(keys{k})=fhash;
        part=unicode2native([relativePaths{k} char(0) fhash char(10)],'UTF-8');
        bytes=[bytes;uint8(part(:))]; %#ok<AGROW>
    end
    hash=sha256_bytes(bytes);
end

function hash=sha256_file(file)
    fid=fopen(file,'rb');if fid<0,hash='不可读';return;end
    c=onCleanup(@()fclose(fid));bytes=fread(fid,Inf,'*uint8');clear c;
    hash=sha256_bytes(bytes);
end

function hash=sha256_bytes(bytes)
    md=java.security.MessageDigest.getInstance('SHA-256');md.update(uint8(bytes));
    digest=typecast(md.digest(),'uint8');hash=lower(reshape(dec2hex(digest,2).',1,[]));
end
