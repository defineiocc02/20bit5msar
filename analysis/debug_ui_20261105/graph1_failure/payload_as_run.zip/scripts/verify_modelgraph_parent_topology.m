function verified=verify_modelgraph_parent_topology(model,fpgaRead,groups)
%VERIFY_MODELGRAPH_PARENT_TOPOLOGY Check wrapper-to-RAW/POL/sum/Outport wiring.
verified={}; rawId=findId(fpgaRead,'RawFields'); polId=findId(fpgaRead,'PublicPol');
for k=1:numel(groups)
    g=groups(k); wrapperId=findId(fpgaRead,g.wrapper);
    for q=1:numel(g.parent_inputs)
        srcName=g.parent_inputs{q}; if strcmp(srcName,'RawFields'), srcId=rawId; else, srcId=polId; end
        srcPort=g.parent_input_ports(q); dstPort=q;
        verifyEdge(model,srcId,srcPort,wrapperId,dstPort,[g.wrapper ' input ' srcName '.y' num2str(srcPort)]);
        verified{end+1}=struct('wrapper',g.wrapper,'direction','input', ...
            'source_id',srcId,'source_port',srcPort,'destination_id',wrapperId,'destination_port',dstPort); %#ok<AGROW>
    end
    for q=1:numel(g.parent_outputs)
        dstId=findId(fpgaRead,g.parent_outputs{q}); srcPort=1; dstPort=g.parent_output_ports(q);
        verifyEdge(model,wrapperId,srcPort,dstId,dstPort, ...
            [g.wrapper ' output ' g.parent_outputs{q} '.u' num2str(dstPort)]);
        verified{end+1}=struct('wrapper',g.wrapper,'direction','output', ...
            'source_id',wrapperId,'source_port',srcPort,'destination_id',dstId,'destination_port',dstPort); %#ok<AGROW>
    end
end
end

function verifyEdge(model,srcId,srcIndex,dstId,dstIndex,label)
srcPath=fullPath(model,srcId); dstPath=fullPath(model,dstId);
srcHandles=get_param(srcPath,'PortHandles'); dstHandles=get_param(dstPath,'PortHandles');
srcPort=srcHandles.Outport(srcIndex); dstPort=dstHandles.Inport(dstIndex);
lineHandle=get_param(srcPort,'Line');
if isempty(lineHandle)||all(lineHandle==-1), error('sar20:modelgraph:MissingWire','No source line for %s.',label); end
dstPorts=[];
for q=1:numel(lineHandle)
    if lineHandle(q)==-1,continue;end
    h=get_param(lineHandle(q),'DstPortHandle'); dstPorts=[dstPorts;h(:)]; %#ok<AGROW>
end
if ~any(dstPorts==dstPort),error('sar20:modelgraph:WrongWire','Wrong parent destination for %s.',label);end
end
function id=findId(report,name)
lines=splitlines(string(report)); cur=''; hits={};
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t),cur=t{1};continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(cur),hits{end+1}=cur;cur='';end %#ok<AGROW>
end
hits=unique(hits,'stable'); if numel(hits)~=1,error('sar20:modelgraph:TopologyId','Expected one ID for %s, got %d.',name,numel(hits));end
id=hits{1};
end
function path=fullPath(model,id)
path=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
