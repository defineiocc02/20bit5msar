function groups=load_fpga_stage1_groups(spec)
%LOAD_FPGA_STAGE1_GROUPS Hydrate the executable wrapper plan from JSON spec.
if ~isfield(spec,'baseline_sha256') || ~isfield(spec,'groups') || isempty(spec.groups)
    error('sar20:modelgraph:FPGAStageSpec','fpga_stage1_spec.json lacks groups or baseline identity.');
end
rows=spec.groups;
groups=struct([]);
for k=1:numel(rows)
    r=rows(k);
    g=struct();
    g.key_field=char(r.key_field);
    g.wrapper=char(r.wrapper);
    g.ref=char(r.ref);
    g.inputs=cellStrings(r.inputs);
    g.outputs=cellStrings(r.outputs);
    g.nodes=cellStrings(r.nodes);
    g.edges=cellStrings(r.edges);
    g.parent_inputs={}; g.parent_input_ports=[];
    for q=1:numel(r.parent_inputs)
        g.parent_inputs{q}=char(r.parent_inputs(q).name); %#ok<AGROW>
        g.parent_input_ports(q)=double(r.parent_inputs(q).port); %#ok<AGROW>
    end
    g.parent_outputs={}; g.parent_output_ports=[];
    for q=1:numel(r.parent_outputs)
        g.parent_outputs{q}=char(r.parent_outputs(q).name); %#ok<AGROW>
        g.parent_output_ports(q)=double(r.parent_outputs(q).port); %#ok<AGROW>
    end
    g.display_text=char(r.display_text);
    groups(k)=g; %#ok<AGROW>
end
end

function c=cellStrings(v)
if iscell(v)
    c=cell(1,numel(v));
    for k=1:numel(v), c{k}=char(v{k}); end
elseif isstring(v)
    c=cellstr(v(:)).';
elseif ischar(v)
    c={v};
else
    error('sar20:modelgraph:FPGAStringArray','Expected a JSON string array.');
end
end
