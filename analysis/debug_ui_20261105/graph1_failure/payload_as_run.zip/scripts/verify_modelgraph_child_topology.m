function verified = verify_modelgraph_child_topology(model,childRead,group,inputIds,outputIds)
%VERIFY_MODELGRAPH_CHILD_TOPOLOGY Confirm every planned internal edge by port handles.
verified={}; internalIds=struct();
for k=1:numel(group.nodes)
    internalIds.(matlab.lang.makeValidName(group.nodes{k}))=findId(childRead,group.nodes{k});
end
for k=1:numel(group.edges)
    edge=split(string(group.edges{k}),'>'); src=char(edge(1)); dst=char(edge(2));
    [srcName,srcPort]=splitEndpoint(src); [dstName,dstPort]=splitEndpoint(dst);
    if any(strcmp(group.inputs,srcName))
        srcId=inputIds{find(strcmp(group.inputs,srcName),1)};
    else
        srcId=internalIds.(matlab.lang.makeValidName(srcName));
    end
    if any(strcmp(group.outputs,dstName))
        dstId=outputIds{find(strcmp(group.outputs,dstName),1)};
    else
        dstId=internalIds.(matlab.lang.makeValidName(dstName));
    end
    verifyEdge(model,srcId,'Outport',srcPort,dstId,'Inport',dstPort,[group.wrapper ':' src ' -> ' dst]);
    verified{end+1}=struct('source_id',srcId,'source_port',srcPort, ...
        'destination_id',dstId,'destination_port',dstPort); %#ok<AGROW>
end
end

function verifyEdge(model,srcId,srcKind,srcIndex,dstId,dstKind,dstIndex,label)
srcPath=fullPath(model,srcId); dstPath=fullPath(model,dstId);
srcHandles=get_param(srcPath,'PortHandles'); dstHandles=get_param(dstPath,'PortHandles');
srcPort=srcHandles.(srcKind)(srcIndex); dstPort=dstHandles.(dstKind)(dstIndex);
lineHandle=get_param(srcPort,'Line');
if isempty(lineHandle) || all(lineHandle==-1)
    error('sar20:modelgraph:MissingWire','Expected connected source port for %s.',label);
end
dstPorts=[];
for q=1:numel(lineHandle)
    if lineHandle(q)==-1, continue; end
    handleTargets=get_param(lineHandle(q),'DstPortHandle');
    dstPorts=[dstPorts;handleTargets(:)]; %#ok<AGROW>
end
if ~any(dstPorts==dstPort)
    error('sar20:modelgraph:WrongWire','Connected source does not terminate at expected destination for %s.',label);
end
end

function [name,index]=splitEndpoint(text)
parts=split(string(text),'.');
if numel(parts)==1, name=char(parts(1)); index=1; return; end
name=char(parts(1)); port=char(parts(2)); tok=regexp(port,'[uy]([0-9]+)','tokens','once');
if isempty(tok), error('sar20:modelgraph:PortSyntax','Cannot parse port index in %s.',text); end
index=str2double(tok{1});
end

function id=findId(report,name)
lines=splitlines(string(report)); cur=''; hits={};
for k=1:numel(lines)
    line=char(lines(k)); t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t),cur=t{1};continue;end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t)&&strcmp(strtrim(t{1}),name)&&~isempty(cur),hits{end+1}=cur;cur='';end %#ok<AGROW>
end
hits=unique(hits,'stable'); if numel(hits)~=1,error('sar20:modelgraph:TopologyId','Expected one ID for %s, got %d.',name,numel(hits));end
id=hits{1};
end
function path=fullPath(model,id)
path=char(Simulink.ID.getFullName([model ':' char(extractAfter(string(id),'blk_'))]));
end
