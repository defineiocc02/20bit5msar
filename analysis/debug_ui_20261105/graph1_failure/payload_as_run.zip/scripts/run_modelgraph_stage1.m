function receipt = run_modelgraph_stage1(projectRoot, privateWorkRoot, varargin)
%RUN_MODELGRAPH_STAGE1 Prepare a private 9197 modelgraph candidate via SATK only.
% This callable stage performs layout/PhysicalView/FPGA D1-D2-DT wrapping only.
% It does not add diagnostic S-function ports or Observer logging and never simulates.
%
% Usage on Windows MATLAB R2024a (root-owned execution only):
%   r = run_modelgraph_stage1(projectRoot, privateWorkRoot)
%   r = run_modelgraph_stage1(projectRoot, privateWorkRoot, 'ColdOpenCompile', true)
%
% Inputs:
%   projectRoot     SAR20 project root, containing current/models/SarAdc.slx
%   privateWorkRoot NEW folder outside projectRoot for a private candidate/receipts
%   ColdOpenCompile true by default; save, cold-open, set SimulationCommand=update,
%                    save receipt. This is diagram compilation only, no simulation.
%
% Safety: reads current baseline, verifies its exact SHA, copies to privateWorkRoot,
% and edits only that copy. All structural changes go through model_edit. A failed
% or partial operation saves a private partial + hash, immediately read/checks the
% active scope and stops. The script never calls native add_block/set_param to edit.

p = inputParser;
addParameter(p, 'ColdOpenCompile', true, @(x)islogical(x)&&isscalar(x));
addParameter(p, 'KeepModelOpen', true, @(x)islogical(x)&&isscalar(x));
parse(p, varargin{:});
opt = p.Results;
projectRoot = char(projectRoot);
privateWorkRoot = char(privateWorkRoot);
expectedSha = '91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e';

if isempty(projectRoot) || ~isfolder(projectRoot)
    error('sar20:modelgraph:ProjectRoot', 'projectRoot must contain the SAR20 project.');
end
if isempty(privateWorkRoot)
    error('sar20:modelgraph:PrivateRoot', 'privateWorkRoot is required.');
end
projectCanonical = canonicalPath(projectRoot);
workCanonical = canonicalPath(privateWorkRoot);
if startsWith(lower(workCanonical), lower(projectCanonical))
    error('sar20:modelgraph:PrivateBoundary', 'privateWorkRoot must be outside projectRoot.');
end

% Restore MATLAB path on exit. The functions below use SATK only for edits.
oldPath = path;
pathCleanup = onCleanup(@()path(oldPath)); %#ok<NASGU>
toolRoot = fullfile(projectRoot, 'dependencies', 'toolkit', 'tools');
requiredToolDirs = {fullfile(toolRoot,'common'), fullfile(toolRoot,'common','autolayout'), ...
    fullfile(toolRoot,'model_read'), fullfile(toolRoot,'model_edit'), fullfile(toolRoot,'model_check')};
for k = 1:numel(requiredToolDirs)
    if ~isfolder(requiredToolDirs{k})
        error('sar20:modelgraph:ToolkitMissing', 'Missing SATK directory: %s', requiredToolDirs{k});
    end
end
addpath(requiredToolDirs{:});
addpath(genpath(fullfile(projectRoot, 'current', 'src')));

% The library/policy gate is intentionally the first SATK action and precedes
% any model XML/spec parsing or model_read/edit operation.
gate = library.settingsLookup();
if gate.found && ~gate.gatePass
    error('sar20:modelgraph:LibraryGate', ...
        'settingsLookup found custom libraries but gatePass=false; stop before model_read/edit.');
end
if gate.found && gate.gatePass
    if ~isfile(gate.kgIndexPath)
        error('sar20:modelgraph:LibraryIndex', 'Gate passed but KG index is missing: %s', gate.kgIndexPath);
    end
    kgIndexText = fileread(gate.kgIndexPath); %#ok<NASGU>
end

sourceModel = fullfile(projectRoot, 'current', 'models', 'SarAdc.slx');
if ~isfile(sourceModel)
    error('sar20:modelgraph:BaselineMissing', 'Missing source baseline: %s', sourceModel);
end
sourceSha = sha256File(sourceModel);
if ~strcmpi(sourceSha, expectedSha)
    error('sar20:modelgraph:BaselineSha', 'Expected 9197 SHA %s, got %s.', expectedSha, sourceSha);
end

scriptRoot = fileparts(mfilename('fullpath'));
generatedRoot = fullfile(scriptRoot, 'generated');
sourceInventory = jsondecode(fileread(fullfile(generatedRoot, 'source_inventory.json')));
fpgaSpec = jsondecode(fileread(fullfile(generatedRoot, 'fpga_stage1_spec.json')));
if ~strcmpi(sourceInventory.baseline_sha256, expectedSha) || ...
        ~strcmpi(fpgaSpec.baseline_sha256, expectedSha)
    error('sar20:modelgraph:SpecSha', 'Generated spec identity does not match current 9197 baseline.');
end

if ~isfolder(privateWorkRoot), mkdir(privateWorkRoot); end
receiptDir = fullfile(privateWorkRoot, 'receipts');
if ~isfolder(receiptDir), mkdir(receiptDir); end
candidatePath = fullfile(privateWorkRoot, 'SarAdc.slx');
if isfile(candidatePath)
    error('sar20:modelgraph:CandidateExists', ...
        'Candidate exists. Do not rerun this whole stage over it. Continue from its recorded private SHA using fresh root model_read/model_check, or choose a new privateWorkRoot: %s', candidatePath);
end
copyfile(sourceModel, candidatePath);
if ~strcmpi(sha256File(candidatePath), expectedSha)
    error('sar20:modelgraph:PrivateCopySha', 'Private initial copy does not match baseline SHA.');
end

model = 'SarAdc';
loaded = find_system('Type','block_diagram','Name',model);
if ~isempty(loaded)
    loadedFile = get_param(model, 'FileName');
    if ~strcmpi(canonicalPath(loadedFile), canonicalPath(candidatePath))
        error('sar20:modelgraph:ModelAlreadyOpen', ...
            'SarAdc is already loaded from another path (%s). Close/resolve it in the root-owned GUI before opening the private candidate.', loadedFile);
    end
else
    open_system(candidatePath);
end
if ~bdIsLoaded(model) || ~strcmpi(canonicalPath(get_param(model,'FileName')), canonicalPath(candidatePath))
    error('sar20:modelgraph:OpenCandidate', 'The active SarAdc is not the private candidate.');
end

receipt = struct();
receipt.schema_version = 'sar20-modelgraph-stage1-receipt/v1';
receipt.baseline_sha256 = expectedSha;
receipt.source_model_path = sourceModel;
receipt.private_model_path = candidatePath;
receipt.private_work_root = privateWorkRoot;
receipt.library_gate = gate;
receipt.no_simulation = true;
receipt.stage = 'layout_physical_view_fpga_d1_d2_dt';
receipt.scopes = {};
receipt.topology_verification = struct();
receipt.started_at = datestr(now, 30);
writeReceipt(receiptDir, receipt);

try
    % ROOT: disable the unreadable EventStep preview.
    rootBefore = readScope(model, 'root');
    eventId = findBlockIdByName(rootBefore, 'EventStep');
    runScopeEdit(model, 'root', 'root_eventstep_preview', ...
        {opConfigure(eventId, struct('ContentPreviewEnabled','off'))}, 'incremental', receiptDir, receipt);
    receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % Re-read EventStep and resolve all IDs from the fresh model_read output.
    rootAfter = readScope(model, 'root');
    eventId = findBlockIdByName(rootAfter, 'EventStep');
    eventBefore = readScope(model, eventId);
    adcId = findBlockIdByName(eventBefore, 'Adc');
    fpgaId = findBlockIdByName(eventBefore, 'Fpga');

    % EVENTSTEP: disable previews for the large Adc/Fpga cards and create the
    % disconnected non-computing PhysicalView entry.
    eventOps = {opConfigure(adcId, struct('ContentPreviewEnabled','off')), ...
                opConfigure(fpgaId, struct('ContentPreviewEnabled','off')), ...
                struct('op','create_subsystem','name','PhysicalView','ref','physical_view', ...
                    'interface',struct('inputs',{{}},'outputs',{{}}))};
    runScopeEdit(model, eventId, 'eventstep_preview_and_physical_view', eventOps, ...
        'incremental', receiptDir, receipt);
    receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % ADC: keep the six real execution blocks readable as a left-to-right stage
    % chain. Their internal calculations remain in their existing subsystems.
    eventAfter = readScope(model, eventId);
    adcId = findBlockIdByName(eventAfter, 'Adc');
    adcBefore = readScope(model, adcId);
    stageNames = {'SampleRaAdvance','DacCtFeedback','Sar1TrialRaCt', ...
        'ResidueCtCompare','SarDecisionTracking','ChargeReturnRaReset'};
    adcOps = cell(1,numel(stageNames));
    for k=1:numel(stageNames)
        sid = findBlockIdByName(adcBefore, stageNames{k});
        adcOps{k} = opConfigure(sid, struct('ContentPreviewEnabled','off'));
    end
    adcOps{end+1} = struct('op','create_subsystem','name','ExecutionSemantics_Note', ...
        'ref','execution_note','interface',struct('inputs',{{}},'outputs',{{}}));
    runScopeEdit(model, adcId, 'adc_execution_stage_previews', adcOps, ...
        'incremental', receiptDir, receipt);
    receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);
    adcAfterPreview = readScope(model,adcId);
    noteId=findBlockIdByName(adcAfterPreview,'ExecutionSemantics_Note');
    noteText=['仅说明，不计算。执行顺序：SampleRaAdvance → DacCtFeedback → Sar1TrialRaCt → ResidueCtCompare → SarDecisionTracking → ChargeReturnRaReset' newline ...
        'commit=应用当前事件命令；持久状态由对应UnitDelay写入。' newline ...
        'z^-1=上一有效离散事件执行状态；不是固定模拟延迟，也不等于一个完整Ts。' newline ...
        'ADC主状态owner：SampleCharge/FE353、RaCtState/RA48、SarState/SAR51。工程另有Bank/Transport/RefQueue状态。'];
    notePath=fullPathFromId(model,noteId);
    notePorts=get_param(notePath,'Ports');
    if any(notePorts(:)~=0), error('sar20:modelgraph:ExecutionNotePorts','ExecutionSemantics_Note must be portless.'); end
    runScopeEdit(model,adcId,'adc_execution_semantics_note', ...
        {opConfigure(noteId,struct('AttributesFormatString',noteText,'ContentPreviewEnabled','off', ...
        'Position',[2780 25 3320 180]))},'incremental',receiptDir,receipt);
    receipt.scopes{end+1}=lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % PhysicalView: create non-computing navigation cards in paper-module order.
    eventAfter = readScope(model, eventId);
    physicalId = findBlockIdByName(eventAfter, 'PhysicalView');
    physicalBefore = readScope(model, physicalId);
    cards = navigationCards();
    cardOps = cell(1,numel(cards));
    for k=1:numel(cards)
        cardOps{k} = struct('op','create_subsystem','name',cards(k).block_name, ...
            'ref',cards(k).ref,'interface',struct('inputs',{{}},'outputs',{{}}));
    end
    runScopeEdit(model, physicalId, 'physical_view_add_cards', cardOps, ...
        'full', receiptDir, receipt);
    receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % Resolve every new card through the actual model_read block IDs, then
    % configure the click callback and visible non-computing label via model_edit.
    physicalAfter = readScope(model, physicalId);
    callbackOps = cell(1,numel(cards)+1);
    callbackOps{1} = opConfigure(physicalId, struct('ContentPreviewEnabled','off', ...
        'AttributesFormatString','物理功能导航｜这些卡片仅导航，不执行计算核。'));
    for k=1:numel(cards)
        cardId = findBlockIdByName(physicalAfter, cards(k).block_name);
        cardPath=fullPathFromId(model,cardId);
        cardPorts=get_param(cardPath,'Ports');
        if any(cardPorts(:)~=0)
            error('sar20:modelgraph:NavigationCardPorts','Navigation card %s is not portless.',cards(k).block_name);
        end
        callbackOps{k+1} = opConfigure(cardId, struct( ...
            'ContentPreviewEnabled','off', ...
            'AttributesFormatString',cards(k).display_text, ...
            'OpenFcn',cards(k).callback,'Position',cards(k).position));
    end
    runScopeEdit(model, physicalId, 'physical_view_focus_callbacks', callbackOps, ...
        'incremental', receiptDir, receipt);
    receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % FPGA: create all three empty virtual wrappers first. No parent data wires
    % are changed until all three child networks have been hydrated and checked.
    eventAfter = readScope(model, eventId);
    fpgaId = findBlockIdByName(eventAfter, 'Fpga');
    fpgaBefore = readScope(model, fpgaId);
    groups = load_fpga_stage1_groups(fpgaSpec);
    verifyFpgaSourceParameters(model, fpgaBefore, sourceInventory, groups);
    wrapperOps = cell(1,numel(groups));
    for k=1:numel(groups)
        wrapperOps{k} = struct('op','create_subsystem','name',groups(k).wrapper, ...
            'ref',groups(k).ref,'interface',struct('inputs',{groups(k).inputs}, ...
            'outputs',{groups(k).outputs}));
    end
    % This parent scope is intentionally staged: its post-edit check is deferred
    % until each wrapper is populated and all parent wires are replaced.
    fpgaCreateBefore = readScope(model, fpgaId);
    createResult = callModelEdit(model, fpgaId, wrapperOps, 'incremental');
    recordToolCall(receiptDir, receipt, 'fpga_create_wrappers', fpgaId, ...
        fpgaCreateBefore, createResult, '', '', false);
    if isPartial(createResult) || hasEditError(createResult)
        partialStop(model, candidatePath, fpgaId, 'fpga_create_wrappers', createResult, receiptDir, receipt);
    end
    fpgaAfterCreate = readScope(model, fpgaId);
    wrapperIds = struct();
    for k=1:numel(groups)
        wrapperIds.(groups(k).key_field) = findBlockIdByName(fpgaAfterCreate, groups(k).wrapper);
    end
    save_system(model);
    receipt.scopes{end+1} = struct('name','fpga_create_wrappers','scope',fpgaId, ...
        'model_read_before',fpgaCreateBefore,'model_edit',char(createResult), ...
        'model_read_after',fpgaAfterCreate,'model_check','deferred until parent scope is complete');
    writeReceipt(receiptDir, receipt);

    % Populate and check each new wrapper independently. Native parameter values
    % are reread from old block DialogParameters; only model_edit creates/wires.
    for k=1:numel(groups)
        group = groups(k);
        parentRead = readScope(model, fpgaId);
        oldParams = hydrateNativeParams(model, parentRead, sourceInventory, group.nodes);
        childId = wrapperIds.(group.key_field);
        childBefore = readScope(model, childId);
        inputIds = cell(1,numel(group.inputs));
        outputIds = cell(1,numel(group.outputs));
        for q=1:numel(group.inputs), inputIds{q}=findBlockIdByName(childBefore, group.inputs{q}); end
        for q=1:numel(group.outputs), outputIds{q}=findBlockIdByName(childBefore, group.outputs{q}); end
        childOps = populateOps(group, oldParams, inputIds, outputIds);
        runScopeEdit(model, childId, ['populate_' group.key_field], childOps, ...
            'full', receiptDir, receipt);
        receipt.scopes{end+1} = lastScopeReceipt(receiptDir);
        writeReceipt(receiptDir, receipt);
        childAfter = readScope(model, childId);
        verifyChildParameters(model, childAfter, oldParams, group);
        internalEdges=verify_modelgraph_child_topology(model, childAfter, group, inputIds, outputIds);
        receipt.topology_verification.(group.key_field)=struct('internal',internalEdges);
        save_system(model);
        writeReceipt(receiptDir, receipt);
    end

    % Parent FPGA scope: connect all replacement outputs to their unchanged
    % legacy consumers, then delete the now-obsolete original nodes. One scope
    % edit, followed by model_read/model_check.
    fpgaBeforeReplace = readScope(model, fpgaId);
    parentOps = {};
    for k=1:numel(groups)
        group=groups(k);
        wrapperId=findBlockIdByName(fpgaBeforeReplace,group.wrapper);
        for q=1:numel(group.parent_inputs)
            srcId=findBlockIdByName(fpgaBeforeReplace,group.parent_inputs{q});
            parentOps{end+1}=opConnect([srcId '.y' num2str(group.parent_input_ports(q)) ' -> ' wrapperId '.u' num2str(q)]); %#ok<AGROW>
        end
        for q=1:numel(group.parent_outputs)
            dstId=findBlockIdByName(fpgaBeforeReplace,group.parent_outputs{q});
            parentOps{end+1}=opConnect([wrapperId '.y1 -> ' dstId '.u' num2str(group.parent_output_ports(q))]); %#ok<AGROW>
        end
        for q=1:numel(group.nodes)
            oldId=findBlockIdByName(fpgaBeforeReplace,group.nodes{q});
            parentOps{end+1}=struct('op','delete','target',oldId); %#ok<AGROW>
        end
        parentOps{end+1}=opConfigure(wrapperId,struct( ...
            'ContentPreviewEnabled','off', ...
            'AttributesFormatString',group.display_text)); %#ok<AGROW>
    end
    runScopeEdit(model, fpgaId, 'fpga_parent_replace_delete_old_nodes', parentOps, ...
        'incremental', receiptDir, receipt);
    receipt.scopes{end+1}=lastScopeReceipt(receiptDir);
    writeReceipt(receiptDir, receipt);

    % Check that each old group has exactly one final wrapper and that sum/output
    % wiring names still resolve. The model_read text is retained for audit.
    fpgaFinal=readScope(model,fpgaId);
    receipt.topology_verification.fpga_parent = verify_modelgraph_parent_topology(model,fpgaFinal,groups);
    for k=1:numel(groups)
        assertNamePresent(fpgaFinal,groups(k).wrapper);
        for q=1:numel(groups(k).nodes)
            assertNameAbsent(fpgaFinal,groups(k).nodes{q});
        end
    end
    % Stage outputs and code chain must remain on their original consumers.
    expectedNames={'d1_v','d2_v','dt_v','D1PlusD2','PlusTracking','PlusDither', ...
        'Counts','UnsignedMidpoint','RoundCode','SaturateCode','Calibration'};
    for k=1:numel(expectedNames), assertNamePresent(fpgaFinal,expectedNames{k}); end
    save_system(model);

    if opt.ColdOpenCompile
        candidateShaBeforeColdOpen=sha256File(candidatePath);
        close_system(model,0);
        open_system(candidatePath);
        if ~bdIsLoaded(model) || ~strcmpi(canonicalPath(get_param(model,'FileName')),canonicalPath(candidatePath))
            error('sar20:modelgraph:ColdOpen', 'Cold open did not reopen the private candidate.');
        end
        set_param(model,'SimulationCommand','update');
        if ~strcmp(get_param(model,'SimulationStatus'),'stopped')
            error('sar20:modelgraph:UnexpectedSimulation', 'Model update unexpectedly started a simulation.');
        end
        save_system(model);
        candidateShaAfterColdOpen=sha256File(candidatePath);
        rootCold=readScope(model,'root');
        eventCold=readScope(model,findBlockIdByName(rootCold,'EventStep'));
        fpgaCold=readScope(model,findBlockIdByName(eventCold,'Fpga'));
        fpgaColdCheck=checkScope(model,findBlockIdByName(eventCold,'Fpga'));
        if checkHasErrors(fpgaColdCheck)
            error('sar20:modelgraph:ColdOpenCheck','Cold-open FPGA model_check reports errors.');
        end
        receipt.cold_open_compile=struct('method','save -> close -> open -> SimulationCommand=update -> save', ...
            'candidate_sha_before',candidateShaBeforeColdOpen, ...
            'candidate_sha_after',candidateShaAfterColdOpen, ...
            'simulation_started',false,'fpga_model_read',fpgaCold,'fpga_model_check',fpgaColdCheck);
    else
        receipt.cold_open_compile=struct('status','not_requested');
    end

    receipt.status='candidate_prepared';
    receipt.finished_at=datestr(now,30);
    receipt.final_model_sha256=sha256File(candidatePath);
    resolvedNav=build_resolved_navigation_stage1(model, projectRoot, candidatePath, expectedSha, receipt.final_model_sha256);
    resolvedNavPath=fullfile(receiptDir,'resolved_navigation_stage1.json');
    writeJson(resolvedNavPath,resolvedNav);
    receipt.resolved_navigation_stage1=resolvedNavPath;
    writeReceipt(receiptDir,receipt);
    if ~opt.KeepModelOpen && bdIsLoaded(model), close_system(model,0); end
catch cause
    try
        save_system(model);
        partial = snapshotPrivatePartial(candidatePath, receiptDir, 'stage1_failure');
        receipt.status='partial_private_saved';
        receipt.partial_snapshot=partial;
        receipt.error=getReport(cause,'extended','hyperlinks','off');
        receipt.finished_at=datestr(now,30);
        writeReceipt(receiptDir,receipt);
    catch snapshotCause
        receipt.status='failure_snapshot_failed';
        receipt.error=getReport(cause,'extended','hyperlinks','off');
        receipt.snapshot_error=getReport(snapshotCause,'extended','hyperlinks','off');
        writeReceipt(receiptDir,receipt);
    end
    rethrow(cause);
end
end

function cards = navigationCards()
base = [100 130 280 205]; dx=195;
labels = {
 'Physical_Sample_DAC1','Sample & DAC1｜采集、DAC1；含SAR1 6b预转换/Trial；仅导航，不计算。','physical:sample_dac1','FE353';
 'Physical_Residue','真实Qres源电荷来自FE353电荷/切换readout；RA48.command.qres只是区间锁存命令；仅导航，不计算。','physical:residue','FE353';
 'Physical_RA_AZ','唯一 RA 与 AZ 存储；仅导航，不计算。','physical:ra_az','RA48';
 'Physical_CINC_CT','CINC / CT 网络；仅导航，不计算。','physical:cinc_ct','RA48';
 'Physical_SAR2_Tracking','SAR2 与 tracking；仅导航，不计算。','physical:sar2_tracking','SAR51';
 'Physical_Digital','D1 / D2 / DT 数字重构；仅导航，不计算。','physical:digital','FPGA';
 'Physical_LVDS','LVDS协议容器：片内TX + 片外FPGA RX；当前OFF，不含电气/CDC；仅导航，不计算。','physical:lvds','Transport'};
cards = struct([]);
for k=1:size(labels,1)
    cards(k).block_name = labels{k,1};
    cards(k).ref = ['nav' num2str(k)];
    cards(k).display_text = labels{k,2};
    cards(k).callback = sprintf("SAR20('focus','%s','%s');",labels{k,3},labels{k,4});
    cards(k).position = base + [(k-1)*dx 0 (k-1)*dx 0];
end
end

function receiptScope = lastScopeReceipt(receiptDir)
p = fullfile(receiptDir,'latest_scope.json');
if ~isfile(p), receiptScope=struct('status','missing scope receipt'); return; end
receiptScope=jsondecode(fileread(p));
end

function runScopeEdit(model,scope,label,ops,layoutMode,receiptDir,receipt)
before=readScope(model,scope);
result=callModelEdit(model,scope,ops,layoutMode);
if isPartial(result) || hasEditError(result)
    partialStop(model, get_param(model,'FileName'), scope, label, result, receiptDir, receipt, before);
end
after=readScope(model,scope);
check=checkScope(model,scope);
if checkHasErrors(check)
    partialStop(model,get_param(model,'FileName'),scope,[label '_model_check'],result,receiptDir,receipt,before,after,check);
end
recordToolCall(receiptDir,receipt,label,scope,before,result,after,check,true);
end

function before = readScope(model,scope)
before=char(model_read(model,scope,'0'));
if ~startsWith(strtrim(before),'status: ok') && ~startsWith(strtrim(before),'status: success')
    error('sar20:modelgraph:ModelRead','model_read failed in scope %s:\n%s',scope,before);
end
end

function result = callModelEdit(model,scope,ops,layoutMode)
opsJson=jsonencode(ops);
if contains(opsJson,newline)
    error('sar20:modelgraph:JsonMultiline','model_edit operations must be single-line JSON.');
end
result=char(model_edit(model,scope,opsJson,layoutMode));
end

function check = checkScope(model,scope)
check=char(model_check(model,scope,'["unconnected_ports","unconnected_lines"]'));
end

function tf=isPartial(reply)
tf=contains(strtrim(char(reply)),'status: partial');
end
function tf=hasEditError(reply)
first=strtrim(extractBefore(string(char(reply))+newline,newline));
tf=contains(first,'status: error') || contains(first,'status: failed');
end
function tf=checkHasErrors(reply)
tf=contains(char(reply),'status: has_errors') || contains(char(reply),'severity: error');
end

function id=findBlockIdByName(readText,name)
lines=splitlines(string(readText)); currentId=''; hits={};
for k=1:numel(lines)
    line=char(lines(k));
    t=regexp(line,'^\s*-\s*id:\s*(blk_[0-9]+)','tokens','once');
    if ~isempty(t), currentId=t{1}; continue; end
    t=regexp(line,'^\s*Name:\s*(.*?)\s*$','tokens','once');
    if ~isempty(t) && strcmp(strtrim(t{1}),name) && ~isempty(currentId)
        hits{end+1}=currentId; %#ok<AGROW>
        currentId='';
    end
end
hits=unique(hits,'stable');
if numel(hits)~=1
    error('sar20:modelgraph:BlockIdResolution','Expected one fresh model_read ID for Name=%s, got %d. Do not build a path from the name.',name,numel(hits));
end
id=hits{1};
end

function pathName=fullPathFromId(model,id)
num=extractAfter(string(id),'blk_');
pathName=char(Simulink.ID.getFullName([model ':' char(num)]));
end

function op=opConfigure(id,params)
op=struct('op','configure','target',id,'params',params);
end
function op=opConnect(target)
op=struct('op','connect','target',target);
end

function verifyFpgaSourceParameters(model,fpgaRead,sourceInventory,groups)
original=sourceInventory.systems.fpga.blocks;
requiredNames={};
for g=1:numel(groups), requiredNames=[requiredNames groups(g).nodes]; end %#ok<AGROW>
requiredNames=unique(requiredNames,'stable');
for k=1:numel(requiredNames)
    nm=requiredNames{k}; rec=original(strcmp({original.name},nm));
    if numel(rec)~=1, error('sar20:modelgraph:SourceSpecNode','Spec expected one %s.',nm); end
    id=findBlockIdByName(fpgaRead,nm); pth=fullPathFromId(model,id);
    actualType=get_param(pth,'BlockType');
    if ~strcmp(actualType,rec.block_type)
        error('sar20:modelgraph:BlockTypeMismatch','%s BlockType changed (%s vs spec %s).',nm,actualType,rec.block_type);
    end
    expected=rec.parameters; names=fieldnames(expected);
    dp=get_param(pth,'DialogParameters'); dpNames=fieldnames(dp);
    for q=1:numel(names)
        key=names{q};
        if ~any(strcmp(dpNames,key))
            error('sar20:modelgraph:DialogParamMissing','Fresh Native DialogParameters lacks %s.%s.',nm,key);
        end
        actual=get_param(pth,key);
        if ~strcmp(canonicalParam(actual),canonicalParam(expected.(key)))
            error('sar20:modelgraph:DialogParamMismatch','%s.%s differs from locked baseline XML. Expected %s; got %s.',nm,key,canonicalParam(expected.(key)),canonicalParam(actual));
        end
    end
end
end

function native = hydrateNativeParams(model,parentRead,sourceInventory,nodeNames)
allNodes=sourceInventory.systems.fpga.blocks;
native=struct();
for k=1:numel(nodeNames)
    nm=nodeNames{k}; rec=allNodes(strcmp({allNodes.name},nm));
    id=findBlockIdByName(parentRead,nm); pth=fullPathFromId(model,id);
    actualType=get_param(pth,'BlockType');
    if ~strcmp(actualType,rec.block_type)
        error('sar20:modelgraph:NativeTypeChanged','%s is %s not %s.',nm,actualType,rec.block_type);
    end
    expected=rec.parameters; keys=fieldnames(expected); dialog=get_param(pth,'DialogParameters'); dlgKeys=fieldnames(dialog);
    vals=struct();
    for q=1:numel(keys)
        key=keys{q};
        if ~any(strcmp(dlgKeys,key)), error('sar20:modelgraph:NativeParameterMissing','No dialog field %s.%s.',nm,key); end
        val=get_param(pth,key);
        if ~strcmp(canonicalParam(val),canonicalParam(expected.(key)))
            error('sar20:modelgraph:NativeParameterDrift','%s.%s no longer matches 9197 XML.',nm,key);
        end
        vals.(key)=encodeParamForEdit(val);
    end
    native.(matlab.lang.makeValidName(nm))=struct('name',nm,'block_type',actualType, ...
        'path_resolved_from_sid',pth,'id',id,'dialog_parameters',dialog,'explicit_params',vals);
end
end

function ops=populateOps(group,native,inputIds,outputIds)
ops={}; refs=struct();
for k=1:numel(group.nodes)
    nm=group.nodes{k}; b=native.(matlab.lang.makeValidName(nm)); r=refName(nm); refs.(matlab.lang.makeValidName(nm))=r;
    op=struct('op','add_block','type',b.block_type,'name',nm,'ref',r);
    if ~isempty(fieldnames(b.explicit_params)), op.params=b.explicit_params; end
    ops{end+1}=op; %#ok<AGROW>
end
for k=1:numel(group.edges)
    edge=group.edges{k}; parts=split(string(edge),'>'); src=char(parts(1)); dst=char(parts(2));
    srcEnd=resolveEndpoint(src,'source',group,refs,inputIds,outputIds);
    dstEnd=resolveEndpoint(dst,'destination',group,refs,inputIds,outputIds);
    ops{end+1}=opConnect([srcEnd ' -> ' dstEnd]); %#ok<AGROW>
end
end

function endpoint=resolveEndpoint(label,role,group,refs,inputIds,outputIds)
if any(strcmp(group.inputs,label))
    ix=find(strcmp(group.inputs,label),1); endpoint=[inputIds{ix} '.y1']; return
end
if any(strcmp(group.outputs,label))
    ix=find(strcmp(group.outputs,label),1); endpoint=[outputIds{ix} '.u1']; return
end
parts=split(string(label),'.'); nm=char(parts(1)); port=char(parts(2));
r=refs.(matlab.lang.makeValidName(nm));
if strcmp(role,'source'), endpoint=['#' r '.' port]; else, endpoint=['#' r '.' port]; end
end

function verifyChildParameters(model,childRead,native,group)
visual={'Position','Orientation','FontSize','FontName','ForegroundColor','BackgroundColor','ShowName','ShowPortLabels','DropShadow','ZOrder'};
for k=1:numel(group.nodes)
    nm=group.nodes{k}; old=native.(matlab.lang.makeValidName(nm)); newId=findBlockIdByName(childRead,nm); newPath=fullPathFromId('SarAdc',newId);
    newType=get_param(newPath,'BlockType');
    if ~strcmp(newType,old.block_type), error('sar20:modelgraph:ChildType','New %s BlockType mismatch.',nm); end
    newDp=get_param(newPath,'DialogParameters'); newFields=fieldnames(newDp);
    oldFields=fieldnames(old.dialog_parameters);
    for q=1:numel(oldFields)
        key=oldFields{q}; if any(strcmp(visual,key)), continue; end
        if ~any(strcmp(newFields,key)), error('sar20:modelgraph:ChildDialogField','New %s lacks dialog field %s.',nm,key); end
        oldValue=get_param(old.path_resolved_from_sid,key); newValue=get_param(newPath,key);
        if ~strcmp(canonicalParam(oldValue),canonicalParam(newValue))
            error('sar20:modelgraph:ChildDialogMismatch','New %s.%s differs; preserve partial and stop.',nm,key);
        end
    end
end
end

function text=canonicalParam(value)
if ischar(value), text=strtrim(value);
elseif isstring(value), text=strtrim(char(value));
elseif isnumeric(value)||islogical(value), text=mat2str(value,17);
else
    try, text=strtrim(jsonencode(value)); catch, text=strtrim(char(string(value))); end
end
text=regexprep(text,'\s+','');
end
function value=encodeParamForEdit(value)
if ischar(value), return; end
if isstring(value), value=char(value); return; end
if isnumeric(value)||islogical(value), value=mat2str(value,17); return; end
try, value=char(jsonencode(value)); catch, value=char(string(value)); end
end
function r=refName(nm)
r=['r_' regexprep(nm,'[^A-Za-z0-9]','_')];
if numel(r)>31, r=r(1:31); end
end

function recordToolCall(receiptDir,receipt,label,scope,before,result,after,check,complete)
s=struct('name',label,'scope',char(scope),'model_read_before',char(before), ...
    'model_edit',char(result),'model_read_after',char(after),'model_check',char(check), ...
    'scope_complete',logical(complete),'recorded_at',datestr(now,30));
writeJson(fullfile(receiptDir,'latest_scope.json'),s);
receipt.last_scope=s;
writeReceipt(receiptDir,receipt);
end

function partialStop(model,candidatePath,scope,label,result,receiptDir,receipt,varargin)
if ~isempty(varargin), before=varargin{1}; else, before=''; end
saveError='';
try
    save_system(model);
catch cause
    saveError=getReport(cause,'extended','hyperlinks','off');
end
if isempty(saveError)
    snapshot=snapshotPrivatePartial(candidatePath,receiptDir,label);
else
    snapshot=struct('path','','sha256','','candidate_sha256','', ...
        'status','not_saved','save_error',saveError);
end
% User/skill contract: immediately perform read+check on partial and preserve both.
try, after=readScope(model,scope); catch e, after=getReport(e,'extended','hyperlinks','off'); end
try, check=checkScope(model,scope); catch e, check=getReport(e,'extended','hyperlinks','off'); end
s=struct('name',label,'scope',char(scope),'status','partial_or_error', ...
    'model_read_before',char(before),'model_edit',char(result), ...
    'model_read_after_partial',char(after),'model_check_after_partial',char(check), ...
    'private_snapshot',snapshot,'recorded_at',datestr(now,30));
writeJson(fullfile(receiptDir,'latest_scope.json'),s);
if isempty(saveError)
    receipt.status='partial_private_saved';
else
    receipt.status='partial_not_persisted';
end
receipt.partial_snapshot=snapshot;
receipt.last_scope=s; writeReceipt(receiptDir,receipt);
if isempty(saveError)
    error('sar20:modelgraph:PartialStop','%s stopped; private partial SHA=%s at %s. Read/check receipt saved.',label,snapshot.sha256,snapshot.path);
else
    error('sar20:modelgraph:PartialSaveFailed','%s stopped; save_system failed, so no resumable private SHA exists. Error: %s',label,saveError);
end
end

function snapshot=snapshotPrivatePartial(candidatePath,receiptDir,label)
if isfile(candidatePath),
    snapshotPath=fullfile(receiptDir,[regexprep(label,'[^A-Za-z0-9]','_') '_partial_' datestr(now,'yyyymmddTHHMMSS') '.slx']);
    [ok,msg]=copyfile(candidatePath,snapshotPath,'f');
    if ~ok, error('sar20:modelgraph:PartialCopyFailed','Could not copy private partial: %s',msg); end
    snapshot=struct('path',snapshotPath,'sha256',sha256File(snapshotPath),'candidate_sha256',sha256File(candidatePath));
    if ~strcmpi(snapshot.sha256,snapshot.candidate_sha256)
        error('sar20:modelgraph:PartialCopyHash','Partial snapshot hash does not match the private candidate.');
    end
else
    error('sar20:modelgraph:PartialCandidateMissing','No private candidate file exists to snapshot.');
end
end

function writeReceipt(receiptDir,receipt)
receiptPath=fullfile(receiptDir,'stage1_receipt.json');
writeJson(receiptPath,receipt);
end
function writeJson(pathName,value)
fid=fopen(pathName,'w','n','UTF-8');
if fid<0, error('sar20:modelgraph:ReceiptWrite','Cannot write %s',pathName); end
closer=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s\n',jsonencode(value,'PrettyPrint',true));
end

function assertNamePresent(report,name)
if isempty(strfind(char(report),name)), error('sar20:modelgraph:ReadbackMissing','model_read omitted expected %s.',name); end
end
function assertNameAbsent(report,name)
if ~isempty(regexp(char(report),['(?m)^\s*Name:\s*' regexptranslate('escape',name) '\s*$'],'once'))
    error('sar20:modelgraph:OldNodeRemains','Old node %s remains after wrapper replacement.',name);
end
end

function out=canonicalPath(pathName)
if isempty(pathName), out=''; return; end
try, out=char(java.io.File(char(pathName)).getCanonicalPath()); catch, out=char(pathName); end
end
function h=sha256File(pathName)
fid=fopen(pathName,'rb'); if fid<0, error('sar20:modelgraph:HashOpen','Cannot read %s',pathName); end
closer=onCleanup(@()fclose(fid)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while true
    chunk=fread(fid,1024*1024,'*uint8'); if isempty(chunk), break; end
    md.update(chunk);
end
bytes=typecast(md.digest(),'uint8'); h=lower(reshape(dec2hex(bytes,2).',1,[]));
end
