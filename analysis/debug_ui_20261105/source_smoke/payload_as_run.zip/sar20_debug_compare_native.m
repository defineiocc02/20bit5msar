function R = sar20_debug_compare_native(referenceOut,candidateOut,mode,rootPortMap)
%SAR20_DEBUG_COMPARE_NATIVE Bit-compare saved SimulationOutput logs and yout roots.
% The reference and candidate are already-run outputs. This function never
% loads a model, executes a kernel, changes RNG, or writes files.
    assert(isa(referenceOut,'Simulink.SimulationOutput')&& ...
        isa(candidateOut,'Simulink.SimulationOutput'),'sar20compare:Output','Need native SimulationOutput objects.');
    assert(any(strcmp(mode,{'prefix','full'})),'sar20compare:Mode','mode must be prefix or full.');
    if nargin<4||isempty(rootPortMap)
        rootPortMap=struct('semantic_name',{'Code20','CodeValid','CodeMeta'},'port',{1,2,3});
    end
    a=cellstr(referenceOut.who);b=cellstr(candidateOut.who);
    a=setdiff(a,{'yout','tout'},'stable');b=setdiff(b,{'yout','tout'},'stable');
    required={'event_log','raw_log','ready_log','front_log','back_log','control_log','code_log'};
    requiredMissing=setdiff(required,a,'stable');missing=setdiff(a,b,'stable');
    details=struct('name',{},'status',{},'reference_rows',{},'candidate_rows',{},'detail',{});mismatch=0;
    for k=1:numel(a)
        name=a{k};if any(strcmp(missing,name))
            details(end+1)=struct('name',name,'status','missing','reference_rows',0,'candidate_rows',0,'detail','candidate log absent'); %#ok<AGROW>
            continue;
        end
        [ok,nr,nc,msg]=value_equal(referenceOut.get(name),candidateOut.get(name),mode);
        if ~ok,mismatch=mismatch+1;end
        details(end+1)=struct('name',name,'status',passfail(ok),'reference_rows',nr,'candidate_rows',nc,'detail',msg); %#ok<AGROW>
    end
    ta=referenceOut.get('tout');tb=candidateOut.get('tout');
    [toutOk,nr,nc,msg]=value_equal(double(ta(:)),double(tb(:)),mode);
    roots=root_equal(referenceOut.get('yout'),candidateOut.get('yout'),rootPortMap,mode);
    legacyOk=isempty(requiredMissing)&&isempty(missing)&&mismatch==0;
    R=struct('schema','sar20-native-output-compare/v1','mode',mode, ...
        'status',passfail(legacyOk&&toutOk&&strcmp(roots.status,'passed')), ...
        'legacy_logs',struct('status',passfail(legacyOk), ...
        'reference_count',numel(a),'candidate_count',numel(b),'missing_count',numel(missing), ...
        'missing_required_count',numel(requiredMissing),'missing_required',{requiredMissing}, ...
        'mismatch_count',mismatch,'items',details), ...
        'tout',struct('status',passfail(toutOk),'reference_rows',nr,'candidate_rows',nc,'detail',msg), ...
        'root_output_ports',roots);
end

function result=root_equal(a,b,map,mode)
    assert(isa(a,'Simulink.SimulationData.Dataset')&&isa(b,'Simulink.SimulationData.Dataset')&& ...
        a.numElements==3&&b.numElements==3&&numel(map)==3, ...
        'sar20compare:RootDataset','Require exactly three native root-output Dataset elements.');
    rows=struct('semantic_name',{},'port',{},'status',{},'detail',{});
    for k=1:numel(map)
        ia=index_for(a,map(k).semantic_name,map(k).port);ib=index_for(b,map(k).semantic_name,map(k).port);
        ea=a.get(ia);eb=b.get(ib);
        [ok,nr,nc,msg]=value_equal(ea.Values,eb.Values,mode);
        rows(end+1)=struct('semantic_name',char(map(k).semantic_name),'port',double(map(k).port), ...
            'status',passfail(ok),'detail',sprintf('%s; rows %d/%d',msg,nr,nc)); %#ok<AGROW>
    end
    result=struct('status',passfail(all(strcmp({rows.status},'passed'))), ...
        'mapping_basis','explicit top-level Outport semantic name/SID and port ordinal','ports',rows);
end

function ix=index_for(ds,name,port)
    names=ds.getElementNames();ix=[];
    for k=1:numel(names),if strcmp(char(names{k}),char(name)),ix=k;break;end,end
    if isempty(ix),ix=double(port);end
    assert(ix>=1&&ix<=ds.numElements,'sar20compare:UnmatchedRoot','Unmatched root output %s.',char(name));
end

function [ok,nr,nc,msg]=value_equal(a,b,mode)
    nr=0;nc=0;msg='';ok=false;
    if isa(a,'timeseries')&&isa(b,'timeseries')
        [ta,xa]=series_rows(a);[tb,xb]=series_rows(b);nr=numel(ta);nc=numel(tb);
        if strcmp(mode,'prefix')
            if nc>nr,msg='candidate longer than reference';return;end
            ok=bits(ta(1:nc),tb)&&bits(xa(1:nc,:),xb);msg='time/data bit-exact prefix';
        else
            ok=bits(ta,tb)&&bits(xa,xb);msg='time/data bit-exact full';
        end
    else
        if strcmp(mode,'prefix')&&isnumeric(a)&&isnumeric(b)&&isvector(a)&&isvector(b)&&numel(b)<=numel(a)
            a=a(1:numel(b));
        end
        ok=bits(a,b);msg='value bit-exact';
        if isnumeric(a),nr=numel(a);end;if isnumeric(b),nc=numel(b);end
    end
end

function [t,x]=series_rows(ts)
    t=double(ts.Time(:));d=ts.Data;
    if ts.IsTimeFirst,x=reshape(d,numel(t),[]);else,x=reshape(permute(d,[ndims(d) 1:ndims(d)-1]),numel(t),[]);end
end

function tf=bits(a,b)
    tf=false;if ~isequal(size(a),size(b)),return;end
    if isa(a,'double')&&isa(b,'double'),tf=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
    elseif isa(a,'single')&&isa(b,'single'),tf=isequal(typecast(a(:),'uint32'),typecast(b(:),'uint32'));
    else,tf=isequaln(a,b);end
end

function s=passfail(ok)
    if ok,s='passed';else,s='mismatch';end
end
