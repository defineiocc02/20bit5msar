function R = sar20_source_smoke(cfg)
%SAR20_SOURCE_SMOKE Run frozen new source on the pinned old 2-dialog 9197 graph.
% cfg: model_file,source_root,reference_run_dir,output_dir,model_sha256(optional).
% The run uses the saved N8 P/DecodeP unchanged; the archived reference is never rerun.
    need={'model_file','source_root','reference_run_dir','output_dir'};
    for k=1:numel(need),assert(isfield(cfg,need{k})&&~isempty(cfg.(need{k})), ...
            'sar20smoke:Config','Missing cfg.%s.',need{k});end
    cap=300e6; mdl='SarAdc';
    assert(~isfolder(cfg.output_dir)&&~isfile(cfg.output_dir),'sar20smoke:OutputExists','Refuse to overwrite output folder.');
    [ok,msg,msgid]=mkdir(cfg.output_dir);assert(ok&&isempty(msgid),'sar20smoke:OutputCreate','%s',msg);
    modelSha=sha(cfg.model_file,cap);baseline='91973cf76507d37acc12515b55ebfe731ad197fe8ca1ecc9014fa07cbd35c27e';
    assert(strcmp(modelSha,baseline),'sar20smoke:ModelPin','Expected the unmodified 9197 two-dialog model.');
    if isfield(cfg,'model_sha256'),assert(strcmpi(modelSha,cfg.model_sha256),'sar20smoke:ModelPin','Model SHA differs from cfg.');end
    file_size(fullfile(cfg.reference_run_dir,'parameters.mat'));file_size(fullfile(cfg.reference_run_dir,'simout.mat'));
    pfile=load(fullfile(cfg.reference_run_dir,'parameters.mat'),'P');
    refFile=load(fullfile(cfg.reference_run_dir,'simout.mat'),'simout');
    assert(isfield(pfile,'P')&&isfield(refFile,'simout'),'sar20smoke:Reference','N8 reference needs P and simout.');
    P=pfile.P;assert(P.N==8&&P.n_cycles==P.first_id+P.N&&P.first_id==4, ...
        'sar20smoke:ReferenceP','Reference is not the pinned same-P N8 case.');
    if isfield(cfg,'expected_seed'),assert(P.seed==cfg.expected_seed,'sar20smoke:Seed','Saved N8 seed differs from cfg.');end
    assert(bdIsLoaded(mdl)==0,'sar20smoke:ModelLoaded','Use the isolated Windows scheduler worker.');
    oldPath=path;pg=onCleanup(@()path(oldPath)); %#ok<NASGU>
    prepare_source(cfg.source_root);
    load_system(cfg.model_file);mg=onCleanup(@()close_model(mdl)); %#ok<NASGU>
    ws=get_param(mdl,'ModelWorkspace');ws.assignin('P',P);ws.assignin('DecodeP',P.digital);ws.assignin('TrainCaptureFile','');
    save(fullfile(cfg.output_dir,'parameters.mat'),'P','-v7.3');
    input=Simulink.SimulationInput(mdl);input=input.setVariable('P',P,'Workspace',mdl);
    input=input.setVariable('DecodeP',P.digital,'Workspace',mdl);input=input.setVariable('TrainCaptureFile','','Workspace',mdl);
    input=input.setModelParameter('ReturnWorkspaceOutputs','on','CaptureErrors','on', ...
        'StartTime','0','StopTime',sprintf('%.17g',P.stop_time_s));
    rng0=rng;t=tic;out=[];
    try,out=sim(input);catch e
        if ~isempty(out),simout=out;save(fullfile(cfg.output_dir,'simout.mat'),'simout','-v7.3');end
        write_json(fullfile(cfg.output_dir,'failure.json'),struct('id',e.identifier,'message',e.message,'simout_saved',~isempty(out)));rethrow(e);
    end
    elapsed=toc(t);simout=out;save(fullfile(cfg.output_dir,'simout.mat'),'simout','-v7.3');
    if isprop(out,'ErrorMessage')&&~isempty(out.ErrorMessage),error('sar20smoke:Simulation','%s',out.ErrorMessage);end
    assert(isequal(rng0,rng),'sar20smoke:RNG','MATLAB global RNG changed.');
    assert(strcmp(sha(cfg.model_file,cap),modelSha),'sar20smoke:ModelMutated','The old graph file changed on disk.');
    portMap=struct('semantic_name',{'Code20','CodeValid','CodeMeta'},'port',{1,2,3});
    comparison=sar20_debug_compare_native(refFile.simout,out,'full',portMap);
    assert(strcmp(comparison.status,'passed'),'sar20smoke:Mismatch','Old logs or 3 root outputs differ; see compare.json.');
    write_json(fullfile(cfg.output_dir,'compare.json'),comparison);
    pBytes=file_size(fullfile(cfg.output_dir,'parameters.mat'));sBytes=file_size(fullfile(cfg.output_dir,'simout.mat'));
    R=struct('status','passed','model_sha256',modelSha,'reference_run_dir',cfg.reference_run_dir, ...
        'N',P.N,'n_cycles',P.n_cycles,'first_id',P.first_id,'seed',P.seed, ...
        'sim_elapsed_seconds',elapsed,'global_rng_unchanged',true,'comparison',comparison, ...
        'parameters_mat_bytes',pBytes,'simout_mat_bytes',sBytes,'total_mat_bytes',pBytes+sBytes);
    write_json(fullfile(cfg.output_dir,'receipt.json'),R);
end

function close_model(mdl),if bdIsLoaded(mdl)&&strcmp(get_param(mdl,'SimulationStatus'),'stopped'),close_system(mdl,0);end,end
function prepare_source(root)
    src=fullfile(root,'current','src');config=fullfile(root,'config');files=[dir(fullfile(src,'**','*.m'));dir(fullfile(config,'*.m'));dir(fullfile(root,'SAR20.m'))];
    names=cell(numel(files),1);paths=cell(numel(files),1);for k=1:numel(files),[~,names{k}]=fileparts(files(k).name);paths{k}=char(java.io.File(fullfile(files(k).folder,files(k).name)).getCanonicalPath());end
    assert(numel(unique(lower(string(names))))==numel(names),'sar20smoke:DuplicateSource','Duplicate candidate source functions.');
    loaded=inmem('-completenames');for j=1:numel(loaded),[~,n]=fileparts(loaded{j});ix=find(strcmpi(n,names));if ~isempty(ix),assert(isscalar(ix)&&strcmpi(char(java.io.File(loaded{j}).getCanonicalPath()),paths{ix}),'sar20smoke:StaleSource','Cached function is outside candidate source.');end,end
    for k=1:numel(names),assert(isvarname(names{k}),'sar20smoke:FunctionName','Invalid MATLAB source function name.');evalin('base',['clear ' names{k}]);end
    addpath(genpath(src),config,root,'-begin');for k=1:numel(names),assert(strcmpi(which(names{k}),paths{k}),'sar20smoke:SourcePath','Source path mismatch: %s.',names{k});end
end
function n=file_size(p),d=dir(p);assert(isscalar(d)&&d.bytes<=300e6,'sar20smoke:FileCap','Missing or oversized MAT.');n=d.bytes;end
function h=sha(p,cap)
    d=dir(p);assert(isscalar(d)&&~d.isdir&&d.bytes<=cap,'sar20smoke:FileCap','Missing/oversized %s.',p);
    f=fopen(p,'rb');assert(f>=0,'sar20smoke:Read','Cannot read %s.',p);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    m=java.security.MessageDigest.getInstance('SHA-256');while ~feof(f),b=fread(f,1024*1024,'*uint8');if ~isempty(b),m.update(typecast(b(:),'int8'));end,end
    h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
function write_json(p,x),f=fopen(p,'w','n','UTF-8');assert(f>=0,'sar20smoke:Write','Cannot write %s.',p);c=onCleanup(@()fclose(f));fprintf(f,'%s\n',jsonencode(x));end
