param([Parameter(Mandatory=$true)][string]$ManifestSha)
# One actual source compatibility simulation, preserving the original MATLAB GUI.
$ErrorActionPreference='Stop'
$job='D:\Temp\SAR20DEBUG_SOURCE_SMOKE_20261105';$file=Join-Path $job 'controller_status.json'
$state=@{status='starting';simulation_run=$true};$exitCode=1
function Write-State {[IO.File]::WriteAllText($file,($state|ConvertTo-Json -Depth 7),[Text.UTF8Encoding]::new($false))}
try {
 if(Test-Path $file){throw 'Job already started.'};Write-State
 $p=@(Get-Process MATLAB)
 if($p.Count -ne 1 -or $p[0].Id -ne 27628 -or -not $p[0].Responding){throw 'Only original responsive GUI expected.'}
 $start=$p[0].StartTime.ToUniversalTime().ToString('o');$original=@{}
 foreach($n in @('SAR20_MatlabControl','SAR20_ReadDesktop')){
  if([string](Get-ScheduledTask -TaskName $n).State -ne 'Ready'){throw 'Original task busy.'}
  $original[$n]=[string](Export-ScheduledTask -TaskName $n)
 }
 if((Get-FileHash (Join-Path $job 'FILES.json') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ManifestSha){throw 'Manifest changed.'}
 $env:SAR20_DEBUG_SMOKE_MANIFEST=$ManifestSha
 $env:TEMP='D:\Temp\SAR20_WORKER_TMP\DEBUG_SOURCE_SMOKE_20261105';$env:TMP=$env:TEMP
 $env:MATLAB_PREFDIR=Join-Path $job 'worker_prefs';$env:MATLABPATH=''
 [void](New-Item -ItemType Directory -Path $env:TEMP -Force);[void](New-Item -ItemType Directory -Path $env:MATLAB_PREFDIR)
 $state.status='running';Write-State
 $child=Start-Process -FilePath 'D:\Academic\Matlab\bin\matlab.exe' -ArgumentList '-wait -softwareopengl -batch "run(''D:/Temp/SAR20DEBUG_SOURCE_SMOKE_20261105/source_smoke_host.m'')"' -WorkingDirectory $job -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput (Join-Path $job 'stdout.log') -RedirectStandardError (Join-Path $job 'stderr.log')
 $state.exit_code=$child.ExitCode;$state.launch_pid=$child.Id
 if($child.ExitCode -ne 0){throw ('Native smoke exited '+$child.ExitCode)}
 $r=Get-Content (Join-Path $job 'host_receipt.json') -Raw -Encoding UTF8|ConvertFrom-Json
 if($r.status -ne 'passed'){throw 'Native smoke failed.'}
 $state.worker_pid=$r.pid;$state.sim_elapsed_s=$r.sim_elapsed_s
 if((Get-Process -Id 27628).StartTime.ToUniversalTime().ToString('o') -ne $start){throw 'GUI changed.'}
 foreach($n in $original.Keys){if([string](Export-ScheduledTask -TaskName $n) -ne $original[$n]){throw 'Original task changed.'}}
 $state.status='passed';$state.original_tasks_unchanged=$true;$state.gui_preserved=$true;$exitCode=0
} catch {$state.status='failed';$state.error=$_.Exception.ToString()+"`n"+$_.ScriptStackTrace}
Write-State
exit $exitCode
