% SOURCE_SMOKE_HOST v1: freeze-check passive trace source, then actual old-model N8.
job='D:/Temp/SAR20DEBUG_SOURCE_SMOKE_20261105';
restoredefaultpath;addpath(job,'-begin');source_smoke_run(job);
function source_smoke_run(job)
    receipt=fullfile(job,'host_receipt.json');assert(~isfile(receipt));
    r=struct('status','starting','pid',feature('getpid'),'simulation_run',true);
    try
        mf=fullfile(job,'FILES.json');assert(strcmp(sha(mf),lower(getenv('SAR20_DEBUG_SMOKE_MANIFEST'))));
        m=jsondecode(fileread(mf));verify(job,m.files);
        cfg=struct('model_file',fullfile(job,'project','current','models','SarAdc.slx'), ...
            'source_root',fullfile(job,'project'),'reference_run_dir',fullfile(job,'reference'), ...
            'output_dir',fullfile(job,'actual'));
        result=sar20_source_smoke(cfg);verify(job,m.files);
        save(fullfile(job,'host_report.mat'),'result','-v7');
        r.status='passed';r.report_sha256=sha(fullfile(job,'host_report.mat'));
        r.sim_elapsed_s=result.sim_elapsed_seconds;r.global_rng_unchanged=result.global_rng_unchanged;
        r.scope='new passive-source legacy 2-dialog native N8; no new observer graph or UI qualification';
    catch ex
        r.status='failed';r.identifier=ex.identifier;r.error=getReport(ex,'extended','hyperlinks','off');
    end
    f=fopen(receipt,'w','n','UTF-8');assert(f>=0);fprintf(f,'%s\n',jsonencode(r));fclose(f);
    assert(strcmp(r.status,'passed'),'debugSmoke:failed','%s',jsonencode(r));
end
function verify(root,rows)
    for k=1:numel(rows)
        p=fullfile(root,rows(k).path);d=dir(p);
        assert(isscalar(d)&&~d.isdir&&d.bytes==rows(k).bytes&&d.bytes<=300e6&& ...
            strcmp(sha(p),rows(k).sha256),'debugSmoke:identity','Input differs: %s',rows(k).path);
    end
end
function h=sha(p)
    f=fopen(p,'rb');assert(f>=0);c=onCleanup(@()fclose(f)); %#ok<NASGU>
    m=java.security.MessageDigest.getInstance('SHA-256');
    while ~feof(f),b=fread(f,1024*1024,'*uint8');if ~isempty(b),m.update(b);end,end
    h=lower(reshape(dec2hex(typecast(m.digest(),'uint8'),2).',1,[]));
end
