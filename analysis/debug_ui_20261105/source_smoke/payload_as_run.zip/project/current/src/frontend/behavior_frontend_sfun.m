function behavior_frontend_sfun(block)
%BEHAVIOR_FRONTEND_SFUN Pure Level-2 frontend adapter, v1 2026-10-27.
% Dialog parameters: kind ('advance'/'commit'), normalized P.front,
% optional P.debug.observer. The exact original two-parameter model is accepted
% with observation disabled while its source/physical path remains unchanged.
% Inputs: state353, context6=[time,id,epoch,event,D1,vtop], external Driver4.
% Outputs: next state353, obs7, debugTrace1079 appended after the legacy ports.
% This block owns no retained state: no DWork, UserData, persistent or Update.
% One standard external UnitDelay owns the final state after both stages.
    setup(block);
end

function setup(block)
    numDialogPrms=dialog_parameter_count(block);
    assert(ismember(numDialogPrms,[2 3]),'behaviorFE:dialogCount', ...
        'Expected the original two or observer-enabled three dialog parameters.');
    block.NumDialogPrms=numDialogPrms;
    block.DialogPrmsTunable=repmat({'Nontunable'},1,numDialogPrms);
    kind=block.DialogPrm(1).Data;
    assert((ischar(kind)||isstring(kind))&&any(strcmp(char(kind),{'advance','commit'})), ...
        'behaviorFE:sfunKind','Frontend stage must be advance or commit.');
    p=block.DialogPrm(2).Data;
    assert(isstruct(p)&&isfield(p,'group_C_f')&&isfield(p,'schema'), ...
        'behaviorFE:sfunParameters','Pass normalized P.front returned by init.');
    if numDialogPrms==3
        debugSpec=block.DialogPrm(3).Data;
    else
        debugSpec=legacy_disabled_debug_spec();
    end
    validate_debug_spec(debugSpec);
    block.NumInputPorts=3;block.NumOutputPorts=2+double(numDialogPrms==3);
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;
    inputWidths=[353 6 4];outputWidths=[353 7 1079];
    for k=1:3
        block.InputPort(k).Dimensions=inputWidths(k);
        block.InputPort(k).DatatypeID=0;
        block.InputPort(k).Complexity='Real';
        block.InputPort(k).DirectFeedthrough=true;
    end
    for k=1:block.NumOutputPorts
        block.OutputPort(k).Dimensions=outputWidths(k);
        block.OutputPort(k).DatatypeID=0;
        block.OutputPort(k).Complexity='Real';
    end
    block.SampleTimes=[-1 0];
    block.NumContStates=0;
    block.SimStateCompliance='DefaultSimState';
    block.RegBlockMethod('Outputs',@(b)outputs(b,kind,p,debugSpec,numDialogPrms));
end

function outputs(block,kind,p,debugSpec,numDialogPrms)
    if numDialogPrms==2
        [next,obs]=behavior_frontend_stage(kind, ...
            block.InputPort(1).Data,block.InputPort(2).Data,p, ...
            block.InputPort(3).Data);
        block.OutputPort(1).Data=next;
        block.OutputPort(2).Data=obs;
        return;
    end
    [next,obs,~,trace]=behavior_frontend_stage(kind, ...
        block.InputPort(1).Data,block.InputPort(2).Data,p, ...
        block.InputPort(3).Data,debugSpec);
    block.OutputPort(1).Data=next;
    block.OutputPort(2).Data=obs;
    block.OutputPort(3).Data=trace;
end

function validate_debug_spec(spec)
    assert(isstruct(spec)&&isscalar(spec)&&all(isfield(spec,{'enabled','sample_id','Ts_s'})), ...
        'behaviorFE:debugSpec','Debug observer spec requires enabled, sample_id, Ts_s.');
    assert((islogical(spec.enabled)||isnumeric(spec.enabled))&&isscalar(spec.enabled)&& ...
        isreal(spec.enabled)&&isfinite(double(spec.enabled))&&ismember(double(spec.enabled),[0 1])&& ...
        isnumeric(spec.sample_id)&&isreal(spec.sample_id)&&isscalar(spec.sample_id)&& ...
        isfinite(spec.sample_id)&&spec.sample_id>=0&&spec.sample_id==floor(spec.sample_id)&& ...
        isnumeric(spec.Ts_s)&&isreal(spec.Ts_s)&&isscalar(spec.Ts_s)&& ...
        isfinite(spec.Ts_s)&&spec.Ts_s>0,'behaviorFE:debugSpec','Invalid debug observer selection.');
end

function n=dialog_parameter_count(block)
    parameters=get_param(block.BlockHandle,'Parameters');
    assert(ischar(parameters)||isstring(parameters),'behaviorFE:dialogText', ...
        'Cannot inspect the S-function dialog parameter list.');
    text=char(parameters);n=1;depth=0;singleQuoted=false;doubleQuoted=false;k=1;
    while k<=numel(text)
        ch=text(k);
        if ch==''''&&~doubleQuoted
            if singleQuoted&&k<numel(text)&&text(k+1)==''''
                k=k+2;continue;
            end
            singleQuoted=~singleQuoted;
        elseif ch=='"'&&~singleQuoted
            doubleQuoted=~doubleQuoted;
        elseif ~singleQuoted&&~doubleQuoted
            if ch=='(',depth=depth+1;
            elseif ch==')',depth=depth-1;
            elseif ch==','&&depth==0,n=n+1;
            end
            assert(depth>=0,'behaviorFE:dialogText','Unbalanced S-function dialog expression.');
        end
        k=k+1;
    end
    assert(depth==0&&~singleQuoted&&~doubleQuoted,'behaviorFE:dialogText', ...
        'Unbalanced S-function dialog expression.');
end

function spec=legacy_disabled_debug_spec()
    spec=struct('enabled',false,'sample_id',5,'Ts_s',200e-9);
end
