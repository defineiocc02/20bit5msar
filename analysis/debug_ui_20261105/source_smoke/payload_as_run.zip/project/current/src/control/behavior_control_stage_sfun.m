function behavior_control_stage_sfun(block)
%BEHAVIOR_CONTROL_STAGE_SFUN v1 (2026-10-27): stateless SLX adapter.
% Dialog: kind ('due'|'prepare'|'decide'), P, optional P.debug.observer; four
% direct-feedthrough inputs[51,2,7,3], outputs[51,13,19,150].
% Only the parent numeric Unit Delay retains SAR state; this block has no DWork.
    numDialogPrms=dialog_parameter_count(block);
    assert(ismember(numDialogPrms,[2 3]),'behavior:stageSfun:dialogCount', ...
        'Expected the original two or observer-enabled three dialog parameters.');
    block.NumDialogPrms=numDialogPrms;
    block.DialogPrmsTunable=repmat({'Nontunable'},1,numDialogPrms);
    kind=block.DialogPrm(1).Data;P=block.DialogPrm(2).Data;
    if numDialogPrms==3
        debugSpec=block.DialogPrm(3).Data;
    else
        debugSpec=legacy_disabled_debug_spec();
    end
    validate_debug_spec(debugSpec);
    % Inspect actual dialog P before simulation; never rebuild/rebind stale P.
    if isstruct(P)&&isfield(P,'control')&&isstruct(P.control)
        behavior_comparator_configuration(P,'check');
    end
    assert(any(strcmp(kind,{'due','prepare','decide'})), ...
        'behavior:stageSfun:kind','Unknown controller stage kind.');
    block.NumInputPorts=4;block.NumOutputPorts=3+double(numDialogPrms==3);
    block.SetPreCompPortInfoToDefaults;
    iw=[51 2 7 3];ow=[51 13 19 150];
    for k=1:4
        block.InputPort(k).Dimensions=iw(k);block.InputPort(k).DatatypeID=0;
        block.InputPort(k).Complexity='Real';block.InputPort(k).DirectFeedthrough=true;
    end
    for k=1:block.NumOutputPorts
        block.OutputPort(k).Dimensions=ow(k);block.OutputPort(k).DatatypeID=0;
        block.OutputPort(k).Complexity='Real';
    end
    block.SampleTimes=[-1 0];block.NumContStates=0;
    block.SimStateCompliance='DefaultSimState';
    block.RegBlockMethod('Outputs',@(b)outputs(b,kind,P,debugSpec,numDialogPrms));
end

function outputs(b,kind,P,debugSpec,numDialogPrms)
    if numDialogPrms==2
        [x,y,z]=behavior_control_stage(kind,double(b.InputPort(1).Data), ...
            double(b.InputPort(2).Data),double(b.InputPort(3).Data), ...
            double(b.InputPort(4).Data),P);
        b.OutputPort(1).Data=x;b.OutputPort(2).Data=y;b.OutputPort(3).Data=z;
        return;
    end
        [x,y,z,trace]=behavior_control_stage(kind,double(b.InputPort(1).Data), ...
            double(b.InputPort(2).Data),double(b.InputPort(3).Data), ...
            double(b.InputPort(4).Data),P,debugSpec);
        b.OutputPort(1).Data=x;b.OutputPort(2).Data=y;b.OutputPort(3).Data=z;
        b.OutputPort(4).Data=trace;
end

function validate_debug_spec(spec)
    assert(isstruct(spec)&&isscalar(spec)&&all(isfield(spec,{'enabled','sample_id','Ts_s'})), ...
        'behavior:stageSfun:debugSpec','Debug observer spec requires enabled, sample_id, Ts_s.');
    assert((islogical(spec.enabled)||isnumeric(spec.enabled))&&isscalar(spec.enabled)&& ...
        isreal(spec.enabled)&&isfinite(double(spec.enabled))&&ismember(double(spec.enabled),[0 1])&& ...
        isnumeric(spec.sample_id)&&isreal(spec.sample_id)&&isscalar(spec.sample_id)&& ...
        isfinite(spec.sample_id)&&spec.sample_id>=0&&spec.sample_id==floor(spec.sample_id)&& ...
        isnumeric(spec.Ts_s)&&isreal(spec.Ts_s)&&isscalar(spec.Ts_s)&& ...
        isfinite(spec.Ts_s)&&spec.Ts_s>0,'behavior:stageSfun:debugSpec','Invalid debug observer selection.');
end

function n=dialog_parameter_count(block)
    parameters=get_param(block.BlockHandle,'Parameters');
    assert(ischar(parameters)||isstring(parameters),'behavior:stageSfun:dialogText', ...
        'Cannot inspect the S-function dialog parameter list.');
    text=char(parameters);n=1;depth=0;singleQuoted=false;doubleQuoted=false;k=1;
    while k<=numel(text)
        ch=text(k);
        if ch==''''&&~doubleQuoted
            if singleQuoted&&k<numel(text)&&text(k+1)==''''
                k=k+2;continue;
            end
            singleQuoted=~singleQuoted;
        elseif ch=='"'&&~singleQuoted
            doubleQuoted=~doubleQuoted;
        elseif ~singleQuoted&&~doubleQuoted
            if ch=='(',depth=depth+1;
            elseif ch==')',depth=depth-1;
            elseif ch==','&&depth==0,n=n+1;
            end
            assert(depth>=0,'behavior:stageSfun:dialogText','Unbalanced S-function dialog expression.');
        end
        k=k+1;
    end
    assert(depth==0&&~singleQuoted&&~doubleQuoted,'behavior:stageSfun:dialogText', ...
        'Unbalanced S-function dialog expression.');
end

function spec=legacy_disabled_debug_spec()
    spec=struct('enabled',false,'sample_id',5,'Ts_s',200e-9);
end
