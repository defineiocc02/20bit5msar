function [next51,signals,signs,trace] = behavior_control_stage(kind,state51,eventvec2,obs7,cmpvec3,P,debugSpec)
%BEHAVIOR_CONTROL_STAGE v1 (2026-10-27): pure ordered SLX stage adapter.
% Inputs: state51=behavior_sar_pack ABI; event=[zero-based cycle;1-based group];
% obs[7], with sample_v=obs(1), vres_v=obs(2), other five words unconsumed;
% cmp=[native decision1;native decision2;physical vy_V].
% P.control=minimal controller parameters, P.groups=grouped calendar,
% P.Ts_s=CNV period [s], optional P.epoch=1; each run uses one fixed epoch.
% This adapter does not implement runtime global-reset/epoch transitions.
% Outputs: numeric state51; signals[13] in the order stated below; signs[19].
% No DWork/persistent/RNG/I/O. State commits only via the parent numeric delay.
    assert(any(strcmp(kind,{'due','prepare','decide'})), ...
        'behavior:stage:kind','kind must be due, prepare, or decide.');
    assert(isa(eventvec2,'double')&&numel(eventvec2)==2&&all(isfinite(eventvec2(:))), ...
        'behavior:stage:event','event must be finite double[2].');
    portsValid=isnumeric(obs7)&&isreal(obs7)&&numel(obs7)==7&&all(isfinite(obs7(:)))&& ...
        isnumeric(cmpvec3)&&isreal(cmpvec3)&&numel(cmpvec3)==3&&all(isfinite(cmpvec3(:)));
    if ~portsValid
        assert(portsValid,'behavior:stage:ports','Stage %s event %s requires finite obs=%s cmp=%s.', ...
            kind,mat2str(eventvec2(:).'),mat2str(obs7(:).'),mat2str(cmpvec3(:).'));
    end
    assert(isstruct(P)&&isscalar(P)&&all(isfield(P,{'control','groups','Ts_s'})), ...
        'behavior:stage:parameters','P requires control, groups, Ts_s.');
    trace=[];
    if nargout>=4,trace=nan(150,1);end
    hasDebugSpec=nargin==7;
    if hasDebugSpec
        assert(valid_debug_spec(debugSpec),'behavior:stage:debugSpec', ...
            'Debug observer spec requires enabled, sample_id, Ts_s.');
    end
    s=behavior_sar_unpack(state51);
    rawReady=false;
    isCnv=false;
    isRelease=false;
    dacChanged=false;
    cycle=eventvec2(1);
    groupIndex=eventvec2(2);
    if cycle==-1&&groupIndex==0
        [next51,signals,signs]=emit(s,rawReady,isCnv,isRelease,dacChanged);return;
    end
    assert(cycle==floor(cycle)&&cycle>=0&&groupIndex==floor(groupIndex)&& ...
        groupIndex>=1&&groupIndex<=numel(P.groups), ...
        'behavior:stage:indices','Invalid zero-based cycle/one-based group.');
    assert(isscalar(P.Ts_s)&&isfinite(P.Ts_s)&&P.Ts_s>0, ...
        'behavior:stage:period','Ts_s must be finite positive seconds.');
    group=P.groups(groupIndex);
    assert(isfield(group,'time_s')&&isfield(group,'events'), ...
        'behavior:stage:group','Require behavior_event_groups group fields.');
    eventTime=cycle*P.Ts_s+group.time_s;
    traceActive=nargout>=4&&hasDebugSpec&&trace_window(debugSpec,eventTime);
    slotCount=0;
    switch kind
        case 'due',accepted={'fine_feedback','d2_feedback','ta_feedback'};
        case 'prepare',accepted={'cnv','coarse_latch','fine_prepare','ra_start', ...
                'd2_prepare','d2_end','tracking_end'};
        case 'decide',accepted={'fine_decide','d2_decide','ta_compare','raw_latch','release'};
    end
    comparison=struct('sample_v',double(obs7(1)),'vres_v',double(obs7(2)), ...
        'vy_v',double(cmpvec3(3)),'decision1',double(cmpvec3(1)), ...
        'decision2',double(cmpvec3(2)),'valid',true,'late',false);
    epoch=1;if isfield(P,'epoch'),epoch=P.epoch;end
    for k=1:numel(group.events)
        event=group.events(k);
        if ~any(strcmp(event.type,accepted)),continue;end
        event.absolute_time_s=cycle*P.Ts_s+group.time_s;
        event.sample_id=cycle;event.epoch=epoch;
        % Optional comparator input perturbation: pure, keyed by the actual
        % event. Missing/disabled configuration preserves the native bits exactly.
        eventComparison=comparison;
        comparisonEvent=any(strcmp(event.type,{'fine_decide','d2_decide','ta_compare'}));
        eventCmpDiag=[];
        if traceActive&&comparisonEvent
            eventCmpDiag=unperturbed_comparator_diag(event,eventComparison);
        end
        if strcmp(kind,'decide') && isfield(P.control,'comparator') && ...
                P.control.comparator.enabled && ...
                comparisonEvent
            if traceActive
                [eventComparison,eventCmpDiag]=behavior_comparator_sample(event,comparison,P.control.comparator);
            else
                eventComparison=behavior_comparator_sample(event,comparison,P.control.comparator);
            end
        end
        [s,out]=behavior_sar_step(s,event,eventComparison,P.control);
        if traceActive
            slotCount=slotCount+1;
            assert(slotCount<=2,'behavior:stage:traceSlots', ...
                'Observer trace supports at most two accepted events per exact group.');
            if comparisonEvent
                comparisonFields=[double(eventComparison.sample_v);double(eventComparison.vres_v); ...
                    double(eventComparison.vy_v);double(eventComparison.decision1); ...
                    double(eventComparison.decision2);double(eventComparison.valid); ...
                    double(eventComparison.late);double(eventCmpDiag.effective_v); ...
                    double(eventCmpDiag.offset_v);double(eventCmpDiag.noise_v)];
                comparisonUsed=1;
            else
                comparisonFields=nan(10,1);
                comparisonUsed=0;
            end
            stageCode=stage_code(kind);
            eventCode=event_code(event.type);
            fields=[1;event.absolute_time_s;event.sample_id;event.epoch;k;stageCode; ...
                eventCode;event.index;event.bit;comparisonUsed;comparisonFields; ...
                double(out.decision);double(out.record_ready);double(out.feedback_changed); ...
                double(out.trial_changed)];
            first=(slotCount-1)*75+1;
            trace(first:first+74)=[fields;behavior_sar_pack(s)];
        end
        rawReady=rawReady||out.record_ready;
        isCnv=isCnv||strcmp(event.type,'cnv');
        isRelease=isRelease||strcmp(event.type,'release');
        dacChanged=dacChanged||out.feedback_changed||out.trial_changed;
    end
    [next51,signals,signs]=emit(s,rawReady,isCnv,isRelease,dacChanged);
end

function active=trace_window(spec,t)
    active=false;
    if ~valid_debug_spec(spec)
        error('behavior:stage:debugSpec','Invalid debug observer selection.');
    end
    if ~logical(spec.enabled),return;end
    t0=double(spec.sample_id)*double(spec.Ts_s);
    t1=(double(spec.sample_id)+1)*double(spec.Ts_s);
    active=t>=t0&&t<=t1;
end

function yes=valid_debug_spec(spec)
    yes=isstruct(spec)&&isscalar(spec)&&all(isfield(spec,{'enabled','sample_id','Ts_s'}));
    if ~yes,return;end
    yes=(islogical(spec.enabled)||isnumeric(spec.enabled))&&isscalar(spec.enabled)&& ...
        isreal(spec.enabled)&&isfinite(double(spec.enabled))&&ismember(double(spec.enabled),[0 1])&& ...
        isnumeric(spec.sample_id)&&isreal(spec.sample_id)&&isscalar(spec.sample_id)&& ...
        isfinite(spec.sample_id)&&spec.sample_id>=0&&spec.sample_id==floor(spec.sample_id)&& ...
        isnumeric(spec.Ts_s)&&isreal(spec.Ts_s)&&isscalar(spec.Ts_s)&& ...
        isfinite(spec.Ts_s)&&spec.Ts_s>0;
end

function d=empty_comparator_diag()
    d=struct('applied',false,'channel',0,'event_code',0,'input_v',NaN, ...
        'offset_v',0,'noise_v',0,'effective_v',NaN,'decision',NaN);
end

function d=unperturbed_comparator_diag(event,c)
    d=empty_comparator_diag();
    switch event.type
        case 'fine_decide'
            d.channel=1;d.event_code=1;voltage='vres_v';decision='decision1';
        case 'd2_decide'
            d.channel=2;d.event_code=2;voltage='vy_v';decision='decision2';
        case 'ta_compare'
            d.channel=2;d.event_code=3;voltage='vy_v';decision='decision2';
        otherwise
            error('behavior:stage:traceComparator','No comparator diagnostic for event %s.',event.type);
    end
    d.input_v=double(c.(voltage));d.effective_v=d.input_v;d.decision=double(c.(decision));
end

function code=stage_code(kind)
    switch kind
        case 'due',code=1;
        case 'prepare',code=2;
        case 'decide',code=3;
        otherwise,error('behavior:stage:traceStage','Unknown controller stage %s.',kind);
    end
end

function code=event_code(type)
    names={'cnv','coarse_latch','fine_prepare','fine_decide','fine_feedback', ...
        'ra_start','d2_prepare','d2_decide','d2_feedback','d2_end','ta_compare', ...
        'ta_feedback','tracking_end','raw_latch','release','reset','frame_ready'};
    code=find(strcmp(type,names),1);
    assert(~isempty(code),'behavior:stage:traceEvent','Unknown event code for %s.',type);
end

function [next51,signals,signs]=emit(s,ready,cnv,release,changed)
    next51=behavior_sar_pack(s);
    signals=[s.trial;double(s.ra_on);double(s.active);double(ready); ...
        s.d1raw;s.d2raw;s.dtraw;double(s.raw_latched&&~s.overrange); ...
        s.sample_id;s.epoch;double(cnv);double(release);double(changed)];
    signs=[s.d2_signs;s.tracking_signs];
end
