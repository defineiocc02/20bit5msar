function behavior_backend_sfun(block)
%BEHAVIOR_BACKEND_SFUN Pure Level-2 backend adapter, v1 2026-10-27.
% Dialog parameters: kind ('advance' or 'commit'), P.backend,
% optional P.debug.observer. The exact original two-parameter model is accepted
% with observation disabled while its source/physical path remains unchanged.
% Inputs: advance=[state48,time1,command26,OLD FE353]; commit keeps3 inputs.
% Outputs next48/obs8/debugTrace164. Advance port4 is fixed across enable changes.
% Off/all-zero tau never reads port4; finite enabled uses it read-only.
% Numerical definitions and reset behavior: behavior_backend_stage/step.
% Caller: current SarAdc SLX. No DWork/UserData/persistent/RNG or Update method;
% standard UnitDelay outside these stages is the sole retained state owner.
    setup(block);
end

function setup(block)
    numDialogPrms=dialog_parameter_count(block);
    assert(ismember(numDialogPrms,[2 3]),'behavior:dialogCount', ...
        'Expected the original two or observer-enabled three dialog parameters.');
    block.NumDialogPrms=numDialogPrms;
    block.DialogPrmsTunable=repmat({'Nontunable'},1,numDialogPrms);
    kind=block.DialogPrm(1).Data;
    p=block.DialogPrm(2).Data;
    if numDialogPrms==3
        debugSpec=block.DialogPrm(3).Data;
    else
        debugSpec=legacy_disabled_debug_spec();
    end
    validate_debug_spec(debugSpec);
    assert((ischar(kind)||isstring(kind))&&any(strcmp(char(kind),{'advance','commit'})), ...
        'behavior:sfunKind','Backend stage must be advance or commit.');
    % Validate every ON configuration at native setup, including dt=0/sigma=0.
    % OFF follows the legacy setup unchanged.
    if isstruct(p)&&isscalar(p)&&isfield(p,'ni')&&isstruct(p.ni)&& ...
            isfield(p.ni,'ra_noise')&&isscalar(p.ni.ra_noise)&& ...
            isreal(p.ni.ra_noise)&&isequal(double(p.ni.ra_noise),1)
        behavior_ra_noise_validate_backend(p);
    end
    isAdvance=strcmp(char(kind),'advance');
    block.NumInputPorts=3+double(isAdvance);
    block.NumOutputPorts=2+double(numDialogPrms==3);
    block.SetPreCompInpPortInfoToDynamic;
    block.SetPreCompOutPortInfoToDynamic;
    inputWidths=[48 1 26];if isAdvance,inputWidths(4)=353;end
    outputWidths=[48 8 164];
    for k=1:numel(inputWidths)
        block.InputPort(k).Dimensions=inputWidths(k);
        block.InputPort(k).DatatypeID=0;
        block.InputPort(k).Complexity='Real';
        block.InputPort(k).DirectFeedthrough=true;
    end
    for k=1:block.NumOutputPorts
        block.OutputPort(k).Dimensions=outputWidths(k);
        block.OutputPort(k).DatatypeID=0;
        block.OutputPort(k).Complexity='Real';
    end
    block.SampleTimes=[-1 0];
    block.NumContStates=0;block.SimStateCompliance='DefaultSimState';
    block.RegBlockMethod('Outputs',@(b)outputs(b,kind,p,debugSpec,numDialogPrms));
end

function outputs(block,kind,p,debugSpec,numDialogPrms)
    finiteCoupling=strcmp(char(kind),'advance')&&isfield(p,'dac_coupling')&& ...
        p.dac_coupling.enabled&&any(p.dac_coupling.tau_dac_s>0);
    if numDialogPrms==2
        if finiteCoupling
            [next,obs]=behavior_backend_stage(kind, ...
                block.InputPort(1).Data,block.InputPort(2).Data, ...
                block.InputPort(3).Data,p,block.InputPort(4).Data);
        else
            % Original two-dialog Sfun path, including the unused advance
            % NEWcmd expression, remains unchanged until diagnostics are added.
            [next,obs]=behavior_backend_stage(kind, ...
                block.InputPort(1).Data,block.InputPort(2).Data, ...
                block.InputPort(3).Data,p);
        end
        block.OutputPort(1).Data=next;
        block.OutputPort(2).Data=obs;
        return;
    end
    if strcmp(char(kind),'advance')
        if finiteCoupling
            [next,obs,trace]=behavior_backend_stage(kind, ...
                block.InputPort(1).Data,block.InputPort(2).Data, ...
                [],p,block.InputPort(4).Data,debugSpec);
        else
            % Advance does not inspect NEWcmd. Preserve its physical OFF path
            % and avoid reading the unconsumed command port for diagnostics.
            [next,obs,trace]=behavior_backend_stage(kind, ...
                block.InputPort(1).Data,block.InputPort(2).Data, ...
                [],p,[],debugSpec);
        end
    else
        % Commit consumes NEWcmd; it has no OLD-FE forcing input.
        [next,obs,trace]=behavior_backend_stage(kind, ...
            block.InputPort(1).Data,block.InputPort(2).Data, ...
            block.InputPort(3).Data,p,[],debugSpec);
    end
    block.OutputPort(1).Data=next;
    block.OutputPort(2).Data=obs;
    block.OutputPort(3).Data=trace;
end

function validate_debug_spec(spec)
    assert(isstruct(spec)&&isscalar(spec)&&all(isfield(spec,{'enabled','sample_id','Ts_s'})), ...
        'behavior:stageDebugSpec','Debug observer spec requires enabled, sample_id, Ts_s.');
    assert((islogical(spec.enabled)||isnumeric(spec.enabled))&&isscalar(spec.enabled)&& ...
        isreal(spec.enabled)&&isfinite(double(spec.enabled))&&ismember(double(spec.enabled),[0 1])&& ...
        isnumeric(spec.sample_id)&&isreal(spec.sample_id)&&isscalar(spec.sample_id)&& ...
        isfinite(spec.sample_id)&&spec.sample_id>=0&&spec.sample_id==floor(spec.sample_id)&& ...
        isnumeric(spec.Ts_s)&&isreal(spec.Ts_s)&&isscalar(spec.Ts_s)&& ...
        isfinite(spec.Ts_s)&&spec.Ts_s>0,'behavior:stageDebugSpec','Invalid debug observer selection.');
end

function n=dialog_parameter_count(block)
    parameters=get_param(block.BlockHandle,'Parameters');
    assert(ischar(parameters)||isstring(parameters),'behavior:dialogText', ...
        'Cannot inspect the S-function dialog parameter list.');
    text=char(parameters);n=1;depth=0;singleQuoted=false;doubleQuoted=false;k=1;
    while k<=numel(text)
        ch=text(k);
        if ch==''''&&~doubleQuoted
            if singleQuoted&&k<numel(text)&&text(k+1)==''''
                k=k+2;continue;
            end
            singleQuoted=~singleQuoted;
        elseif ch=='"'&&~singleQuoted
            doubleQuoted=~doubleQuoted;
        elseif ~singleQuoted&&~doubleQuoted
            if ch=='(',depth=depth+1;
            elseif ch==')',depth=depth-1;
            elseif ch==','&&depth==0,n=n+1;
            end
            assert(depth>=0,'behavior:dialogText','Unbalanced S-function dialog expression.');
        end
        k=k+1;
    end
    assert(depth==0&&~singleQuoted&&~doubleQuoted,'behavior:dialogText', ...
        'Unbalanced S-function dialog expression.');
end

function spec=legacy_disabled_debug_spec()
    spec=struct('enabled',false,'sample_id',5,'Ts_s',200e-9);
end
