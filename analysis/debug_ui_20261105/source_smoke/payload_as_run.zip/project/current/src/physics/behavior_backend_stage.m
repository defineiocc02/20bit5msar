function [stateNext,obs,trace] = behavior_backend_stage(kind,state,eventTime,command,p,oldFrontend,debugSpec)
%BEHAVIOR_BACKEND_STAGE Pure backend Advance/Commit adapter, v1 2026-10-27.
% Caller: behavior_backend_sfun or direct event runner. No retained memory/RNG.
% Inputs: kind='advance'/'commit'; state48 per behavior_backend_pack; absolute
% eventTime [s]; command26=[Qres C; Ctop F; D2(12); TA(7); RAon; AZon; reset; sample_id; epoch].
% Output stateNext48 and obs8=[VX V; VY V; Vtop V; target V; NG 1; tau s;
% AZ input-differential V; CT reset-baseline VX V]. All voltage obs differential.
% Advance ignores NEW command and advances only the command in the incoming
% state. Commit requires eventTime==state.time_s and applies NEW command at dt0.
% Both blocks represent successive transforms of ONE state, not two memories.
% Candidate optional oldFrontend353 is read ONLY in finite-DAC active advance;
% off/all-zero tau retains the original backend_step call/operations.
    assert((ischar(kind)&&isrow(kind))||(isstring(kind)&&isscalar(kind)), ...
        'behavior:stageKind','Stage kind must be advance or commit.');
    kind=char(kind);
    assert(isnumeric(eventTime)&&isreal(eventTime)&&isscalar(eventTime)&&isfinite(eventTime), ...
        'behavior:stageTime','Event time must be finite scalar seconds.');
    s=behavior_backend_unpack(state);
    trace=[];
    if nargout>=3,trace=nan(164,1);end
    hasDebugSpec=nargin==7;
    if hasDebugSpec
        assert(valid_debug_spec(debugSpec),'behavior:stageDebugSpec', ...
            'Debug observer spec requires enabled, sample_id, Ts_s.');
    end
    traceActive=nargout>=3&&hasDebugSpec&&trace_window(debugSpec,double(eventTime));
    if traceActive
        oldState=double(state(:));
        oldS=s;
    end
    switch kind
        case 'advance'
            dt=double(eventTime)-s.time_s;
            assert(dt>=0,'behavior:stageTimeOrder','Advance time precedes retained state time.');
            finiteCoupling=isfield(p,'dac_coupling')&&p.dac_coupling.enabled&& ...
                any(p.dac_coupling.tau_dac_s>0);
            % The original caller and arithmetic remain exact for noise OFF.
            % ON receives the ORIGINAL eventTime word, never s.time_s+dt.
            noiseInterval=isfield(p,'ni')&&isstruct(p.ni)&& ...
                isfield(p.ni,'ra_noise')&&isscalar(p.ni.ra_noise)&& ...
                isreal(p.ni.ra_noise)&&isequal(double(p.ni.ra_noise),1)&& ...
                s.command.ra_on&&~s.command.reset&&dt>0;
            if finiteCoupling&&s.command.ra_on&&~s.command.reset
                assert(nargin==6||(nargin==7&&hasDebugSpec),'behaviorDAC:oldFrontRequired', ...
                    'Finite coupling requires the actual OLD FE state input.');
                forcing=behavior_dac_forcing_from_frontend(oldFrontend,s,eventTime,p);
                if noiseInterval
                    % Hash the original binary64 endpoint, never t0+dt.
                    if traceActive&&dt>0
                        [s,y,advancedState]=behavior_backend_step(s,s.command,dt,p,forcing,double(eventTime));
                    else
                        [s,y]=behavior_backend_step(s,s.command,dt,p,forcing,double(eventTime));
                    end
                else
                    % Preserve the legacy OFF/zero-duration call and arithmetic.
                    if traceActive&&dt>0
                        [s,y,advancedState]=behavior_backend_step(s,s.command,dt,p,forcing);
                    else
                        [s,y]=behavior_backend_step(s,s.command,dt,p,forcing);
                    end
                end
            else
                if noiseInterval
                    if traceActive&&dt>0
                        [s,y,advancedState]=behavior_backend_step(s,s.command,dt,p,[],double(eventTime));
                    else
                        [s,y]=behavior_backend_step(s,s.command,dt,p,[],double(eventTime));
                    end
                else
                    if traceActive&&dt>0
                        [s,y,advancedState]=behavior_backend_step(s,s.command,dt,p);
                    else
                        [s,y]=behavior_backend_step(s,s.command,dt,p);
                    end
                end
            end
        case 'commit'
            assert(double(eventTime)==s.time_s,'behavior:stageCommitTime', ...
                'Commit requires the state already advanced to the exact event time.');
            c=unpack_command(command);
            [s,y]=behavior_backend_step(s,c,0,p);
        otherwise
            error('behavior:stageKind','Unknown backend stage %s.',kind);
    end
    % Align to the exact event-time word rather than trusting (t0+(t-t0))
    % to reproduce it for all positive/negative simulator start-time values.
    s.time_s=double(eventTime);
    stateNext=behavior_backend_pack(s);
    obs=[y.vx_v;y.vy_v;y.vtop_v;y.target_v;y.noise_gain;y.tau_ra_s; ...
        s.az_input_half_v(1)-s.az_input_half_v(2);s.ct_reset_vx_v];
    assert(isequal(size(obs),[8 1])&&all(isfinite(obs)), ...
        'behavior:stageObservation','Backend observation must contain eight finite doubles.');
    if traceActive
        if strcmp(kind,'advance')&&dt>0
            advanced=behavior_backend_pack(advancedState);
            advancedValid=1;
        else
            advanced=nan(48,1);
            advancedValid=0;
        end
        ypred=y.predicted;
        predictedObs=[ypred.vx_v;ypred.vy_v;ypred.vtop_v;ypred.target_v; ...
            ypred.noise_gain;ypred.tau_ra_s; ...
            ypred.az_input_half_v(1)-ypred.az_input_half_v(2);oldS.ct_reset_vx_v];
        trace=[1;double(eventTime);1+double(strcmp(kind,'commit'));advancedValid; ...
            oldState;advanced;stateNext;predictedObs;obs];
    end
end

function active=trace_window(spec,t)
    active=false;
    if ~valid_debug_spec(spec)
        error('behavior:stageDebugSpec','Invalid debug observer selection.');
    end
    if ~logical(spec.enabled),return;end
    t0=double(spec.sample_id)*double(spec.Ts_s);
    t1=(double(spec.sample_id)+1)*double(spec.Ts_s);
    active=t>=t0&&t<=t1;
end

function yes=valid_debug_spec(spec)
    yes=isstruct(spec)&&isscalar(spec)&&all(isfield(spec,{'enabled','sample_id','Ts_s'}));
    if ~yes,return;end
    yes=(islogical(spec.enabled)||isnumeric(spec.enabled))&&isscalar(spec.enabled)&& ...
        isreal(spec.enabled)&&isfinite(double(spec.enabled))&&ismember(double(spec.enabled),[0 1])&& ...
        isnumeric(spec.sample_id)&&isreal(spec.sample_id)&&isscalar(spec.sample_id)&& ...
        isfinite(spec.sample_id)&&spec.sample_id>=0&&spec.sample_id==floor(spec.sample_id)&& ...
        isnumeric(spec.Ts_s)&&isreal(spec.Ts_s)&&isscalar(spec.Ts_s)&& ...
        isfinite(spec.Ts_s)&&spec.Ts_s>0;
end

function c=unpack_command(v)
    assert(isa(v,'double')&&isreal(v)&&isvector(v)&&numel(v)==26&&all(isfinite(v(:))), ...
        'behavior:stageCommand','Backend command must contain 26 finite doubles.');
    v=v(:);
    assert(all(ismember(v(3:21),[-1 0 1]))&&all(ismember(v(22:24),[0 1])), ...
        'behavior:stageCommandSigns','Invalid D2/TA signs or command booleans.');
    assert(v(25)>=-1&&v(25)==floor(v(25))&&v(26)>=0&&v(26)==floor(v(26)), ...
        'behavior:stageCommandTags','Require integer sample_id>=-1 and epoch>=0.');
    c=struct('qres_c',v(1),'ctop_f',v(2),'d2_signs',v(3:14), ...
        'ta_signs',v(15:21),'ra_on',logical(v(22)), ...
        'az_on',logical(v(23)),'reset',logical(v(24)), ...
        'sample_id',v(25),'epoch',v(26));
end
