/* Version 1. Stateless sparse products for the existing PoolCt equations.
 * [hi,lo] = pool_sparse_mex(A,x,0): original ordered Dot2 row accumulation.
 * y = pool_sparse_mex(A,x,1): original globally levelled pairwise tree.
 * [rHi,rLo,gHi,gLo] = pool_sparse_mex(C,G,nextHi,nextLo,previousHi,
 *     previousLo,f,h,2): fused pool_mex_be/be_residual_pair, fixed 1540 nodes.
 * Mode2 C/G: real sparse double 1540-by-1540. State hi/lo [V] and f:
 * full real double 1540-vectors; h: finite positive double scalar [s].
 * Its four outputs are 1540-by-1: r [C] on physical rows / [V*s] on pole
 * rows, and g [A] on physical rows / [V] on pole rows, each as hi/lo pairs.
 * Mode2 is stateless and retains every original Dot2/DD operation; no solver
 * or score is moved. Mode0/1 A: real sparse double; x: real double vector.
 * Units of mode0/1 outputs are those of A*x. No time advancement or physical/
 * RNG state commit, configuration mutation or file access. Build without
 * fast-math, reassociation or floating-point contraction. Golden-bit tests
 * are required before this kernel can replace the MATLAB implementation.
 */
#include "mex.h"
#include <stddef.h>
#include <string.h>
#pragma STDC FP_CONTRACT OFF
static void two_sum(double a,double b,double *s,double *e) {
    volatile double v=a+b;
    volatile double bv=v-a, av=v-bv;
    volatile double br=b-bv, ar=a-av;
    *s=v; *e=ar+br;
}
static void split(double a,double *hi,double *lo) {
    volatile double t=134217729.0*a;
    volatile double d=t-a, h=t-d;
    *hi=h; *lo=a-h;
}
static void product_dot2(double a,double b,double *p,double *e) {
    double ah,al,bh,bl; volatile double v=a*b;
    split(a,&ah,&al);split(b,&bh,&bl);
    volatile double hh=ah*bh, lh=al*bh, hl=ah*bl, ll=al*bl;
    volatile double d0=v-hh,d1=d0-lh,d2=d1-hl;
    *p=v;*e=ll-d2;
}
static void product_tree(double a,double b,double *p,double *e) {
    double ah,al,bh,bl; volatile double v=a*b;
    split(a,&ah,&al);split(b,&bh,&bl);
    volatile double hh=ah*bh,hl=ah*bl,lh=al*bh,ll=al*bl;
    volatile double d0=hh-v,d1=d0+hl,d2=d1+lh;
    *p=v;*e=d2+ll;
}
/* The original mode0 loop, shared verbatim with mode2. Each row visits
 * terms in increasing column order; hi/lo must start as positive zero. */
static void ordered_dot2(const mxArray *A,const double *x,double *hi,double *lo) {
    const mwSize n=mxGetN(A);
    const mwIndex *ir=mxGetIr(A),*jc=mxGetJc(A);
    const double *a=mxGetDoubles(A);
    for(mwIndex c=0;c<n;++c) for(mwIndex k=jc[c];k<jc[c+1];++k) {
        const mwIndex r=ir[k];double ph,pl,p,q;
        product_dot2(a[k],x[c],&ph,&pl);two_sum(hi[r],ph,&p,&q);
        volatile double tail=q+pl;volatile double s=lo[r]+tail;
        hi[r]=p;lo[r]=s;
    }
}
static void dd_add(double ah,double al,double bh,double bl,double *hi,double *lo) {
    double s1,e1,s2,e2,s3,e3,s4,e4,s5,e5,s6,e6,sh,sl;
    two_sum(ah,bh,&s1,&e1);
    two_sum(al,bl,&s2,&e2);
    two_sum(e1,s2,&s3,&e3);
    two_sum(s1,s3,&s4,&e4);
    two_sum(e2,e3,&s5,&e5);
    two_sum(e4,s5,&s6,&e6);
    two_sum(s4,s6,&sh,&sl);
    volatile double t0=sl+e5,t1=t0+e6;
    two_sum(sh,t1,hi,lo);
}
static int sparse_real_square(const mxArray *a,mwSize n) {
    return mxIsSparse(a)&&mxIsDouble(a)&&!mxIsComplex(a)&&
        mxGetNumberOfDimensions(a)==2&&mxGetM(a)==n&&mxGetN(a)==n;
}
static int full_real_vector(const mxArray *a,mwSize n) {
    return !mxIsSparse(a)&&mxIsDouble(a)&&!mxIsComplex(a)&&
        mxGetNumberOfDimensions(a)==2&&(mxGetM(a)==1||mxGetN(a)==1)&&
        mxGetNumberOfElements(a)==n;
}
static void require_finite(const double *x,mwSize n) {
    for(mwIndex k=0;k<n;++k) if(!mxIsFinite(x[k]))
        mexErrMsgIdAndTxt("poolSparse:residualFinite","Mode2 inputs must be finite real binary64 values.");
}
static void residual_mode2(int nlhs,mxArray **plhs,const mxArray **prhs) {
    const mwSize n=1540;
    if(nlhs!=4||!sparse_real_square(prhs[0],n)||!sparse_real_square(prhs[1],n))
        mexErrMsgIdAndTxt("poolSparse:residualMatrix","Mode2 requires four outputs and real sparse double 1540-by-1540 C/G.");
    for(int k=2;k<=6;++k) if(!full_real_vector(prhs[k],n))
        mexErrMsgIdAndTxt("poolSparse:residualShape","Mode2 state and forcing inputs must be full real double 1540-vectors.");
    if(!full_real_vector(prhs[7],1)||!mxIsFinite(mxGetScalar(prhs[7]))||mxGetScalar(prhs[7])<=0.0)
        mexErrMsgIdAndTxt("poolSparse:residualStep","Mode2 h must be a finite positive real double scalar.");
    for(int k=0;k<2;++k) {
        const mwIndex *jc=mxGetJc(prhs[k]);
        require_finite(mxGetDoubles(prhs[k]),jc[n]);
    }
    for(int k=2;k<=6;++k) require_finite(mxGetDoubles(prhs[k]),n);
    const double *nextHi=mxGetDoubles(prhs[2]),*nextLo=mxGetDoubles(prhs[3]);
    const double *previousHi=mxGetDoubles(prhs[4]),*previousLo=mxGetDoubles(prhs[5]);
    const double *f=mxGetDoubles(prhs[6]);const double h=mxGetScalar(prhs[7]);
    for(int k=0;k<4;++k) plhs[k]=mxCreateDoubleMatrix(n,1,mxREAL);
    double *rHi=mxGetDoubles(plhs[0]),*rLo=mxGetDoubles(plhs[1]);
    double *gHi=mxGetDoubles(plhs[2]),*gLo=mxGetDoubles(plhs[3]);
    double *scratch=(double*)mxCalloc(8*n,sizeof(double));
    double *deltaHi=scratch,*deltaLo=deltaHi+n,*cHi=deltaLo+n,*cLo=cHi+n;
    double *clHi=cLo+n,*clLo=clHi+n,*glHi=clLo+n,*glLo=glHi+n;
    for(mwIndex i=0;i<n;++i) {
        two_sum(nextHi[i],-previousHi[i],&deltaHi[i],&deltaLo[i]);
        dd_add(deltaHi[i],deltaLo[i],nextLo[i],-previousLo[i],&deltaHi[i],&deltaLo[i]);
    }
    ordered_dot2(prhs[0],deltaHi,cHi,cLo);
    ordered_dot2(prhs[0],deltaLo,clHi,clLo);
    for(mwIndex i=0;i<n;++i) dd_add(cHi[i],cLo[i],clHi[i],clLo[i],&cHi[i],&cLo[i]);
    ordered_dot2(prhs[1],nextHi,gHi,gLo);
    ordered_dot2(prhs[1],nextLo,glHi,glLo);
    for(mwIndex i=0;i<n;++i) {
        double p1,s1,p2,s2,hGHi,hGLo,hfHi,hfLo,p=0.0,s=0.0,q;
        dd_add(gHi[i],gLo[i],glHi[i],glLo[i],&gHi[i],&gLo[i]);
        product_dot2(h,gHi[i],&p1,&s1);
        product_dot2(h,gLo[i],&p2,&s2);
        dd_add(p1,s1,p2,s2,&hGHi,&hGLo);
        product_dot2(h,f[i],&hfHi,&hfLo);
        const double components[6]={cHi[i],cLo[i],hGHi,hGLo,-hfHi,-hfLo};
        for(int k=0;k<6;++k) {
            two_sum(p,components[k],&p,&q);
            volatile double t=s+q;s=t;
        }
        two_sum(p,s,&rHi[i],&rLo[i]);
    }
    mxFree(scratch);
}
void mexFunction(int nlhs,mxArray **plhs,int nrhs,const mxArray **prhs) {
    /* New arity is dispatched separately, leaving the mode0/1 guards intact.
     * The mode2 tag itself must be a full real double scalar exactly 2. */
    if(nrhs==9) {
        if(!full_real_vector(prhs[8],1)||mxGetScalar(prhs[8])!=2.0)
            mexErrMsgIdAndTxt("poolSparse:residualMode","The nine-input residual signature requires mode2.");
        residual_mode2(nlhs,plhs,prhs);return;
    }
    if(nrhs!=3 || !mxIsSparse(prhs[0]) || !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
       !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || mxIsSparse(prhs[1]))
        mexErrMsgIdAndTxt("poolSparse:input","Require sparse real-double A, full real-double x, and mode 0/1.");
    const mwSize m=mxGetM(prhs[0]),n=mxGetN(prhs[0]);
    if(mxGetNumberOfElements(prhs[1])!=n || mxGetNumberOfElements(prhs[2])!=1)
        mexErrMsgIdAndTxt("poolSparse:shape","Incompatible vector/mode dimensions.");
    const double mode=mxGetScalar(prhs[2]);
    if((mode!=0.0 && mode!=1.0) || (mode==0.0 && nlhs!=2) || (mode==1.0 && nlhs!=1))
        mexErrMsgIdAndTxt("poolSparse:mode","Mode0 requires two outputs; mode1 requires one.");
    const mwIndex *ir=mxGetIr(prhs[0]),*jc=mxGetJc(prhs[0]);
    const double *a=mxGetDoubles(prhs[0]),*x=mxGetDoubles(prhs[1]);
    plhs[0]=mxCreateDoubleMatrix(m,1,mxREAL);double *hi=mxGetDoubles(plhs[0]);
    if(mode==0.0) {
        plhs[1]=mxCreateDoubleMatrix(m,1,mxREAL);double *lo=mxGetDoubles(plhs[1]);
        /* CSC traversal visits each row's terms in increasing column order,
         * exactly as sortrows([row,column],[1,2]) in the MATLAB reference. */
        ordered_dot2(prhs[0],x,hi,lo);
    } else {
        const mwSize nnz=jc[n];
        mwSize *count=(mwSize*)mxCalloc(m,sizeof(mwSize));
        mwIndex *start=(mwIndex*)mxCalloc(m+1,sizeof(mwIndex));
        mwIndex *next=(mwIndex*)mxCalloc(m,sizeof(mwIndex));
        double *ph=(double*)mxCalloc(nnz?nnz:1,sizeof(double));
        double *pl=(double*)mxCalloc(nnz?nnz:1,sizeof(double));
        for(mwIndex k=0;k<nnz;++k)++count[ir[k]];
        mwSize maximum=0;for(mwIndex r=0;r<m;++r){start[r+1]=start[r]+count[r];next[r]=start[r];if(count[r]>maximum)maximum=count[r];}
        for(mwIndex c=0;c<n;++c)for(mwIndex k=jc[c];k<jc[c+1];++k){mwIndex at=next[ir[k]]++;product_tree(a[k],x[c],&ph[at],&pl[at]);}
        /* Keep the global number of levels, including zero-padded renormalizing
         * operations on rows that have already reduced to one term. */
        for(mwSize levelSize=maximum;levelSize>1;levelSize=(levelSize+1)/2) {
            for(mwIndex r=0;r<m;++r) {
                const mwSize length=count[r],remaining=(length+1)/2;const mwIndex base=start[r];
                for(mwIndex j=0;j<remaining;++j) {
                    mwIndex left=base+2*j,right=left+1;double rh=0.0,rl=0.0,s,e;
                    if(2*j+1<length){rh=ph[right];rl=pl[right];}
                    two_sum(ph[left],rh,&s,&e);
                    volatile double t0=e+pl[left],t1=t0+rl;
                    two_sum(s,t1,&ph[base+j],&pl[base+j]);
                }
                count[r]=remaining;
            }
        }
        for(mwIndex r=0;r<m;++r)if(count[r])hi[r]=ph[start[r]]+pl[start[r]];
        mxFree(count);mxFree(start);mxFree(next);mxFree(ph);mxFree(pl);
    }
}
