function [nextHi,nextLo,resHi,resLo,gHi,gLo,info] = pool_mex_be( ...
        previousHi,previousLo,C,G,f,free,known,knownValue,h,chargeGoal,poleGoal,physicalMask)
%POOL_BE_STEP One pure DD backward-Euler step for the fixed 1540-node pool model.
% Version: twofold-BE/r1 (2026-10-24). Called only by pool_analog_predict.
% State is represented by binary64 pairs v=hi+lo; this adds no circuit unknown.
% Original equations and units are unchanged:
%   R = C*((vnext_hi+vnext_lo)-(vprev_hi+vprev_lo))
%       + h*(G*(vnext_hi+vnext_lo)-f).
% Physical rows use C [F], G [S], f [A], R [C], and chargeGoal [C].
% The two retained pole rows use C [s], G [1], f [V], R [V*s], and
% poleGoal [V*s]. h remains the original binary64 step in seconds.
% The initial solve forms M=C/h+G in binary64, row-scales its free block,
% and factors it once. Up to four residual corrections solve M*delta=-R/h;
% each correction is accumulated with TwoSum into the high/low state pair.
% Known voltages remain exactly knownValue with a zero low word and zero update.
% No RNG, persistent state, reset, time change, parameter change, or ledger write.
% If four corrections do not meet the supplied step goals, the best actual
% DD state is returned with info.converged=false; the caller must apply its
% unchanged physical half/full budget gates.
% Private candidate: a one-entry exact-Mff cache reuses only row scaling and LU.
% No forcing, state, RNG, residual, or correction data is cached.

    n=size(C,1);
    assert(n==1540&&isequal(size(C),[n n])&&isequal(size(G),[n n])&& ...
        issparse(C)&&issparse(G), ...
        'poolBE:matrix','C and G must be sparse 1540-by-1540 matrices.');
    assert(isa(previousHi,'double')&&isa(previousLo,'double')&& ...
        isa(f,'double')&&isa(knownValue,'double')&& ...
        numel(previousHi)==n&&numel(previousLo)==n&&numel(f)==n, ...
        'poolBE:shape','State and forcing vectors must be double 1540-vectors.');
    previousHi=previousHi(:); previousLo=previousLo(:); f=f(:);
    knownValue=knownValue(:); free=free(:); known=known(:);
    physicalMask=physicalMask(:);
    assert(numel(physicalMask)==n&&numel(knownValue)==numel(known)&& ...
        (islogical(physicalMask)|| ...
        (isnumeric(physicalMask)&&isreal(physicalMask)&&all(isfinite(physicalMask(:)))&& ...
        all(physicalMask(:)==0|physicalMask(:)==1))), ...
        'poolBE:shape','Known values and the physical-row mask have invalid dimensions.');
    physicalMask=logical(physicalMask);
    assert(isreal(previousHi)&&isreal(previousLo)&&isreal(f)&&isreal(knownValue)&& ...
        all(isfinite(previousHi))&&all(isfinite(previousLo))&&all(isfinite(f))&& ...
        all(isfinite(knownValue))&&isreal(C)&&isreal(G)&& ...
        all(isfinite(nonzeros(C)))&&all(isfinite(nonzeros(G))), ...
        'poolBE:finite','BE inputs must be finite real binary64 values.');
    assert(isscalar(h)&&isreal(h)&&isfinite(h)&&h>0&& ...
        isscalar(chargeGoal)&&isfinite(chargeGoal)&&chargeGoal>0&& ...
        isscalar(poleGoal)&&isfinite(poleGoal)&&poleGoal>0, ...
        'poolBE:step','h and both step goals must be positive finite scalars.');
    assert(isnumeric(free)&&isreal(free)&&all(isfinite(free))&& ...
        isnumeric(known)&&isreal(known)&&all(isfinite(known))&& ...
        all(free>=1&free<=n&free==floor(free))&& ...
        all(known>=1&known<=n&known==floor(known))&& ...
        numel(unique(free))==numel(free)&&numel(unique(known))==numel(known)&& ...
        isempty(intersect(free,known))&&numel(free)+numel(known)==n, ...
        'poolBE:index','free and known must be a disjoint partition of all nodes.');
    assert(all(previousLo(known)==0), ...
        'poolBE:knownLow','Known state coordinates must enter with a zero low word.');

    physicalFree=free(physicalMask(free));
    poleFree=free(~physicalMask(free));
    assert(~isempty(physicalFree)&&numel(poleFree)==2, ...
        'poolBE:rowKinds','The fixed pool state requires physical free rows and exactly two pole rows.');
    M=C/h+G;
    assert(all(isfinite(nonzeros(M))), ...
        'poolBE:matrixFinite','C/h+G is nonfinite in binary64.');
    Mff=M(free,free);
    [factor,rowScale]=cached_factorization(Mff,free,known,h);

    % The initial estimate solves the ordinary high-word system. Carry old low
    % words through a separate RHS solve so C*previousLo is not RN-folded away.
    rhsHi=C(free,:)*previousHi/h+f(free)-M(free,known)*knownValue;
    rhsLo=C(free,:)*previousLo/h;
    initialHi=factor\(rowScale.*rhsHi);
    initialLo=factor\(rowScale.*rhsLo);
    nextHi=previousHi; nextLo=zeros(n,1);
    nextHi(known)=knownValue; nextLo(known)=0;
    [freeHi,freeLo]=dd_add(zeros(numel(free),1),zeros(numel(free),1),initialHi,initialLo);
    nextHi(free)=freeHi; nextLo(free)=freeLo;

    scoreHistory=nan(5,2); bestScore=[Inf Inf];
    bestHi=nextHi; bestLo=nextLo; bestResHi=zeros(n,1); bestResLo=zeros(n,1);
    bestGHi=zeros(n,1); bestGLo=zeros(n,1); selectedRefinement=0;
    correctionsApplied=0; evaluated=0; converged=false;
    for refinement=0:4
        [rHi,rLo,currentGHi,currentGLo]=be_residual_pair( ...
            nextHi,nextLo,previousHi,previousLo,C,G,f,h);
        assert(all(isfinite(nextHi))&&all(isfinite(nextLo))&& ...
            all(isfinite(rHi))&&all(isfinite(rLo))&& ...
            all(isfinite(currentGHi))&&all(isfinite(currentGLo)), ...
            'poolBE:residual','A DD BE state or residual is nonfinite.');
        score=dd_residual_score(rHi,rLo,physicalFree,poleFree,chargeGoal,poleGoal);
        assert(all(isfinite(score)), ...
            'poolBE:score','The normalized DD residual score is nonfinite.');
        scoreHistory(refinement+1,:)=score; evaluated=refinement+1;
        if score_better(score,bestScore)
            bestScore=score; bestHi=nextHi; bestLo=nextLo;
            bestResHi=rHi; bestResLo=rLo; bestGHi=currentGHi; bestGLo=currentGLo;
            selectedRefinement=refinement;
        end
        if score(1)<=1
            converged=true;
            break;
        end
        if refinement==4
            break;
        end

        % Solve both residual words with the same binary64 factorization; add
        % them as a pair instead of folding Rlo into Rhi before the solve.
        correctionRhsHi=-rHi(free)/h;
        correctionRhsLo=-rLo(free)/h;
        deltaHi=factor\(rowScale.*correctionRhsHi);
        deltaLo=factor\(rowScale.*correctionRhsLo);
        assert(all(isfinite(deltaHi))&&all(isfinite(deltaLo)), ...
            'poolBE:correction','A DD residual correction is nonfinite.');
        [freeHi,freeLo]=dd_add(nextHi(free),nextLo(free),deltaHi,deltaLo);
        nextHi(free)=freeHi; nextLo(free)=freeLo;
        nextHi(known)=knownValue; nextLo(known)=0;
        correctionsApplied=correctionsApplied+1;
    end

    nextHi=bestHi; nextLo=bestLo;
    resHi=bestResHi; resLo=bestResLo; gHi=bestGHi; gLo=bestGLo;
    info=struct('converged',converged,'status','iteration_limit_best_returned', ...
        'refinements_evaluated',evaluated,'corrections_applied',correctionsApplied, ...
        'selected_refinement',selectedRefinement,'best_score',bestScore, ...
        'score_history',scoreHistory);
    if converged
        info.status='step_goals_met';
    end
end

function [factor,rowScale]=cached_factorization(Mff,free,known,h)
% One bounded entry; hit only on identical sparse operator/index/time-step bits.
    persistent cacheValid cacheMatrixClass cacheRows cacheColumns cacheValueBits ...
        cacheFree cacheKnown cacheHClass cacheHBits cacheFactor cacheRowScale
    if isempty(cacheValid),cacheValid=false;end
    [rows,columns,values]=find(Mff);
    valueBits=typecast(values(:),'uint64'); hBits=typecast(double(h),'uint64');
    matrixClass=class(Mff);hClass=class(h);
    hit=cacheValid&&strcmp(cacheMatrixClass,matrixClass)&&strcmp(cacheHClass,hClass)&& ...
        isequal(cacheRows,rows(:))&&isequal(cacheColumns,columns(:))&& ...
        isequal(cacheValueBits,valueBits)&&isequal(cacheFree,free(:))&& ...
        isequal(cacheKnown,known(:))&&isequal(cacheHBits,hBits);
    if hit
        factor=cacheFactor;rowScale=cacheRowScale;return
    end

    rowMagnitude=full(max(abs(Mff),[],2));
    assert(all(isfinite(rowMagnitude)&rowMagnitude>0), ...
        'poolBE:rowScale','The free BE matrix has an invalid row scale.');
    rowScale=1./rowMagnitude;
    assert(all(isfinite(rowScale)), ...
        'poolBE:rowScale','The free BE row scales are nonfinite.');
    factor=decomposition(spdiags(rowScale,0,numel(free),numel(free))*Mff,'lu');

    cacheMatrixClass=matrixClass;cacheRows=rows(:);cacheColumns=columns(:);cacheValueBits=valueBits;
    cacheFree=free(:);cacheKnown=known(:);cacheHClass=hClass;cacheHBits=hBits;
    cacheFactor=factor;cacheRowScale=rowScale;cacheValid=true;
end

function [rHi,rLo,gHi,gLo]=be_residual_pair(nextHi,nextLo,previousHi,previousLo,C,G,f,h)
    % Candidate stateless mode2 keeps the original ordered Dot2/DD residual.
    % Solver, score, state ABI and finite-result checks remain in this caller.
    [rHi,rLo,gHi,gLo]=pool_sparse_mex(C,G,nextHi,nextLo, ...
        previousHi,previousLo,f,h,2);
end

function score=dd_residual_score(rHi,rLo,physicalFree,poleFree,chargeGoal,poleGoal)
    residualAbs=abs(rHi)+abs(rLo);
    charge=residualAbs(physicalFree)/chargeGoal;
    pole=residualAbs(poleFree)/poleGoal;
    score=[max([charge(:);pole(:)]) sum(charge)+sum(pole)];
end

function yes=score_better(candidate,current)
    yes=candidate(1)<current(1)||(candidate(1)==current(1)&&candidate(2)<current(2));
end

function [sumHi,sumLo]=dd_add(aHi,aLo,bHi,bLo)
    [s1,e1]=two_sum(aHi,bHi);
    [s2,e2]=two_sum(aLo,bLo);
    [s3,e3]=two_sum(e1,s2);
    [s4,e4]=two_sum(s1,s3);
    [s5,e5]=two_sum(e2,e3);
    [s6,e6]=two_sum(e4,s5);
    [sumHi,sumLo]=two_sum(s4,s6);
    sumLo=sumLo+e5+e6;
    [sumHi,sumLo]=two_sum(sumHi,sumLo);
end

function [p,s]=dot2_sparse_rows(A,x)
% Stateless compiled version of the original ordered compensated dot product.
    [p,s]=pool_sparse_mex(A,x,0);
end

function [p,s]=dot2_sum_components(varargin)
    assert(~isempty(varargin),'poolBE:dot2Sum','At least one pair component is required.');
    p=zeros(size(varargin{1})); s=p;
    for k=1:numel(varargin)
        [p,q]=two_sum(p,varargin{k});
        s=s+q;
    end
end

function [p,s]=scalar_pair_product(a,bHi,bLo)
    [p1,s1]=two_product(a,bHi);
    [p2,s2]=two_product(a,bLo);
    [p,s]=dd_add(p1,s1,p2,s2);
end

function [p,e]=two_product(a,b)
    p=a.*b;
    splitter=134217729;
    splitA=splitter.*a; highA=splitA-(splitA-a); lowA=a-highA;
    splitB=splitter.*b; highB=splitB-(splitB-b); lowB=b-highB;
    e=lowA.*lowB-(((p-highA.*highB)-lowA.*highB)-highA.*lowB);
end

function [s,e]=two_sum(a,b)
    s=a+b; bVirtual=s-a; aVirtual=s-bVirtual;
    bRoundoff=b-bVirtual; aRoundoff=a-aVirtual; e=aRoundoff+bRoundoff;
end
