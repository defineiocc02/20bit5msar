function [report,cases]=verify_residual_mode2(captureDir,mode2,dot2,rowIndices)
% Host-only arithmetic gate on closed physics node arrays; NEVER a BE replay.
% mode2(C,G,nextHi,nextLo,previousHi,previousLo,f,h) -> four double vectors.
% dot2(A,x) -> [hi,lo], bound to the unchanged original mode-0 MEX.
% Root must bind distinct original/candidate MEX basenames before calling.
% This function does not alter paths, models, configuration, or input files.
% Save report AND cases to a new MAT file outside the closed capture directory.
    assert(isa(mode2,'function_handle')&&isa(dot2,'function_handle'), ...
        'SAR20Mode2:handles','Supply independently bound candidate and original Dot2 handles.');
    rngBefore=rng;
    rawPath=fullfile(captureDir,'raw.mat');
    raw=load(rawPath,'simOut','PoolAnalogCfg','PoolAnalogPrototype','PoolAnalogStateLayout');
    assert(isempty(raw.simOut.ErrorMessage),'SAR20Mode2:capture','Capture has a simulation error.');
    cfg=raw.PoolAnalogCfg;prototype=raw.PoolAnalogPrototype;layout=raw.PoolAnalogStateLayout;
    assert(layout.width==5181&&strcmp(layout.version,'pool-analog-state/v4'), ...
        'SAR20Mode2:layout','Require actual schema-4 physics state.');
    oldSeries=raw.simOut.get('pool_analog_old_state');
    nextSeries=raw.simOut.get('pool_analog_pred_state');
    assert(same_bits(oldSeries.Time,nextSeries.Time),'SAR20Mode2:time','Owner axes differ.');
    oldData=state_matrix(oldSeries);nextData=state_matrix(nextSeries);
    assert(isequal(size(oldData),size(nextData)),'SAR20Mode2:shape','State shapes differ.');
    % The saved time leaf identifies genuine positive owner prediction intervals.
    timeLeaf=find(arrayfun(@(x)isequal(x.path,{'time_s'}),layout.leaves));
    assert(isscalar(timeLeaf),'SAR20Mode2:layout','Missing unique time_s leaf.');
    timeColumn=layout.leaves(timeLeaf).offset;
    eligible=find(nextData(:,timeColumn)>oldData(:,timeColumn));
    assert(~isempty(eligible),'SAR20Mode2:rows','No positive owner interval.');
    if nargin<4||isempty(rowIndices)
        rowIndices=eligible(unique(round(linspace(1,numel(eligible),min(12,numel(eligible))))));
    end
    assert(isnumeric(rowIndices)&&isvector(rowIndices)&&all(ismember(rowIndices,eligible)), ...
        'SAR20Mode2:rows','Rows must be actual positive owner intervals.');
    rowIndices=unique(rowIndices(:));
    cases=cell(numel(rowIndices),1);results=cell(numel(rowIndices),1);
    for k=1:numel(rowIndices)
        row=rowIndices(k);
        old=restore_state(oldData(row,:).',prototype,layout);
        next=restore_state(nextData(row,:).',prototype,layout);
        % Saved mode/source are real capture values. No claim that this sys/f
        % equals every unlogged midpoint/event/AZ source in the owner interval.
        sys=pool_mex_matrix(old.mode,old.src,cfg);
        previousHi=old.voltage_v;previousLo=node_low(old);
        nextHi=next.voltage_v;nextLo=node_low(next);
        h=min(cfg.max_step_s,next.time_s-old.time_s);
        expected=cell(1,4);actual=cell(1,4);
        [expected{:}]=reference_residual_pair(nextHi,nextLo,previousHi,previousLo, ...
            sys.C,sys.G,sys.f,h,dot2);
        [actual{:}]=mode2(sys.C,sys.G,nextHi,nextLo,previousHi,previousLo,sys.f,h);
        equal=cellfun(@same_bits,expected,actual);
        cases{k}=struct('row',row,'logged_time_s',oldSeries.Time(row), ...
            'old_time_s',old.time_s,'next_time_s',next.time_s,'h',h, ...
            'C',sys.C,'G',sys.G,'f',sys.f,'previousHi',previousHi, ...
            'previousLo',previousLo,'nextHi',nextHi,'nextLo',nextLo, ...
            'reference_outputs',{expected},'candidate_outputs',{actual});
        results{k}=struct('row',row,'rHi_bits_equal',equal(1),'rLo_bits_equal',equal(2), ...
            'gHi_bits_equal',equal(3),'gLo_bits_equal',equal(4),'all_equal',all(equal), ...
            'h',h,'nnz_C',nnz(sys.C),'nnz_G',nnz(sys.G));
    end
    results=vertcat(results{:});
    report=struct('schema','sar20-residual-mode2-owner-array-arithmetic/v1', ...
        'status','arithmetic_bitwise_fail','capture_dir',captureDir,'raw_file',rawPath, ...
        'matlab_version',version,'pid',feature('getpid'),'mode2_handle',func2str(mode2), ...
        'reference_dot2_handle',func2str(dot2),'matrix_function',which('pool_mex_matrix'), ...
        'reference_formula_source_sha256','f9de903debb070796681bfb729b3e7ade8fd35ec2b9e4ad4c5b3d93356cdb083', ...
        'rows',results,'global_rng_unchanged',isequaln(rngBefore,rng), ...
        'actual_BE_substep_replayed',false,'full_59_logger_gate_still_required',true, ...
        'scope',['Original residual formula versus mode2 on captured owner endpoint node arrays ' ...
        'and a system built from saved old mode/source/cfg. h is capped by saved max_step_s. ' ...
        'Owner endpoints may span many BE steps/events/projections; these are not logged BE substeps.']);
    if all([results.all_equal])&&report.global_rng_unchanged
        report.status='arithmetic_bitwise_pass_not_full_state_acceptance';
    end
end

function data=state_matrix(series)
    assert(isa(series,'timeseries')&&isa(series.Data,'double')&&isreal(series.Data), ...
        'SAR20Mode2:series','Require real-double physics timeseries.');
    data=squeeze(series.Data);if size(data,1)~=numel(series.Time),data=data.';end
    assert(ismatrix(data)&&size(data,1)==numel(series.Time)&&size(data,2)==5181, ...
        'SAR20Mode2:width','Require all 5181 state words.');
end

function state=restore_state(packed,state,layout)
% Saved layout paths/shapes/classes only; no owner/model initialization.
    for k=1:numel(layout.leaves)
        leaf=layout.leaves(k);value=packed(leaf.offset:leaf.offset+leaf.width-1);
        value=reshape(cast(value,leaf.class),leaf.shape);
        accessor=repmat(struct('type','.','subs',''),1,numel(leaf.path));
        for j=1:numel(leaf.path),accessor(j).subs=leaf.path{j};end
        state=subsasgn(state,accessor,value);
    end
end

function low=node_low(state)
    assert(all(state.voltage_low_v([750 1520])==0),'SAR20Mode2:poleLow','Duplicate pole low words.');
    low=state.voltage_low_v;low([750;1520])=state.pole_z_lo_v;
end

function yes=same_bits(a,b)
    yes=strcmp(class(a),class(b))&&isequal(size(a),size(b));
    if ~yes,return;end
    assert(isa(a,'double')&&isreal(a)&&isreal(b)&&~issparse(a)&&~issparse(b), ...
        'SAR20Mode2:output','Arithmetic outputs must be full real double.');
    yes=isequal(typecast(a(:),'uint64'),typecast(b(:),'uint64'));
end

function [rHi,rLo,gHi,gLo]=reference_residual_pair(nextHi,nextLo,previousHi,previousLo,C,G,f,h,dot2)
    [deltaHi,deltaLo]=two_sum(nextHi,-previousHi);
    [deltaHi,deltaLo]=dd_add(deltaHi,deltaLo,nextLo,-previousLo);
    [cHi,cLo]=dot2(C,deltaHi);
    [clHi,clLo]=dot2(C,deltaLo);
    [cHi,cLo]=dd_add(cHi,cLo,clHi,clLo);
    [gHi,gLo]=dot2(G,nextHi);
    [glHi,glLo]=dot2(G,nextLo);
    [gHi,gLo]=dd_add(gHi,gLo,glHi,glLo);
    [hGHi,hGLo]=scalar_pair_product(h,gHi,gLo);
    [hfHi,hfLo]=two_product(h,f);
    [rHi,rLo]=dot2_sum_components(cHi,cLo,hGHi,hGLo,-hfHi,-hfLo);
    [rHi,rLo]=two_sum(rHi,rLo);
end

function [sumHi,sumLo]=dd_add(aHi,aLo,bHi,bLo)
    [s1,e1]=two_sum(aHi,bHi);
    [s2,e2]=two_sum(aLo,bLo);
    [s3,e3]=two_sum(e1,s2);
    [s4,e4]=two_sum(s1,s3);
    [s5,e5]=two_sum(e2,e3);
    [s6,e6]=two_sum(e4,s5);
    [sumHi,sumLo]=two_sum(s4,s6);
    sumLo=sumLo+e5+e6;
    [sumHi,sumLo]=two_sum(sumHi,sumLo);
end

function [p,s]=dot2_sum_components(varargin)
    assert(~isempty(varargin),'poolBE:dot2Sum','At least one pair component is required.');
    p=zeros(size(varargin{1})); s=p;
    for k=1:numel(varargin)
        [p,q]=two_sum(p,varargin{k});
        s=s+q;
    end
end

function [p,s]=scalar_pair_product(a,bHi,bLo)
    [p1,s1]=two_product(a,bHi);
    [p2,s2]=two_product(a,bLo);
    [p,s]=dd_add(p1,s1,p2,s2);
end

function [p,e]=two_product(a,b)
    p=a.*b;
    splitter=134217729;
    splitA=splitter.*a; highA=splitA-(splitA-a); lowA=a-highA;
    splitB=splitter.*b; highB=splitB-(splitB-b); lowB=b-highB;
    e=lowA.*lowB-(((p-highA.*highB)-lowA.*highB)-highA.*lowB);
end

function [s,e]=two_sum(a,b)
    s=a+b; bVirtual=s-a; aVirtual=s-bVirtual;
    bRoundoff=b-bVirtual; aRoundoff=a-aVirtual; e=aRoundoff+bRoundoff;
end
