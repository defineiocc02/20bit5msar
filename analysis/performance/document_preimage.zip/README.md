# SAR20 工程入口

此目录只提供一个工程说明和一个 MATLAB 入口：`README.md`、`SAR20.m`。当前唯一代码树位于 `current/`，必须是完整的 270 路径依赖树；唯一当前模型为 `current/runtime_work/pool_pole_precision_trial_r1/models/PoolCt.slx`。不从 `preparation/`、版本包或历史模型中选择替代项。

## 启动与运行

从本目录调用 MATLAB：

```matlab
SAR20                 % 打开唯一当前 PoolCt
SAR20('check')        % 冷开目标模型并编译；不仿真、不保存
SAR20('run')          % 调用原 f2_ktc_dither_workspace_entry direct_run，真实仿真
SAR20('apply')        % 将 config/parameters.json 显式应用到当前模型并刷新绑定
```

当前保存配置是 **M8、UGB=1.2 GHz、BE内部子步62.5 ps、N=8**，用于数值步长核验，尚未签收收敛或速度。模型SHA为`fadd1138f9703b8a9a998be61687aebac1527f9441542a9becee59276b454741`；两端模型/参数/工作区快照已同步，实际运行平台仍是Windows。修改 `config/parameters.json` 后必须先执行 `SAR20('apply')`，再执行 `SAR20('run')`。直接在 Simulink 点 **Run** 只使用当前 SLX 已保存的 Model Workspace，不读取 JSON，也不应用工厂参数。`open/check`检查模型和绑定，不表示修改后的JSON已应用；`run`会拒绝未应用的参数。

`SAR20.m` 从自身位置解析工程根目录，并显式使用 `current/`、`config/parameters.json` 和 `dependencies/toolkit/`。结果写到 `runs/<run-id>/`；`evidence/` 是原始证据归档，不加入 MATLAB path。当前运行平台为 Windows MATLAB R2024a；Mac 保存同一份源和证据，尚未验证 macOS MEX。

| JSON 字段 | 作用和单位 |
|---|---|
| `record_length` | 有效输出码数，默认8；256点才能作初步动态验证。 |
| `tracking_count` | 8为8比较/7更新；1是显式M1对照。 |
| `AChanges` | 保持空对象表示沿用保存配置。例如 `{"UGB_hz":1200000000}`；UGB单位Hz，A0无量纲，max_step_s单位s。 |
| `source_override` | 默认空数组，沿用已保存输入；不是在每次run中自动重新生成激励。 |
| `capture_mode` | 默认compact；完整物理日志用physics，应限制记录长度。 |
| `debug_sample_ids` | 只读观察样本，不改变物理过程。 |

当前保存的设计假设为A0=10000、UGB=1.2GHz；它们不是论文披露参数。采样率5MS/s、全局步长250ps、owner间隔1.25ns、12次D2及M8的8/7时序保持原值。`max_step_s`只改变内部BE积分，不能拿它与全局采样/调度步长混用。不要直接改`current/`中的源或模型绕过绑定。

## 当前验证与历史性能

| 分支/证据 | 已确认内容 | 不能据此声称 |
|---|---|---|
| 当前源码：M8/1.2GHz/62.5ps/N8 | 实际8码已生成，sim208.1844647s；逐ID原码、LVDS和12D2/8TA/7更新已核。见`analysis/time_step/REPORT.md`。 | 仍有步长敏感性，未验收full analog state/charge；不是提速或频谱达标结果。 |
| 当前源码：M8/1.2GHz/250ps/N8基准 | 实际sim103.3587453s；与旧250ps记录的54路data/time、tout、整个selected逐位相同，无容差。见`analysis/time_step/anchor_comparison.json`。 | 只闭合compact可观察范围，不等于全隐藏模拟状态核验或N256性能。 |
| 清理里程碑：M8/600 MHz/N8 | 实际迁移8码及54路日志逐位匹配，证据`evidence/RELOCATION_BITWISE.json`。 | 这是历史配置，当前JSON已改为上述数值核验配置。 |
| 历史 R91：M8/1.2 GHz/N256 | SNDR 99.608385 dB、SNR 99.994041 dB（未达到100dB），单次sim1484.1254161s；原始数据和报告在证据归档中。 | 不是当前R4的性能，不能作为提速或完整复现证明。 |

速度问题仍未解决；减小BE子步使本次8码耗时增加。完整复现、当前源码N256动态结果、时间步验收、静态INL/DNL、完整非理想扫描和校准仍未完成。模型内个别F0/OFF/5178旧显示标签尚待修改，真实配置为F2/kTC/DEM/dither开启、v4/5181。当前8码不能承接旧NativeCt固定A/B、冻结校准的101.91dB。

读本轮真实结果从[步长核验报告](analysis/time_step/REPORT.md)开始。`analysis/p0_data/`只存真实MAT数据；Python仅用于读数与画图，不生成ADC码，也不代替Simulink数字重构。尚未初始化的全新副本应先保留其随包参数运行`SAR20`；不要先改JSON再初始化绑定。

## 结果与旧文档

旧候选、旧版本入口和重复包已移出开发树并删除。原始raw、as-run和关键回执集中在`evidence/records.zip`；其中`ORIGINAL_FILES.json`记录原路径、SHA及去重内容位置。当前开发不需要从该归档挑模型。论文与产品定义在`docs/`；统一spec是设计输入，历史执行状态不代表本次运行。
